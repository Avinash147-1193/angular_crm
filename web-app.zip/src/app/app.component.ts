import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Event, NavigationEnd} from '@angular/router';
import {GeneralServices} from './common/general-services';
import {ServerAuthService} from './common/server-auth';
import {environment} from '../environments/environment';
import LogRocket from 'logrocket';
import {Intercom} from 'ng-intercom';

if (environment.logRocket) {
  if (localStorage.getItem('currentUser')) {
    LogRocket.init('whlkmc/fitdayio-webapp');
    const email = JSON.parse(localStorage.getItem('currentUser'))['email'];
    LogRocket.identify(email);
  }
}

// tslint:disable-next-line: component-selector
@Component({moduleId: module.id, selector: 'web-app', templateUrl: 'app.component.html'})
export class AppComponent {
  include_center: any = null;
  currentUser: any = null;
  loader: any = true;

  constructor(
        private route: ActivatedRoute,
        private router: Router,
        private generalFunctions: GeneralServices,
        private http: ServerAuthService,
        public intercom: Intercom) {

        if (localStorage.getItem('currentUser')) {
            this.include_center = this.generalFunctions.includeCenter();

        if (JSON.parse(localStorage.getItem('currentUser')).roles) {
            const id = JSON.parse(localStorage.getItem('currentUser')).client_id;
            this.http.getData('staff/' + id + this.include_center).subscribe(success => {
            success = success;
            const rolePermissions = JSON.stringify(success.data.roles);
            const currentUser = JSON.parse(localStorage.getItem('currentUser'));
            this.currentUser = currentUser;
            currentUser.intercomSecret = success.data.secret;
            currentUser.roles = JSON.stringify(success.data.roles);
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
            });
        }

        if (environment.production) {
            this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                // tslint:disable-next-line: use-life-cycle-interface
                (<any>window).ga('set', 'page', event.urlAfterRedirects); (<any>window).ga('send', 'pageview');
            }
        });
    } }
 }



                ngOnInit() {
                    if (this.currentUser == undefined) {} else {
                        this.intercom.boot({
                        app_id: environment.intercomAppId,
                        email: this.currentUser.email,
                        user_hash: this.currentUser.intercomSecret,
                        widget: {
                            activator: '#intercom'
                        }
                        });
                    }
                }
            }
