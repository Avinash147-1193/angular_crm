import {Routes, RouterModule} from '@angular/router';

/* AUTHENTICATION FILE FOR CRM ACCESS */

import {AuthGuard, DestroyPOS, AccessGuard, DestroyIntercom, DestroyBilling} from './common/guard-service';
import {RefreshComponent} from './components/refresh';

/* DIFFERENT ROUTE FILES */
// import { DashboardComponent } from "./components/main/content/dashboard";


/* POS SECTION */

import {MainComponent} from './components/main';
import {PosComponent} from './components/main/content/pos';
import {PosHistoryComponent} from './components/main/content/pos-history';
import {SettingsComponent} from './components/main/content/settings';

import {MembershipsComponent} from './components/main/content/services';
import {MembershipServicesComponent} from './components/main/content/services/membership-services/membership-services.component';
import {MembershipPlansTableComponent} from './components/main/content/services/membership-plans/membership-plans-table/membership-plans-table.component';
import {CreateMembershipPlansComponent} from './components/main/content/services/membership-plans/create-membership-plans/create-membership-plans.component';
import {ClassScheduleListComponent} from './components/main/content/services/class-schedule/class-schedule-list/class-schedule-list.component';
import {ClassScheduleDetailsComponent} from './components/main/content/services/class-schedule/class-schedule-details/class-schedule-details.component';
import {ClassPackListComponent} from './components/main/content/services/class-packs/class-pack-list/class-pack-list.component';
import {CreateClassPacksComponent} from './components/main/content/services/class-packs/create-class-packs/create-class-packs.component';
import {PersonalTrainingListComponent} from './components/main/content/services/personal-training/personal-training-list/personal-training-list.component';
import {PersonalTrainingDetailsComponent} from './components/main/content/services/personal-training/personal-training-details/personal-training-details.component';
import {AvailabilityComponent} from './components/main/content/services/availability/availability.component';
import {FacilityTableComponent} from './components/main/content/services/facility/facility-table/facility-table.component';

import {DiscountsComponent} from './components/main/content/discounts';
import {DiscountsTableComponent} from './components/main/content/discounts/discounts-table';
import {DiscountCreateComponent} from './components/main/content/discounts/discount-create';

import {CustomersComponent} from './components/main/content/customers';
import {CustomersAddComponent} from './components/main/content/customers/customers-add';
import {CustomersTableComponent} from './components/main/content/customers/customers-table';
import {FormlinkRequestsComponent} from './components/main/content/customers/formlink-requests';

import {ProspectsComponent} from './components/main/content/prospects';
import {ProspectsTableComponent} from './components/main/content/prospects/prospects-table';
import {ProspectsAddComponent} from './components/main/content/prospects/prospects-add';
import {ProspectsProfileComponent} from './components/main/content/prospects/prospects-profile';



import {StaffComponent} from './components/main/content/staff';
import {StaffTableComponent} from './components/main/content/staff/staff-table';
import {StaffAddComponent} from './components/main/content/staff/staff-add';
import {StaffProfileComponent} from './components/main/content/staff/staff-profile';

import {ReportsComponent} from './components/main/content/reports';
import {ReportsHomeComponent} from './components/main/content/reports/reports-home';
import {ReportsSaleComponent} from './components/main/content/reports/reports-sale';
import {ReportsCustomerComponent} from './components/main/content/reports/reports-customer'





import {EventsCalendarComponent} from './components/main/content/events-calendar/events-calendar.component';

import {AutoMessagesComponent} from './components/main/content/auto-messages/auto-messages.component';
import {AutoMessagesListComponent} from './components/main/content/auto-messages/auto-messages-list/auto-messages-list.component';
import {AutoMessagesDetailsComponent} from './components/main/content/auto-messages/auto-messages-details/auto-messages-details.component';

import {TasksListComponent} from './components/main/content/tasks/tasks-list/tasks-list.component';
import {TasksDetailsComponent} from './components/main/content/tasks/tasks-details/tasks-details.component';

import {OnboardingComponent} from './components/onboarding/onboarding.component';
import {DashboardNewComponent} from './components/main/content/dashboard-new/dashboard-new.component';
import {BusinessSettingsComponent} from './components/main/content/settings/business-settings/business-settings.component';
import {PaymentSettingsComponent} from './components/main/content/settings/payment-settings/payment-settings.component';
import {TaxSettingsComponent} from './components/main/content/settings/tax-settings/tax-settings.component';
import {BookingSettingsComponent} from './components/main/content/settings/booking-settings/booking-settings.component';
import {WaiverSettingsComponent} from './components/main/content/settings/waiver-settings/waiver-settings.component';
import {WebstoreSettingsComponent} from './components/main/content/settings/webstore-settings/webstore-settings.component';
import {CustomerAppSettingsComponent} from './components/main/content/settings/customer-app-settings/customer-app-settings.component';
import {CustomerSettingsComponent} from './components/main/content/settings/customer-settings/customer-settings.component';
import {LeadSettingsComponent} from './components/main/content/settings/lead-settings/lead-settings.component';
import {MobileAccessComponent} from './components/mobile-access/mobile-access.component';
import {GetStartedComponent} from './components/main/content/get-started/get-started.component';

import {HelpComponent} from './components/main/content/help/help.component';
import {LocationComponent} from './components/location/location.component';
import {RegionComponent} from './components/region/region.component';
import {MarketingComponent} from './components/main/content/marketing';
import {ReferralComponent} from './components/main/content/marketing/referral';
import {ReferralSetupComponent} from './components/main/content/marketing/referral-setup';
import {AppsComponent} from './components/main/content/apps/apps.component'
import { CustomersDetailComponent } from './components/main/content/customers/customers-detail';
import { DetailedReportsComponent } from './components/main/content/reports/detailed-reports/detailed-reports.component';

import { BillingComponent } from './components/main/content/billing/billing.component';
import { AdyenTestComponent } from './adyen-test/adyen-test.component';
import { CourseCreateComponent } from './components/main/content/services/courses/course-create/course-create.component';
import { CourseListComponent } from './components/main/content/services/courses/course-list/course-list.component';
import { VodListComponent } from './components/main/content/vod/vod-list/vod-list.component';
import { VodUploadComponent } from './components/main/content/vod/vod-upload/vod-upload.component';
import { VodCreatePlaylistComponent } from './components/main/content/vod/vod-create-playlist/vod-create-playlist.component';
import { VodCreateVideoComponent } from './components/main/content/vod/vod-create-video/vod-create-video.component';
import { CommunicationsEmailComponent } from './components/main/content/settings/communications-email/communications-email.component';
import { GiftCardTableComponent } from './components/main/content/services/gift-card/gift-card-table/gift-card-table.component';
import { CreateGiftCardComponent } from './components/main/content/services/gift-card/create-gift-card/create-gift-card.component';

/* COMPONENT LINKED TO ROUTES */

const authRoutes: Routes = [
  {
    path: 'onboarding',
    component: OnboardingComponent,
    canActivate: [AccessGuard]
  }, {
    path: 'location',
    component: LocationComponent,
    canActivate: [AccessGuard]
  }, {
    path: 'region',
    component: RegionComponent,
    canActivate: [AccessGuard]
  }, {
    path: 'mobile',
    component: MobileAccessComponent,
    canActivate: [AccessGuard]
  }, {
    path: '',
    component: MainComponent,
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
          path:'adyen-test',
        component: AdyenTestComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'dashboard',
        component: DashboardNewComponent,
        canActivate: [AccessGuard]
      },
      {
        path : 'apps',
        component : AppsComponent,
        canActivate : [AccessGuard]
      },
      {
        path : 'billing',
        component : BillingComponent,
        canActivate : [AccessGuard],
        // canDeactivate: [DestroyBilling]
      },
      {
        path: 'pos',
        component: PosComponent,
        canDeactivate: [DestroyPOS],
        canActivate: [AccessGuard]
      },
      // { path: 'pos', component: PosComponent, canActivate: [AccessGuard] },
      {
        path: 'pos/history',
        component: PosHistoryComponent
      },
      {
        path: 'pos/:id',
        component: PosComponent,
        canDeactivate: [DestroyPOS],
        canActivate: [AccessGuard]
      },
      // { path: 'pos/:id', component: PosComponent, canActivate: [AccessGuard] },
      {
        path: 'services',
        component: MembershipsComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: MembershipServicesComponent,
            canActivate: [AccessGuard]
          },

            {
                path: 'gift-cards',
                component: GiftCardTableComponent,
                canActivate: [AccessGuard]
              }, {
                path: 'gift-cards/create',
                component: CreateGiftCardComponent,
                canActivate: [AccessGuard]
              }, {
                path: 'gift-cards/:id',
                component: CreateGiftCardComponent,
                canActivate: [AccessGuard]
              },


          {
            path: 'plans',
            component: MembershipPlansTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'plans/create',
            component: CreateMembershipPlansComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'plans/:id',
            component: CreateMembershipPlansComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'class-schedules',
            component: ClassScheduleListComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'class-schedules/create',
            component: ClassScheduleDetailsComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'class-schedules/:id',
            component: ClassScheduleDetailsComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'class-packs',
            component: ClassPackListComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'create-packs',
            component: CreateClassPacksComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'class-packs/:id',
            component: CreateClassPacksComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'personal-training',
            component: PersonalTrainingListComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'personal-training/create',
            component: PersonalTrainingDetailsComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'personal-training/:id',
            component: PersonalTrainingDetailsComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'facility',
            component: FacilityTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'availability/:id',
            component: AvailabilityComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'availability/:id/update',
            component: AvailabilityComponent,
            canActivate: [AccessGuard]
          },
          {
            path: 'courses',
            loadChildren: () => import('app/components/main/content/services/courses/courses.module').then(m => m.CoursesModule),
            canActivate: [AccessGuard],
            children: [
            {
                path: 'create',
                component: CourseCreateComponent,
                canActivate: [AccessGuard]
            },
            {
                path: ':id/update',
                component: CourseCreateComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'list',
                component: CourseListComponent,
                canActivate: [AccessGuard]
            }
            ]
          },
          {
            path: 'vod',
            loadChildren: () => import('app/components/main/content/vod/vod.module').then(m => m.VodModule),
            canActivate: [AccessGuard],
            children: [
            {
                path: 'upload',
                component: VodUploadComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'list',
                component: VodListComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'playlist/create',
                component: VodCreatePlaylistComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'playlist/:id',
                component: VodCreatePlaylistComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'video/create',
                component: VodCreateVideoComponent,
                canActivate: [AccessGuard]
            },
            {
                path: 'video/:id',
                component: VodCreateVideoComponent,
                canActivate: [AccessGuard]
            }
            ]
          }
        ]
      },
      {
        path: '',
        component: MarketingComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: 'referral',
            component: ReferralComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'referral/setup',
            component: ReferralSetupComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'referral/edit',
            component: ReferralSetupComponent,
            canActivate: [AccessGuard]
          }
        ]
      },
      {
        path: 'calendar',
        component: EventsCalendarComponent,
        canActivate: [AccessGuard]
        // children: [
        //   {
        //     path: "calendar",
        //     component: EventsCalendarComponent,
        //     canActivate: [AccessGuard]
        //   }
        // ]
      },
      {
        path: 'tasks',
        component: TasksListComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'tasks/create',
        component: TasksDetailsComponent,
        canActivate: [AccessGuard]
      },
      // { path: '', component: TasksDetailsComponent, outlet: 'taskPopup', canActivate: [AccessGuard] },
      {
        path: 'tasks/:id',
        component: TasksDetailsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'auto-messages',
        component: AutoMessagesListComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'auto-messages/create',
        component: AutoMessagesDetailsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'auto-messages/:id',
        component: AutoMessagesDetailsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'discounts',
        component: DiscountsComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: DiscountsTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'create',
            component: DiscountCreateComponent,
            canActivate: [AccessGuard]
          }, {
            path: ':id',
            component: DiscountCreateComponent,
            canActivate: [AccessGuard]
          }
        ]
      },
      {
        path: 'customers',
        component: CustomersComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: CustomersTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'add',
            component: CustomersAddComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'formlink',
            component: FormlinkRequestsComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'edit/:id',
            component: CustomersAddComponent,
            canActivate: [AccessGuard]
          }, {
              path : ':id',
              component : CustomersDetailComponent,
              canActivate : [AccessGuard]
          }
        ]
      },
      {
        path: 'reports',
        component: ReportsComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: ReportsHomeComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'reports-sale',
            component: ReportsSaleComponent,
            canActivate: [AccessGuard]
          },
          {
            path: 'detailed-reports',
            component: DetailedReportsComponent,
            canActivate: [AccessGuard]
          },
          {
            path: 'reports-customer',
            component: ReportsCustomerComponent,
            canActivate: [AccessGuard]
          },


        ]
      },


      {
        path: 'prospects',
        component: ProspectsComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: ProspectsTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'add',
            component: ProspectsAddComponent,
            canActivate: [AccessGuard]
          }, {
            path: ':id',
            component: ProspectsProfileComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'edit/:id',
            component: ProspectsAddComponent,
            canActivate: [AccessGuard]
          }
        ]
      }, {
        path: 'staff',
        component: StaffComponent,
        canActivate: [AccessGuard],
        children: [
          {
            path: '',
            component: StaffTableComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'add',
            component: StaffAddComponent,
            canActivate: [AccessGuard]
          }, {
            path: ':id',
            component: StaffProfileComponent,
            canActivate: [AccessGuard]
          }, {
            path: 'edit/:id',
            component: StaffAddComponent,
            canActivate: [AccessGuard]
          }
        ]
      }, {
        path: 'settings',
        component: SettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/business',
        component: BusinessSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/payment',
        component: PaymentSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/tax',
        component: TaxSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/booking',
        component: BookingSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/waiver',
        component: WaiverSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/webstore',
        component: WebstoreSettingsComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'settings/customer',
        component: CustomerSettingsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'settings/lead',
        component: LeadSettingsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'settings/customer-app',
        component: CustomerAppSettingsComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'settings/communications-email',
        component: CommunicationsEmailComponent,
        canActivate: [AccessGuard]
      },
      {
        path: 'refresh',
        component: RefreshComponent,
        canActivate: [AccessGuard]
      }, {
        path: 'help',
        component: HelpComponent
      }, {
        path: 'get-started',
        component: GetStartedComponent
      }
    ]
  }
];

export const CustomAuthRoutes = RouterModule.forChild(authRoutes);
