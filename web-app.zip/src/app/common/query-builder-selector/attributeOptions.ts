const attributeOptions = {
    'text': [
        {
            op_list_name: '',
            op_list: [
                {operator: 'is', type: 'text', value_required: true},
                {operator: 'is not', type: 'text', value_required: true},
                {operator: 'starts with', type: 'text', value_required: true},
                {operator: 'ends with', type: 'text', value_required: true},
                {operator: 'contains', type: 'text', value_required: true},
                {operator: 'does not contain', type: 'text', value_required: true},
                {operator: 'is unknown', value_required: false},
                {operator: 'has any value', value_required: false},
            ]
        }
    ],
    'number': [
        {
            op_list_name: '',
            op_list: [
                {operator: 'is', type: 'number', value_required: true},
                {operator: 'is not', type: 'number', value_required: true},
                {operator: 'greater than', type: 'number', value_required: true},
                {operator: 'lower than', type: 'number', value_required: true},
                {operator: 'is unknown', value_required: false},
                {operator: 'has any value', value_required: false},
            ]
        }
    ],
    'date': [
        {
            op_list_name: 'Relative',
            op_list: [
                {operator: 'more than', label_after: 'days ago', type: 'number', value_required: true},
                {operator: 'exactly', label_after: 'days ago', type: 'number', value_required: true},
                {operator: 'less than', label_after: 'days ago', type: 'number', value_required: true},
            ]
        },
        {
            op_list_name: 'Absolute',
            op_list: [
                {operator: 'after', type: 'date', value_required: true},
                {operator: 'on', type: 'date', value_required: true},
                {operator: 'before', type: 'date', value_required: true},
                {operator: 'is unknown', value_required: false},
                {operator: 'has any value', value_required: false},
            ]
        },
    ],
    'list': [{
        op_list_name: '',
        op_list: [
            {operator: 'is', type: 'dropdown', value_required: true},
            {operator: 'is not', type: 'dropdown', value_required: true},
        ]
    }]
}


export default attributeOptions;
