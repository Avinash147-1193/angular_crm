import attributeOptions from './attributeOptions';
import moment from 'moment';


export function get_display_value(type, operator, value, rule_desc) {
    let all_options = [];
    let display_value = '';
    attributeOptions[type].forEach((op) => {
        all_options = [...all_options, ...op.op_list];
    });
    const operator_obj = all_options.find((option) => option.operator === operator);
    if (operator_obj.value_required) {
        if (!value) {
            throw new Error('value not defined');
        }
        switch (operator_obj.type) {
            case 'date':
                display_value = moment(value).format('MMM D, YYYY');
                break;
            case 'dropdown':
                display_value = rule_desc.values.find(val => String(val.value) === String(value)).label;
                break;
            default:
                display_value = value;
                break;
        }
        display_value = display_value + (operator_obj.label_after ? ' ' + operator_obj.label_after : '');
    }
    return display_value;
}
