import {NgModule} from '@angular/core';
import {MatRadioModule} from '@angular/material/radio';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSelectModule} from '@angular/material/select';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {Md2Module} from 'angular-md2';
import {FormsModule} from '@angular/forms';
import {QueryBuilderSelectorComponent} from './query-builder-selector.component';
import {RuleSetComponent} from './rule-set/rule-set.component';
import {RuleComponent} from './rule/rule.component';
import {OptionsBuilderComponent} from './options-builder/options-builder.component';
import {CommonModule} from '@angular/common';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatDialogModule} from '@angular/material/dialog';
import {TextMaskModule} from 'angular2-text-mask';
import {DropdownModule} from 'primeng/dropdown';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {BsDatepickerModule} from 'ngx-bootstrap';
import {StopPropagationDirective} from './stopPropogation';
import {SearchDropdownNoInputComponent} from '../search-dropdown-no-input/search-dropdown-no-input.component';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        TextMaskModule,
        Md2Module,
        DropdownModule,
        OverlayPanelModule,
        MatRadioModule,
        MatCheckboxModule,
        MatSelectModule,
        MatSnackBarModule,
        MatProgressBarModule,
        MatDialogModule,
        BsDatepickerModule,
    ],
    declarations: [
        RuleSetComponent,
        RuleComponent,
        OptionsBuilderComponent,
        QueryBuilderSelectorComponent,
        StopPropagationDirective,
        SearchDropdownNoInputComponent
    ],
    providers: [],
    exports: [QueryBuilderSelectorComponent, SearchDropdownNoInputComponent, StopPropagationDirective]
})
export class QueryBuilderSelectorModule {}
