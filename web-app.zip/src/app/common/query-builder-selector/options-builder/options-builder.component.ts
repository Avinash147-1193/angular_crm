import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import attributeOptions from '../attributeOptions'
import moment from 'moment';


@Component({
    selector: 'app-qb-options-builder',
    templateUrl: './options-builder.component.html',
    styleUrls: ['./options-builder.component.scss']
})
export class OptionsBuilderComponent implements OnInit {

    @Input() type: 'text'|'number'|'date'|'list';
    @Input() value: any = null;
    @Input() operator: any = null;
    @Input() optionDropdown: Array<object>|null = [
        {label: '', value: ''},
    ];

    @Output() valueChange = new EventEmitter();
    public show = false;
    options = [];
    all_options = [];
    date_value = null;
    has_error = false;

    startDatepickerConfig = {
        showWeekNumbers: false,
        containerClass: 'theme-default',
    };

    ngOnInit() {
        this.getOptions();
    }


    isValid() {
        const currentOperator = this.all_options.find((option) => option.operator === this.operator);
        return currentOperator && currentOperator['value_required']
            ? !!this.value
            : true;
    }

    getOptions() {
        this.date_value = this.type === 'date'
            ? this.value
            : null;
        this.options = attributeOptions[this.type];
        this.options.forEach((op) => {
            this.all_options = [...this.all_options, ...op.op_list];
        });
    }

    submitFilter() {
        const value = this.getValue();
        if (typeof value === 'boolean' && value === false) {
            this.has_error = true;
        } else {
            this.has_error = false;
            this.show = !this.show;
            this.valueChange.emit({...value});
        }
    }

    getValue() {
        const currentOperator = this.all_options.find((option) => option.operator === this.operator);
        if (currentOperator) {
            let value = currentOperator.type === 'date' ? this.date_value : this.value;
            if ((currentOperator.value_required && !!value) || (!currentOperator.value_required)) {
                // console.log(value, currentOperator.type)
                // has to be removed
                value = currentOperator.type === 'date' ? moment(this.date_value).format('YYYY-MM-DD') : this.value;
                console.log(value, currentOperator.type)

                return {
                    operator: this.operator,
                    value: value
                };
            }
        }
        return false;

    }

    public toggle() {
        this.show = !this.show;
    }
}
