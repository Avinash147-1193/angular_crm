import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    ComponentFactoryResolver,
    ComponentRef, EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild,
    ViewContainerRef
} from '@angular/core';
import {ServerAuthService} from '../server-auth';
import moment from 'moment';
import {RuleSetComponent} from './rule-set/rule-set.component';


@Component({
    selector: 'app-query-builder-selector',
    templateUrl: './query-builder-selector.component.html',
    styleUrls: ['./query-builder-selector.component.scss'],
})
export class QueryBuilderSelectorComponent implements OnInit, AfterViewInit{


    @ViewChild('viewContainerRefMain', { read: ViewContainerRef })
    VCRM: ViewContainerRef;

    @Input() data: any = {
        rules: [],
        condition: 'and'
    };
    @Input() filters: Array<object>|null = [
        {name: '', field: '', type: ''},
    ];
    @Output() valueChange = new EventEmitter();

    anyOptionOpen = false;

    child_unique_key = 0;
    componentsReferences = Array<ComponentRef<RuleSetComponent>>()

    constructor(private CFR: ComponentFactoryResolver, private cd: ChangeDetectorRef) {}


    ngOnInit(): void {
        //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
        //Add 'implements OnInit' to the class.
        console.log('data, filters', this.data, this.filters)

        if(this.data.length === 0) {
            this.data = {
                rules: [],
                condition: 'and'
            };
        }
    }
    createComponent(rulesetObj) {
        const componentFactory = this.CFR.resolveComponentFactory(RuleSetComponent);
        const childComponentRef = this.VCRM.createComponent(componentFactory);
        const childComponent = childComponentRef.instance;
        childComponent.id = ++this.child_unique_key;
        childComponent.parentRef = this;
        childComponent.ruleSet = rulesetObj.rules ? rulesetObj.rules : [];
        childComponent.filters = this.filters;
        childComponent.condition = rulesetObj.condition;
        // add reference for newly created component
        this.componentsReferences.push(childComponentRef);
    }

    ngAfterViewInit(): void {
        if (this.componentsReferences.length === 0) {
            this.createComponent(this.data);
            this.cd.detectChanges();
        }
    }

    handleRuleChange() {
        this.data.rules = this.componentsReferences[0].instance.ruleSet;
        console.log('this.data', this.data)
        this.valueChange.emit(this.data);
    }

    handleOptionToggle() {
        const optionsMenu = this.componentsReferences.map((ref) => ref.instance.anyOptionOpen);
        this.anyOptionOpen = optionsMenu.some((e) => e === true);
    }
}
