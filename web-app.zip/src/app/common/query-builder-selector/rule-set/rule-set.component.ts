import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    ComponentFactoryResolver,
    ComponentRef,
    Input, OnInit,
    ViewChild,
    ViewContainerRef
} from '@angular/core';
import {RuleComponent} from '../rule/rule.component';
import {SearchDropdownNoInputComponent} from '../../search-dropdown-no-input/search-dropdown-no-input.component';
import {QueryBuilderSelectorComponent} from '../query-builder-selector.component';


@Component({
    selector: 'app-qb-rule-set',
    templateUrl: './rule-set.component.html',
    styleUrls: ['./rule-set.component.scss']
})
export class RuleSetComponent implements AfterViewInit {

    @ViewChild('viewContainerRef', { read: ViewContainerRef })
    VCR: ViewContainerRef;

    @Input() ruleSet = [];
    @Input() filters: any = {};
    @Input() condition: 'and'|'or' = 'and';

    public id: any = null;
    public parentRef: QueryBuilderSelectorComponent;
    public anyOptionOpen = false;

    loading = false;
    child_unique_key = 0;
    componentsReferences = Array<ComponentRef<RuleComponent>>()


    constructor(private CFR: ComponentFactoryResolver, private cd: ChangeDetectorRef) {}

    createComponent(rule) {
        const componentFactory = this.CFR.resolveComponentFactory(RuleComponent);
        const childComponentRef = this.VCR.createComponent(componentFactory);
        const childComponent = childComponentRef.instance;
        childComponent.id = ++this.child_unique_key;
        childComponent.parentRef = this;
        childComponent.rule = rule;
        childComponent.filters = this.filters;
        childComponent.condition = this.condition;
        childComponent.show_condition = this.componentsReferences.length !== 0;
        // add reference for newly created component
        this.componentsReferences.push(childComponentRef);
    }

    remove(key: number) {
        if (this.VCR.length < 1) { return; }
        const componentRef = this.componentsReferences.filter(
            x => String(x.instance.id) === String(key)
        )[0];
            const vcrIndex: number = this.VCR.indexOf(componentRef['hostView']);
            // removing component from container
            this.VCR.remove(vcrIndex);
        this.componentsReferences = this.componentsReferences.filter(
            x => x.instance.id !== key
        );
        if (this.componentsReferences.length > 0) {
            this.componentsReferences[0].instance.show_condition = false;
        }
        this.handleRuleChange();
    }

    changeCondition(cond) {
        this.condition = cond;
        this.componentsReferences.forEach(
            (ref) => {ref.instance.condition = this.condition; }
        )
    }

    addRule(rule) {
        this.createComponent( {
            field: rule['field'],
            operator: rule['operator'],
            value: ''
        });
    }

    ngAfterViewInit(): void {
        if (this.componentsReferences.length === 0 && this.ruleSet && this.ruleSet.length > 0) {
            for (const rule of this.ruleSet) {
                this.createComponent(rule);
            }
            this.cd.detectChanges();
        }
    }

    handleRuleChange() {
        const newRuleSet = [];
        this.componentsReferences.forEach(
            (ref) => { newRuleSet.push({...ref.instance.rule}) }
        );
        this.ruleSet = newRuleSet;
        this.parentRef.handleRuleChange();
    }

    handleOptionToggle() {
        const optionsMenu = this.componentsReferences.map((ref) => ref.instance.isOpen());
        this.anyOptionOpen = optionsMenu.some((e) => e === true);
        this.cd.detectChanges();
    }



}
