import {
    Component,
    EventEmitter,
    Input,
    OnDestroy,
    OnInit,
    Output,
    ViewChild,
    ComponentFactoryResolver,
    AfterViewInit,
    ChangeDetectorRef
} from '@angular/core';
import {get_display_value} from '../helperFunctions';
import {RuleSetComponent} from '../rule-set/rule-set.component';


@Component({
    selector: 'app-qb-rule',
    templateUrl: './rule.component.html',
    styleUrls: ['./rule.component.scss']
})
export class RuleComponent implements OnInit, AfterViewInit {

    @ViewChild('opBuilder')opBuilder;

    public id: any = null;
    public rule: any = null;
    public filters: any = {};
    public fieldName: string;
    public show_condition = true;
    public condition: 'and'| 'or' = 'and';
    public parentRef: RuleSetComponent;
    public error = false;

    type: 'text'|'number'|'date'|'list';
    display_value = '';
    rule_desc: any ;
    constructor(private cd: ChangeDetectorRef) {}

    ngOnInit() {
        this.rule_desc  = this.filters.filter((f) => f.field === this.rule.field)[0];
        this.type = this.rule_desc.type;
        if (this.rule.value) {
            this.setDisplayValue(this.rule.operator, this.rule.value);
        }
        this.fieldName = this.filters.filter((f) => f.field === this.rule.field)[0].name;


    }

    setDisplayValue(operator, value ) {
        try {
            this.error = false;
            this.display_value = get_display_value(this.type, operator, value, this.rule_desc)
        } catch (e) {
            this.display_value = '';
            this.error = true;
        }

    }

    ngAfterViewInit(): void {

        if (!this.rule.value) {
            this.openOptionsPopUp();
            this.cd.detectChanges();
        }
    }

    handleValueChange(event) {
        this.setDisplayValue(event.operator, event.value)
        this.rule = {...this.rule, ...event};
        this.parentRef.handleOptionToggle();
        this.parentRef.handleRuleChange();
    }

    handleDeleteClicked(e) {
        console.log('delete', this.id)
        this.parentRef.remove(this.id);
        this.parentRef.handleOptionToggle();
    }

    openOptionsPopUp () {
        this.opBuilder.toggle()
        this.parentRef.handleOptionToggle()
    }

    public isOpen() {
        return this.opBuilder.show
    }

    handleConditionChange() {
        this.parentRef.changeCondition(this.condition);
    }
}
