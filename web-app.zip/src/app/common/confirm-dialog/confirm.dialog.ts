import {Component, Inject, Optional} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
	selector: 'confirm-dialog',
	template: `
		<h2 mat-dialog-title> {{data.title}} </h2>
		<mat-dialog-content>
			<img src="{{data.imgSrc}}" alt=""/>
		</mat-dialog-content>
		<mat-dialog-actions>
		  <button class="btn btn-gray-hollow dark-color-text-2 text-uppercase small-text letter-spacing-03 semibold-font margin-right16" [mat-dialog-close]="false"> {{data.revertAction}} </button>
		  <button class="btn btn-delete light-color-text-1 text-uppercase small-text letter-spacing-03 semibold-font" [mat-dialog-close]="true"> {{data.proceedAction}} </button>
		</mat-dialog-actions>
	`
})

export class ConfirmDialog {
	constructor(
		@Optional() @Inject(MAT_DIALOG_DATA) 
		public data: any
	) { }
}