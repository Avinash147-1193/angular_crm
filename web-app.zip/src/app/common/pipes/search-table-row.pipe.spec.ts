import { SearchTableRowPipe } from './search-table-row.pipe';

describe('SearchTableRowPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchTableRowPipe();
    expect(pipe).toBeTruthy();
  });
});
