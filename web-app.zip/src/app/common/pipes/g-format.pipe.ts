import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gFormat'
})
export class GFormatPipe implements PipeTransform {

  transform(value: string, ...args: any[]): any {
        let str = [];
        let counter = 0;
        for (let  i = 0;  i < value.length / 5; i++) {
            str.push([...value.slice(counter, counter + 5)].join(''))
            counter = counter + 5;
        }
        return str.join(' ');
  }

}
