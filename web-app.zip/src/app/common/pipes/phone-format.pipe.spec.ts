import { PhoneFormatPipe } from './phone-format.pipe';

describe('PhoneFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new PhoneFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
