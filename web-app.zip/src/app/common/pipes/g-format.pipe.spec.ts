import { GFormatPipe } from './g-format.pipe';

describe('GFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new GFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
