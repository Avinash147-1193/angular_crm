import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "filter"
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], value: string, label: string): any[] {
    if (!items) return [];
    if (!value) return items;
    if (value == "" || value == null) return [];
    console.log(label);
    console.log(value);
    console.log(items);
    return items.filter(e => {
      if (label == "plan.name") {
        return e.plan.name.toLowerCase().indexOf(value) > -1;
      } else {
        return e.name.toLowerCase().indexOf(value) > -1;
      }
    });
  }
}
