import { SortTablePipe } from './sort-table.pipe';

describe('SortTablePipe', () => {
  it('create an instance', () => {
    const pipe = new SortTablePipe();
    expect(pipe).toBeTruthy();
  });
});
