import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortTable'
})
export class SortTablePipe implements PipeTransform {

  transform(rows: any, sortType:number, sortValue?:{'key':string,'dt':any} ): any {
    	var send;
    	if(sortType == 0) {
    		send = rows
  		return send;
  	}else{
  		switch (sortValue.dt) {
  			case "string":
  				send = rows.sort((a,b)=>{ 
		  			var bool = 0,
		  				i = a[sortValue.key].toLowerCase(),
		  				j = b[sortValue.key].toLowerCase();
		    			(i>j) ? ((sortType==1)? bool = 1 : bool = -1) : '';
		    			(i<j) ? ((sortType==1)? bool = -1 : bool = 1) : '';
		    			return bool;
		    		});
  				break;
  			case "number":
  			case "boolean":
  				send = rows.sort((a,b)=>{ 
		  			var bool = 0,
		  				i = a[sortValue.key],
		  				j = b[sortValue.key];
		    			(i>j) ? ((sortType==1)? bool = 1 : bool = -1) : '';
		    			(i<j) ? ((sortType==1)? bool = -1 : bool = 1) : '';
		    			return bool;
		    		});
  				break;
  			case "amount":
  				send = rows.sort((a,b)=>{ 
		  			var bool = 0,
		  				i = a[sortValue.key],
		  				j = b[sortValue.key],
		  				k = a["value_type"],
		  				l = b["value_type"];
		    			(k>l) ? ((sortType==1)? bool = -1 : bool = 1) : '';
		    			(k<l) ? ((sortType==1)? bool = 1 : bool = -1) : '';
		    			if(k == l){
		    				(i>j) ? ((sortType==1)? bool = 1 : bool = -1) : '';
		    				(i<j) ? ((sortType==1)? bool = -1 : bool = 1) : '';
		    			}
		    			return bool;
		    		});
  				break;

  		}
  		return send;
  		
  	}
  }

}
