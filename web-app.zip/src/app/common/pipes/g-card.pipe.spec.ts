import { GCardPipe } from './g-card.pipe';

describe('GCardPipe', () => {
  it('create an instance', () => {
    const pipe = new GCardPipe();
    expect(pipe).toBeTruthy();
  });
});
