import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'phoneFormat'
})
export class PhoneFormatPipe implements PipeTransform {

	transform(value: any, args?: any): any {
        if(value && value.length > 2){
		var val = value.toString();
		var newString = val.slice(0,3)+'-'+val.slice(3,6)+ '-'+val.slice(6);

		return newString;
        }else{
            return value;

        }
	}

}
