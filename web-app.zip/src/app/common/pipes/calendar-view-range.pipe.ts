import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({ name: 'viewRange', pure: false })
export class ViewRangePipe implements PipeTransform {
	transform(date: Date, viewType: string) {
		let viewRange: any = '';
		let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
		let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
		let offset, weekStart, weekEnd;

		if (viewType === 'day') {
			viewRange = date.getDate() + ' ' + months[date.getMonth()];
		}

		else if (viewType === 'week') {
			offset = date.getDay();
			let weekStart = moment(date);
			let weekEnd = moment(date);

			if (offset === 0) {
				weekStart.subtract(6, 'days');
				weekEnd.add(0, 'days');
			}
			else {
				weekStart.subtract((offset - 1), 'days');
				weekEnd.add((7 - offset), 'days');
			}

			viewRange = weekStart.format('DD') + ' ' + weekStart.format('MMM') + ' - ' + weekEnd.format('DD') + ' ' + weekEnd.format('MMM');
		}

		return viewRange;
	}
}