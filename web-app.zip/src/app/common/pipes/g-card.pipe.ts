import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'gCard'
})
export class GCardPipe implements PipeTransform {

  transform(value: string, ...args: any[]): any {
      let str = value;

      return `••••• ••••• ••••• ${ str.slice(str.length - 5, str.length)}`;
  }

}
