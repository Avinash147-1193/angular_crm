import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'searchTableRow'
})
export class SearchTableRowPipe implements PipeTransform {

	transform(values: any, items: Array<any>, fltr: Array<any>) {
		if(items === undefined || items[0] == "" || items[0] == "all" || items[0] === undefined) {
			return values;
		}else{
			return values.filter((value)=>{ 
				var bool = false;
				fltr.forEach((el,index)=>{
					items.forEach((item,i)=>{
						if((value[el]===true||value[el]===false)&&(item===true||item===false)){
							(value[el]==item) ? bool = true : "";
						}else{
							(JSON.stringify(value[el]).toLowerCase().includes(item.toLowerCase())) ? bool = true : "" ;
						}
					})
				})
				return bool;
			});
		}
	}

}
