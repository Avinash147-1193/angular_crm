import { Component,ApplicationRef,OnChanges, Input , Output, EventEmitter}from '@angular/core';
import { GeneralServices } from '../general-services';
import { ServerAuthService } from '../server-auth';


 
@Component({

	selector:'popup-component',
	templateUrl:'./popup.component.html',
	styleUrls: ['popup.component.css']

})


export class PopupComponent{

    
	
	popup: boolean = false;
	popup_for: any = null;
	popup_action: any = null;

	prospect_id: any = null;
	prospect_data: any = null;
	prospect_name: string = null;
	prospect_contact:string = null;

	staff_list: any = [];

	add_task_in_stage: boolean = false;
	add_task_in_comment: boolean = false;

	task_data: any = {
		"id": null,
		"type": "phone",
		"remind_on": null,
		"comment": null,
		"client_id": null
	}

	
	@Input('center_id') CenterId:any;
	@Output() updateTaskInParent = new EventEmitter<any>();
	@Output() deleteTaskInParent = new EventEmitter<any>();
	
	constructor(
		private generalFunctions: GeneralServices,
		private http: ServerAuthService,
		private ref: ApplicationRef
		){};
	
	openTaskEditPopup(taskAction,  taskId,taskType, taskRemind, taskComment, taskClient, prospectId, prospectName,prospectContact?) {
		
		this.getStaff(this.CenterId);

		this.popup = true;
		this.popup_for = 'task';
		this.popup_action = taskAction;
		this.prospect_data = true;
		this.task_data["id"] = taskId;
		this.task_data["type"] = taskType;
		this.task_data["remind_on"] = taskRemind;
		this.task_data["comment"] = taskComment;
		this.task_data["client_id"] = taskClient;
		this.prospect_id = prospectId;
		this.prospect_name = prospectName;
		this.prospect_contact  = prospectContact;
	
	}

	resetPopup() {
		this.popup = false;
		this.popup_action = null;
		this.popup_for = null;
		this.add_task_in_stage = false;
		this.add_task_in_comment = false;
		this.task_data["id"] = null;
		this.task_data["type"] = 'phone';
		this.task_data["remind_on"] = null;
		this.task_data["comment"] = null;
		this.task_data["client_id"] = JSON.parse(localStorage.getItem("currentUser"))["client_id"];
	}

	updateTask(){
		this.updateTaskInParent.next(this.task_data);
		this.resetPopup();
	}
	
	deleteTask()
	{
		this.deleteTaskInParent.next(this.task_data);
		this.resetPopup();
	}	

	
	getStaff(centerId) {
		this.http.getData("staff/dropdown" + centerId)
			.subscribe(
			(success) => {
				success = success;
				this.staff_list = success.data;
				this.task_data["client_id"] = JSON.parse(localStorage.getItem("currentUser"))["client_id"];

				//	
			},
			(err) => {
				this.generalFunctions.openToast(err.message, 3000, "error");
			}
			)
	}

}


