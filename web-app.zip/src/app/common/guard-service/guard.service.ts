import {Injectable, OnInit} from "@angular/core";
import {MatDialogRef, MatDialog} from "@angular/material/dialog";
import {PosComponent} from "../../components/main/content/pos";
import {GeneralServices} from "../general-services";
import {Observable} from "rxjs";
import {ConfirmDialog} from "../confirm-dialog";
import {Intercom} from "ng-intercom";
import {
  Router,
  CanActivate,
  CanDeactivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  ActivatedRoute,
  UrlTree
} from "@angular/router";
import {Subscription} from "rxjs";

import {HelpComponent} from "app/components/main/content/help";
import {environment} from "environments/environment";
import { BillingComponent } from "app/components/main/content/billing/billing.component";

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router : Router, public intercom : Intercom) {}


  canActivate(route : ActivatedRouteSnapshot, state : RouterStateSnapshot) {

    if (localStorage.getItem("currentUser")) {
      this.intercom.boot({
        app_id: environment.intercomAppId,
        email: JSON.parse(localStorage.getItem("currentUser")).email,
        name: JSON.parse(localStorage.getItem("currentUser")).name,
        user_hash: JSON.parse(localStorage.getItem("currentUser")).intercomSecret,
        widget: {
          activator: "#intercom"
        }
      });

      return true;
    }
    console.log('state.url', state.url)
    if (state.url == "/client" || state.url == "/client/dashboard") {
      this.router.navigate(["login"]);
    } else {
      this.router.navigate(["login"], {
        queryParams: {
          returnUrl: state.url
        }
      });
    }
    return false;
  }
}

@Injectable()
export class DestroyBilling implements CanDeactivate<BillingComponent>{
    constructor() {}
    // tslint:disable-next-line: max-line-length
    canDeactivate(component: BillingComponent): boolean | boolean {
       console.log('component', component);
        if (component.subscription.status === 2 || 1) {
            return true;
        } else if (component.subscription.status === 3 && component.mode === 'checkout-after') {
            return false;
        } else {
            return true;
        }
    }


}

@Injectable()
export class DestroyPOS implements CanDeactivate<PosComponent> {
  dialogRef: MatDialogRef<any>;
  flag: any;
  subscription: Subscription;
  constructor(private router : Router, private route : ActivatedRoute, private confirmDialog : ConfirmDialog, private dialog : MatDialog, private generalFunction : GeneralServices) {}

  canDeactivate(component : PosComponent, currentRoute : ActivatedRouteSnapshot, currentState : RouterStateSnapshot, nextState : RouterStateSnapshot): boolean | Promise<boolean> {
    // this.generalFunction.getMessage().subscribe(message => { this.flag = message; });
    console.log("this.subscription", this.generalFunction.getMessage().subscribe(message => {
      this.flag = message;
    }));
    if (component.isContactSelected && !component.is_transaction_successful) {
      component.pop_up_for = "escape";
      component.routeLink = nextState.url;

      if (component.popUpClose == true) {
        return true;
      } else {
        return false;
      }

      // let data: any = {
      // 	title: 'Do you want to cancel the transaction?',
      // 	imgSrc: '../../../../assets/img/alert-sign.svg',
      // 	revertAction: 'No, return to POS',
      // 	proceedAction: 'Yes, cancel'
      // };

      // let dialogRef = this.dialog.open(ConfirmDialog,{
      // 	data:data,
      // 	panelClass:'posDestroy',
      // 	height: '240px',
      // 	width: '448px'
      // })

      // return new Promise((resolve,reject)=>{
      // 	dialogRef.afterClosed().subscribe(
      // 		(result) => {
      // 				res = result;
      // 				resolve(res);
      // 		},(error)=>{
      // 			reject(false);
      // 		}
      // 	)
      // })
    } else {
      return true;
    }
  }
}

@Injectable()
export class AccessGuard implements CanActivate {
  constructor(private router : Router, private generalFunctions : GeneralServices) {}

  //ENTRY AUTHENTICATING FUNCTION ON DYNAMIC URL ENTRY

  canActivate(route : ActivatedRouteSnapshot, state : RouterStateSnapshot) {
    var grantAccess: boolean = true;
    if (!JSON.parse(localStorage.getItem("currentUser"))) {
      this.generalFunctions.openToast("Please login again", 3000, "success");
      this.router.navigate(["login"]);

      return false;
    }

    if (JSON.parse(localStorage.getItem("currentUser")).roles) {
      return grantAccess;
    }

    if (!grantAccess) {
      this.generalFunctions.openToast("You are not authorized for this module!", 3000, "error");
      return grantAccess;
    }
    return grantAccess;
  }
}

@Injectable()
export class DestroyIntercom implements CanDeactivate<HelpComponent> {
  constructor(public intercom : Intercom) {}

  canDeactivate(component : HelpComponent, currentRoute : ActivatedRouteSnapshot, currentState : RouterStateSnapshot, nextState : RouterStateSnapshot): boolean | Promise<boolean> {
    this.intercom.shutdown();
    return true;
  }
}
