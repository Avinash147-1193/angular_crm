import {Injectable, Component} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {MatSnackBar, MatSnackBarConfig} from "@angular/material/snack-bar";
import {Observable, Subject} from "rxjs";
import {environment} from "../../../environments/environment";
import moment from "moment";
interface Window {
  Echo: any;
}

@Injectable()
export class GeneralServices {
  private subject = new Subject<any>();

  public add_customer: Subject<any>;
  public plan_details: any;
  addCustomer$ = null;

  channel: any;

  constructor(public snackBar : MatSnackBar) {
    this.add_customer = new Subject();
    // let config = new MatSnackBarConfig();
    // config. = ['custom-class'];
    this.addCustomer$ = this.add_customer.asObservable();
  }

  sendMessage(message : string) {
    this.subject.next({flag: message});
  }

  getMessage(): Observable<any> {
    return this.subject.asObservable();
  }

  // SETUP WEBSOCKET CHANNEL

  // GENERAL FUNCTIONS USEFUL FORM APP DOM MANIPULATION

  /* 1.0 SWITCH TOGGLE */
  toggleCustomSwitch(ev : any) {
    let state = ev.target.value;
    if (state == "active") {
      status = "inactive";
    }
    if (state == "inactive") {
      status = "active";
    }
    if (state == "true") {
      status = "false";
      alert("hello");
    }
    if (state == "false") {
      status = "true";
    }
    ev.target.value = state;
  }

  /* 2.0 INPUT FIELD VALIDATY */
  isFilled(e) {
    if (e.target.value != "") {
      e.target.classList.add("active");
      if (e.target.parentElement.classList.contains("validate-field")) {
        if (e.target.checkValidity()) {
          e.target.classList.remove("invalid");
          e.target.classList.add("valid");
        } else {
          e.target.classList.remove("valid");
          e.target.classList.add("invalid");
        }
      }
    } else {
      e.target.classList.remove("invalid", "valid", "active");
    }
  }

  /* 3.0 TIC TAC TOGGLE */
  toggleCustomTicTac(ev : any) {
    var container = ev.target.parentElement.parentElement;
    var child = container.children;
    var selec = ev.target.parentElement.classList.contains("selected")
      ? true
      : false;
    // for (var i = 0; i< child.length; i++){
    // 	if(child[i].classList.contains('selected')){
    // 		child[i].classList.remove("selected");
    // 		child[i].children[1].checked=false;
    // 		child[i].children[1].removeAttribute("checked");
    //  }
    // }
    if (!selec) {
      ev.target.parentElement.classList.add("selected");
      ev.target.setAttribute("checked", "true");
      ev.target.checked = true;
    }
  }

  /* 4.0 TOAST FOR NOTIFICATIONS */
  openToast(
    msg, time, state
    ?) {
    let snackBarRef = this.snackBar.open(msg, "", {
      duration: time,
      panelClass: ["snackbar", state]
    });
    snackBarRef.onAction().subscribe(() => {
      snackBarRef.dismiss();
    });
  }

  /* 5.0 SMALL TOAST FOR MOBILE NOTIFICATIONS */
  openSmallToast(
    msg, time, state
    ?) {
    let snackBarRef = this.snackBar.open(msg, "  ", {
      duration: time,
      panelClass: ["snackbar-small", state]
    });
    snackBarRef.onAction().subscribe(() => {
      snackBarRef.dismiss();
    });
  }

  /* 6.0 OBSERVABLE SUBJECT FUNCTION FOR ADD CUSTOMER POPUP */
  addCustomer(bool) {
    this.add_customer.next(bool);
  }

  /* 7.0 INCLUDE CENTER IN HTTP REQUEST FOR AUTHORIZED REQUESTS */
  includeCenter() {
    var center_id = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    var result = "?center_id=" + center_id;
    return result;
  }

  getCurrency() {
    const currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    return currency;
  }

  /* 8.0 BREADCRUMB APPEARANCE BASED ON SCROLL */
  breadcrumbLastScrollTop: number = 0;
  breadcrumbToggle(e) {
    var breadcrumbHeight = e.target.getElementsByClassName("breadcrumb")[0].offsetHeight;
    var st = e.target.scrollTop;
    var delta = 5;

    if (Math.abs(this.breadcrumbLastScrollTop - st) <= delta)
      return;

    if (st > this.breadcrumbLastScrollTop && st > breadcrumbHeight) {
      e.target.getElementsByClassName("breadcrumb")[0].classList.add("hidden");
    } else {
      e.target.getElementsByClassName("breadcrumb")[0].classList.remove("hidden");
    }

    this.breadcrumbLastScrollTop = st;
  }

  // CUSTOM JQUERY LIBRARY

  /* GET LIST OF ALL PARENT NODES OF ELEMENT */
  parents(el
  : any) {
    let current = el,
      list = [];
    while (current.parentElement != null && current.parentElement != document.documentElement) {
      list.push(current.parentElement);
      current = current.parentElement;
    }
    return list;
  }

  /* GET CLOSEST ELEMENT BY TAG NAME (BUBBLING) OF ELEMENT */
  closestTag(el, cls) {
    while ((el = el.parentElement) && !(el.nodeName == cls))
    ;
    return el;
  }

  /* GET CLOSEST ELEMENT BY CLASS NAME (BUBBLING) OF ELEMENT */
  closestClass(el, cls) {
    while ((el = el.parentElement) && !el.classList.contains(cls))
    ;
    return el;
  }

  /* INDEX OF AN ELEMENT WRT PARENT ELEMENT */
  index(el) {
    var sib = el.parentNode.childNodes;
    var n = 0;
    for (var i = 0; i < sib.length; i++) {
      if (sib[i] == el)
        return n;
      if (sib[i].nodeType == 1)
        n++;
      }
    return -1;
  }

  /* GROUP ARRAY BY A PROPERTY */
  groupBy(collection, property) {
    var i = 0,
      val,
      index,
      values = [],
      result = [];
    for (; i < collection.length; i++) {
      val = collection[i][property];
      index = values.indexOf(val);
      if (index > -1)
        result[index].push(collection[i]);
      else {
        values.push(val);
        result.push([collection[i]]);
      }
    }
    return result;
  }

  /* REMOVE NULL VALUE KEYS FROM OBJECT */
  removeEmpty(obj) {
    Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === "object")
        this.removeEmpty(obj[key]);
      else if (obj[key] == null || obj[key] === "")
        delete obj[key];
      }
    );
    return obj;
  }

  /* DECODE BASE 64 */
  decodeBase64(s) {
    var e = {},
      i,
      b = 0,
      c,
      x,
      l = 0,
      a,
      r = "",
      w = String.fromCharCode,
      L = s.length;
    var A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i = 0; i < 64; i++) {
      e[A.charAt(i)] = i;
    }
    for (x = 0; x < L; x++) {
      c = e[s.charAt(x)];
      b = (b << 6) + c;
      l += 6;
      while (l >= 8) {
        ((a = (b >>> (l -= 8)) & 0xff) || x < L - 2) && (r += w(a));
      }
    }
    return r;
  }

  /* INSERT TEXT AT CURSOR POINTER */
  insertAtCursor(el, teXt) {
    var start,
      end;
    if (el.selectionStart || el.selectionStart == "0") {
      var startPos = el.selectionStart;
      var endPos = el.selectionEnd;
      el.value = el.value.substring(0, startPos) + teXt + el.value.substring(endPos, el.value.length);
      start = startPos + teXt.length;
      end = startPos + teXt.length;
    } else {
      el.value += teXt;
      start = teXt.length;
      end = teXt.length;
    }
    this.setSelectionRange(el, start, end);
  }
  setSelectionRange(input, selectionStart, selectionEnd) {
    if (input.setSelectionRange) {
      input.focus();
      input.setSelectionRange(selectionStart, selectionEnd);
    } else if (input.createTextRange) {
      var range = input.createTextRange();
      range.collapse(true);
      range.moveEnd("character", selectionEnd);
      range.moveStart("character", selectionStart);
      range.select();
    }
  }

  /* CHANGE TO IN THE ISO FORMAT REQUIRED BY BACKEND */
  convertDateToISOFormat(date) {
    date = new Date(date);
    function pad(n) {
      return n < 10
        ? "0" + n
        : n;
    }
    var result = {};
    result["date"] = date.getFullYear() + "-" + pad(date.getMonth() + 1) + "-" + pad(date.getDate());
    result["time"] = pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds());
    return result;
  }

  /* CONSOLE LOG IN DEV MODE */
  console(item) {
    !environment.production
      ? console.log(item)
      : "";
  }

  /* SCROLL TO SPECIFIED INVALID INPUT ELEMENT IN FORM */
  scrolltoinvalid(el) {
    // scroll to input element's (using name attr) parent i.e. 'form-field'
    document.getElementsByName(el)[0].parentElement.scrollIntoView({behavior: "smooth", block: "start"});
  }

  calculateTax(TR, price) {
    let taxRate = TR / 100;
    return parseFloat((taxRate * price / (1 + taxRate)).toFixed(2));
  }

  //check mobile login
  checkDevice() {
    if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i)) {
      return true;
    } else {
      return false;
    }
  }

  secToMin(sec) {

    return  moment.utc(sec*1000).format('HH:mm:ss')

  }
}
