import {throwError as observableThrowError, Observable, Subject} from "rxjs";
import {map, catchError} from "rxjs/operators";
import {Injectable} from "@angular/core";
import {GeneralServices} from "../general-services";
import {environment} from "../../../environments/environment";

import {
  HttpClient,
  HttpHeaders,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpEvent,
  HttpResponse,
  HttpErrorResponse
} from "@angular/common/http";
import "rxjs/add/operator/do";

import {Router} from "@angular/router";

@Injectable()
export class ServerAuthService {
  logInHeaders = new HttpHeaders();
  commonHeader = new HttpHeaders();
  private baseApiUrl;
  private clientId;
  private getLogInHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({Accept: "application/x.gymday.v1+json"})
    };
    return httpOptions;
  }

  private getLogOutHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        Accept: "application/x.gymday.v1+json",
        Authorization: "Bearer" + this.getToken()
      })
    };
    return httpOptions;
  }

  private getCommonHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Accept: "application/x.gymday.v1+json",
        Authorization: "Bearer" + this.getToken()
      })
    };
    return httpOptions;
  }

  private searchClientHeader() {
    const httpOptions = {
      headers: new HttpHeaders({"Content-Type": "application/json", Accept: "application/x.gymday.v1+json"})
    };
    return httpOptions;
  }

  private getBlobHeader() {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/csv; charset=UTF-8",
        Accept: "application/csv",
        Authorization: "Bearer" + this.getToken()
      })
    };
    return httpOptions;
  }

  private getFormdataHeaders() {
    const httpOptions = {
      headers: new HttpHeaders({
        Accept: "application/x.gymday.v1+json",
        Authorization: "Bearer" + this.getToken()
      })
    };
    return httpOptions;
  }

  private getToken() {
    var token = JSON.parse(localStorage.getItem("currentUser")).token;
    return token;
  }

  // private getClient() {
  //   var clientId = JSON.parse(localStorage.getItem("currentUser")).client_id;
  //   return "?client_id=" + clientId;
  // }

  constructor(private http : HttpClient, private router : Router, private generalFunctions : GeneralServices) {
    this.baseApiUrl = environment.baseUrl + "api/";
    // this.clientId = JSON.parse(localStorage.getItem("currentUser")).client_id;
  }

  //GET LOCATION
  getLocation(pin): Observable<any> {
    return this.http.get(this.baseApiUrl + "location/search/" + pin, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //SIGNUP FUNCTION
  signup(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "register", data, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //SEND EMAIL VERIFICATION LINK
  resendEmailVerification(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "email/resend", data, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //VERIFY EMAIL
  verifyEmail(id): Observable<any> {
    return this.http.post(this.baseApiUrl + "email/verify/" + id, {}, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        // var err: any = {};
        // if (e["errors"]) {
        // 	err.message = e["errors"][Object.keys(e["errors"])[0]];
        // } else {
        // 	err.message = e.message;
        // }
        return observableThrowError(e);
      }
      return observableThrowError(e);
    }));
  }

  //VERIFY EMAIL
  setPassword(id, obj): Observable<any> {
    return this.http.post(this.baseApiUrl + "email/verify/" + id, obj, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //LOGIN FUNCTION
  login(email : string, password : string, client_id : any): Observable<any> {
    return this.http.post(this.baseApiUrl + "login", {
      email: email,
      password: password,
      client_id: client_id
    }, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  //RESET PASSWORD LINK
  resetPasswordLink(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "password/forgot", data, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      e = e;
      var err = {
        message: null
      };
      if (e["errors"]) {
        err.message = e["errors"][Object.keys(e["errors"])[0]];
      } else {
        err.message = e.message;
      }
      return observableThrowError(err);
    }));
  }

  //RESET CLIENT PASSWORD
  resetPassword(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "password/reset", data, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      e = e;
      var err = {
        message: null
      };
      if (e["error"]["errors"]) {
          console.log('w',e.error["errors"][Object.keys(e.error["errors"])[0]] )
        err.message = e.error["errors"][Object.keys(e.error["errors"])[0]];
      } else {
        err.message = e.message;
      }
      console.log('err', err)
      return observableThrowError(err);
    }));
  }

  linkValidation(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "password/reset/token/verify", data, this.getLogInHeaders())
    .pipe(map((response: Response) => {
        return response;
      }), catchError(e => {
        return this.catchErrors(e);
      }));
  }

  //GET FORM LINK DATA
  getLinkData(id): Observable<any> {
    return this.http.get(this.baseApiUrl + "contact/formlink/" + id, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //SEND FORM LINK DATA
  sendLinkData(data): Observable<any> {
    return this.http.post(this.baseApiUrl + "contact/formlink", data, this.getLogInHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  //LOGOUT FUNCTION INVALIDATE TOKEN
  logout(): Observable<any> {
    return this.http.get(this.baseApiUrl + "logout", this.getLogOutHeaders()).pipe(map((response : Response) => {
      return response;
    }));
  }

  //FOR FORMDATA
  sendFormData(endpoint, obj): Observable<any> {
    return this.http.post(this.baseApiUrl + endpoint, obj, this.getFormdataHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
          console.log("err.message", err.message);
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  videoUpload(endpoint, obj): Observable<any> {
    return this.http.post( endpoint, obj).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      if (e.status === 422) {
        e = e;
        var err: any = {};
        if (e["errors"]) {
          err.message = e["errors"][Object.keys(e["errors"])[0]];
          console.log("err.message", err.message);
        } else {
          err.message = e.message;
        }
        return observableThrowError(err);
      }
      return observableThrowError(e);
    }));
  }

  getCountryCode(endpoint): Observable<any> {
    return this.http.get(this.baseApiUrl + endpoint, this.getFormdataHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  /* FOR AUTHENTICATED REQUESTS */
  getData(endpoint): Observable<any> {
    return this.http.get(this.baseApiUrl + endpoint, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  getMock(endpoint): Observable<any> {
      return this.http.get(endpoint).pipe(map((response : Response)=>{
          return response;
      }))
  }

  sendData(endpoint, data): Observable<any> {
    return this.http.post(this.baseApiUrl + endpoint, data, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  searchClient(endpoint): Observable<any> {
    return this.http.get(this.baseApiUrl + endpoint, this.searchClientHeader()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  // sendDataBlob(endpoint, data) {
  //   this.http.post(this.baseApiUrl + endpoint, data, this.getBlobHeader()).subscribe(success => {
  //     console.log("response", success);
  //   }, err => {
  //     console.log("err", err);
  //   });
  // }

  updateData(endpoint, data): Observable<any> {
    return this.http.put(this.baseApiUrl + endpoint, data, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  patchData(endpoint, data): Observable<any> {
    return this.http.patch(this.baseApiUrl + endpoint, data, this.getCommonHeaders()).pipe(map((response : Response) => {
        return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  deleteData(endpoint): Observable<any> {
    return this.http.delete(this.baseApiUrl + endpoint, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }

  deleteBody(endpoint, data): Observable<any> {

    const options = {
        headers: new HttpHeaders({
            "Content-Type": "application/json",
            Accept: "application/x.gymday.v1+json",
            Authorization: "Bearer" + this.getToken()
        }),
        body: data,
      };

      return this.http
        .delete(this.baseApiUrl + endpoint, options)
        .pipe(map((response: Response)  => {
            console.log('response', response)
            if (!response) {
                return {message : 'success'}
            }
            return response;
          }),
          catchError(e => {
            return this.catchErrors(e);
          }));

  }



  deleteDataBody(endpoint, obj): Observable<any> {
    // return this.http.delete(this.baseApiUrl + endpoint, { headers: this.getCommonHeaders(), body: obj })
    return this.http.delete(this.baseApiUrl + endpoint, this.getCommonHeaders()).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return this.catchErrors(e);
    }));
  }



  catchErrors(e) {
    var result;
        if (e.status == 401) {
            result = this.rejectRequest(e);
        }
        else if (e.status == 403) {
            let err = {
                message: e.error.message
            };
            this.generalFunctions.openToast(err.message, 3000, 'error');
            return;
        }
        else if (e.status == 404) {
            let err = {
                message: e.error.message
            };
            result = observableThrowError(err);
        }
        else if (e.status == 500) {
            var err = {
                message: "Something weird happened. We are looking into it and will fix it soon."
            };
            result = observableThrowError(err);
        }
        else if (e.status == 422) {
            let err: any = {};
            if (e.error.errors) {
                err.message = e.error["errors"][Object.keys(e.error["errors"])[0]];
            }
            else {
                err.message = "Please enter valid data";
            }
            result = observableThrowError(err);
        }
        else if (e.status == 413) {
            result = observableThrowError(e);
        }
        else if (e.status == 400) {
            let err = {
                message: e.error.message
            };
            result = observableThrowError(err);
        }
        else if (e.status == 409) {
            let err = {
                message: e.error.message
            };
            result = observableThrowError(err);
        }
        else if (e.status == 403) {
            let err = {
                message: e.error.message
            };
            this.generalFunctions.openToast(err.message, 3000, 'error');
            return;
        }

        else if (e.status === 405) {
            let err = {
                message: e.error.message
            };
            result = observableThrowError(err);
        }

        else if (e.status === 504) {
            let err = {
                message: 'Request time out.'
            };
            result = observableThrowError(err);
        }
        else {
            result = observableThrowError(err);
        }

    return result;
  }

  rejectRequest(e) {
    localStorage.removeItem("currentUser");
    this.router.navigate(["login"]);
    var err = {
      message: "Invalid user!"
    };
    return observableThrowError(err);
  }

  getExternalData(externalEndpoint : string): Observable<any> {
    return this.http.get(externalEndpoint).pipe(map((response : Response) => {
      return response;
    }), catchError(e => {
      return e;
    }));
  }
}

@Injectable()
export class MyInterceptor implements HttpInterceptor {
  intercept(req : HttpRequest<any>, next : HttpHandler): Observable<HttpEvent<any>> {
    if(!window.navigator.onLine) {
      // if there is no internet, throw a HttpErrorResponse error
      // since an error is thrown, the function will terminate here
      let err = {
        status: 404,
        error: {
          message: "Not connected"
        }
      };
      return observableThrowError(err);
    } else {
      // else return the normal request
      return next.handle(req);
    }
  }
}

@Injectable()
export class GiftCardService {
    sub: Subject<any>;


    constructor() {
        this.sub = new Subject();
    }

    giftCardValidity(data) {
         this.sub.next(data)

    }
}
