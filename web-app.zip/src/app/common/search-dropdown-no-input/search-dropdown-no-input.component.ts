import {
    Component,
    OnInit,
    ViewChild,
    Output,
    Input,
    ViewEncapsulation,
    EventEmitter, TemplateRef, AfterViewInit
} from '@angular/core';
@Component({selector: 'app-search-dd-no-input',
    templateUrl: './search-dropdown-no-input.component.html',
    styleUrls: ['./search-dropdown-no-input.component.scss']
    })
export class SearchDropdownNoInputComponent  {

    @Input()
    buttonTemplate: TemplateRef<any> = null;
    @Input()
    displayElementTemplate: TemplateRef<any> = null;

    @Input()value: any = null;
    @Input()disabled = false;
    @Input()options: any = {};
    @Input()buttonText = 'Add';

    @Output()valueSelected = new EventEmitter();

    handleValueChange(event) {
        if (event && event.value) {
          this.valueSelected.emit(event.value);
        }
    }
}
