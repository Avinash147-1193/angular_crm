import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDropdownNoInputComponent } from './search-dropdown-no-input.component';

describe('AddTagComponent', () => {
  let component: SearchDropdownNoInputComponent;
  let fixture: ComponentFixture<SearchDropdownNoInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDropdownNoInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDropdownNoInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
