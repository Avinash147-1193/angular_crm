import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdyenTestComponent } from './adyen-test.component';

describe('AdyenTestComponent', () => {
  let component: AdyenTestComponent;
  let fixture: ComponentFixture<AdyenTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdyenTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdyenTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
