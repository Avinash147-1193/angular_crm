import {
    Component,
    OnInit,
    AfterViewInit,
    Output,
    EventEmitter,
    Input,
    SimpleChanges,
    OnChanges

} from '@angular/core';
import { GeneralServices } from 'app/common/general-services';
import { ServerAuthService } from 'app/common/server-auth';
import { environment } from 'environments/environment';

@Component({
    selector: 'app-adyen-test',
    templateUrl: './adyen-test.component.html',
    styleUrls: ['./adyen-test.component.scss']
})
export class AdyenTestComponent implements OnInit, AfterViewInit, OnChanges {
    @Output()adyenValidCard = new EventEmitter();
    @Input()adyenId;
    adyenState  = null;
    paymentMethodsResponse = {};
    test = true;
    configuration = {};
    include_center = null;
    adyenToken = null;

    constructor( private generalFunctions: GeneralServices, private http: ServerAuthService) {

        console.log('3');

    }

    ngOnInit(): void {
        console.log('2');

        this.include_center = this.generalFunctions.includeCenter();
        this.getPaymentMethod();

    }

    ngAfterViewInit() {

        this.adyenate();






    }

    adyenate() {
        console.log('1')
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href =
            "https://checkoutshopper-live.adyen.com/checkoutshopper/sdk/3.14.1/adyen.css";
        //   link.integrity = "sha384-dNVP3hcwQ/DJnbhWtKjt/xpYSDyS1Ch8m8tnxNehvZoGzcrjeGuKk9/dGstY+vxu";
        document.head.appendChild(link);

        const script = document.createElement("script");
        script.src =
            "https://checkoutshopper-live.adyen.com/checkoutshopper/sdk/3.14.1/adyen.js";

        script.async = true;
        // script.integrity = "sha384-6CKCjdBJ5e8ODBkoPb8aS4NUVZUT84+EwcOq/EdHIQJsHXZyRy4Hzmlo3Cm/3VX3";

            script.onload = this.initAdyenCheckout.bind(this); // Wait until the script is loaded before initiating AdyenCheckout
            document.body.appendChild(script);

    }

    ngOnChanges(changes: SimpleChanges): void {
        console.log('changes', changes)
    }
//StudioYou778ECOM
    //   AQEnhmfuXNWTK0Qc+iSDhnE8ruuiR54aWsusxWR0I5eELp4H5Q74MHEsEMFdWw2+5HzctViMSCJMYAc=-0c+CQn1yWFhYGMSrzhlEbAM3Zo1Gl1Gofxhdba/xff4=-gns>bJB;n^H{7S?+

//test_I7TMNJ2O3RGPXF62HSVOGQO4KQWLM3CI
    stateChanges = (state) => {
        console.log('this.adyenState', state)
        this.adyenValidCard.emit(state);
    }

    getPaymentMethod() {
        this.http.getData('apps/adyen/config' + this.include_center).subscribe((response) => {
            console.log('response', response)
            this.paymentMethodsResponse =  response;
        })
    }

    initAdyenCheckout() {
        this.http.getData('apps' + this.include_center).subscribe(success => {
            const adyen = success.apps.filter(app => app.app.name === 'Adyen')
            let adyenConnected;
            adyen.length > 0 ? adyenConnected = true : adyenConnected = false;
            if (adyenConnected) {
                this.adyenToken = adyen[0].settings.client_id;
                this.configuration = {
                    locale: "en_US",
                    environment: environment.adyenMode,
                    originKey: this.adyenToken,
                    paymentMethodsResponse: this.paymentMethodsResponse,
                    onChange: this.stateChanges
                };
                console.log('this.configuration', this.configuration)

                const checkout = new AdyenCheckout(this.configuration);
                const card = checkout.create('card').mount('#component-container');
            }
          }, error => {
            this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
          });

    }

}
