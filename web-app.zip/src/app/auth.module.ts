/* BASIC IMPORTS FOR APP MODULE */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {CustomAuthRoutes} from './auth.routes';
import {DragulaModule} from 'ng2-dragula';
import {TextMaskModule} from 'angular2-text-mask';

// import { Md2Module } from 'md2';
import {Md2Module, NoConflictStyleCompatibilityMode} from 'angular-md2';
import {ConnectionService} from 'ng-connection-service';

import {CalendarModule, CalendarNativeDateFormatter, DateAdapter, DateFormatterParams} from 'angular-calendar';
import {adapterFactory} from 'angular-calendar/date-adapters/date-fns';
import {BsDatepickerModule} from 'ngx-bootstrap/datepicker';
import {CalendarModule as PrimeCalendar} from 'primeng/calendar';
import {MultiSelectModule} from 'primeng/multiselect';
import {DropdownModule} from 'primeng/dropdown';
import {TooltipModule} from 'primeng/tooltip';

import {environment} from '../environments/environment';
import {ChartsModule} from 'ng2-charts';
import {ColorPickerModule} from 'ngx-color-picker';
/* IMPORT SERVICES AND PIPES FOR MODULE */
import {AccessGuard, AuthGuard, DestroyIntercom, DestroyPOS} from './common/guard-service';
import {GiftCardService, MyInterceptor, ServerAuthService} from './common/server-auth';
import {ConfirmDialog} from './common/confirm-dialog';
import {GeneralServices} from './common/general-services';
import {SearchTableRowPipe} from './common/pipes/search-table-row.pipe';
import {OrderByPipe} from './common/pipes/order-by.pipe';
import {SortTablePipe} from './common/pipes/sort-table.pipe';
import {firstLetters} from './common/pipes/firstLetters';
import {PhoneFormatPipe} from './common/pipes/phone-format.pipe';
import {PopupComponent} from './common/popup';
import {ViewRangePipe} from './common/pipes/calendar-view-range.pipe';
/* COMPONENT CATEGORY 0 */
import {HeaderComponent} from './components/main/header';
import {SidebarComponent} from './components/main/sidebar';
import {MainComponent} from './components/main';
import {RefreshComponent} from './components/refresh';
/* CONTENT COMPONENT */
import {DashboardComponent} from './components/main/content/dashboard';

import {MobileAccessComponent} from './components/mobile-access/mobile-access.component';


import {PosComponent} from './components/main/content/pos';
import {PosMembershipsComponent} from './components/main/content/pos/memberships/pos-memberships.component';
import {PosCustomerComponent} from './components/main/content/pos/customer-profile/pos-customer.component';
import {PosCoursesComponent} from './components/main/content/pos/courses/pos-courses.component';
import {PosGCards} from './components/main/content/pos/g-cards/pos-g-cards.component';

import {PosCartComponent} from './components/main/content/pos/cart/pos-cart.component';
import {PosAddCardComponent} from './components/main/content/pos/pos-add-card/pos-add-card.component';
import {PosHistoryComponent} from './components/main/content/pos-history';

import {MembershipsComponent} from './components/main/content/services';

import {DiscountsComponent} from './components/main/content/discounts';
import {DiscountsTableComponent} from './components/main/content/discounts/discounts-table';
import {DiscountCreateComponent} from './components/main/content/discounts/discount-create';

import {CustomersComponent} from './components/main/content/customers';
import {CustomersAddComponent} from './components/main/content/customers/customers-add';
import {CustomersTableComponent} from './components/main/content/customers/customers-table';
import {FormlinkRequestsComponent} from './components/main/content/customers/formlink-requests';

import {ProspectAttendanceComponent} from './components/main/content/prospects/prospects-profile/attendance-calendar.component';
import {ProspectsComponent} from './components/main/content/prospects';
import {ProspectsTableComponent} from './components/main/content/prospects/prospects-table';
import {ProspectsAddComponent} from './components/main/content/prospects/prospects-add';
import {ProspectsProfileComponent} from './components/main/content/prospects/prospects-profile';

import {ReportsComponent} from './components/main/content/reports';
import {ReportsHomeComponent} from './components/main/content/reports/reports-home';




import {SettingsComponent} from './components/main/content/settings';
import {StaffComponent} from './components/main/content/staff';
import {StaffTableComponent} from './components/main/content/staff/staff-table';
import {StaffAddComponent} from './components/main/content/staff/staff-add';
import {StaffProfileComponent} from './components/main/content/staff/staff-profile';
import {StaffAttendanceComponent} from './components/main/content/staff/staff-profile/attendance-calendar.component';
import {MembershipPlansTableComponent} from './components/main/content/services/membership-plans/membership-plans-table/membership-plans-table.component';
import {MembershipServicesComponent} from './components/main/content/services/membership-services/membership-services.component';
import {CreateMembershipPlansComponent} from './components/main/content/services/membership-plans/create-membership-plans/create-membership-plans.component';
import {ClassScheduleListComponent} from './components/main/content/services/class-schedule/class-schedule-list/class-schedule-list.component';
import {ClassScheduleDetailsComponent} from './components/main/content/services/class-schedule/class-schedule-details/class-schedule-details.component';
import {ClassPackListComponent} from './components/main/content/services/class-packs/class-pack-list/class-pack-list.component';
import {CreateClassPacksComponent} from './components/main/content/services/class-packs/create-class-packs/create-class-packs.component';
import {EventsCalendarComponent} from './components/main/content/events-calendar/events-calendar.component';
import {FilterPipe} from './common/pipes/filter.pipe';
import {PersonalTrainingListComponent} from './components/main/content/services/personal-training/personal-training-list/personal-training-list.component';
import {PersonalTrainingDetailsComponent} from './components/main/content/services/personal-training/personal-training-details/personal-training-details.component';
import {AutoMessagesComponent} from './components/main/content/auto-messages/auto-messages.component';
import {AutoMessagesListComponent} from './components/main/content/auto-messages/auto-messages-list/auto-messages-list.component';
import {AutoMessagesDetailsComponent} from './components/main/content/auto-messages/auto-messages-details/auto-messages-details.component';
import {TasksListComponent} from './components/main/content/tasks/tasks-list/tasks-list.component';
import {TasksDetailsComponent} from './components/main/content/tasks/tasks-details/tasks-details.component';
import {MessageEditorComponent} from './components/feature/message-editor/message-editor.component';
import {OnboardingComponent} from './components/onboarding/onboarding.component';
import {DashboardNewComponent} from './components/main/content/dashboard-new/dashboard-new.component';
import {BusinessSettingsComponent} from './components/main/content/settings/business-settings/business-settings.component';
import {PaymentSettingsComponent} from './components/main/content/settings/payment-settings/payment-settings.component';
import {TaxSettingsComponent} from './components/main/content/settings/tax-settings/tax-settings.component';
import {HelpComponent} from './components/main/content/help/help.component';

import {IntercomModule} from 'ng-intercom';
import {BookingSettingsComponent} from './components/main/content/settings/booking-settings/booking-settings.component';
import {ReportsSaleComponent} from './components/main/content/reports/reports-sale/reports-sale.component';
import {WaiverSettingsComponent} from './components/main/content/settings/waiver-settings/waiver-settings.component';
import {WebstoreSettingsComponent} from './components/main/content/settings/webstore-settings/webstore-settings.component';
import {GetStartedComponent} from './components/main/content/get-started/get-started.component';

import {DragDropModule} from '@angular/cdk/drag-drop';
import {FacilityTableComponent} from './components/main/content/services/facility/facility-table/facility-table.component';
import {LocationComponent} from './components/location/location.component';
import {RegionComponent} from './components/region/region.component';
import {AvailabilityComponent} from './components/main/content/services/availability/availability.component';
import {CustomerAppSettingsComponent} from './components/main/content/settings/customer-app-settings/customer-app-settings.component';
import {ServicesModalComponent} from './components/feature/services-modal/services-modal.component';
import {ReferralComponent} from './components/main/content/marketing/referral';
import {MarketingComponent} from './components/main/content/marketing';
import {ReferralSetupComponent} from './components/main/content/marketing/referral-setup/referral-setup.component';
import {CustomerSettingsComponent} from './components/main/content/settings/customer-settings/customer-settings.component';
import {AddTagComponent} from './components/feature/add-tag/add-tag.component';
import { CustomersDetailComponent } from './components/main/content/customers/customers-detail';
import { PillComponent } from './components/main/content/customers/customers-detail/pill.component';
import { ReportsCustomerComponent } from './components/main/content/reports/reports-customer/reports-customer.component';
import { ReportsTableComponent } from './components/feature/reports-table';
import {AppsComponent} from './components/main/content/apps/apps.component';
import {MailchimpComponent} from './components/main/content/apps/mailchimp.component'
import {AdyenComponent} from './components/main/content/apps/adyen.component'

import {QueryBuilderSelectorModule} from './common/query-builder-selector/query-builder-selector.module';
import { DetailedReportsComponent } from './components/main/content/reports/detailed-reports/detailed-reports.component';
import { LeadSettingsComponent } from './components/main/content/settings/lead-settings/lead-settings.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { EditorModule, TINYMCE_SCRIPT_SRC } from '@tinymce/tinymce-angular';
import { BillingComponent } from './components/main/content/billing/billing.component';
import { AdyenTestComponent } from './adyen-test/adyen-test.component';
import { CoursesModule } from './components/main/content/services/courses/courses.module';
import { SharedModule } from './shared/shared.module';
import { VodModule } from './components/main/content/vod/vod.module';
import { ReportsNotificationComponent } from './components/main/content/reports/reports-notification/reports-notification.component';
import { CommunicationsEmailComponent } from './components/main/content/settings/communications-email/communications-email.component';
import { GiftCardComponent } from './components/main/content/services/gift-card';
import { CreateGiftCardComponent } from './components/main/content/services/gift-card/create-gift-card/create-gift-card.component';
import { GiftCardTableComponent } from './components/main/content/services/gift-card/gift-card-table/gift-card-table.component';
import { InlineFieldComponent } from './components/feature/inline-field/inline-field.component';
import { GCardPipe } from './common/pipes/g-card.pipe';
import { GFormatPipe } from './common/pipes/g-format.pipe';
import { TextRegion } from './components/main/content/customers/customers-detail/text-region.directive';
// import { ImageUploadComponent } from './components/feature/image-upload/image-upload.component';

// <-- import the module


// import * as Raven from 'raven-js';

class CustomDateFormatter extends CalendarNativeDateFormatter {
  public monthViewColumnHeader({date, locale}: DateFormatterParams): string {
    return new Intl.DateTimeFormat(locale, {weekday: 'short'}).format(date);
  }
}

@NgModule({
  imports: [
    SharedModule,
    FormsModule,
    CommonModule,
    DragDropModule,
    ReactiveFormsModule,
    HttpClientModule,
    CustomAuthRoutes,

    DragulaModule,
    TextMaskModule,
    Md2Module,
    PrimeCalendar,
    MultiSelectModule,
    DropdownModule,
    ChartsModule,
    ColorPickerModule,
    NoConflictStyleCompatibilityMode,
    TooltipModule,
    CalendarModule.forRoot({provide: DateAdapter, useFactory: adapterFactory}),
    BsDatepickerModule.forRoot(),
    IntercomModule.forRoot({appId: environment.intercomAppId, updateOnRouterChange: false}),
    QueryBuilderSelectorModule,
    NgxPaginationModule,
    EditorModule,
    CoursesModule,
    VodModule

  ],
  declarations: [
    PillComponent,
    SidebarComponent,
    HeaderComponent,
    MainComponent,
    RefreshComponent,

    PosComponent,
    PosMembershipsComponent,
    PosCustomerComponent,
    PosCartComponent,
    PosCoursesComponent,
    PosAddCardComponent,
    PosGCards,

    PosHistoryComponent,

    CustomersComponent,
    CustomersAddComponent,
    CustomersTableComponent,
    FormlinkRequestsComponent,
    PopupComponent,

    ProspectsComponent,
    ProspectsTableComponent,
    ProspectAttendanceComponent,
    ProspectsAddComponent,
    ProspectsProfileComponent,

    DiscountsComponent,
    DiscountsTableComponent,
    DiscountCreateComponent,



    ReportsComponent,
    ReportsHomeComponent,


    MembershipsComponent,

    DashboardComponent,

    SettingsComponent,

    SearchTableRowPipe,
    OrderByPipe,
    SortTablePipe,
    firstLetters,
    PhoneFormatPipe,

    ViewRangePipe,

    ConfirmDialog,

    StaffComponent,
    StaffTableComponent,
    StaffAddComponent,
    StaffProfileComponent,
    StaffAttendanceComponent,



    MembershipPlansTableComponent,
    MembershipServicesComponent,
    CreateMembershipPlansComponent,
    ClassScheduleListComponent,
    ClassScheduleDetailsComponent,
    ClassPackListComponent,
    CreateClassPacksComponent,
    EventsCalendarComponent,
    FilterPipe,
    PersonalTrainingListComponent,
    PersonalTrainingDetailsComponent,
    AutoMessagesComponent,
    AutoMessagesListComponent,
    AutoMessagesDetailsComponent,
    TasksListComponent,
    TasksDetailsComponent,
    MessageEditorComponent,
    OnboardingComponent,
    DashboardNewComponent,
    BusinessSettingsComponent,
    PaymentSettingsComponent,
    TaxSettingsComponent,
    HelpComponent,
    MobileAccessComponent,
    BookingSettingsComponent,
    ReportsSaleComponent,
    WaiverSettingsComponent,
    WebstoreSettingsComponent,
    GetStartedComponent,
    FacilityTableComponent,
    LocationComponent,
    RegionComponent,
    AvailabilityComponent,
    CustomerAppSettingsComponent,
    ServicesModalComponent,
    ReferralComponent,
    MarketingComponent,
    ReferralSetupComponent,
    CustomerSettingsComponent,
    AddTagComponent,
    AppsComponent,
    CustomersDetailComponent,
    ReportsCustomerComponent,
    ReportsTableComponent,
    DetailedReportsComponent,
    LeadSettingsComponent,
    MailchimpComponent,
    BillingComponent,
    AdyenTestComponent,
    AdyenComponent,
    ReportsNotificationComponent,
    CommunicationsEmailComponent,
    GiftCardComponent,
    CreateGiftCardComponent,
    GiftCardTableComponent,
    InlineFieldComponent,
    GCardPipe,
    GFormatPipe,
    TextRegion
  ],
  providers: [
    AuthGuard,
    DestroyPOS,
    // DestroyBilling,
    DestroyIntercom,
    AccessGuard,
    ServerAuthService,
    GiftCardService,
    ConfirmDialog,
    GeneralServices,
    { provide: TINYMCE_SCRIPT_SRC, useValue: 'tinymce/tinymce.min.js' },
    ConnectionService, {
      provide: HTTP_INTERCEPTORS,
      useClass: MyInterceptor,
      multi: true
    }
  ],
  entryComponents: [ConfirmDialog],
  exports: [ConfirmDialog],

})
export class AuthModule {}
