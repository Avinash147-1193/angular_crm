/* BASIC IMPORTS FOR APP MODULE */
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {CustomRoutes} from './app.routes';
// import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatSnackBarModule} from '@angular/material/snack-bar';
// import { Md2Module }  from 'md2';
import {Md2Module, NoConflictStyleCompatibilityMode} from 'angular-md2';
import {environment} from '../environments/environment';
import {RouterModule} from '@angular/router';
import {IntercomModule} from 'ng-intercom';

// import * as Raven from 'raven-js';

/* IMPORT SERVICES AND PIPES FOR MODULE */
import {AuthGuard, DestroyPOS, AccessGuard, DestroyIntercom} from './common/guard-service';
import {ServerAuthService} from './common/server-auth';
import {GeneralServices} from './common/general-services';
import {PhoneFormatPipe} from './common/pipes/phone-format.pipe';
import {PopupComponent} from './common/popup';

/* IMPORT DIRECTIVES */
import {selectRequiredValidatorDirective} from './shared/select-required-validator-directive';

/* COMPONENT CATEGORY 0 */
import {AppComponent} from './app.component';
import {HomeComponent} from './components/home';
import {SignupComponent} from './components/home/signup';
import {LoginComponent} from './components/home/login';
import {VerifyEmailComponent} from './components/home/verify-email';
import {VerifyStaffComponent} from './components/home/verify-staff';
import {ContactFormComponent} from './components/home/contact-form';
import {NotFoundFormlinkComponent} from './components/not-found-formlink';
import {ForgotPasswordComponent} from './components/home/forgot-password';
import {NotfoundComponent} from './components/not-found';
import {AuthLoginComponent} from './components/home/auth-login';
import {AuthForgotPasswordComponent} from './components/home/auth-forgot-password';
import { RecaptchaModule } from 'ng-recaptcha';
import {QueryBuilderSelectorModule} from './common/query-builder-selector/query-builder-selector.module';

/* CONTENT COMPONENT */

@NgModule({
  imports: [
    BrowserModule, HttpClientModule, CustomRoutes, BrowserAnimationsModule,
    // NoopAnimationsModule,
    MatRadioModule,
    MatCheckboxModule,
    MatSelectModule,
    MatSnackBarModule,
    Md2Module,
    NoConflictStyleCompatibilityMode,
    FormsModule,
    ReactiveFormsModule,
    RecaptchaModule,
    // RouterModule.forRoot([], { useHash: !environment.production }),
    RouterModule.forRoot([], {useHash: true}),
    IntercomModule.forRoot({
      appId: environment.intercomAppId, // from your Intercom config
      updateOnRouterChange: true, // will automatically run `update` on router event changes. Default: `false`,
      alignment: "right"
    }),
  ],
  declarations: [
    AppComponent,
    NotfoundComponent,
    HomeComponent,
    ContactFormComponent,
    NotFoundFormlinkComponent,
    VerifyEmailComponent,
    ForgotPasswordComponent,
    SignupComponent,
    LoginComponent,
    VerifyStaffComponent,
    selectRequiredValidatorDirective,
    AuthLoginComponent,
    AuthForgotPasswordComponent,
  ],
  providers: [
    AuthGuard,
    DestroyPOS,
    DestroyIntercom,
    AccessGuard,
    ServerAuthService,
    GeneralServices,
    PopupComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
