import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ServerAuthService} from "../../../common/server-auth";
import {GeneralServices} from "../../../common/general-services";

@Component({templateUrl: "./verify-email.component.html", styleUrls: ["./verify-email.component.css"]})
export class VerifyEmailComponent implements OnInit {
  // @ViewChild('ajax_loader') ajax_loader;

  constructor(private route : ActivatedRoute, private router : Router, private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit() {
    // this.ajax_loader.nativeElement.classList.add("active");
    this.route.params.subscribe(params => {
      if (params["id"]) {
        this.verifyEmail(params["id"]);
      }
    });
  }

  verifyEmail(id) {
    this.http.verifyEmail(id).subscribe(success => {
      success = success.auth;
      let token = success && success.access_token,
        center_id = success && success.center_id,
        businessName = success && success.client_name,
        client_id = success && success.logged_user.uuid,
        currency = success && success.currency,
        country = success && success.country,
        name = success && success.logged_user.first_name ,

        // name = success && success.logged_user.first_name + " " + success.logged_user.last_name,
        phone = success && success.logged_user.phone,
        setup_completed = success && success.logged_user.setup_completed,
        email = success && success.logged_user.email;

      var role = null;
      if (success.logged_user.is_super_admin == 0) {
        role = JSON.stringify(success.logged_user.roles);
      }

      console.log(setup_completed);

      localStorage.setItem("currentUser", JSON.stringify({
        appId: 3,
        email: email,
        token: token,
        center_id: center_id,
        name: name,
        country: country.iso_code_2,
        currency: currency.symbol,
        client_id: client_id,
        phone: phone,
        businessName: businessName,
        roles: role,
        setup_completed: setup_completed,
        intercomSecret: success.logged_user.secret
      }));

      if (!setup_completed) {
        this.router.navigate(["client/onboarding"]);
      } else {
        this.router.navigate(["client/dashboard"]);
      }
    }, error => {
      if (error.error.message == "Wrong token or your email is already verified.") {
        this.generalFunctions.openToast("email already verified", 3000, "success");

        this.router.navigate(["/login"], {
          queryParams: {
            setupCompleted: true
          }
        });
      } else {
        this.router.navigate(["/login"]);
        this.generalFunctions.openToast(error.message, 3000, "error");
      }
      console.log(error);
    });
  }
}
