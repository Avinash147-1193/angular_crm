import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyStaffComponent } from './verify-staff.component';

describe('VerifyStaffComponent', () => {
  let component: VerifyStaffComponent;
  let fixture: ComponentFixture<VerifyStaffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyStaffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
