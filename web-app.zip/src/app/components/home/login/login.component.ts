import {Component, OnInit, ViewChild} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ServerAuthService} from "../../../common/server-auth";
import {GeneralServices} from "../../../common/general-services";

@Component({templateUrl: "./login.component.html", styleUrls: ["./login.component.css"]})
export class LoginComponent implements OnInit {
  client: any = {
    email: null,
    password: null
  };
  reset_password: any = {
    email: null
  };
  returnUrl: string;
  forgot_password: boolean = false;
  link_sent: boolean = false;
  error: any = {
    login: null,
    reset_password: null
  };

  @ViewChild("ajax_loader")ajax_loader;

  constructor(private route : ActivatedRoute, private router : Router, private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {}

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  loginClient(form, e) {
    if (!form.valid) {
      e.target.classList.add("submit-false");
      this.error.login = "Enter valid values before you proceed!";
    } else {
      e.target.classList.remove("submit-false");
      localStorage.removeItem("currentUser");
      this.error.login = null;

      var btn = e.target.querySelectorAll("[type='submit']")[0];
      btn.classList.add("loading-ajax");
      this.ajax_loader.nativeElement.classList.add("active");

      this.http.login(this.client.email, this.client.password, "").subscribe(success => {
        success = success;
        console.log("success", success);
        let token = success && success.access_token,
          center_id = success && success.center_id,
          client_id = success && success.logged_user.uuid,
          currency = success && success.currency,
          country = success && success.country,
          businessName = success && success.client_name,
          name = success && success.logged_user.first_name + " " + success.logged_user.last_name,
          setup_completed = success && success.logged_user.setup_completed,
          phone = success && success.logged_user.phone;

        var role = null;
        if (success.logged_user.is_super_admin == 0) {
          role = JSON.stringify(success.logged_user.roles);
        }
        var localizedData = success.localization;
        localStorage.setItem("localization", JSON.stringify(localizedData));
        localStorage.setItem("currentUser", JSON.stringify({
          appId: 3,
          email: this.client.email,
          token: token,
          center_id: center_id,
          businessName: businessName,
          name: name,
          client_id: client_id,
          roles: role,
          setup_completed: setup_completed,
          intercomSecret: success.logged_user.secret
        }));

        if (setup_completed == true) {
          this.router.navigate(["client/dashboard"]);
        } else {
          this.router.navigate(["client/onboarding"]);
        }
      }, error => {
        this.error.login = error.message;
        btn.classList.remove("loading-ajax");
        this.ajax_loader.nativeElement.classList.remove("active");
      });
    }
  }

  resetPassword(form, e) {
    if (!form.valid) {
      e.target.classList.add("submit-false");

      this.error.reset_password = "Enter valid values before you proceed!";
    } else {
      e.target.classList.remove("submit-false");

      this.error.reset_password = null;
      var btn = e.target.querySelectorAll("[type='submit']")[0];
      this.resetPasswordHttp(e);
    }
  }

  resetPasswordHttp(e) {
    var btn = e.target.nodeName == "BUTTON"
      ? e.target
      : e.target.querySelectorAll("[type='submit']")[0];
    btn.classList.add("loading-ajax");
    this.ajax_loader.nativeElement.classList.add("active");

    this.http.resetPasswordLink(this.reset_password).subscribe(success => {
      var msg = "Password reset email successfully sent!";
      this.generalFunctions.openToast(msg, 3000, "success");
      this.forgot_password = false;
      this.link_sent = true;
      btn.classList.remove("loading-ajax");
      this.ajax_loader.nativeElement.classList.remove("active");
    }, error => {
      this.error.reset_password = error.message;
      btn.classList.remove("loading-ajax");
      this.ajax_loader.nativeElement.classList.remove("active");
    });
  }
}
