import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-color-toggle',
  templateUrl: './color-toggle.component.html',
  styleUrls: ['./color-toggle.component.scss']
})
export class ColorToggleComponent implements OnInit {
    @Input()color;
    @Input()selectedColor;
    @Output()valueChange = new EventEmitter();

    constructor() { }
    ngOnInit(): void {
        console.log('color', this.color)
    }

    setColor(color) {
        this.selectedColor = color;
        this.valueChange.emit(color)
    }
}
