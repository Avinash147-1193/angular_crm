import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ColorToggleComponent } from './color-toggle.component';

describe('ColorToggleComponent', () => {
  let component: ColorToggleComponent;
  let fixture: ComponentFixture<ColorToggleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColorToggleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColorToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
