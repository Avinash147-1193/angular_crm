import {
    Component,
    Input,
    OnInit,
    Output,
    ViewEncapsulation
} from '@angular/core';
import { GeneralServices } from 'app/common/general-services/general.service';
import {
    ServerAuthService
} from 'app/common/server-auth';
import {  EventEmitter } from '@angular/core';
@Component({
    selector: 'app-inline-field',
    templateUrl: './inline-field.component.html',
    styleUrls: ['./inline-field.component.scss'],
    encapsulation: ViewEncapsulation.ShadowDom
})
export class InlineFieldComponent implements OnInit {

    fieldValue: any;
    @Input() customerId: any;
    include_center: string;
    @Output()cardValue: any =  new EventEmitter();
    @Output()removeGCard: any = new EventEmitter();
    addingKey = 'redeem';
    @Input() remaining: any;
    currency: any;

    constructor(private http: ServerAuthService, private generalFunctions : GeneralServices,) {
        this.include_center = this.generalFunctions.includeCenter();
        this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;

    }

    ngOnInit(): void {}

    checkCardValidity() {

        this.addingKey = 'load';

        this.http.sendData("cards/gift_card_data" + this.include_center, { card_number: this.fieldValue, contact_id : this.customerId.id})
        .subscribe(success => {
            this.cardValue.emit(success.data)
            this.addingKey = 'remove';
            console.log('suc => ', success.data)

          }, error => {
            this.fieldValue = '';
            this.generalFunctions.openToast(error.message, 3000, "error");
            this.addingKey = 'redeem';
          });

    }

    removeGift() {
        this.fieldValue = '';
        this.addingKey = 'redeem';
        this.remaining = 0;
        this.removeGCard.emit()
    }

}
