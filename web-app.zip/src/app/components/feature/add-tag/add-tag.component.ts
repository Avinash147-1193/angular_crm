import {
  Component,
  OnInit,
  ViewChild,
  Output,
  Input,
  ViewEncapsulation,
  EventEmitter
} from "@angular/core";
import {GeneralServices} from "../../../common/general-services";
import {ServerAuthService} from "../../../common/server-auth";
import {SelectItem} from "primeng/api";
@Component({selector: "app-add-tag", templateUrl: "./add-tag.component.html", styleUrls: ["./add-tag.component.scss"], encapsulation: ViewEncapsulation.None})
export class AddTagComponent implements OnInit {
  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  @Input()contact_id: any;
  @Input()discount_id: any;
  @Output()valueChange = new EventEmitter();

  cars: SelectItem[] = [];
  selectedCar: any = {};
  tags: any = [];
  customer_id: "";
  include_center = "";
  isTags: boolean = false;
  @ViewChild("dd")dd;
  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getTags();
    this.getContactTags();

  }


  openDropdown() {
    this.dd.click();
  }

  getContactTags() {
    if (this.contact_id) {
      var endpoint = "contact/" + this.contact_id + this.include_center;
      let tags = [];
      this.tags = [];
      this.http.getData(endpoint).subscribe(data => {
        tags = [
          ...data.data.tags,
          ...data.data.contact.data.tags
        ];
        // data.data.contact.data.tags.length > 0
        //   ? data.data.contact.data.tags
        //   : data.data.tags;

        if (tags.length > 0) {

          tags.forEach(tag => {
            this.tags.push({
              label: {
                id: tag.id,
                data: tag
              }
            });
          });
        }


      });
    } else if (this.discount_id) {
      let tags = [];
      this.tags = [];
      this.http.getData(`discount/${this.discount_id}${this.include_center}`).subscribe(response => {
        tags = response.data.applicable_customer_tags;
        if (tags.length > 0) {
          tags.forEach(tag => {
            this.tags.push({
              label: {
                id: tag.id,
                data: tag
              }
            });
          });
        }
        this.valueChange.emit(this.tags);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
      });
    }
  }

  checkExistance(data) {
    let state = true;
    this.tags.forEach(tag => {
      if (tag.label.id == data.label.id) {
        this.generalFunctions.openToast("Tag already added for customer", 3000, "error");
        state = false;
      }
    });

    return state;
  }

  addTo(data) {
    if (this.checkExistance(data)) {
      this.tags.push(data);
      if (this.contact_id) {
        this.http.sendData(`contact/${this.contact_id}/tags/attach${this.include_center}`, {tag_id: data.label.id}).subscribe(response => {
          this.generalFunctions.openToast("Tag added", 3000, "success");
        }, err => {
          this.generalFunctions.openToast(err.message, 3000, "error");
        });
      } else {
        this.valueChange.emit(this.tags);
      }
    }
  }

  detachTag(tag) {
    if (this.contact_id) {
      this.http.updateData(`contact/${this.contact_id}/tags/detach${this.include_center}`, {tag_id: tag.label.id}).subscribe(response => {
        this.getContactTags();
        this.generalFunctions.openToast("Tag removed", 3000, "success");
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });
    } else {
      let tags = [];
      let id = tag.label.id;
      tags = this.tags.filter(ta => {
        return ta.label.id !== id;
      });
      this.tags = tags;
      console.log("this.tags", tags);
      this.valueChange.emit(this.tags);
    }
  }

  getTags() {
    this.http.getData(`tags${this.include_center}`).subscribe(response => {
      let tags = response.tags;
      tags.forEach(tag => {
        if (this.contact_id) {
          if (tag.is_system == 0) {
            let template = {
              label: tag.name,
              value: {
                id: tag.id,
                data: tag
              }
            };
            this.cars.push(template);
          }
        } else {
          let template = {
            label: tag.name,
            value: {
              id: tag.id,
              data: tag
            }
          };
          this.cars.push(template);
        }
      });

      this.isTags = true;
    }, err => {});
  }
}
