import {Component, OnInit, Output, Input, EventEmitter} from '@angular/core';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {MembershipTypes} from 'app/constants';

@Component({selector: 'app-services-modal', templateUrl: './services-modal.component.html', styleUrls: ['./services-modal.component.scss']})
export class ServicesModalComponent implements OnInit {
    pop_up_for: any = 'services';
    center_id: any;
    planData: any;
    packData: any;
    allServices: any = [];
    copyApplicables: any = [];
    @Output()valueChange = new EventEmitter();
    @Input()applicables = [];

constructor(private generalFunctions: GeneralServices, private http: ServerAuthService) {}

  ngOnInit() {
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    if (this.applicables.length == 0) {
      this.getServices();
    } else {
      this.allServices = [...this.applicables];
    }
  }

  getServices() {
    this.http.sendData('plan?center_id=' + this.center_id, '').subscribe(response => {
      this.planData = response.data.filter((plan) => plan.type === MembershipTypes.PLAN || plan.type === MembershipTypes.SUBSCRIPTION);
      this.packData = response.data.filter((pack) => pack.type === MembershipTypes.PACK);
      this.createCheckboxes();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  createCheckboxes() {
    this.allServices = [];
    this.planData.forEach(element => {
      element.type = 'plan';
      element.checked = false;
      this.allServices.push(element);
    });
    this.packData.forEach(element => {
      element.type = 'pack';
      element.checked = false;
      this.allServices.push(element);
    });
  }

  emitServices() {
    let finalObject = [];
    this.allServices.forEach(service => {
      if (service.checked == true) {
        finalObject.push({
          service_type_id: service.id,
          service_id: 1,
          service_name: service.name
        });
      }
    });
    console.log('finalObject, this.allServices', finalObject, this.allServices)
    this.valueChange.emit(this.allServices);
  }

  //changing the event to close
  cancelEmitServices() {
    this.valueChange.emit('close');
  }

  markChecked(service) {
    service.checked = !service.checked;
  }
  checkBoxUpdated(service) {
    service.checked = !service.checked;
  }
}
