import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy,
  OnChanges,
  Output,
  Input,
  EventEmitter
} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {Location} from "@angular/common";
import {GeneralServices} from "../../../common/general-services";
import {ServerAuthService} from "../../../common/server-auth";

@Component({selector: "app-image-upload-rect", templateUrl: "./image-upload-rect.component.html", styleUrls: ["./image-upload-rect.component.scss"]})
export class ImageUploadRectComponent implements OnInit,
OnChanges {
  @Input()image_url: any;
  @Input()isService = false;
  @Input()dis_abled: any = false;
  @Output()valueChange = new EventEmitter();
  include_center: any = null;
  // loaderflags starts
  heyLoader: boolean = false;
  heyLoaderImage: boolean = false;
  fileLoaded: any = null;
  uploadFlag = false;
  imagePreview: boolean = false;
  noImage: any = false;
  show_update_profile_picture_popup: boolean = false;
  webcam_initiate: boolean = false;
  isCameraAdapted: boolean = true;
  videoStream: any = null;
  photo_selected: boolean = false;
  photo_captured: boolean = false;
  @ViewChild("video")video;
  @ViewChild("canvas")canvas;
  @ViewChild("photo_tag")photo_tag;

  @ViewChild("selected_image")selected_image;

  constructor(private location : Location, private generalFunctions : GeneralServices, private http : ServerAuthService, private router : Router, private route : ActivatedRoute, private activatedRoute : ActivatedRoute) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
  }
  ngOnChanges() {}

  removeFile() {
    this.image_url = null;
    this.valueChange.emit(this.image_url);
    this.noImage = true;
  }
  imageClick(event) {
    document.getElementById("imageInput").click();
  }

  fileUpload(event) {
    console.log("event", event.target.files[0].size);
    let fSize = event.target.files[0].size;

    if (event.target.files && event.target.files[0] && fSize < 2000000) {
      const file = event.target.files[0];
      const fileType = file.type.split("/");
      this.heyLoaderImage = true;
      const uploadData = new FormData();
      uploadData.append("image", file);
      uploadData.append("type", "plans");

      this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
        this.heyLoaderImage = false;
        this.show_update_profile_picture_popup = false;
        this.image_url = response.url;
        this.valueChange.emit(this.image_url);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
      });

      this.fileLoaded = "File uploaded";
      this.uploadFlag = true;
      this.imagePreview = true;
    } else {
      this.generalFunctions.openToast("Please upload a image of size 2mb or less", 3000, "error");
    }
  }

  openPhotoPopup() {
    this.webcam_initiate = true;
    let width = 400;
    let height = 400;
    setTimeout(() => {
      navigator.mediaDevices.getUserMedia({video: true, audio: false}).then(stream => {
        this.video.nativeElement.srcObject = stream;
        this.videoStream = stream;
        this.video.nativeElement.play();
      }).catch(err => {
        this.isCameraAdapted = false;
      });

      this.video.nativeElement.addEventListener("canplay", e => {
        height = width;
        if (isNaN(height)) {
          height = width;
        }

        this.video.nativeElement.setAttribute("width", width);
        this.video.nativeElement.setAttribute("height", height);
      }, false);
    }, 200);
  }

  takePicture() {
    var context = this.canvas.nativeElement.getContext("2d");
    this.canvas.nativeElement.width = 400;
    this.canvas.nativeElement.height = 400;
    context.drawImage(this.video.nativeElement, -66.66, 0, 533.33, 400);

    var data = this.canvas.nativeElement.toDataURL("image/png");
    this.photo_tag.nativeElement.setAttribute("src", data);
    this.photo_captured = true;
  }

  changePicture() {
    var context = this.canvas.nativeElement.getContext("2d");
    context.fillStyle = "#AAA";
    context.fillRect(0, 0, 0, 0);

    var data = this.canvas.nativeElement.toDataURL("image/png");
    this.photo_tag.nativeElement.removeAttribute("src");
    this.photo_captured = false;
  }

  stopWebcam() {
    if (this.videoStream) {
      this.videoStream.getTracks()[0].stop();
    }
    this.webcam_initiate = false;
  }

  selectPicture(e) {
    var src = this.photo_tag.nativeElement.getAttribute("src");
    e.target.classList.add("loading-ajax");

    var data = this.canvas.nativeElement.toDataURL("image/png");
    this.photo_tag.nativeElement.removeAttribute("src");

    var obj = {};

    obj["photo"] = src;

    console.log("src", src);
    const uploadData = new FormData();

    uploadData.append("blob", src);
    uploadData.append("type", "contacts");

    this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
      console.log("this.customer_data", response);
      var context = this.canvas.nativeElement.getContext("2d");
      context.fillStyle = "#AAA";
      context.fillRect(0, 0, 0, 0);
      this.photo_captured = false;
      this.photo_selected = true;
      this.stopWebcam();
      this.heyLoaderImage = false;
      this.image_url = response.url;
      this.valueChange.emit(this.image_url);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.stopWebcam();
      this.photo_captured = false;
      this.photo_selected = true;
      this.webcam_initiate = false;
    });
  }
}
