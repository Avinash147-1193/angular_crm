import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageUploadRectComponent } from './image-upload-rect.component';

describe('ImageUploadComponent', () => {
  let component: ImageUploadRectComponent;
  let fixture: ComponentFixture<ImageUploadRectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImageUploadRectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageUploadRectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
