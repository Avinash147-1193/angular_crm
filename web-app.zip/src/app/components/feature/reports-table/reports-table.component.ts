import {Component, OnInit, ViewEncapsulation, ElementRef, ViewChild, Input} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {SelectItem, Header} from 'primeng/api';



@Component({
  selector: 'app-reports-table',
  templateUrl: './reports-table.component.html',
  styleUrls: ['./reports-table.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class ReportsTableComponent implements OnInit {

  @Input() reportsMode: any;
  reportMode: any;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  startEndDate: any;
  center_id: any;
  currency: any;
  reportsPagination: any = {
    count : '',
    current_page:'',
    links:'',
    per_page:'',
    total:'',
    total_page:'',
    from:'',
    to:''
  };
  reportsSummary: any;
  reportsData: any = [];
  pop_custom = false;
  reqState: any = {};

  colDropdown: SelectItem[] = [];

  colSelected: any = [];

  descendingOrder: boolean;
  DatepickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default'
  };
  sortTable = {

  };
  sortTablePayment = {

  };
  populateSummary: boolean;
  populateBody: boolean;

  hovered = false;
  viewHeight = 22;
  hoveredLeft = false;
  hoveredRight = true;
  @ViewChild('mainScreen', {
    read: ElementRef,
    static: false
  })
  elementView: ElementRef;

  @ViewChild('sort_direction', {
    read: ElementRef,
    static: false
  })
  SortDirection: ElementRef;
  reportsHeader: any;



  reportsDefaultFilter = {
    data: {
        rules: [

        ],
        condition: 'and'
    },
    filters: [

    ],
    columns : [],
    handleValueChange: (value) => {
       this.handleValueChanged(value);
    },
    sorting : {
        sort_by: '',
        sort_direction: ''
    }

}

mappedHeader: any;
currentFilter: any;
currentPage = 1;
page: any;
    pop_up_for: string;
    message: any;


  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private http: ServerAuthService,
    private generalFunctions: GeneralServices) {
  this.bsRangeValue = [this.bsValue, this.maxDate];
}


    ngOnInit(): void {
      this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
      this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
      this.getReports();
    }

    checkColumn(data) {
        if (data.is_selectable === true) {
            return this.colSelected.includes(data.field)
        }
        return true;
    }

    exportReport() {
        this.http.sendData(`reports/advanced/${this.reportsMode}?export=true&center_id=${this.center_id}`, this.currentFilter)
        .subscribe(response => {
            console.log('download response', response)
          const str = response.url;
          const res = str.split('/');
          const name = res[res.length - 1];
          this.download(response.url, name);
        }, err => {});
      }

      download(url, name) {
        const a = document.createElement('a');
        a.setAttribute('href', url);
        a.setAttribute('download', 'report.csv');
        document.querySelector('.link-container').appendChild(a);
        a.click();
        const container = document.querySelector('.link-container');
      }

    scrollRight() {
        this.elementView.nativeElement.scrollLeft += 150;
        this.hoveredLeft = true;
        const element = this.elementView.nativeElement;
        const hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
        this.hoveredRight = true;
        if (Math.round(element.scrollWidth) - Math.round(element.scrollLeft) == element.clientWidth) {
            this.hoveredRight = false;
        }
    }

    scrollLeft() {
        this.hoveredRight = true;
        const element = this.elementView.nativeElement;
        this.hoveredLeft = true;
        if ( Math.round(element.scrollLeft) === 0 ) {
            this.hoveredLeft = false;
        }
        this.elementView.nativeElement.scrollLeft -= 150;
    }

    // updateTimeline(range, sort, type) {
    // if (this.reportsMode === 'customers') {
    //     this.populateBody = false;
    //     const start = moment(this.bsRangeValue[0]).format('YYYY-MM-DD');
    //     const end = moment(this.bsRangeValue[1]).format('YYYY-MM-DD');
    //     const reqObj = {};
    //     const sortBy = sort;

    //     if (sortBy !== null) {
    //         this.resetSortTable(sort);
    //         console.log('this.sortTable', this.sortTable);
    //         if (this.sortTable[sort]) {
    //           reqObj['sortBy'] = {
    //             [sort]: 'desc'
    //           };
    //         } else {
    //           reqObj['sortBy'] = {
    //             [sort]: 'asc'
    //           };
    //         }
    //       }
    //       reqObj['starts_at'] = start;
    //       reqObj['ends_at'] = end;
    //       this.reqState = reqObj;
    //       this.getReports();
    // }

    // if (this.reportMode === 'sale') {
    //     if (type == null) {
    //     this.sortTable = {
    //         created_at: false,
    //         id: false,
    //         subtotal: false,
    //         discount: false,
    //         amount_refunded: false,
    //         amount_total: false,
    //         amount_write_off: false,
    //         amount_due: false,
    //         tax: false
    //     };
    //     }

    //     this.populateBody = false;

    //     const start = moment(this.bsRangeValue[0]).format('YYYY-MM-DD');
    //     const end = moment(this.bsRangeValue[1]).format('YYYY-MM-DD');
    //     const reqObj = {};
    //     const sortBy = sort;

    //     if (sortBy !== null) {
    //     this.resetSortTable(sort);
    //     console.log('this.sortTable', this.sortTable);
    //     if (this.sortTable[sort]) {
    //         reqObj['sortBy'] = {
    //         [sort]: 'desc'
    //         };
    //     } else {
    //         reqObj['sortBy'] = {
    //         [sort]: 'asc'
    //         };
    //     }
    //     }
    //     reqObj['starts_at'] = start;
    //     reqObj['ends_at'] = end;
    //     this.reqState = reqObj;
    //     // this.saleWithFilter(reqObj);
    // }

    // if (this.reportMode === 'payment') {
    //     if (type == null) {
    //     this.sortTablePayment = {
    //         created_at: false,
    //         payment_id: false,
    //         sale_id: false,
    //         amount: false
    //     };
    //     }

    //     this.populateBody = false;

    //     const start = moment(this.bsRangeValue[0]).format('YYYY-MM-DD');
    //     const end = moment(this.bsRangeValue[1]).format('YYYY-MM-DD');
    //     const reqObj = {};
    //     const sortBy = sort;

    //     if (sortBy !== null) {
    //     // this.resetPaymentSortTable(sort);
    //     if (this.sortTablePayment[sort]) {
    //         reqObj['sortBy'] = {
    //         [sort]: 'desc'
    //         };
    //     } else {
    //         reqObj['sortBy'] = {
    //         [sort]: 'asc'
    //         };
    //     }
    //     }
    //     reqObj['starts_at'] = start;
    //     reqObj['ends_at'] = end;
    //     this.reqState = reqObj;

    //     // this.paymentWithFilter(reqObj);
    // }

    // }

    resetSortTable(sort) {
        for (const key in this.sortTable) {
        if (this.sortTable.hasOwnProperty(key)) {
            if (key == sort) {
            this.sortTable[sort] = !this.sortTable[sort];
            } else {
            this.sortTable[key] = false;
            }
        }
        }
    }


    columnPicker(columns) {
        this.colSelected = [];
        this.colDropdown = [];
        columns.forEach(element => {
            if (element.is_selectable === true) {
                const data = {
                    label : element.name,
                    value : element.field
                }
                this.colDropdown.push(data);
                this.colSelected.push(element.field)
            }
        });
    }


    getReports() {
        const reportsUrl = `reports/advanced/${this.reportsMode}?page=${this.currentPage}&center_id=${this.center_id}`;
        const reportsColUrl = `reports/advanced/${this.reportsMode}/columns?center_id=${this.center_id}`;

        const reportsFiltersUrl = `reports/advanced/${this.reportsMode}/filters?center_id=${this.center_id}`;

        this.http.getData(reportsColUrl).subscribe(response => {
            this.reportsHeader = response;
            this.transformHeaders();
        })



        this.http.getData(reportsFiltersUrl).subscribe(response => {
        this.reportsDefaultFilter.data = response.default_filter;
        this.reportsDefaultFilter.filters = response.filters;
        this.reportsDefaultFilter.sorting.sort_by = response.default_sorting.field;
        this.reportsDefaultFilter.sorting.sort_direction = response.default_sorting.sorting;
            this.reportsDefaultFilter.columns = response.filters.map((items) => {
                return items.field ;
            })

            this.columnPicker(response.filters);
            const filter = this.getFilterStructure(
                this.reportsDefaultFilter.columns,
                this.reportsDefaultFilter.data,
                this.reportsDefaultFilter.sorting
                );
                this.currentFilter = filter;
            this.getReportData(reportsUrl, filter);
        });

        setTimeout(() => {
            const hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
            this.hoveredLeft = this.hoveredRight = hs;
        }, 1000);
    }


    getFilterStructure(
        col,
        filter,
        sort
        ) {
        return {
            columns: [...col],
            filters: filter.length === 0 ? {rules : []} : {...filter} ,
            sort_by: sort.sort_by,
            sort_direction: sort.sort_direction
        };
    }

    pageChanged(event) {
        this.currentPage = event;
        const reportsUrl = `reports/advanced/${this.reportsMode}?page=${this.currentPage}&center_id=${this.center_id}`;
        this.getReportData(reportsUrl, this.currentFilter);

    }

    getReportData(reportsUrl: string, filter: any) {

        this.populateBody = false;
        this.http.sendData(reportsUrl, filter).subscribe(result => {
            this.reportsData = result.data.data;
            this.reportsPagination['count'] = result.data.per_page;
            this.reportsPagination['current_page'] = result.data.current_page;
            this.reportsPagination['links'] = result.data.links;
            this.reportsPagination['per_page'] = result.data.per_page;
            this.reportsPagination['total'] = result.data.total;
            this.reportsPagination['total_page'] = result.data.total_page;
            this.reportsPagination['from'] = result.data.from;
            this.reportsPagination['to'] = result.data.to;
            this.populateBody = true;
        });

        const reportsSummary = `reports/advanced/${this.reportsMode}/summary?center_id=${this.center_id}`;

        this.http.sendData(reportsSummary, filter).subscribe(response => {
            this.reportsSummary = response.data;
        })
    }


    transformHeaders() {
        const mappedHeader = {};
        this.reportsHeader.forEach(header => {
            mappedHeader[header.field] = header;
        });
        this.mappedHeader = mappedHeader;

    }

    handleValueChanged(value) {
        this.currentPage = 1;
        const filter = this.getFilterStructure(this.reportsDefaultFilter.columns, value, this.reportsDefaultFilter.sorting)
        this.currentFilter = this.getFilterStructure(this.reportsDefaultFilter.columns, value, this.reportsDefaultFilter.sorting)
        const reportsUrl = `reports/advanced/${this.reportsMode}?page=${this.currentPage}&center_id=${this.center_id}`;
        this.getReportData(reportsUrl, filter);
    }


    columnSelected(event) {

        const reportsUrl = `reports/advanced/${this.reportsMode}?page=${this.currentPage}&center_id=${this.center_id}`;
        const column = [];
        this.reportsHeader.forEach((col) => {

           col.is_selectable ?
           // tslint:disable-next-line: no-unused-expression
           (this.colSelected.includes(col.field) ? column.push(col.field) : null )
           :
            column.push(col.field)
        })
        const filter = this.getFilterStructure(column, this.reportsDefaultFilter.data, this.reportsDefaultFilter.sorting);
        this.reportsDefaultFilter.columns = filter.columns;
        this.getReportData(reportsUrl, filter);
    }


    getSelectableHeader(header) {
       return  header.is_selectable ? this.reportsDefaultFilter.columns.includes(header.field) : true
    }

    sortReports(sortArr) {
        this.reportsDefaultFilter.sorting.sort_by === sortArr[0]
        ?
        sortArr[1] = this.reportsDefaultFilter.sorting.sort_direction === 'desc'
        ?
        'asc' : 'desc'
        :
        sortArr[1] = sortArr[1];
        const obj = {sort_by: sortArr[0], sort_direction: sortArr[1]}
        this.currentPage = 1;
        const reportsUrl = `reports/advanced/${this.reportsMode}?page=${this.currentPage}&center_id=${this.center_id}`;
        const filter = this.getFilterStructure(this.reportsDefaultFilter.columns, this.reportsDefaultFilter.data, obj);
        this.reportsDefaultFilter.sorting['sort_by'] = filter.sort_by;
        this.reportsDefaultFilter.sorting['sort_direction']  = filter.sort_direction;
        this.currentFilter = filter;
        // this.restoreArrow( sortArr[2], sortArr[1]);
        this.getReportData(reportsUrl, filter);
    }

    private restoreArrow(ref, dir) {
        const el = document.querySelectorAll('.filter-up');


        el.forEach(element => {
            element.classList.contains('filter-up')
            ?
            element.classList.remove('filter-up')
            :
            null;
        });
        if (dir === 'desc') {
            ref.classList.add('filter-up');
        }


    }


    openMessage(message){
        this.pop_up_for = 'message';
        this.message = message;
    }

    formatMsg(mgs){
        return mgs.replace(/<[^>]*>?/gm, '');
    }
 }
