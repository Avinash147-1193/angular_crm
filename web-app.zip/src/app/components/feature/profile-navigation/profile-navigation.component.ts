import {Component, OnInit, Input, Output, EventEmitter} from "@angular/core";

@Component({selector: "app-profile-navigation", templateUrl: "./profile-navigation.component.html", styleUrls: ["./profile-navigation.component.scss"]})
export class ProfileNavigationComponent implements OnInit {
  setActive: any;
  @Input()items;
  @Input()def;
  @Output()outputData = new EventEmitter();
  constructor() {}
  ngOnInit(): void {
      if(this.def){
        this.setActive = this.def;
      }
      else{
        this.setActive = this.items[0];
      }
  }

  emitData(data) {
    this.setActive = data;
    this.outputData.emit(data);
  }
}
