import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation,
  SimpleChanges,
  OnChanges,
  ChangeDetectorRef
} from '@angular/core';
import {ServerAuthService} from 'app/common/server-auth';
// import 'tinymce';
// declare var tinymce: any;


// tslint:disable-next-line: max-line-length
@Component({selector: 'app-message-editor', templateUrl: './message-editor.component.html', styleUrls: ['./message-editor.component.scss'], encapsulation: ViewEncapsulation.None})
export class MessageEditorComponent implements OnInit, OnChanges {
  @Input()quillMessage;
  @Input()studioInfo: boolean = false;
  @Input()showToolbar: boolean = true;
  @Input()tags;
  @Input()showTags: boolean = true;
  editorConfigwithout:any = {};
    withButton = false;

  @Output()messageChange = new EventEmitter();

  editorInstance: any = {};
  checkFlag = false;
  loginUser: any = {};
  centerInfo: any = {
    client: {
      image_url: null
    }
  };

  editorConfig: any ;
  brandcolor : any;

  constructor(private http: ServerAuthService, private cdRef: ChangeDetectorRef) {}

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnChanges(changes: SimpleChanges): void {
    console.log('changes', changes)
    if (Array.isArray(this.tags) && this.showTags) {
        if( this.tags.includes('online_class_link')) {
            // this.getCenterInfo();
            this.addButton()
            console.log('add')
        }
        else if(this.tags.length > 0) {
            this.checkFlag = true;
            this.withButton = false;
            this.editorConfig =  {
                base_url: '/tinymce',
                suffix: '.min',
                branding : false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table paste code help wordcount'
                ],
                toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent',
            }
        }
    } else if (!this.showTags) {
        this.checkFlag = true;
        this.withButton = false;
        this.editorConfig =  {
            base_url: '/tinymce',
            suffix: '.min',
            branding : false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent',
        }
    }
  }

  ngOnInit() {
    this.loginUser = JSON.parse(localStorage.getItem('currentUser'));
    this.getCenterInfo();
  }



  addButton() {
    let that = this;
    this.checkFlag = true;
    this.withButton = true;
    this.editorConfigwithout =  {
        base_url: '/tinymce',
        suffix: '.min',
        branding : false,
        plugins: [
            'advlist autolink lists link image charmap print preview anchor',
            'searchreplace visualblocks code fullscreen',
            'insertdatetime media table paste code help wordcount'
        ],
        toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | myCustomToolbarButton',
        setup : function (editor) {
            editor.ui.registry.addButton('myCustomToolbarButton', {
                text: 'Event Link',
                onAction: function (_) {
                    // editor.insertContent('<a  class="anchor-button" style="box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.24); white-space : nowrap; background-color:#eb3b7b; text-transform: capitalize; display:inline-flex; align-items:center; justify-content: center; width: 163px; height: 48px; font-size: 14px; text-align: center; color: #ffffff; font-weight: bold; cursor: pointer; border: none; text-decoration:none;" href="{online_class_link}" target="_blank" > Event Link </a>');
                    editor.insertContent(`<a style="box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.24); white-space : nowrap; background-color:${that.brandcolor}; text-transform: capitalize; display:inline-block; padding: 14px 0; vertical-align: middle;  width: 163px; font-size: 14px; text-align: center; color: #ffffff; font-weight: bold; cursor: pointer; border: none; text-decoration:none; border-radius:4px;" href="{online_class_link}" target="_blank" > Join event</a>`);
                }
                });
        }
    }
    this.cdRef.detectChanges();
  }

  getCenterInfo() {
    this.http.getData(`center/${this.loginUser.center_id}`).subscribe(response => {
      this.centerInfo = response.data;
      this.brandcolor = response.data.settings.general.brand_color;
      console.log('this.centerInfo', this.brandcolor)
    }, error => {
      console.log(error);
    });
  }

  editorCreated(e) {
    this.editorInstance = e;
  }

  updateMessage() {
    this.messageChange.emit(this.quillMessage);
  }

  appendTag(tagLabel) {
   const cursor =  this.editorInstance.editor.selection.getSel();
   console.log('cursor', cursor);
   this.editorInstance.editor.insertContent('{' + tagLabel + '}', cursor.anchorOffset);
  }
}
