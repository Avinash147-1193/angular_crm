import {
    Component,
    OnInit,
    ViewEncapsulation,
    ViewChild,
    ElementRef
} from "@angular/core";
import {
    Router,
    ActivatedRoute
} from "@angular/router";
import {
    ServerAuthService
} from "app/common/server-auth";
import {
    HttpClient
} from "@angular/common/http";
import {
    SelectItem
} from "primeng/api";
import {
    COUNTRIES
} from "../onboarding/countries";

import {
    CURRENCIES
} from "../onboarding/currencies";
import {
    GeneralServices
} from "../../common/general-services";

import momenttz from 'moment-timezone';
import csc from 'country-state-city';


@Component({
    selector: 'app-location',
    templateUrl: './location.component.html',
    styleUrls: ['./location.component.scss'],
    encapsulation: ViewEncapsulation.None
})


export class LocationComponent implements OnInit {



    @ViewChild("location") location: ElementRef;
    disableButton: boolean = false;
    loader: boolean = false;

    currentUser = JSON.parse(localStorage.getItem("currentUser"));
    centerId: string = "";
    clientName: string = this.currentUser.name;
    ipInfo: any = {};
    countries: any = COUNTRIES;
    currencies: any = CURRENCIES;
    regionDropdown: SelectItem[] = [];
    allServices: any = {};
    setup_disabled = false;


    formStages = [{
        name: "stage-one",
        stage: 1
    }, {
        name: "stage-two",
        stage: 2
    }, {
        name: "stage-three",
        stage: 3
    }];

    formHeader: any = {
        title: "",
        description: ""
    };

    currentStage: number = 1;

    studioDetails: any = {
        branch: "",
        address: "",
        city: "",
        state: "",
        pincode: "",
        country_id: "",
        currency_id: "",
        timezone: null,
        region_id: "",
        region_type: "existing",
        region_name: "",
        phone : {
            code : ''
        }
    };

    isWebstoreUrlEdited: boolean = false;

    countriesDropdown: SelectItem[] = [];
    countryCodesDropdown: SelectItem[] = [];
    currenciesDropdown: SelectItem[] = [];
    timezonesDropdown: SelectItem[] = [];
    statesDropdown: SelectItem[] = [];



    validationFields: any = {
        name: false,
        url: false,
        location: false,
        phone_number: false
    };

    nextOne: boolean = false;
    nextTwo: boolean = false;

    reachOutDropdown: any = [{
        label: "Friend",
        value: "friend"
    }, {
        label: "Social media",
        value: "social media"
    }, {
        label: "Blog",
        value: "blog"
    }, {
        label: "We reached out to you",
        value: "we"
    }, {
        label: "Other",
        value: "other"
    }]

    studioTypes: any = [{
        label: "Gym",
        value: "gym"
    }, {
        label: "Yoga",
        value: "yoga"
    }, {
        label: "CrossFit",
        value: "crossfit"
    }, {
        label: "Bootcamp",
        value: "bootcamp"
    }, {
        label: "Cycling",
        value: "cycling"
    }, {
        label: "Boxing",
        value: "boxing"
    }, {
        label: "Martial Arts",
        value: "martialarts"
    }, {
        label: "Pilates",
        value: "pilates"
    }, {
        label: "Barre",
        value: "barre"
    }, {
        label: "Dance",
        value: "dance"
    }, {
        label: "Other",
        value: "other"
    }];

    loaderOn: any;

    classesServiceCode: number;
    appointmentsServiceCode: number;
    regions: any;

    constructor(private http: ServerAuthService, private router: Router, private generalFunctions: GeneralServices) {}
    ngOnInit() {
        this.loaderOn = true;
        this.loader = true;


        this.centerId = this.currentUser["center_id"];
        this.formHeader = {
            title: `Welcome ${this.clientName}`,
            description: "Tell us about your business"
        };

        this.getCountries();
        this.getCurrencies();

        this.getRegion();
        this.getAllServices();
    }

    getRegion() {
        this.http.getData("regions").subscribe(success => {
            this.regions = success;

            success.forEach(element => {
                this.regionDropdown.push({
                    label: element.name,
                    value: element.id,

                })
            });

            if (this.regionDropdown.length > 0) {
                this.studioDetails.region_id = this.regionDropdown[0].value;
                this.setRegion();
            }
        }, error => {});
    }

    setRegion() {
        const regionSelected = this.regions.filter(region => region.id === this.studioDetails.region_id)[0];
        console.log('regionSelected', regionSelected)
        const code = regionSelected.country.iso_code_2;
        const statesDump =  csc.getStatesOfCountry(csc.getCountryByCode(String(code)).id);
        this.statesDropdown = statesDump.map(state => { return {'label' : state.name, 'value' : state.name}});
        this.studioDetails.state = this.statesDropdown[0].value;
    }

    formValidate(field) {
        let isValid = true;

        switch (field) {

        }

        return !isValid;
    }

    valdiateUrl(link) {
        var re = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
        return !re.test(link) && link.replace(/\s/g, "").length > 4;
    }

    goToNextForm(formNumber: number) {
        switch (formNumber) {
            case 1:
                this.setFormHeader(1);
                break;

            case 2:
                this.nextOne = true;

                if (!(this.validationFields.name && this.validationFields.url)) {
                    return;
                }

                this.setFormHeader(2);
                break;

            case 3:
                this.nextTwo = true;

                if (!(this.validationFields.location && this.validationFields.phone_number)) {
                    return;
                }

                this.setFormHeader(3);
                break;

            default:
                break;
        }

        // move to next stage of the form
        this.currentStage = formNumber;
    }

    goToPreviousForm(formNumber: number) {
        this.setFormHeader(formNumber);
        this.currentStage = formNumber;
    }

    setFormHeader(formNumber: number) {
        switch (formNumber) {
            case 1:
                this.formHeader = {
                    title: `Welcome ${this.clientName}!`,
                    description: "Tell us about your business"
                };
                break;

            case 2:
                this.formHeader = {
                    title: this.studioDetails.name,
                    description: "Setup your first location"
                };
                break;

            case 3:
                this.formHeader = {
                    title: this.studioDetails.name + ", " + this.studioDetails.location,
                    description: "Tell us about the services you offer"
                };
                break;

            default:
                break;
        }
    }

    studioNameChanged() {
        // if(!this.isWebstoreUrlEdited) {
        // 	this.updateWebstoreUrl();
        // }
        this.updateWebstoreUrl();
    }

    updateWebstoreUrl() {
        this.studioDetails.url = this.studioDetails.name.replace(/\s/g, "").toLowerCase();
    }

    webstoreUrlEdited() {
        this.isWebstoreUrlEdited = true;
    }

    getCountries() {
        this.http.getData(`countries?center+id=` + this.centerId).subscribe(response => {
            this.countries = response.data;
            this.prepareCountriesDropdown();
        }, error => {
            console.log(error);
        });
    }

    // preapreReachOutDropdown() {
    // 	this.reachOut.forEach(element => {
    // 		let reachOutCode = {
    // 			label: "",
    // 			value: ""
    // 		};
    // 		reachOutCode.label = element.name;
    // 		reachOutCode.value = element.value;
    // 		this.reachOutDropdown.push(reachOutCode);
    // 	});

    // 	console.log("this.reachOutDropdown", this.reachOutDropdown);
    // }

    prepareCountriesDropdown() {
        for (let i = 0; i < this.countries.length; i++) {
            let country = {
                label: "",
                value: 0
            };

            let code = {
                label: "",
                value: 0
            };

            // country name
            country.label = this.countries[i].name;
            country.value = this.countries[i].id;

            // country code
            code.label = this.countries[i].isd_code;
            code.value = this.countries[i].id;

            this.countriesDropdown.push(country);
        }


        // get ip info and set dropdown value
        this.getIPinfo();
    }

    getCurrencies() {
        this.http.getData(`currencies?center+id=` + this.centerId).subscribe(response => {
            this.currencies = response.data;
            this.loader = false;

            this.prepareCurrenciesDropdown();
        }, error => {
            this.loader = false;
        });
    }

    prepareCurrenciesDropdown() {
        for (let i = 0; i < this.currencies.length; i++) {
            let currency = {
                label: "",
                value: "",
                id: 0
            };

            currency.label = `${this.currencies[i].name} (${this.currencies[i].code})`;
            currency.value = this.currencies[i].code;

            this.currenciesDropdown.push(currency);
        }
    }

    setTimezone() {
        this.studioDetails.timezone = null;

       let selectedCountry = COUNTRIES.filter(country => this.studioDetails.country == country.id);
       const statesDump =  csc.getStatesOfCountry(csc.getCountryByCode(String(selectedCountry[0].iso_code_2)).id);
       this.statesDropdown = statesDump.map(state => { return {'label' : state.name, 'value' : state.name}})
       const timezones = momenttz.tz.zonesForCountry(String(selectedCountry[0].iso_code_2));
       this.timezonesDropdown = timezones.map(tz => {
            return {'label' : tz, 'value': tz}
        })
        if ( !this.studioDetails.timezone) {
            this.studioDetails.timezone = this.timezonesDropdown[0].value;
        }

        if ( !this.studioDetails.state) {
            this.studioDetails.state = this.statesDropdown[0].value;
        }
    }



    getIPinfo() {
        let apiEndpoint = "https://ipapi.co/json/";

        this.http.getExternalData(apiEndpoint).subscribe(response => {
            this.ipInfo = response;
            this.setCountryDropdownValue();
            this.setCurrencyDropdownValue();
        }, error => {});
    }

    setCountryDropdownValue() {
        for (let i = 0; i < this.countriesDropdown.length; i++) {
            if (this.countriesDropdown[i].label === this.ipInfo.country_name) {
                this.studioDetails.country = this.countriesDropdown[i].value;
            }
        }
        this.setTimezone();
    }

    setCurrencyDropdownValue() {
        this.studioDetails.currency = this.ipInfo.currency;
    }

    getAllServices() {
        this.http.getData("services").subscribe(response => {
            this.allServices = response;

            for (let i = 0; i < this.allServices.length; i++) {
                switch (this.allServices[i].code) {
                    case "CLASSES":
                        this.classesServiceCode = this.allServices[i].id;
                        break;

                    case "APPOINTMENTS":
                        this.appointmentsServiceCode = this.allServices[i].id;
                        break;

                    default:
                        // code...
                        break;
                }
            }
            this.loaderOn = false;
        }, err => {
            this.loaderOn = false;

        });
    }

    getSelectedCurrencyId() {
        let currencyId = "";
        for (let i = 0; i < this.currencies.length; i++) {
            if (this.currencies[i].code === this.studioDetails.currency) {
                currencyId = this.currencies[i].id;
            }
        }
        return currencyId;
    }




    addLocation() {
        let sd = this.studioDetails;
        let reqObj = {
            branch: sd.location,
            address: sd.address,
            city: sd.city,
            state: sd.state,
            pincode: sd.pincode,
            region_type: sd.region_type,
            region_id: sd.region_id,
            region_name: sd.region_name
        };
        if (reqObj.region_type === 'new') {
            let newObj = {
                country_id: sd.country,
                currency_id: this.getSelectedCurrencyId(),
                timezone: this.studioDetails.timezone,
                timezone_name: this.studioDetails.timezone
            }
            Object.assign(reqObj, newObj);
        }
        let client_id = JSON.parse(localStorage.getItem("currentUser"))['client_id'];
        this.disableButton = true;


        this.http.sendData(`center?client_id=${client_id}`, reqObj).subscribe(response => {
            let oldCurrentUser = JSON.parse(localStorage.getItem("currentUser"));
            this.loader = true;

            localStorage.setItem("currentUser", JSON.stringify({
                appId: 3,
                email: oldCurrentUser.email,
                token: oldCurrentUser.token,
                center_id: response.data.id,
                name: oldCurrentUser.name,
                client_id: oldCurrentUser.client_id,
                roles: oldCurrentUser.role,
                setup_completed: 1,
                webstore_url: oldCurrentUser.webstore_url,
                intercomSecret: oldCurrentUser.intercomSecret
            }));

            localStorage.setItem("localization", JSON.stringify({
                currency: response.data.region.currency,
                country: response.data.region.country,
                timezone: response.data.region.timezone,
                timezone_name : response.data.region.timezone_name
            }));

            if (this.generalFunctions.checkDevice()) {
                this.router.navigate(["client/mobile"]);
            } else {
                let selectedRegion = {
                    currency: response.data.region.currency,
                    country: response.data.region.country,
                    timezone: response.data.region.timezone,
                    timezone_name : response.data.region.timezone_name,
                    centers: response.data.id
                };
                this.directDashboard(selectedRegion);
            }
        }, error => {
            this.generalFunctions.openToast(Array.isArray(error.message) ? error.message[0] : error.message, 3000, 'error')
            this.disableButton = false;
        });
    }


    directDashboard(selectedRegion) {
        if (localStorage.getItem("currentUser")) {
            let currentData = JSON.parse(localStorage.getItem("currentUser"));
            let localized = {
                currency: selectedRegion.currency,
                country: selectedRegion.country,
                timezone: selectedRegion.timezone,
                timezone_name : selectedRegion.timezone_name
            };
            currentData["center_id"] = selectedRegion.centers;
            localStorage.setItem("currentUser", JSON.stringify(currentData));
            localStorage.setItem("localization", JSON.stringify(localized));
            this.router.navigate(["client/dashboard"]);
        }
    }


    logOut() {
        this.http.logout().subscribe(success => {
            this.generalFunctions.openToast("Successfully logged out!", 2000, "success");
            localStorage.removeItem("currentUser");
            this.router.navigate(["login"]);
        }, error => {
            this.generalFunctions.openToast(error.message, 2000, "error");
            localStorage.removeItem("currentUser");
            this.router.navigate(["login"]);
        });
    }

}
