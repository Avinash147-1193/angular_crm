import { Component, OnInit, } from '@angular/core'; 
import {Intercom} from 'ng-intercom';
import {
	ServerAuthService
} from '../../../../common/server-auth';
import {
	Router,
	ActivatedRoute
} from '@angular/router';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit {

  constructor( public intercom : Intercom
    ) {}

  ngOnInit() {
    
    this.intercom.boot({
      app_id : 'lzcn0xd6',
      widget : { 
        "activator": "#intercom"
      }
    })
  }

  openIntercom(){
    this.intercom.show();
  }

}
