import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
	templateUrl: './memberships.component.html'
})

export class MembershipsComponent implements OnInit {

	constructor(){}

	ngOnInit() {}
}
