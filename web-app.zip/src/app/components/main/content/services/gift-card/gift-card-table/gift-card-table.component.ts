import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {ServerAuthService} from 'app/common/server-auth';
import {GeneralServices} from 'app/common/general-services';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-gift-card-table',
  templateUrl: './gift-card-table.component.html',
  styleUrls: ['./gift-card-table.component.scss', '../../styles/service-list.scss']
})
export class GiftCardTableComponent implements OnInit {
    center_id: any;
    cards: any;
    hovered = false;
    currency: any;
    totalClasses: any;

constructor(private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit(): void {
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;


    this.getCards();
  }

  dropGroup(event){
    // moveItemInArray(this.allClasses, event.previousIndex, event.currentIndex);

    // const newResObj = Object.values(this.allClasses);
    // const arr = [];
    // newResObj.forEach((element, index) => {
    //   const obj = {
    //     class_id: element['id'],
    //     order: index + 1
    //   };
    //   arr[index] = obj;
    // });
    // this.http.updateData('classes/order?center_id=' + this.center_id, {classes : arr}).subscribe(response => {
    // }, err => {
    //   console.log('err', err);
    // });
  }

  getCards() {
    this.http.sendData('cards?center_id=' + this.center_id,{}).subscribe(response => {
        console.log('response', response)
        this.cards = response.data;
        this.totalClasses = this.cards.length;
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

}
