import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GiftCardTableComponent } from './gift-card-table.component';

describe('GiftCardTableComponent', () => {
  let component: GiftCardTableComponent;
  let fixture: ComponentFixture<GiftCardTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GiftCardTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GiftCardTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
