import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateGiftCardComponent } from './create-gift-card.component';

describe('CreateGiftCardComponent', () => {
  let component: CreateGiftCardComponent;
  let fixture: ComponentFixture<CreateGiftCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateGiftCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateGiftCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
