import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {Location} from '@angular/common';

@Component({
  selector: 'app-create-gift-card',
  templateUrl: './create-gift-card.component.html',
  styleUrls: ['./create-gift-card.component.scss',  "../../styles/services.scss", "../../styles/schedule.scss"]
})
export class CreateGiftCardComponent implements OnInit {
  currency: any;
    center_id: any;
    newPlan: any = {
        title : '',
        type: 1,
        amount : ''
    }
    creating = false;
    cardId = null;
    editCard = false;
    pop_up_for : any  = false;
    isVisible: any = true;

  constructor(private generalFunctions : GeneralServices, private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private location : Location, private activatedRoute : ActivatedRoute, ) {}


  ngOnInit(): void {
    this.cardId = this.route.snapshot.paramMap.get('id');
    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    if (this.cardId) {
        this.getCard();
        this.editCard = true;
    }

  }

  getCard() {
    this.http.getData(`cards/${this.cardId}?center_id=${this.center_id}`).subscribe(response => {
    this.newPlan = response.data;
    this.isVisible = this.newPlan.visibility;
    }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
  }

  deleteGCard(){
      this.http.deleteData(`cards/${this.cardId}?center_id=${this.center_id}`).subscribe(response => {
        this.generalFunctions.openToast('Gift card deleted',3000,'success');
        this.pop_up_for = null;
        this.router.navigate(['/client/services/gift-cards']);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
        this.pop_up_for = null;
      })
  }

  createGift() {
    this.creating = true;
    this.newPlan['visibility'] = this.isVisible;
    this.http.sendData(`cards/store?center_id=${this.center_id}`, this.newPlan).subscribe(response => {
        this.creating = false;
        this.router.navigate(['/client/services/gift-cards']);
        this.generalFunctions.openToast('Gift card created', 3000, 'success');
      }, error => {
        this.creating = false;
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
  }

  updateCard() {
    this.creating = true;
    let reqObj = {
        title : this.newPlan.title,
        amount: this.newPlan.amount,
        type: this.newPlan.type,
        visibility : this.isVisible
    };

     console.log('reqObj', reqObj)
    this.http.updateData(`cards/${this.cardId}?center_id=${this.center_id}`, reqObj).subscribe(response => {
        this.creating = false;
        this.router.navigate(['/client/services/gift-cards']);
        this.generalFunctions.openToast('Gift card updated', 3000, 'success');
      }, error => {
        this.creating = false;
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
  }

}
