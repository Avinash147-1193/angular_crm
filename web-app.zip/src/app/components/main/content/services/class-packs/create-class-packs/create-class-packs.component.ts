import {
  Component,
  OnInit,
  OnChanges,
  ViewChild,
  ElementRef,
  ViewEncapsulation
} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from '../../../../../../common/general-services';
import {Key} from 'protractor';
import {viewClassName, IfStmt} from '@angular/compiler';
import {ServerAuthService} from '../../../../../../common/server-auth';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import {SelectItem} from 'primeng/api';

declare var $: any;

@Component({
  selector: 'app-create-class-packs',
  templateUrl: './create-class-packs.component.html',
  styleUrls: [
    './create-class-packs.component.scss', '../../../dashboard/dashboard.component.css', '../../memberships.component.css', '../../../pos/pos.component.scss', '../../styles/services.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class CreateClassPacksComponent implements OnInit,
OnChanges {
  @ViewChild('basicDetailsCollapse')basicDetailsCollapse: ElementRef;
  selectedFile: File;

  // loaderflags starts
  heyLoader: boolean = false;
  heyLoaderImage: boolean = false;
  // loaderflags ends

  name: any = null;
  fileLoaded: any = null;
  currency: any;
  model: any;
  defaultFreqMonth: any;
  recurringPay = true;
  uploadFlag = false;
  joiningFee = false;
  pricePerItem: any;
  pause_days: any;
  pause_count: any;
  everyMonthFirst: any;
  nonEditable = null;
  dataToBind: any;
  joining_amount: any;
  membershipPaused: any;
  payableTerm: any;
  center_id: any;
  imageUrl: any;
  isNewPlan: boolean = true;
  currentSection: number = 1;
  imagePreview: boolean = false;
  planPaused: boolean = false;
  isJoiningFee: boolean = false;
  noImage: any = false;

  //modalFlags starts
  openModalFlag: boolean = false;
  openRightModalFlagOne: boolean = false;
  openRightModalFlagTwo: boolean = false;
  randArray: any = [];
  classRandArray: any = [];
  modalTempArray: any = [];
  classModalTempArray: any = [];
  //modalFlags ends

  //PlanData for checkboxes
  planData: any;
  classData: any;
  packId: string = '';
  // formData: FormData = new FormData();

  // start: Applicable services modal vars
  openClassesModalFlag: boolean = false;
  classes: any;
  tempClassesSelected: any = [];
  tempClassesOption: any;

  openAppointmentsModalFlag: boolean = false;
  trainers: any;
  tempAppointmentsSelected: any = [];
  tempAppointmentsOption: any;

  allServices: any;
  classesServiceId: number;
  appointmentsServiceId: number;
  selectedServiceId: number;
  isVisible: boolean = true;
  // end: Applicable services modal vars

  createPacks: any = {
    name: '',
    description: '',
    duration: '1',
    duration_type: 'month',
    service_type: 2,
    image_url: null,
    group_id: '',
    credits_type: 'unlimited',
    is_trial: false,
    trial_limit: 1,
    trial_duration_limit: 12,
    applicable_services: [
      {
        service_id: '',
        service_type_id: [],
        sessions: 2,
        option: 'all',
        option_id: null,
        credits: -1
      }
    ],
    payments: {
      price: 0
    },
    settings: {
      start_type: 'immediate'
      // credits_amount: "0",
      // applicable_service_option: {
      //   class: "all"
      // }
    }
  };

  locationScope: SelectItem[] = [];
  locationScopeList: any = [];

  getPlans: any = {
    name: null,
    description: ''
  };

  editPlan: any = {};
  classPack: any;

  validationFields: any = {
    packName: false,
    planGroup: false,
    price: false
  };

  isSpecificClassesValid: boolean = true;
  isSpecificTrainersValid: boolean = true;

  nextOne: boolean = false;
  nextTwo: boolean = false;
  groupsLoaded: boolean = false;
  groups: SelectItem[] = [];

  groupList: any;

  @ViewChild('ajax_screen')ajax_screen;
  @ViewChild('restricted_service')restricted_service;
  @ViewChild('unlimited_service')unlimited_service;
  @ViewChild('planeName')planeName: ElementRef;
  @ViewChild('plan_description')plan_description: ElementRef;
  @ViewChild('noDays')noDays: ElementRef;
  @ViewChild('iterationTime')iterationTime: ElementRef;
  @ViewChild('plan_price')plan_price: ElementRef;
  @ViewChild('joining_fee')joining_fee: ElementRef;
//   @ViewChild("cycles_per_plan")cycles_per_plan: ElementRef;
  pop_up_for: any;
  groupName: any;
  setCurrentGroup: any = null;
  creditsLoop: any = [];

  constructor(private generalFunctions : GeneralServices, private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private location : Location, private activatedRoute : ActivatedRoute) {}

  ngOnInit() {
    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.getMembershipGroups();
    this.generateCredit();

    this.getCurrentLocation();

    this.dataToBind = this.generalFunctions.plan_details;
    this.nonEditable = this.generalFunctions.plan_details != undefined
      ? true
      : null;
    this.generalFunctions.plan_details = null;

    if (this.router.url.includes('/create-packs')) {
      // ends get plans for checkboxed
      this.isNewPlan = true;
      this.getAllServices();
      this.getClasses();
      this.getAvailableTrainers();
    } else {
      this.isNewPlan = false;
      this.packId = this.activatedRoute.snapshot.paramMap.get('id');
      this.heyLoader = true;
      this.http.getData(`packs/${this.packId}?center_id=${this.center_id}`).subscribe(response => {
        var res = response;
        // this.heyLoader = false;
        this.classPack = res.data;
        // create edit plan object
        setTimeout(() => {
          this.createPacks.group_id = this.classPack.service_group_id;
        }, 10);
        // this.createPacks.group_id = this.classPack.service_group_id;

        this.createPacks.name = this.classPack.name;
        this.createPacks.description = this.classPack.description;
        this.isVisible = this.classPack.visibility === 1
          ? true
          : false;
        // this.createPacks.applicable_services[0].credits = this.classPack.applica	ble_services[0].credits;
        this.createPacks.service_type = this.classPack.service_type;
        this.createPacks.image_url = this.classPack.image_url;
        this.createPacks.settings.start_type = this.classPack.settings.start_type;
        this.createPacks.duration = this.classPack.duration;
        this.createPacks.share_type = this.classPack.share_type;
        // this.createPacks.applicable_services[0].option = this.classPack.applicable_services[0].option
        // this.createPacks.applicable_services[0].service_type_id = this.classPack.applicable_services[0].service_type_id;
        this.createPacks.is_trial = this.classPack.is_trial;
        this.createPacks.trial_limit = this.classPack.trial_limit;
        this.createPacks.trial_duration_limit = this.classPack.trial_duration_limit;
        this.createPacks.applicable_services[0].sessions = this.classPack.applicable_services[0].sessions;
        this.createPacks.applicable_services[0].service_type_id = this.classPack.applicable_services[0].service_type_id;
        this.createPacks.applicable_services[0].option = this.classPack.applicable_services[0].option;
        this.createPacks.applicable_services[0].credits = this.classPack.applicable_services[0].credits;
        this.classPack.applicable_services[0].credits == -1
          ? (this.createPacks.credits_type = 'unlimited')
          : (this.createPacks.credits_type = 'fixed');
        this.createPacks.applicable_services[0].service_id = this.classPack.applicable_services[0].service_id;
        this.selectedServiceId = this.classPack.applicable_services[0].service_id;

        // pre-fill saved specific classes
        // this.prefillSpecificClasses();
        // get all services
        this.getAllServices();
        this.getClasses();
        this.getAvailableTrainers();

        // classPacks.settings.applicable_service_option.class == "all"
        //   ? ((this.openRightModalFlagOne = false),
        //     (this.openRightModalFlagTwo = false))
        //   : classPacks.applicable_services[0].class ==
        //     "category"
        //     ? ((this.openRightModalFlagOne = true),
        //       (this.openRightModalFlagTwo = false))
        //     : ((this.openRightModalFlagOne = false),
        //       (this.openRightModalFlagTwo = true));

        // this.createPacks.settings.applicable_service_option.class =
        //   classPacks.settings.applicable_service_option.class;

        // this.createPacks.applicable_services.service_type_id =
        //   classPacks.applicable_services.service_type_id;

        this.createPacks.duration_type = this.classPack.duration_type;
        this.createPacks.payments.price = this.classPack.amount;

        this.imagePreview = true;
      }, error => {
        let msg;
        console.log(error);
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }
  }

  generateCredit() {
    for (let i = 1; i <= 50; i++) {
      this.creditsLoop.push({key: i, value: i});
    }
    this.creditsLoop.push({key: 'Unlimited', value: -1});
  }

  getCurrentLocation() {
    this.http.getData(`center/${this.center_id}?center_id=${this.center_id}`).subscribe(response => {
      this.locationScopeList.push({
        name: '\'' + response.data.name + '\' location only',
        value: 'location'
      });
      this.locationScopeList.push({
        name: '\'' + response.data.region.name + '\' region',
        value: 'region'
      });

      this.locationScope = [];
      for (let i = 0; i < this.locationScopeList.length; i++) {
        let event = {
          label: '',
          value: ''
        };
        event.label = this.locationScopeList[i].name;
        event.value = this.locationScopeList[i].value;
        this.locationScope.push(event);
      }
      if (this.isNewPlan) {
        this.createPacks.share_type = this.locationScope[0].value;
      }
    }, err => {
      console.log('err', err);
    });
  }

  getAllServices() {
    this.http.getData('center/' + this.center_id + '/services').subscribe(response => {
      this.allServices = response;
      console.log(this.allServices);

      for (let i = 0; i < this.allServices.length; i++) {
        let service = this.allServices[i];

        if (service.service.code === 'CLASSES') {
          this.classesServiceId = service.service_id;
        } else if (service.service.code === 'APPOINTMENTS') {
          this.appointmentsServiceId = service.service_id;
        }
      }
      // set classes as default for new plan
      if (this.createPacks.applicable_services[0].service_id === '') {
        this.createPacks.applicable_services[0].service_id = this.classesServiceId;
      } else {
        this.createPacks.applicable_services[0].service_id = this.selectedServiceId;
      }

      this.heyLoader = false;

      // this.setImageBG();
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  setImageBG() {
    setTimeout(() => {
      (<HTMLElement>document.getElementsByClassName( 'planImage' )[0]).style.backgroundImage = `url(${this.classPack.image_url})`; }, 500);

    }




      getClasses() {
          this.http.getData('classes?center_id=' + this.center_id).subscribe(response => {
            this.classes = response.data;

            for (let i = 0; i < this.classes.length; i++) {
              this.classes[i].checked = false;
            }

            if (!this.isNewPlan) {
              // this.prepareSelectedClasses();
            }
          }, err => {
            const msg = err;
            this.generalFunctions.openToast(msg, 3000, 'error');
          }, () => {});
        }

        prepareSelectedClasses() {
          for (let i = 0; i < this.createPacks.applicable_services[0].service_type_id.length; i++) {
            for (let j = 0; j < this.classes.length; j++) {
              if (this.createPacks.applicable_services[0].service_type_id[i] === this.classes[j].id) {
                this.classes[j].checked = true;
              }
            }
          }
        }

        getMembershipGroups() {
          this.http.getData('groups?service_id=4&center_id=' + this.center_id).subscribe(response => {
            this.groupsLoaded = true;
            this.groupList = response.data;
            this.groups = [];

            for (let i = 0; i < this.groupList.length; i++) {
              let event = {
                label: '',
                value: 0
              };

              event.label = this.groupList[i].name;
              event.value = this.groupList[i].id;

              this.groups.push(event);
            }

            let defaultEvent = {
              label: '',
              value: ''
            };

            defaultEvent.label = 'Add new Group';
            defaultEvent.value = 'add';

            this.groups.push(defaultEvent);

            if (this.setCurrentGroup == null) {
              this.createPacks.group_id = this.groupList.length > 0
                ? this.groupList[0].id
                : null;
            } else {
              this.createPacks.group_id = this.setCurrentGroup;
            }
          }, err => {
            this.groupsLoaded = true;
          });
        }

        getAvailableTrainers() {
          this.http.getData(`appointments?center_id=${this.center_id}`).subscribe(response => {
            this.trainers = response.data;

            for (let i = 0; i < this.trainers.length; i++) {
              this.trainers[i].checked = false;
            }

            if (!this.isNewPlan) {}
          }, err => {
            const msg = err;
            this.generalFunctions.openToast(msg, 3000, 'error');
          }, () => {});
        }

        prepareSelectedTrainers() {
          for (let i = 0; i < this.createPacks.applicable_services[0].service_type_id.length; i++) {
            for (let j = 0; j < this.trainers.length; j++) {
              if (this.createPacks.applicable_services[0].service_type_id[i] === this.trainers[j].id) {
                this.trainers[j].checked = true;
              }
            }
          }
        }

        ngOnChanges(e) {
          console.log(e);
        }

        removeFile() {
          console.log('imag eurl is set to null');
          this.createPacks.image_url = null;
          this.noImage = true;
        }

        imagUploadClick() {
          document.getElementById('imageUploadInput').click();
        }
        fileUpload(event) {
          console.log(event);

          if (event.target.files && event.target.files[0]) {
            let msg;
            const file = event.target.files[0];
            console.log(event.target.files);
            const fileType = file.type.split('/');
            this.heyLoaderImage = true;

            if (fileType[1].includes('png') || fileType[1] === 'jpeg' || fileType[1] === 'jpg') {
              this.createPacks.fileUpload = {
                name: file.name,
                type: file.type,
                size: file.size
              };

              if (this.createPacks.fileUpload.size < 5242880) {
                console.log(this.createPacks);
                const uploadData = new FormData();
                uploadData.append('image', file);
                uploadData.append('type', 'plans');
                // console.log(uploadData);

                this.http.sendFormData(`image?center_id=${this.center_id}`, uploadData).subscribe(response => {
                  this.heyLoaderImage = false;
                  this.createPacks.image_url = response.url;
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });

                this.fileLoaded = 'File uploaded';
                this.uploadFlag = true;

                //  show image preview
                // this.imageUrl = URL.createObjectURL(event.target.files[0]);
                // console.log(this.imageUrl);
                // document.getElementById("planImage").style.backgroundImage = `url(${
                //   this.imageUrl
                // })`;
                this.imagePreview = true;
              } else {
                msg = 'Please upload a file less than 5 MB';
              }
            } else {
              msg = 'Please upload  a file of type .png, .jpg, .jpeg';
            }
            if (msg) {
              this.generalFunctions.openToast(msg, 3000, 'error');
              return false;
            }
          }
        }

        imageClick(event) {
          // this.imageClicked = true;
          console.log(event);
          document.getElementById('imageInput').click();
        }

        getFormStatus() {
          let isFormValid = true;

          for (var property in this.validationFields) {
            isFormValid = isFormValid && this.validationFields[property];
            if (!this.validationFields[property]) {
              this.generalFunctions.scrolltoinvalid(property);
              break;
            }
          }

          return isFormValid;
        }

        preparePackRequest() {
          if (this.createPacks.applicable_services[0].service_id === this.classesServiceId) {
            this.createPacks.applicable_services[0].service_type_id = this.getTempClassesSelected();
          } else if (this.createPacks.applicable_services[0].service_id === this.appointmentsServiceId) {
            this.createPacks.applicable_services[0].service_type_id = this.getTempAppointmentsSelected();
          }

          this.createPacks.visibility = this.isVisible
            ? 1
            : 2;
        }

        createClassPacks() {
          this.nextTwo = true;
          let isFormValid = this.getFormStatus();

          if (!isFormValid) {
            this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            return;
          }
          this.createPacks.credits_type == 'unlimited'
            ? (this.createPacks.applicable_services[0].credits = -1)
            : this.createPacks.applicable_services[0].credits;

          this.preparePackRequest();

          this.http.sendData(`packs/create?center_id=${this.center_id}`, this.createPacks).subscribe(response => {
            console.log(response);
            this.router.navigate(['/client/services/class-packs']);
            this.generalFunctions.openToast('Class Packs Created', 3000, 'success');
          }, error => {
            let msg;
            if (error['errors']) {
              msg = error['errors'][Object.keys(error['errors'])[0]];
            } else {
              msg = error.message;
            }
            this.generalFunctions.openToast(msg, 3000, 'error');
          });
        }

        savePlan() {
          let isFormValid = this.getFormStatus();

          if (!isFormValid) {
            this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            return;
          }

          this.createPacks.credits_type == 'unlimited'
            ? (this.createPacks.applicable_services[0].credits = -1)
            : this.createPacks.applicable_services[0].credits;

          this.preparePackRequest();

          this.http.updateData(`packs/${this.packId}?center_id=${this.center_id}`, this.createPacks).subscribe(response => {
            // console.log(response);
            this.router.navigate(['/client/services/class-packs']);
            this.generalFunctions.openToast('Class packs saved', 3000, 'success');
          }, error => {
            let msg;
            if (error['errors']) {
              msg = error['errors'][Object.keys(error['errors'])[0]];
            } else {
              msg = error.message;
            }
            this.generalFunctions.openToast(msg, 3000, 'error');
          });
        }
        editImageClick() {
          document.getElementById('imageInputTwo').click();
        }

        editFileUpload(event) {
          if (event.target.files && event.target.files[0]) {
            let msg;
            const file = event.target.files[0];
            this.heyLoaderImage = true;

            console.log(event.target.files);
            const fileType = file.type.split('/');
            if (fileType[1].includes('png') || fileType[1] === 'jpeg' || fileType[1] === 'jpg') {
              this.createPacks.fileUpload = {
                name: file.name,
                type: file.type,
                size: file.size
              };

              if (this.createPacks.fileUpload.size < 5242880) {
                console.log(this.createPacks);
                const uploadData = new FormData();
                uploadData.append('image', file);
                uploadData.append('type', 'plans');
                // console.log(uploadData);

                this.http.sendFormData(`image?center_id=${this.center_id}`, uploadData).subscribe(response => {
                  this.createPacks.image_url = response.url;
                  this.heyLoaderImage = false;
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });

                this.fileLoaded = 'File uploaded';
                this.uploadFlag = true;

                // show image preview
                // this.imageUrl = URL.createObjectURL(event.target.files[0]);
                // console.log(this.imageUrl);
                // document.getElementById("planImage").style.backgroundImage = `url(${
                //   this.imageUrl
                // })`;
                // this.imagePreview = true;
              } else {
                msg = 'Please upload a file less than 5 MB';
              }
            } else {
              msg = 'Please upload  a file of type .png, .jpg, .jpeg';
            }
            if (msg) {
              this.generalFunctions.openToast(msg, 3000, 'error');
              return false;
            }
          }
        }

        cancelChanges() {
          this.router.navigate(['/client/services/class-packs']);
        }

        deletePlan() {
          console.log(this.createPacks);

          this.http.deleteData(`packs/${this.packId}?center_id=${this.center_id}`).subscribe(response => {
            console.log(response);
            this.router.navigate(['/client/services/class-packs']);
            this.generalFunctions.openToast('Class Packs deleted', 3000, 'success');
          }, error => {
            let msg;
            if (error['errors']) {
              msg = error['errors'][Object.keys(error['errors'])[0]];
            } else {
              msg = error.message;
            }
            this.generalFunctions.openToast(msg, 3000, 'error');
          });
        }

        formValidate(field) {
          let isValid = true;

          switch (field) {
            case 'pack-name':
              isValid = !this.createPacks.name.replace(/\s/g, '').length
                ? false
                : true;
              // check if field contains only whitespaces
              this.validationFields.packName = isValid;
              break;

            case 'plan-group':
              isValid = !this.validateId(this.createPacks.group_id)
                ? false
                : true;
              this.validationFields.planGroup = isValid;
              break;

            case 'price':
              isValid = (this.createPacks.payments.price >= 0) && (this.createPacks.payments.price !== '')
                ? true
                : false;
              this.validationFields.price = isValid;
              break;

            default:
              break;
          }

          return !isValid;
        }

        validateId(num) {
          var re = /(^[0][1-9]+)|([1-9]\d*)/;
          return re.test(num);
        }

        goToNext(current, next) {
          switch (current) {
            case 1:
              this.nextOne = true;

              if (!this.validationFields.packName) {
                this.generalFunctions.scrolltoinvalid('packName');
                this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                return;
              }
              if (!this.validationFields.planGroup) {
                this.generalFunctions.scrolltoinvalid('planGroup');
                this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                return;
              }
              break;

            default:
              break;
          }

          this.currentSection++;
          console.log(next);
          console.log(document.getElementById(next));
          document.getElementById(next).click();
          // console.log(this.createPacks);
        }

        goBack(collapse) {
          this.currentSection--;
          console.log(collapse);
          console.log(document.getElementById(collapse));
          document.getElementById(collapse).click();
        }

        pausePlan() {
          this.planPaused = !this.planPaused;
        }

        toggleJoiningFee() {
          this.isJoiningFee = !this.isJoiningFee;
        }

        //modal function starts // openModal(event) {
          //   this.openModalFlag = true;
          // }

        // popModalRight(event) {
          //   console.log("are you calling this");
          //   event.target.value == "all"
          //     ? ((this.openRightModalFlagOne = false),
          //       (this.openRightModalFlagTwo = false))
          //     : event.target.value == "category"
          //       ? ((this.openRightModalFlagOne = true),
          //         (this.openRightModalFlagTwo = false))
          //       : ((this.openRightModalFlagOne = false),
          //         (this.openRightModalFlagTwo = true));
          // }

        // pushToApplicables(event, id) {

          //    let arr = this.createPacks.applicable_services[0].service_type_id;
          //   let arr = this.modalTempArray;
          //   if (arr.includes(id)) {
          //     if (event.target.checked == false || event.target.checked == null) {
          //       pop the element from array
          //       if (arr.indexOf(id) > -1) {
          //         arr.splice(arr.indexOf(id), 1);
          //       } else {
          //         console.log("no array exists");
          //       }
          //     }
          //   } else {
          //      push it to the array
          //     arr.push(id);
          //   }
          // }

        // classPushToApplicables(event, id) {

          //    let arr = this.createPacks.applicable_services[0].service_type_id;
          //   let arr = this.classModalTempArray;
          //   if (arr.length == 0) {
          //     arr.push(id);
          //   } else {
          //     arr.pop();
          //     arr.push(id);
          //   }
          // }

        // clickedApplyChanges(event) {
          //   this.createPacks.applicable_services[0].service_type_id = [...this.modalTempArray];
          //   this.openModalFlag = false;
          //   console.log(this.createPacks.applicable_services[0].service_type_id);
          // }

        // clickedOverlay() {
          //   console.log("clicked cancel");
          //   this.openModalFlag = false;
          //   this.modalTempArray = [...this.createPacks.applicable_services[0].service_type_id];

          //   for (var i = 0; i < this.classData.length; i++) {
          //     this.classData[i].checked = this.modalTempArray.includes(this.classData[i].id);
          //   }
          // }

        // checkAll() {
          //   this.classData.forEach((item) => {
          //     item.checked = true;
          //     if (this.modalTempArray.length == 0) {
          //       this.modalTempArray.push(item.id);
          //     }
          //     else {
          //       if (this.modalTempArray.includes(item.id)) {
          //         do nothing
          //       }
          //       else {
          //         this.modalTempArray.push(item.id);

          //       }
          //     }
          //   })
          // }

        // unCheckAll() {
          //   this.classData.forEach((item) => {
          //     item.checked = false;
          //   })
          //   this.modalTempArray = [];
          // }

        openClassesModal() {
          console.log(this.classes);
          this.openClassesModalFlag = true;
          this.isSpecificClassesValid = true;

          // record saved state
          this.tempClassesOption = this.createPacks.applicable_services[0].option;
          this.tempClassesSelected = this.getTempClassesSelected();
        }

        closeClassesModal(action) {
          if (action === 'cancel') {
            this.isSpecificClassesValid = false;
            this.createPacks.applicable_services[0].option = this.tempClassesOption;

            for (let i = 0; i < this.classes.length; i++) {
              this.classes[i].checked = false;
              for (let j = 0; j < this.tempClassesSelected.length; j++) {
                if (this.classes[i].id === this.tempClassesSelected[j]) {
                  this.classes[i].checked = true;
                }
              }
            }
          } else if (action === 'apply') {
            // Validation for specific classes option
            if (this.createPacks.applicable_services[0].option === 'selection') {
              this.isSpecificClassesValid = false;
              // check if atleast one class selected
              for (let i = 0; i < this.classes.length; i++) {
                if (this.classes[i].checked) {
                  this.isSpecificClassesValid = true;
                  break;
                }
              }

              if (!this.isSpecificClassesValid) {
                return;
              }
            }
          }

          this.openClassesModalFlag = false;
        }

        getTempClassesSelected() {
          let selected = [];
          for (let i = 0; i < this.classes.length; i++) {
            if (this.classes[i].checked === true) {
              selected.push(this.classes[i].id);
            }
          }

          return selected;
        }

        openAppointmentsModal() {
          console.log(this.trainers);
          this.openAppointmentsModalFlag = true;
          this.isSpecificTrainersValid = true;

          // record saved state
          this.tempAppointmentsOption = this.createPacks.applicable_services[0].option;
          this.tempAppointmentsSelected = this.getTempAppointmentsSelected();
        }

        closeAppointmentsModal(action) {
          if (action === 'cancel') {
            this.isSpecificTrainersValid = false;
            this.createPacks.applicable_services[0].option = this.tempAppointmentsOption;

            for (let i = 0; i < this.trainers.length; i++) {
              this.trainers[i].checked = false;
              for (let j = 0; j < this.tempAppointmentsSelected.length; j++) {
                if (this.trainers[i].id === this.tempAppointmentsSelected[j]) {
                  this.trainers[i].checked = true;
                }
              }
            }
          } else if (action === 'apply') {
            // Validation for specific classes option
            if (this.createPacks.applicable_services[0].option === 'selection') {
              this.isSpecificTrainersValid = false;
              // check if atleast one class selected
              for (let i = 0; i < this.trainers.length; i++) {
                if (this.trainers[i].checked) {
                  this.isSpecificTrainersValid = true;
                  break;
                }
              }

              if (!this.isSpecificTrainersValid) {
                return;
              }
            }
          }

          this.openAppointmentsModalFlag = false;
        }

        createGroup() {
          let reqObj = {
            name: this.groupName,
            service_id: 4
          };
          this.http.sendData('groups?center_id=' + this.center_id, reqObj).subscribe(response => {
            this.getMembershipGroups();
            this.setCurrentGroup = response.data.id;

            this.generalFunctions.openToast('New Group is added', 3000, 'success');
            console.log('object', response);
            this.pop_up_for = null;
          }, err => {
            this.pop_up_for = null;
          });
        }
        callForCancel() {
          this.groups = [];
          this.createPacks.group_id = '';
          this.getMembershipGroups();
          this.pop_up_for = null;
        }

        getTempAppointmentsSelected() {
          let selected = [];
          for (let i = 0; i < this.trainers.length; i++) {
            if (this.trainers[i].checked === true) {
              selected.push(this.trainers[i].id);
            }
          }

          return selected;
        }

        mapImageUrl(event) {
          this.createPacks.image_url = event;
        }
        checkForAdd(event) {
          if (event.value == 'add') {
            this.pop_up_for = 'addGroup';
          }
        }
        }
