import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassPackListComponent } from './class-pack-list.component';

describe('ClassPackListComponent', () => {
  let component: ClassPackListComponent;
  let fixture: ComponentFixture<ClassPackListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassPackListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassPackListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
