import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CreateClassPacksComponent } from "./create-class-packs.component";

describe("CreateClassPacksComponent", () => {
  let component: CreateClassPacksComponent;
  let fixture: ComponentFixture<CreateClassPacksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateClassPacksComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateClassPacksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
