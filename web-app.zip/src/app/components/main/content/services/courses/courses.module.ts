import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseCreateComponent } from './course-create/course-create.component';
import { CourseListComponent } from './course-list/course-list.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MultiSelectModule} from 'primeng/multiselect';
import {DropdownModule} from 'primeng/dropdown';
import {TooltipModule} from 'primeng/tooltip';
import {CalendarModule as PrimeCalendar} from 'primeng/calendar';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { RouterModule } from '@angular/router';
import { SharedModule } from 'app/shared/shared.module';
// import {SharedModule} from '../../../../../shared.module'
// import { ImageUploadComponent } from 'app/components/feature/image-upload/image-upload.component';
// import { ImageUploadComponent } from 'app/components/feature/image-upload/image-upload.component';




@NgModule({
  declarations: [CourseCreateComponent, CourseListComponent],
  imports: [
      SharedModule,
    CommonModule,
    FormsModule,
    BsDatepickerModule.forRoot(),
    ReactiveFormsModule,
    MultiSelectModule,
    DropdownModule,
    DragDropModule,
    RouterModule,
    TooltipModule, PrimeCalendar
  ]
})
export class CoursesModule { }
