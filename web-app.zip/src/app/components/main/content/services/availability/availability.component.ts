import {Component, OnInit, OnChanges, ViewChild, ElementRef} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "app/common/general-services";
import {ServerAuthService} from "app/common/server-auth";
import {FormControl, FormGroup, FormBuilder, FormArray} from "@angular/forms";
import {Timeslot, Price} from "../models/availability.model";
import {SelectItem} from "primeng/api";
import {ServiceId} from "../../../../../constants";

@Component({
  selector: "app-availability",
  templateUrl: "./availability.component.html",
  styleUrls: ["./availability.component.scss", "../styles/services.scss", "../styles/schedule.scss"]
})
export class AvailabilityComponent implements OnInit {
  mondayClassSchedule: FormGroup;
  mondayClasses: FormArray;

  tuesdayClassSchedule: FormGroup;
  tuesdayClasses: FormArray;

  wednesdayClassSchedule: FormGroup;
  wednesdayClasses: FormArray;

  thursdayClassSchedule: FormGroup;
  thursdayClasses: FormArray;

  fridayClassSchedule: FormGroup;
  fridayClasses: FormArray;

  saturdayClassSchedule: FormGroup;
  saturdayClasses: FormArray;

  sundayClassSchedule: FormGroup;
  sundayClasses: FormArray;

  plansForm: FormGroup;
  allPlans: FormArray;

  planPackForm: FormGroup;
  allPlanPack: FormArray;

  name: any = null;
  fileLoaded: any = null;
  currency: any;
  uploadFlag = false;
  center_id: any;

  isNewSchedule: boolean = true;
  currentSection: number = 1;
  imagePreview: boolean = false;
  planPaused: boolean = false;
  isClassStartDate: boolean = false;
  isClassEndDate: boolean = false;
  isVisible: boolean = false;
  hovered: any = "";

  //   trainers: any;

  trainerId: string = "";

  classSchedule: any = {
    starts_at: "",
    ends_at: "",
    availability: []
  };

  classDetails: any;

  membershipPlans: any;

  startDate: any = new Date();
  endDate: any = "";
  isDropinOne: boolean = false;
  dropinOnePrice: number = 0;
  isAllMembers: boolean = false;
  allMembersPrice: number = 0;
  isDropinTwo: boolean = false;
  dropinTwoPrice: number = 0;
  calculateTimeout: any = null;

  trainers: any;
  trainersDropdown: SelectItem[] = [];
  allServices: any;
  ptServiceId: any;
  categories: any;
  categoriesDropdown: SelectItem[] = [];
  duration: any;
  durationDropdown: SelectItem[] = [
    {
      label: "15 mins",
      value: 15
    }, {
      label: "30 mins",
      value: 30
    }, {
      label: "45 mins",
      value: 45
    }, {
      label: "60 mins",
      value: 60
    }
  ];

  scheduleDaysStatus: any = {
    monday: false,
    tuesday: false,
    wednesday: false,
    thursday: false,
    friday: false,
    saturday: false,
    sunday: false
  };

  startDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: "theme-default",
    minDate: new Date()
  };

  endDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: "theme-default",
    minDate: new Date()
  };

  membersCustomerType: number = 1;
  dropinCustomerType: number = 2;

  appointments: any;

  validationFields: any = {
    trainerId: false
  };

  nextOne: boolean = false;
  nextTwo: boolean = false;
  priceType: any = 4;
  trainersName: any;

  isDaysScheduleValid: boolean = true;

  constructor(private generalFunctions : GeneralServices, private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private activatedRoute : ActivatedRoute, private fb : FormBuilder) {}

  ngOnInit() {
    this.createAllClassSchedules([]);

    this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;
    this.center_id = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.generalFunctions.plan_details = null;

    console.log("edit schedule");

    this.trainerId = this.activatedRoute.snapshot.paramMap.get("id");
    console.log(this.trainerId);

    this.http.getData(`staff/${this.trainerId}?center_id=${this.center_id}`).subscribe(response => {
      this.trainersName = response.data.first_name;
      console.log("response.data.availability.length", response.data.availability.availability.length);
      response.data.availability.availability.length === 0
        ? (this.isNewSchedule = true)
        : (this.isNewSchedule = false);
      this.classDetails = response.data.availability;
      // check if date is not null or empty
      if (this.classDetails.starts_at && this.classDetails.starts_at !== "") {
        this.isClassStartDate = true;
        this.startDate = new Date(this.classDetails.starts_at);
      }
      // check if date is not null or empty
      if (this.classDetails.ends_at && this.classDetails.ends_at !== "") {
        this.isClassEndDate = true;
        this.endDate = new Date(this.classDetails.ends_at);
      }
      this.prepareScheduleForm();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  ngOnChanges(e) {
    console.log(e);
  }

  // getter functions for quick access to timeslots formarray
  get mondayTimeslots(): FormArray {
    return this.mondayClassSchedule.get("mondayClasses")as FormArray;
  }

  get tuesdayTimeslots(): FormArray {
    return this.tuesdayClassSchedule.get("tuesdayClasses")as FormArray;
  }

  get wednesdayTimeslots(): FormArray {
    return this.wednesdayClassSchedule.get("wednesdayClasses")as FormArray;
  }

  get thursdayTimeslots(): FormArray {
    return this.thursdayClassSchedule.get("thursdayClasses")as FormArray;
  }

  get fridayTimeslots(): FormArray {
    return this.fridayClassSchedule.get("fridayClasses")as FormArray;
  }

  get saturdayTimeslots(): FormArray {
    return this.saturdayClassSchedule.get("saturdayClasses")as FormArray;
  }

  get sundayTimeslots(): FormArray {
    return this.sundayClassSchedule.get("sundayClasses")as FormArray;
  }

  get planPrices(): FormArray {
    return this.plansForm.get("allPlans")as FormArray;
  }

  get planPackPrices(): FormArray {
    return this.planPackForm.get("allPlanPack")as FormArray;
  }

  addWeekdayTimeslot(day : string) {
    let timeslot = new Timeslot();

    timeslot["trainers"] = this.classSchedule["trainers"];
    timeslot["level"] = this.classSchedule["level"];
    timeslot["max_allowed"] = this.classSchedule["max_allowed"];
    timeslot["visibility"] = this.classSchedule["visibility"];

    switch (day) {
      case "monday":
        this.mondayTimeslots.push(this.fb.group(timeslot));
        console.log(this.mondayClassSchedule);
        break;

      case "tuesday":
        this.tuesdayTimeslots.push(this.fb.group(timeslot));
        console.log(this.tuesdayClassSchedule);
        break;

      case "wednesday":
        this.wednesdayTimeslots.push(this.fb.group(timeslot));
        console.log(this.wednesdayClassSchedule);
        break;

      case "thursday":
        this.thursdayTimeslots.push(this.fb.group(timeslot));
        console.log(this.thursdayClassSchedule);
        break;

      case "friday":
        this.fridayTimeslots.push(this.fb.group(timeslot));
        console.log(this.fridayClassSchedule);
        break;

      case "saturday":
        this.saturdayTimeslots.push(this.fb.group(timeslot));
        console.log(this.saturdayClassSchedule);
        break;

      case "sunday":
        this.sundayTimeslots.push(this.fb.group(timeslot));
        console.log(this.sundayClassSchedule);
        break;

      default:
        break;
    }
  }

  deleteWeekdayTimeslot(day, index) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    // delete timeslot api
    if (allDaysClasses[day].at(index).value.isSaved == true) {
      this.deleteTimeslot(allDaysClasses[day].at(index).value.slotId);
    }

    // remove formarray control
    allDaysClasses[day].removeAt(index);

    // if deleting last slot, then unselect day
    if (allDaysClasses[day].value.length === 0) {
      switch (day) {
        case 0:
          this.scheduleDaysStatus.monday = false;
          break;

        case 1:
          this.scheduleDaysStatus.tuesday = false;
          break;

        case 2:
          this.scheduleDaysStatus.wednesday = false;
          break;

        case 3:
          this.scheduleDaysStatus.thursday = false;
          break;

        case 4:
          this.scheduleDaysStatus.friday = false;
          break;

        case 5:
          this.scheduleDaysStatus.saturday = false;
          break;

        case 6:
          this.scheduleDaysStatus.sunday = false;
          break;

        default:
          break;
      }
    }
  }

  dayToggle(day) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    let allDays = [
      "monday",
      "tuesday",
      "wednesday",
      "thursday",
      "friday",
      "saturday",
      "sunday"
    ];

    if (allDaysClasses[day].value.length === 0) {
      this.addWeekdayTimeslot(allDays[day]);
    }

    // check validity of daysSchedule -- check if at least one day is selected
    this.isDaysScheduleValid = false;
    for (var property in this.scheduleDaysStatus) {
      if (this.scheduleDaysStatus[property]) {
        this.isDaysScheduleValid = true;
      }
    }
  }

  createAllClassSchedules(mondayClasses) {
    this.mondayClassSchedule = this.fb.group({mondayClasses: this.fb.array([])});

    this.tuesdayClassSchedule = this.fb.group({tuesdayClasses: this.fb.array([])});

    this.wednesdayClassSchedule = this.fb.group({wednesdayClasses: this.fb.array([])});

    this.thursdayClassSchedule = this.fb.group({thursdayClasses: this.fb.array([])});

    this.fridayClassSchedule = this.fb.group({fridayClasses: this.fb.array([])});

    this.saturdayClassSchedule = this.fb.group({saturdayClasses: this.fb.array([])});

    this.sundayClassSchedule = this.fb.group({sundayClasses: this.fb.array([])});

    this.mondayTimeslots.valueChanges.subscribe(values => {
      console.log(values);

      clearTimeout(this.calculateTimeout);

      this.calculateTimeout = setTimeout(() => {
        console.log("calculate");
      }, 3000);
    });

    this.addWeekdayTimeslot("monday");
    this.addWeekdayTimeslot("tuesday");
    this.addWeekdayTimeslot("wednesday");
    this.addWeekdayTimeslot("thursday");
    this.addWeekdayTimeslot("friday");
    this.addWeekdayTimeslot("saturday");
    this.addWeekdayTimeslot("sunday");
  }

  prepareScheduleForm() {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];
    for (let i = 0; i < this.classDetails.availability.length; i++) {
      // remove empty timeslot
      let day = this.classDetails.availability[i].day;
      allDaysClasses[day - 1].removeAt(0);

      // Toggle selected day card
      switch (day) {
        case 1:
          this.scheduleDaysStatus["monday"] = true;
          break;
        case 2:
          this.scheduleDaysStatus["tuesday"] = true;
          break;
        case 3:
          this.scheduleDaysStatus["wednesday"] = true;
          break;
        case 4:
          this.scheduleDaysStatus["thursday"] = true;
          break;
        case 5:
          this.scheduleDaysStatus["friday"] = true;
          break;
        case 6:
          this.scheduleDaysStatus["saturday"] = true;
          break;
        case 7:
          this.scheduleDaysStatus["sunday"] = true;
          break;
        default:
          // code...
          break;
      }

      // create timeslots in formarray
      for (let j = 0; j < this.classDetails.availability[i].slots.length; j++) {
        let newTimeslot = new Timeslot();
        let slot = this.classDetails.availability[i].slots[j];

        let startTime = this.getTimepickerDate(slot.from);
        let endTime = this.getTimepickerDate(slot.to);

        // set values of timeslot object to be inserted into formarray
        newTimeslot = {
          start: startTime,
          end: endTime,
          slotId: this.classDetails.availability[i].slots[j].id,
          isSaved: true,
          trainers: "",
          level: "",
          max_allowed: "",
          visibility: false
        };

        allDaysClasses[day - 1].push(this.fb.group(newTimeslot));
        console.log(allDaysClasses[day - 1]);
      }
    }
  }

  prepareScheduleArray() {
    const formModelMonday = this.mondayClassSchedule.value;
    const formModelTuesday = this.tuesdayClassSchedule.value;
    const formModelWednesday = this.wednesdayClassSchedule.value;
    const formModelThursday = this.thursdayClassSchedule.value;
    const formModelFriday = this.fridayClassSchedule.value;
    const formModelSaturday = this.saturdayClassSchedule.value;
    const formModelSunday = this.sundayClassSchedule.value;

    // To be reviewed -- Deep copies of Form Array
    const timeslotsDeepCopyMonday: Timeslot[] = formModelMonday.mondayClasses.map((timeslot : Timeslot) => Object.assign({}, timeslot));

    // create schedule of all days
    var mondaySlots = {};
    mondaySlots["day"] = 1;
    mondaySlots["slots"] = [];

    var tuesdaySlots = {};
    tuesdaySlots["day"] = 2;
    tuesdaySlots["slots"] = [];

    var wednesdaySlots = {};
    wednesdaySlots["day"] = 3;
    wednesdaySlots["slots"] = [];

    var thursdaySlots = {};
    thursdaySlots["day"] = 4;
    thursdaySlots["slots"] = [];

    var fridaySlots = {};
    fridaySlots["day"] = 5;
    fridaySlots["slots"] = [];

    var saturdaySlots = {};
    saturdaySlots["day"] = 6;
    saturdaySlots["slots"] = [];

    var sundaySlots = {};
    sundaySlots["day"] = 7;
    sundaySlots["slots"] = [];

    let allDaysClasses = [
      {
        formTimeslots: formModelMonday.mondayClasses,
        requestTimeslots: mondaySlots
      }, {
        formTimeslots: formModelTuesday.tuesdayClasses,
        requestTimeslots: tuesdaySlots
      }, {
        formTimeslots: formModelWednesday.wednesdayClasses,
        requestTimeslots: wednesdaySlots
      }, {
        formTimeslots: formModelThursday.thursdayClasses,
        requestTimeslots: thursdaySlots
      }, {
        formTimeslots: formModelFriday.fridayClasses,
        requestTimeslots: fridaySlots
      }, {
        formTimeslots: formModelSaturday.saturdayClasses,
        requestTimeslots: saturdaySlots
      }, {
        formTimeslots: formModelSunday.sundayClasses,
        requestTimeslots: sundaySlots
      }
    ];

    for (let i = 0; i < allDaysClasses.length; i++) {
      for (let j = 0; j < allDaysClasses[i]["formTimeslots"].length; j++) {
        let formTimeslot = allDaysClasses[i]["formTimeslots"][j];
        let requestTimeslot = {};
        let settings = {};
        let startTime = this.getRequestTime(formTimeslot["start"]);
        let endTime = this.getRequestTime(formTimeslot["end"]);

        requestTimeslot["from"] = startTime;
        requestTimeslot["to"] = endTime;

        let reqSlot = Object.assign({}, requestTimeslot);

        allDaysClasses[i]["requestTimeslots"]["slots"].push(reqSlot);
      }
    }

    // Add to 'schedule' array only if particular day checkbox is selected
    if (this.scheduleDaysStatus["monday"])
      this.classSchedule["availability"].push(mondaySlots);
    if (this.scheduleDaysStatus["tuesday"])
      this.classSchedule["availability"].push(tuesdaySlots);
    if (this.scheduleDaysStatus["wednesday"])
      this.classSchedule["availability"].push(wednesdaySlots);
    if (this.scheduleDaysStatus["thursday"])
      this.classSchedule["availability"].push(thursdaySlots);
    if (this.scheduleDaysStatus["friday"])
      this.classSchedule["availability"].push(fridaySlots);
    if (this.scheduleDaysStatus["saturday"])
      this.classSchedule["availability"].push(saturdaySlots);
    if (this.scheduleDaysStatus["sunday"])
      this.classSchedule["availability"].push(sundaySlots);

    console.log(this.classSchedule);
  }

  // Function to convert Date object to hh:mm time format
  getRequestTime(date) {
    let hours = date.getHours();
    let mins = date.getMinutes();
    let time;

    hours = hours < 10
      ? "0" + hours
      : hours;
    mins = mins < 10
      ? "0" + mins
      : mins;

    time = hours + ":" + mins;

    return time;
  }

  // convert time string to Date object
  getTimepickerDate(time) {
    let date = new Date();

    date.setHours(parseInt(time.substr(0, 2)));
    date.setMinutes(parseInt(time.substr(3, 2)));

    return date;
  }

  prepareDate(dateInput) {
    let dateOutput = "";

    if (dateInput !== "") {
      dateInput.setHours(12); //avoid decrement of date due to iso string conversion
      dateOutput = dateInput.toISOString().substring(0, 10);
    }

    return dateOutput;
  }

  getFormStatus() {
    let isFormValid = true;

    // check if all input fields are valid
    for (var property in this.validationFields) {
      isFormValid = isFormValid && this.validationFields[property];
      if (!this.validationFields[property]) {
        this.generalFunctions.scrolltoinvalid(property);
        return isFormValid;
      }
    }

    // check if schedule is valid
    this.isDaysScheduleValid = this.getDaysScheduleValidityStatus();
    if (!this.isDaysScheduleValid) {
      this.generalFunctions.scrolltoinvalid("daysSchedule");
    }
    return this.isDaysScheduleValid;
  }

  prepareScheduleRequest() {
    this.prepareScheduleArray();

    // prepare start and end date
    this.classSchedule.starts_at = this.prepareDate(this.startDate);
    this.classSchedule.ends_at = this.prepareDate(this.endDate);

    console.log(this.classSchedule);
  }

  createAvailability() {
    this.prepareScheduleRequest();
    this.http.sendData(`staff/${this.trainerId}/availability?center_id=${this.center_id}`, this.classSchedule).subscribe(response => {
      console.log(response);
      this.router.navigate(["/client/staff/" + this.trainerId]);
      this.generalFunctions.openToast("Availability schedule created", 3000, "success");
    }, error => {
      this.generalFunctions.openToast("Unable to create availability schedule", 3000, "error");
    });
  }

  saveSchedule() {
    this.prepareScheduleRequest();
    this.http.updateData(`staff/${this.trainerId}/availability?center_id=${this.center_id}`, this.classSchedule).subscribe(response => {
      console.log(response);
      this.router.navigate(["/client/staff/" + this.trainerId]);
      this.generalFunctions.openToast("Availability schedule created", 3000, "success");
    }, error => {
      this.generalFunctions.openToast("Unable to create availability schedule", 3000, "error");
    });
  }

  cancelChanges() {
    this.router.navigate(["/client/staff/" + this.trainerId]);
  }

  deleteSchedule() {
    console.log(this.classSchedule);

    this.http.deleteData(`appointments/${this.trainerId}?center_id=${this.center_id}`).subscribe(response => {
      console.log(response);
      this.router.navigate(["/client/services/personal-training"]);
      this.generalFunctions.openToast("Trainer availability deleted", 3000, "success");
    }, error => {
      this.generalFunctions.openToast("Unable to delete availability schedule", 3000, "error");
    });
  }

  deleteTimeslot(slotId) {

      this.generalFunctions.openToast("Timeslot deleted", 3000, "success");

  }

  getDaysScheduleValidityStatus() {
    let isDaysInvalid = false;
    for (var property in this.scheduleDaysStatus) {
      isDaysInvalid = isDaysInvalid || this.scheduleDaysStatus[property];
    }
    return isDaysInvalid;
  }

  startDateChanged(e) {
    this.endDatepickerConfig["minDate"] = e;
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
      case "trainer-id":
        isValid = this.classSchedule.user_id.length > 0
          ? true
          : false;
        this.validationFields.trainerId = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }
  checkTheChange() {
    if (this.classSchedule.price_type == 2 || this.classSchedule.price_type == 3) {
      return;
    } else {
      this.classSchedule.price_type = 2;
    }
  }

  applyAll(index) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    allDaysClasses.forEach(element => {
      if (element !== allDaysClasses[index]) {
        let length = element.value.length;
        for (let i = 0; i < length; i++) {
          element.removeAt(0);
        }
      }
    });

    allDaysClasses[index].value.forEach(slot => {
      let timeslot = new Timeslot();
      let neto = {
        ...slot
      };
      neto["trainers"] = [neto.trainers];
      timeslot = neto;
      allDaysClasses.forEach(classes => {
        if (classes !== allDaysClasses[index]) {
          classes.push(this.fb.group(timeslot));
        }
      });
    });
  }
}
