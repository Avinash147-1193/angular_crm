import {
  Component,
  OnInit,
  OnChanges,
  ViewChild,
  ElementRef,
  ViewEncapsulation
} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "../../../../../../common/general-services";
import {ServerAuthService} from "../../../../../../common/server-auth";
import {HttpClientModule} from "@angular/common/http";
import {SelectItem} from "primeng/api";

@Component({
  selector: "app-facility-table",
  templateUrl: "./facility-table.component.html",
  styleUrls: ["./facility-table.component.scss", "../../styles/service-list.scss"]
})
export class FacilityTableComponent implements OnInit {
  center_id: any;
  pop_up_for: any = null;
  newFacility: Object = {
    name: "",
    description: ""
  };
  editMode: boolean = false;

  facilities: Object = {
    name: "",
    description: ""
  };
  adding: any;
  tool_tip_for: any = null;
  dataLoaded: boolean = false;

  constructor(private generalFunctions : GeneralServices, private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private activatedRoute : ActivatedRoute) {}

  ngOnInit() {
    this.center_id = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.getAllFacility();
  }

  addFacility() {
    this.adding = true;

    this.http.sendData(`facilities?center_id=${this.center_id}`, this.newFacility).subscribe(response => {
      this.adding = false;
      this.getAllFacility();
      this.pop_up_for = null;
      this.generalFunctions.openToast("Facility has been created", 3000, "success");
    }, err => {
      this.pop_up_for = null;
      this.generalFunctions.openToast(err.message, 3000, "error");
      this.adding = false;
    });
  }

  resetModal() {
    this.newFacility = {
      name: "",
      description: ""
    };
  }
  getAllFacility() {
    this.http.getData(`facilities?center_id=${this.center_id}`).subscribe(response => {
      this.dataLoaded = true;
      this.facilities = response.data;
    }, err => {
      console.log(err);
    });
  }
  getFacility(id) {
    this.editMode = true;
    this.http.getData(`facilities/${id}?center_id=${this.center_id}`).subscribe(success => {
      this.newFacility = success.data;

      this.pop_up_for = "add";
    }, err => {
      console.log(err);
    });
  }

  saveFacility(id) {
    this.http.updateData(`facilities/${id}?center_id=${this.center_id}`, this.newFacility).subscribe(success => {
      this.generalFunctions.openToast("Facility has been saved", 3000, "success");
      this.getAllFacility();
      this.pop_up_for = null;
      this.editMode = false;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
      this.pop_up_for = null;
      this.editMode = false;
    });
  }

  deleteFacility(obj) {
    let reqObj = obj;
    console.log("reqObj", obj);
    reqObj["status"] = 2;
    this.http.updateData(`facilities/${obj.id}?center_id=${this.center_id}`, reqObj).subscribe(success => {
      this.generalFunctions.openToast("Facility has been deleted", 3000, "success");
      this.getAllFacility();
      this.tool_tip_for = null;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
      this.tool_tip_for = null;
    });
  }
}
