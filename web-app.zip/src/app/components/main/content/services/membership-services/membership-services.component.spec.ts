import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MembershipServicesComponent } from './membership-services.component';

describe('MembershipServicesComponent', () => {
  let component: MembershipServicesComponent;
  let fixture: ComponentFixture<MembershipServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MembershipServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembershipServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
