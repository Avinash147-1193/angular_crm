import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ServerAuthService} from "../../../../../common/server-auth";
import {GeneralServices} from "../../../../../common/general-services";
import {Location} from "@angular/common";

@Component({templateUrl: "./membership-services.component.html", styleUrls: ["./membership-services.component.scss"]})
export class MembershipServicesComponent implements OnInit {
  center_id: any;
  servicePacks: any;
  placeHolder: boolean;
  service: boolean = true;
  classSchedule: boolean = true;
  membershipPlan: boolean = true;
  courses: boolean = false;
  facility: boolean = true;
  appointements: boolean = true;

  constructor(private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit() {
    this.placeHolder = true;
    this.center_id = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.getServicePacks();
  }

  getServicePacks() {
    this.http.getData("center/" + this.center_id + "/services").subscribe(success => {
      this.placeHolder = false;

      this.servicePacks = success;
      this.setRoute(this.servicePacks);
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }
  private setRoute(code) {
    code.forEach(e => {
      e.service.code == "MEMBERSHIP_PLANS" && e.status == 1
        ? (this.membershipPlan = false)
        : e.service.code == "CLASSES" && e.status == 1
          ? (this.classSchedule = false)
          : e.service.code == "SERVICEPACKS" && e.status == 1
            ? (this.service = false)
            : e.service.code == "APPOINTMENTS" && e.status == 1
              ? (this.appointements = false)
              : e.service.code == "FACILITIES" && e.status == 1
                ? (this.facility = false)
                : null;
    });
  }
}
