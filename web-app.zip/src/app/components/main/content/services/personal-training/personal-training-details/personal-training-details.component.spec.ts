import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalTrainingDetailsComponent } from './personal-training-details.component';

describe('PersonalTrainingDetailsComponent', () => {
  let component: PersonalTrainingDetailsComponent;
  let fixture: ComponentFixture<PersonalTrainingDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalTrainingDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalTrainingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
