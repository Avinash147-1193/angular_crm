import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalTrainingListComponent } from './personal-training-list.component';

describe('PersonalTrainingListComponent', () => {
  let component: PersonalTrainingListComponent;
  let fixture: ComponentFixture<PersonalTrainingListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalTrainingListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalTrainingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
