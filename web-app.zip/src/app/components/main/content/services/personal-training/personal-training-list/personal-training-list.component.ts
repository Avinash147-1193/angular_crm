import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {ServerAuthService} from 'app/common/server-auth';
import {GeneralServices} from 'app/common/general-services';
import {moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-personal-training-list',
  templateUrl: './personal-training-list.component.html',
  styleUrls: ['../../styles/service-list.scss', './personal-training-list.component.scss']
})
export class PersonalTrainingListComponent implements OnInit {
  currencySymbol: any;
  centerId: any;

  appointments: any;
  totalAppointments: any;
  trainers: any;

  hovered : null;

  constructor(private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit() {
    // this.currencySymbol = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.getAvailableTrainers();
    this.getTrainers();
  }

  getAvailableTrainers() {
    this.http.getData('appointments?center_id=' + this.centerId).subscribe(response => {
        this.appointments = response.data.sort((a, b) => {
            return a.order - b.order;
        } )

      this.totalAppointments = response.meta?.pagination?.total;
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  dropGroup(event){
    moveItemInArray(this.appointments, event.previousIndex, event.currentIndex);

    const newResObj = Object.values(this.appointments);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        appointment_id: element['id'],
        order: index + 1
      };
      arr[index] = obj;
    });
    this.http.updateData('appointments/order?center_id=' + this.centerId, {appointments : arr}).subscribe(response => {
      console.log('response', response);
    }, err => {
      console.log('err', err);
    });
}

  getTrainers() {
    this.http.getData('staff?center_id=' + this.centerId).subscribe(response => {
      this.trainers = response.data;
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  fetchName(ids) {
    let str = '';
    this.trainers?.forEach(trainer => {
      ids.forEach(element => {
        if (element === trainer.id) {
          str += (
            str.length > 0
            ? ', '
            : ' ') + trainer.first_name + ' ' + trainer.last_name;
        }
      });
    });

    return str;
  }

  showAvailableDays(days) {
    let availableDays = '';
    let allDays = [
      '',
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun'
    ];

    for (let i = 0; i < days.length; i++) {
      availableDays += allDays[days[i].day] + ', ';
    }

    return availableDays;
  }

  showWeeklySessions(days) {
    let weeklySessions = 0;

    for (let i = 0; i < days.length; i++) {
      for (let j = 0; j < days[i].slots.length; j++) {
        weeklySessions += parseInt(days[i].slots[j].slots);
      }
    }

    return weeklySessions;
  }
}
