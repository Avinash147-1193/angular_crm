import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMembershipPlansComponent } from './create-membership-plans.component';

describe('CreateMembershipPlansComponent', () => {
  let component: CreateMembershipPlansComponent;
  let fixture: ComponentFixture<CreateMembershipPlansComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateMembershipPlansComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateMembershipPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
