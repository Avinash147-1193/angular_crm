import {
    Component,
    OnInit,
    OnChanges,
    ViewEncapsulation,
    ChangeDetectorRef
  } from '@angular/core';
  import {Router, ActivatedRoute} from '@angular/router';
  import {GeneralServices} from 'app/common/general-services';

  import {GiftCardService, ServerAuthService} from 'app/common/server-auth';
  import {Location} from '@angular/common';
  import {SelectItem} from 'primeng/api';
  import {MembershipTypes} from '../../../../../../constants';

  @Component({
    selector: 'app-create-membership-plans',
    templateUrl: './create-membership-plans.component.html',
    styleUrls: [
      '../../styles/services.scss', './create-membership-plans.component.scss', '../../class-packs/create-class-packs/create-class-packs.component.scss'
    ],
    encapsulation: ViewEncapsulation.None
  })
  export class CreateMembershipPlansComponent implements OnInit,
  OnChanges {
    name: any = null;
    fileLoaded: any = null;
    currency: any;
    uploadFlag = false;
    center_id: any;
    membershipTypes =  MembershipTypes;

    isNewPlan = true;
    currentSection = 1;
    imagePreview = false;
    planPaused = false;
    isJoiningFee = false;
    isStopsAfter = false;
    noImage: any = false;
    planId = '';
    // loaderflags starts
    heyLoader = false;
    recurring = false;
    heyLoaderImage = false;
    // loaderflags ends

    // start: Applicable services modal vars
    openClassesModalFlag = false;
    classes: any;
    tempClassesSelected: any = [];
    tempClassesOption: any;

    openAppointmentsModalFlag = false;
    trainers: any;
    tempAppointmentsSelected: any = [];
    tempAppointmentsOption: any;

    allServices: any;
    classesServiceId: number;
    appointmentsServiceId: number;
    selectedServiceId: number;
    creditsValue = true;
    recurringValue = false;
    // end: Applicable services modal vars

    newPlan: any = {
      type: this.membershipTypes.SUBSCRIPTION,
      name: '',
      description: '',
      duration: 1,
      duration_type: 'month',
      service_type: 1,
      expiry_trigger: 'expiry_date',
      image_url: null,
      is_trial: false,
      trial_limit: 1,
      trial_duration_limit: 12,
      is_pause_enabled: 0,
      group_id: '',
      credits_type: 'unlimited',
      applicable_services: [
        {
          service_id: '',
          sessions: 2,
          option: 'all',
          option_id: null,
          credits: 1
        }
      ],
      settings: {
        joining_fee: 0,
        max_cycles: 12,
        pay_on_first: false,
        min_cycles: 1,
        start_type: 'immediate'

      },
      payments: {
        type: 1,
        price: 0
      }
    };

    validationFields: any = {
      planName: false,
      planGroup: false,
      price: false
    };

    isSpecificClassesValid = true;
    isSpecificTrainersValid = true;

    nextOne = false;
    nextTwo = false;
    nextThree = false;

    groups: SelectItem[] = [];
    locationScope: SelectItem[] = [];
    locationScopeList: any = [];
    groupList: any;
    pop_up_for: any = null;
    groupName: any = '';
    setCurrentGroup: any = null;
    is_recurring = true;
    creditsLoop: any = [];
    stripeOn: any = false;
    isVisible = true;
    groupsLoaded: boolean;
    isMinCycle = false;
    creating = false;

    constructor(private giftCardService : GiftCardService,
        private generalFunctions : GeneralServices,
        private router : Router,
        private route : ActivatedRoute,
        private http : ServerAuthService,
        private location : Location,
        private activatedRoute : ActivatedRoute, private cdRef : ChangeDetectorRef) {
        this.giftCardService.sub.subscribe(x => console.log('inside membership subscribing ? ', x))
    }

    ngOnInit() {
      this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
      this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
      this.getMembershipGroups();
      this.getCurrentLocation();
      this.generateCredit();
      this.getCenter();

      this.router.navigate([], {
        queryParams: {
          step: 1
        }
      });

      this.generalFunctions.plan_details = null;

      if (this.router.url.includes('/plans/create')) {
        this.isNewPlan = true;
        this.getAllServices();
        this.getClasses();
        this.getAvailableTrainers();
      } else {
        this.isNewPlan = false;

        this.planId = this.activatedRoute.snapshot.paramMap.get('id');

        this.heyLoader = true;

        this.http.getData(`plan/${this.planId}?center_id=${this.center_id}`).subscribe(response => {
          const res = response;
          const membershipPlan = res.data;

          // create edit plan object
          setTimeout(() => {
            this.newPlan.group_id = membershipPlan.service_group_id;
          }, 10);
          this.newPlan.name = membershipPlan.name;
          this.newPlan.description = membershipPlan.description;
          this.newPlan.duration = membershipPlan.duration;
          this.newPlan.duration_type = membershipPlan.duration_type;
          this.newPlan.share_type = membershipPlan.share_type;
          this.newPlan.is_pause_enabled = membershipPlan.is_pause_enabled;
          this.newPlan.is_trial = membershipPlan.is_trial;
          this.newPlan.trial_limit = membershipPlan.trial_limit;
          if (membershipPlan.type !== 3){
            this.newPlan.expiry_trigger = membershipPlan.expiry_trigger;
          }
          this.newPlan.trial_duration_limit = membershipPlan.trial_duration_limit;
          this.newPlan.settings.pause_count = membershipPlan.settings.pause_count;
          this.newPlan.settings.pause_days = membershipPlan.settings.pause_days;
          this.newPlan.settings.start_type = membershipPlan.settings.start_type;
          this.isVisible = membershipPlan.visibility === 1
            ? true
            : false;

            if(membershipPlan.type === 1 ) {
              this.newPlan.type =  this.membershipTypes.PLAN;
            }
              if(membershipPlan.type === 2 ) {
              this.newPlan.type =  this.membershipTypes.PACK;
            }

            if(membershipPlan.type === 3 ) {
              this.newPlan.type =  this.membershipTypes.SUBSCRIPTION;
            }

          // this.newPlan.type = membershipPlan.type === 1 ? this.membershipTypes.PLAN : (membershipPlan.type === 2 ? this.membershipPlan.PACK : (membershipPlan.type === 3 ? this.membershipPlan.SUBSCRIPTION : null) );
          this.is_recurring = membershipPlan.is_recurring;
          this.newPlan.payments.price = membershipPlan.amount;
          this.newPlan.settings.joining_fee = membershipPlan.settings.joining_fee;
          this.newPlan.settings.pay_on_first = membershipPlan.settings.pay_on_first;
          this.newPlan.settings.max_cycles = membershipPlan.settings.max_cycles;
          this.newPlan.settings.min_cycles = membershipPlan.settings.min_cycles;
          membershipPlan.settings.min_cycles >= 0 ?  this.isMinCycle = true : this.isMinCycle = false;
          this.newPlan.image_url = membershipPlan.image_url;
          this.newPlan.applicable_services[0].sessions = membershipPlan.applicable_services[0].sessions;
          // this.newPlan.applicable_services[0].service_type_id = membershipPlan.applicable_services[0].service_type_id;
          this.newPlan.applicable_services[0].option = membershipPlan.applicable_services[0].option;
          this.newPlan.applicable_services[0].credits = membershipPlan.applicable_services[0].credits;
          membershipPlan.applicable_services[0].credits == -1
            ? (this.newPlan.credits_type = 'unlimited')
            : (this.newPlan.credits_type = 'fixed');

          this.newPlan.applicable_services[0].service_id = membershipPlan.applicable_services[0].service_id;
          this.selectedServiceId = membershipPlan.applicable_services[0].service_id;

          if (parseInt(membershipPlan.settings.pause_count) > 0) {
            this.newPlan.is_pause_enabled = true;
          }

          if (membershipPlan.settings.joining_fee) {
            this.isJoiningFee = true;
          }

          if (membershipPlan.settings.max_cycles) {
            this.isStopsAfter = true;
          }

          // get all services
          this.getAllServices();
          this.getClasses();

          this.getAvailableTrainers();
          this.cdRef.detectChanges();
        }, error => {
          let msg;
          if (error['errors']) {
            msg = error['errors'][Object.keys(error['errors'])[0]];
          } else {
            msg = error.message;
          }
          this.generalFunctions.openToast(msg, 3000, 'error');
        });
      }
    }

    generateCredit() {
      for (let i = 1; i <= 50; i++) {
        this.creditsLoop.push({key: i, value: i});
      }
      this.creditsLoop.push({key: 'Unlimited', value: -1});
    }

    updateGroup(event) {
      this.newPlan.group_id = event.value;
    }

    getCurrentLocation() {
      this.http.getData(`center/${this.center_id}?center_id=${this.center_id}`).subscribe(response => {
        this.locationScopeList.push({
          name: '\'' + response.data.name + '\' location only',
          value: 'location'
        });
        this.locationScopeList.push({
          name: '\'' + response.data.region.name + '\' region',
          value: 'region'
        });

        this.locationScope = [];
        for (let i = 0; i < this.locationScopeList.length; i++) {
          const event = {
            label: '',
            value: ''
          };
          event.label = this.locationScopeList[i].name;
          event.value = this.locationScopeList[i].value;
          this.locationScope.push(event);
        }
        if (this.isNewPlan) {
          this.newPlan.share_type = this.locationScope[0].value;
        }
      }, err => {});
    }

    getMembershipGroups() {
      this.http.getData('groups?service_id=1&center_id=' + this.center_id).subscribe(response => {
        this.groupList = response.data;

        this.groups = [];

        for (let i = 0; i < this.groupList.length; i++) {
          const event = {
            label: '',
            value: 0
          };

          event.label = this.groupList[i].name;
          event.value = this.groupList[i].id;

          this.groups.push(event);
        }
        const defaultEvent = {
          label: '',
          value: ''
        };

        defaultEvent.label = 'Add new group';
        defaultEvent.value = 'add';
        this.groups.push(defaultEvent);
        console.log('this.groups', this.groups);
        if (this.setCurrentGroup == null) {
          this.newPlan.group_id = this.groupList[0]?.id
            ? this.groupList[0].id
            : '';
        } else {
          this.newPlan.group_id = this.setCurrentGroup;
        }
        this.groupsLoaded = true;
      }, err => {
        const defaultEvent = {
          label: '',
          value: ''
        };

        defaultEvent.label = 'Add new group';
        defaultEvent.value = 'add';
        this.groups.push(defaultEvent);
        this.groupsLoaded = true;
      });
    }

    // GET ALL SERVICES FOR THIS CENTER
    getAllServices() {
      this.http.getData('center/' + this.center_id + '/services').subscribe(response => {
        this.allServices = response;

        for (let i = 0; i < this.allServices.length; i++) {
          const service = this.allServices[i];

          if (service.service.code === 'CLASSES') {
            this.classesServiceId = service.service_id;
          } else if (service.service.code === 'APPOINTMENTS') {
            this.appointmentsServiceId = service.service_id;
          }
        }
        // set classes as default for new plan
        if (this.newPlan.applicable_services[0].service_id === '') {
          this.newPlan.applicable_services[0].service_id = this.classesServiceId;
        } else {
          this.newPlan.applicable_services[0].service_id = this.selectedServiceId;
        }

        this.heyLoader = false;
      }, err => {
        err = err;
        this.generalFunctions.openToast(err.message, 3000, 'error');
      });
    }

    getClasses() {
      this.http.getData('classes?center_id=' + this.center_id).subscribe(response => {
        this.classes = response.data;

        for (let i = 0; i < this.classes.length; i++) {
          this.classes[i].checked = false;
        }

        if (!this.isNewPlan) {
          // this.prepareSelectedClasses();
        }
      }, err => {
        const msg = err;
        this.generalFunctions.openToast(msg, 3000, 'error');
      }, () => {});
    }

    // prepareSelectedClasses() {
    //   for (let i = 0; i < this.newPlan.applicable_services[0].service_type_id.length; i++) {
    //     for (let j = 0; j < this.classes.length; j++) {
    //       if (this.newPlan.applicable_services[0].service_type_id[i] === this.classes[j].id) {
    //         this.classes[j].checked = true;
    //       }
    //     }
    //   }
    // }

    getAvailableTrainers() {
      this.http.getData(`appointments?center_id=${this.center_id}`).subscribe(response => {
        this.trainers = response.data;

        for (let i = 0; i < this.trainers.length; i++) {
          this.trainers[i].checked = false;
        }

        if (!this.isNewPlan) {
          // this.prepareSelectedTrainers();
        }
      }, err => {
        const msg = err;
        this.generalFunctions.openToast(msg, 3000, 'error');
      }, () => {});
    }

    // prepareSelectedTrainers() {
    //   for (let i = 0; i < this.newPlan.applicable_services[0].service_type_id.length; i++) {
    //     for (let j = 0; j < this.trainers.length; j++) {
    //       if (this.newPlan.applicable_services[0].service_type_id[i] === this.trainers[j].id) {
    //         this.trainers[j].checked = true;
    //       }
    //     }
    //   }
    // }

    // image upload module
    imageClick(event) {
      document.getElementById('imageInput').click();
    }

    editImageClick() {
      document.getElementById('imageInputTwo').click();
    }

    removeFile() {
      this.newPlan.image_url = null;
      this.noImage = true;
    }

    ngOnChanges(e) {}

    openRecurring() {
      this.recurring = true;
    }

    getFormStatus() {
      let isFormValid = true;

      for (const property in this.validationFields) {
        // escape check for credits when plan in unlimited
        if (this.newPlan.applicable_services[0].sessions === 1 && property === 'credits') {
          continue;
        }

        // proceed with check
        isFormValid = isFormValid && this.validationFields[property];
        if (!this.validationFields[property]) {
          this.generalFunctions.scrolltoinvalid(property);
          break;
        }
      }

      return isFormValid;
    }

    preparePlanRequest() {

      if (!this.isJoiningFee) {
        this.newPlan.settings.joining_fee = 0;
      }

      this.newPlan.visibility = this.isVisible
        ? 1
        : 2;

        if (this.is_recurring) {
            this.newPlan.payments.is_recurring = 1;
            delete this.newPlan.expiry_trigger;
        } else {
            this.newPlan.payments.is_recurring = 0
        }

        if (!this.is_recurring) {
            delete this.newPlan.settings.max_cycles;
            delete this.newPlan.settings.min_cycles;
            delete this.newPlan.settings.pay_on_first;
        }

        if (this.newPlan.type !== this.membershipTypes.PACK) {
            delete this.newPlan.settings.start_type;
        }

    }

    createPlan() {
      this.nextThree = true;
      this.creating = true;
      // section Three invalid
      if (!this.validationFields.price) {
        this.generalFunctions.scrolltoinvalid('price');
        this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
        this.creating = false;
        return;
      }

      this.newPlan.credits_type == 'unlimited'
        ? (this.newPlan.applicable_services[0].credits = -1)
        : this.newPlan.applicable_services[0].credits;

      this.preparePlanRequest();
      console.log('this.newPlan', this.newPlan)
      this.http.sendData(`plan/create?center_id=${this.center_id}`, this.newPlan).subscribe(response => {
        this.router.navigate(['/client/services/plans']);
        this.creating = false;

        this.generalFunctions.openToast('Membership  created', 3000, 'success');
      }, error => {
        this.creating = false;

        let msg;
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }

    savePlan() {
      const isFormValid = this.getFormStatus();

      if (!isFormValid) {
        this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
        return;
      }

      this.newPlan.credits_type == 'unlimited'
        ? (this.newPlan.applicable_services[0].credits = -1)
        : this.newPlan.applicable_services[0].credits;

      this.preparePlanRequest();

      this.http.updateData(`plan/${this.planId}?center_id=${this.center_id}`, this.newPlan).subscribe(response => {
        this.router.navigate(['/client/services/plans']);
        this.generalFunctions.openToast('Membership  plan saved', 3000, 'success');
      }, error => {
        let msg;
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }

    cancelChanges() {
      this.router.navigate(['/client/services/plans']);
    }

    deletePlan() {
      this.http.deleteData(`plan/${this.planId}?center_id=${this.center_id}`).subscribe(response => {
        this.router.navigate(['/client/services/plans']);
        this.generalFunctions.openToast('Membership  plan deleted', 3000, 'success');
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
    }

    formValidate(field) {
      let isValid = true;

      switch (field) {
        case 'plan-name':
          isValid = !this.newPlan.name.replace(/\s/g, '').length
            ? false
            : true; // check if field contains only whitespaces
          this.validationFields.planName = isValid;
          break;

        case 'plan-group':
          isValid = !this.validateId(this.newPlan.group_id)
            ? false
            : true;
          this.validationFields.planGroup = isValid;
          break;
          // (^[0][1-9]+)|([1-9]\d*)

        case 'price':
          isValid = (this.newPlan.payments.price >= 0) && (this.newPlan.payments.price !== '')
            ? true
            : false;
          this.validationFields.price = isValid;
          break;

        default:
          break;
      }

      return !isValid;
    }

    validateId(num) {
      const re = /(^[0][1-9]+)|([1-9]\d*)/;
      return re.test(num);
    }

    goToNext(current, next) {
      switch (current) {
        case 1:
          this.nextOne = true;
          this.router.navigate([], {
            queryParams: {
              step: 2
            }
          });

          if (!this.validationFields.planName) {
            this.generalFunctions.scrolltoinvalid('planName');
            this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            return;
          }
          if (!this.validationFields.planGroup) {
            this.generalFunctions.scrolltoinvalid('planName');
            this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            return;
          }

          break;

        case 2:
          this.nextTwo = true;
          this.router.navigate([], {
            queryParams: {
              step: 3
            }
          });

          if (this.newPlan.applicable_services[0].sessions === 2) {}
          break;

        default:
          break;
      }

      this.currentSection++;
      document.getElementById(next).click();
    }

    goBack(collapse) {
      this.currentSection--;
      document.getElementById(collapse).click();
    }

    pausePlan() {
      this.planPaused = !this.planPaused;
    }

    toggleJoiningFee() {
      this.isJoiningFee = !this.isJoiningFee;
    }

    getCenter() {
      const center_id = JSON.parse(localStorage.getItem('currentUser')).center_id;
      this.http.getData('center/' + center_id).subscribe(success => {
        success.data.gateway_id
          ? (this.stripeOn = true)
          : (this.stripeOn = false);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
    }

    checkStripe() {
      if (this.stripeOn == false) {
        this.generalFunctions.openToast('Connect stripe to enable recurring', 3000, 'success');
      }
    }

    // Classes modal functions
    openClassesModal() {
      this.openClassesModalFlag = true;
      this.isSpecificClassesValid = true;
      // record saved state
      this.tempClassesOption = this.newPlan.applicable_services[0].option;
      this.tempClassesSelected = this.getTempClassesSelected();
    }

    closeClassesModal(action) {
      if (action === 'cancel') {
        this.isSpecificClassesValid = false;
        this.newPlan.applicable_services[0].option = this.tempClassesOption;

        for (let i = 0; i < this.classes.length; i++) {
          this.classes[i].checked = false;
          for (let j = 0; j < this.tempClassesSelected.length; j++) {
            if (this.classes[i].id === this.tempClassesSelected[j]) {
              this.classes[i].checked = true;
            }
          }
        }
      } else if (action === 'apply') {
        // Validation for specific classes option
        if (this.newPlan.applicable_services[0].option === 'selection') {
          this.isSpecificClassesValid = false;
          // check if atleast one class selected
          for (let i = 0; i < this.classes.length; i++) {
            if (this.classes[i].checked) {
              this.isSpecificClassesValid = true;
              break;
            }
          }
          if (!this.isSpecificClassesValid) {
            return;
          }
        }
      }

      this.openClassesModalFlag = false;
    }

    getTempClassesSelected() {
      let selected = [];
      for (let i = 0; i < this.classes.length; i++) {
        if (this.classes[i].checked === true) {
          selected.push(this.classes[i].id);
        }
      }
      return selected;
    }

    // Appointments modal functions
    openAppointmentsModal() {
      this.openAppointmentsModalFlag = true;
      this.isSpecificTrainersValid = true;
      // record saved state
      this.tempAppointmentsOption = this.newPlan.applicable_services[0].option;
      this.tempAppointmentsSelected = this.getTempAppointmentsSelected();
    }

    closeAppointmentsModal(action) {
      if (action === 'cancel') {
        this.isSpecificClassesValid = false;
        this.newPlan.applicable_services[0].option = this.tempAppointmentsOption;

        for (let i = 0; i < this.trainers.length; i++) {
          this.trainers[i].checked = false;
          for (let j = 0; j < this.tempAppointmentsSelected.length; j++) {
            if (this.trainers[i].id === this.tempAppointmentsSelected[j]) {
              this.trainers[i].checked = true;
            }
          }
        }
      } else if (action === 'apply') {
        // Validation for specific classes option
        if (this.newPlan.applicable_services[0].option === 'selection') {
          this.isSpecificTrainersValid = false;
          // check if atleast one class selected
          for (let i = 0; i < this.trainers.length; i++) {
            if (this.trainers[i].checked) {
              this.isSpecificTrainersValid = true;
              break;
            }
          }

          if (!this.isSpecificTrainersValid) {
            return;
          }
        }
      }
      this.openAppointmentsModalFlag = false;
    }

    getTempAppointmentsSelected() {
      let selected = [];
      for (let i = 0; i < this.trainers.length; i++) {
        if (this.trainers[i].checked === true) {
          selected.push(this.trainers[i].id);
        }
      }

      return selected;
    }

    toggleCredits() {
      this.creditsValue == false
        ? (this.newPlan.applicable_services[0].sessions = 1)
        : (this.newPlan.applicable_services[0].sessions = 2);
    }

    mapImageUrl(event) {
      this.newPlan.image_url = event;
    }

    checkForAdd(event) {
      if (event.value == 'add') {
        this.pop_up_for = 'addGroup';
      }
    }

    createGroup() {
      const reqObj = {
        name: this.groupName,
        service_id: 1
      };
      this.http.sendData('groups?center_id=' + this.center_id, reqObj).subscribe(response => {
        this.setCurrentGroup = response.data.id;
        this.getMembershipGroups();
        this.generalFunctions.openToast('New Group is added', 3000, 'success');
        this.pop_up_for = null;
      }, err => {
        this.pop_up_for = null;
      });
    }
    callForCancel() {
      this.groups = [];
      this.newPlan.group_id = '';
      this.getMembershipGroups();
      this.pop_up_for = null;
    }

    setRecurring(type, method = 'plan') {
      if(type === 'plan'){
        if(false){
          this.newPlan.type = this.membershipTypes.PLAN;
        }
         else{
          this.newPlan.type = this.membershipTypes.SUBSCRIPTION;
        }
      } else if (method === 'pack') {
        this.newPlan.type = this.membershipTypes.PACK;
      }

        this.is_recurring = type;
    }
  }
