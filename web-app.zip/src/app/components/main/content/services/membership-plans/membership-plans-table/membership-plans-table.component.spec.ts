import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MembershipPlansTableComponent } from './membership-plans-table.component';

describe('MembershipPlansTableComponent', () => {
  let component: MembershipPlansTableComponent;
  let fixture: ComponentFixture<MembershipPlansTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MembershipPlansTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembershipPlansTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
