import {Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import {ServerAuthService} from 'app/common/server-auth';
import {GeneralServices} from 'app/common/general-services';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-membership-plans-table',
  templateUrl: './membership-plans-table.component.html',
  styleUrls: ['../../styles/service-list.scss', './membership-plans-table.component.scss']
})
export class MembershipPlansTableComponent implements OnInit {
  currencySymbol: any;
  centerId: any;

  membershipPlans: any;
  totalPlans: any;

  isOpenGroup: any;
  isDropper = false;
  isAddMode = false;
  newMode: any = {
    name: 'Untitled Group',
    service_id: 1
  };
  allPlans: any;
  groupList: any;
  flags: any = {
    plansLoaded: false
  };
  editableGroup: any = null;
  pop_up_for: any = null;
  groupId: any;
  hovered = null;
  hoveredService = null;

  @ViewChild('myInputName')myInput: ElementRef;

  constructor(private http: ServerAuthService, private generalFunctions: GeneralServices) {}

  ngOnInit() {
    this.currencySymbol = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.getMembershipGroups();
    document.addEventListener('click', event => {
      this.documentClickHandler(event);
    });
  }

  documentClickHandler(e) {
    Array.prototype.forEach.call(document.getElementsByClassName('more-options-list'), (item, index) => {
      item.classList.contains('display-none')
        // tslint:disable-next-line: no-unused-expression
        ? ''
        : item.classList.add('display-none');
    });
    if (e.target.parentElement) {
      if (e.target.parentElement.classList.contains('more-options-icon')) {
        const list = this.generalFunctions.parents(e.target)[1].getElementsByClassName('more-options-list')[0];
        list.classList.remove('display-none');
      }
    }
  }

  handleEnter(event) {
    if (event.keyCode === 13) {
        const target = event.target;
        target.blur();
    }
  }

  handleRenameEnter(event, id, name) {
    if (event.keyCode === 13) {
      this.renameGroup(id, name);
    }
  }

  getMembershipGroups() {
    this.http.getData('groups?service_id=1&center_id=' + this.centerId).subscribe(response => {
      this.groupList = response.data;
      this.groupList.forEach((element, index) => {
        this.groupList[index].newName = element.name;
      });
    }, err => {});
  }

  saveGroup() {
    this.http.sendData('groups?center_id=' + this.centerId, this.newMode).subscribe(response => {
      this.getMembershipGroups();
      this.generalFunctions.openToast('New Group is added', 3000, 'success');
    }, err => {});
    this.isAddMode = false;
  }

  openGroup(id) {
    if (this.isOpenGroup == id) {
      this.isOpenGroup = null;
    } else {
      this.isOpenGroup = id;
    }
    this.flags.plansLoaded = false;
    const reqObj = {
      filterBy: {
        group_id: id
      }
    };
    this.allPlans = {};
    this.http.sendData('plan?center_id=' + this.centerId, reqObj).subscribe(response => {
      console.log('response', response);
      this.allPlans.length = response.data.length;
      this.allPlans = response.data;
      this.flags.plansLoaded = true;
    }, err => {
      console.log('response', err);
    });
  }

  triggerOptions() {
    this.isDropper = !this.isDropper;
  }

  addMode() {
    this.isAddMode = true;
    this.newMode.name = 'Untitled Group';
  }

  dropGroup(event) {

    moveItemInArray(this.groupList, event.previousIndex, event.currentIndex);

    const newResObj = Object.values(this.groupList);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        group_id: element['id'],
        order: index + 1
      };
      arr[index] = obj;
    });
    this.http.updateData('groups/order?center_id=' + this.centerId, {groups : arr}).subscribe(response => {
    }, err => {
    });
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.allPlans, event.previousIndex, event.currentIndex);
    const newResObj = Object.values(this.allPlans);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        plan_id: element['id'],
        order: index + 1
      };
      arr[index] = obj;
    });
    this.http.patchData('plan/order?center_id=' + this.centerId, arr).subscribe(response => {
    }, err => {
     this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  editGroup(id) {
    this.editableGroup = id;
  }

  renameGroup(id, newName) {
    this.http.updateData(`groups/${id}?center_id=${this.centerId}`, {
      name: newName,
      status: 1
    }).subscribe(response => {
      console.log('response', response);
      this.editableGroup = null;
      this.generalFunctions.openToast('New name updated', 3000, 'success');
      this.getMembershipGroups();
    }, err => {
      this.generalFunctions.openToast(err, 3000, 'error');
      this.editableGroup = null;
      this.getMembershipGroups();
    });
  }

  deleteGroup() {
    this.http.updateData(`groups/${this.groupId}?center_id=${this.centerId}`, {status: 0}).subscribe(response => {
      this.pop_up_for = null;
      this.generalFunctions.openToast('Group archieved', 3000, 'success');
      this.getMembershipGroups();
    }, err => {
      this.pop_up_for = null;

      this.generalFunctions.openToast(err, 3000, 'error');
      this.getMembershipGroups();
    });
  }
}
