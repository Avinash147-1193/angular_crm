import {
  Component,
  OnInit,
  OnChanges,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ViewEncapsulation
} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {FormControl, FormGroup, FormBuilder, FormArray} from '@angular/forms';
import {Timeslot, Price} from '../../models/schedule.model';
import {SelectItem} from 'primeng/api';
import {defineLocale, enGbLocale} from 'ngx-bootstrap/chronos';
import {BsLocaleService} from 'ngx-bootstrap/datepicker';
import {ServiceId, MembershipTypes} from '../../../../../../constants';

@Component({
  selector: 'app-class-schedule-details',
  templateUrl: './class-schedule-details.component.html',
  styleUrls: [
    '../../styles/services.scss', '../../styles/schedule.scss', './class-schedule-details.component.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class ClassScheduleDetailsComponent implements OnInit,
OnChanges {
  pop_up_for: any;

  applyMon: boolean = false;
  openSlots: any = [];

  mondayClassSchedule: FormGroup;
  mondayClasses: FormArray;

  tuesdayClassSchedule: FormGroup;
  tuesdayClasses: FormArray;

  wednesdayClassSchedule: FormGroup;
  wednesdayClasses: FormArray;

  thursdayClassSchedule: FormGroup;
  thursdayClasses: FormArray;

  fridayClassSchedule: FormGroup;
  fridayClasses: FormArray;

  saturdayClassSchedule: FormGroup;
  saturdayClasses: FormArray;

  sundayClassSchedule: FormGroup;
  sundayClasses: FormArray;

  plansForm: FormGroup;
  allPlans: FormArray;

  planPackForm: FormGroup;
  allPlanPack: FormArray;

  name: any = null;
  fileLoaded: any = null;
  currency: any;
  uploadFlag = false;
  center_id: any;

  isNewSchedule: boolean = true;
  currentSection: number = 1;
  imagePreview: boolean = false;
  planPaused: boolean = false;
  isClassEndDate: boolean = false;
  isVisible: boolean = true;

  classId: string = '';

  // loaderflags starts
  heyLoader: boolean = false;
  heyLoaderImage: boolean = false;
  imageUrl: any;
  noImage: any = false;
  // loaderflags ends

  classSchedule: any = {
    name: '',
    category: 0,
    description: '',
    // 'room': '',
    category_id: 0,
    users: [],
    max_allowed: '',
    level: 'none',
    starts_at: '',
    ends_at: '',
    price_type: 4,
    visibility: false,
    schedule: [],
    pricing: [],
    image: null,
    recurring_period: '1 week',
    event_app_id : '',
    is_online : '',
    is_featured : 1,
    policy_id: null,
    color: '#eb6363'
  };

  changeType: any = 2;
  resetType: any = 0;
  classDetails: any;

  allServices: any;
  membershipPlans: any;
  membershipPacks: any;
  classesServiceId: any;

  startDate: any = new Date();
  endDate: any = '';
  isDropinOne: boolean = false;
  dropinOnePrice: number = 0;
  isAllMembers: boolean = false;
  allMembersPrice: number = 0;
  isDropinTwo: boolean = false;
  dropinTwoPrice: number = 0;

  scheduleDaysStatus: any = {
    monday: false,
    tuesday: false,
    wednesday: false,
    thursday: false,
    friday: false,
    saturday: false,
    sunday: false
  };

  startDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default',
    minDate: new Date()
  };

  endDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default',
    minDate: new Date()
  };

  membersCustomerType: number = 1;
  dropinCustomerType: number = 2;

  validationFields: any = {
    className: false,
    classSize: false
  };

  nextOne: boolean = false;
  nextTwo: boolean = false;

  isDaysScheduleValid: boolean = true;

  trainers: any;
  trainersDropdown: SelectItem[] = [];

  zoomUsers: any;
  zoomUsersDropdown: SelectItem[] = [];

  policy: any;
  policyDropdown: SelectItem[] = [];


  weeksDropdown: SelectItem[] = [
    {
      label: '1 week',
      value: '1 week'
    }, {
      label: '2 week',
      value: '2 week'
    }, {
      label: '3 week',
      value: '3 week'
    }, {
      label: '4 week',
      value: '4 week'
    }, {
      label: '5 week',
      value: '5 week'
    }, {
      label: '6 week',
      value: '6 week'
    }, {
      label: '7 week',
      value: '7 week'
    }, {
      label: '8 week',
      value: '8 week'
    }
  ];

  facilities: any;
  facilityDropdown: SelectItem[] = [];

  categories: any;
  categoriesDropdown: SelectItem[] = [];

  pageLoader: boolean = false;

  deleteSlotDay: any;
  deleteSlotIndex: any;
  priceType: any = 6;
  loaded: any = false;
  locale: any = 'en';
  hovered: any = '';
  serviceGroup: any;
  membershipGroup: any;

  newPricingService: any = [];
  pricingLoader: any = false;
  isOnline: any = false;
  zoomDropdown: SelectItem[] = [];
  zoomId: any;

  memberships: any;
  membershipsGroup: any;

  colors = ['#eb6363', '#ff9500', '#ebd700', '#89cc49', '#4bdbab', '#00ace0', '#6b70ff', '#bb6df2', '#ff73cc', '#9c9c9c'];

  constructor(
      private generalFunctions: GeneralServices,
      private localeService: BsLocaleService,
      private router: Router,
      private http: ServerAuthService,
      private activatedRoute: ActivatedRoute,
      private fb: FormBuilder,
      private cdRef: ChangeDetectorRef) {
    defineLocale('en-gb', enGbLocale);
  }

  // getter functions for quick access to timeslots formarray
  get mondayTimeslots(): FormArray {
    return this.mondayClassSchedule.get('mondayClasses')as FormArray;
  }

  get tuesdayTimeslots(): FormArray {
    return this.tuesdayClassSchedule.get('tuesdayClasses')as FormArray;
  }

  get wednesdayTimeslots(): FormArray {
    return this.wednesdayClassSchedule.get('wednesdayClasses')as FormArray;
  }

  get thursdayTimeslots(): FormArray {
    return this.thursdayClassSchedule.get('thursdayClasses')as FormArray;
  }

  get fridayTimeslots(): FormArray {
    return this.fridayClassSchedule.get('fridayClasses')as FormArray;
  }

  get saturdayTimeslots(): FormArray {
    return this.saturdayClassSchedule.get('saturdayClasses')as FormArray;
  }

  get sundayTimeslots(): FormArray {
    return this.sundayClassSchedule.get('sundayClasses')as FormArray;
  }

  get planPrices(): FormArray {
    return this.plansForm.get('allPlans')as FormArray;
  }

  get planPackPrices(): FormArray {
    return this.planPackForm.get('allPlanPack')as FormArray;
  }

  addWeekdayTimeslot(day: string) {
    let timeslot = new Timeslot();

    timeslot['trainers'] = this.classSchedule['trainers'];
    timeslot['level'] = this.classSchedule['level'];
    timeslot['max_allowed'] = '';
    timeslot['visibility'] = this.isVisible;

    switch (day) {
      case 'monday':
        this.mondayTimeslots.push(this.fb.group(timeslot));
        console.log('monday', this.mondayClassSchedule);
        break;

      case 'tuesday':
        this.tuesdayTimeslots.push(this.fb.group(timeslot));
        break;

      case 'wednesday':
        this.wednesdayTimeslots.push(this.fb.group(timeslot));
        break;

      case 'thursday':
        this.thursdayTimeslots.push(this.fb.group(timeslot));
        break;

      case 'friday':
        this.fridayTimeslots.push(this.fb.group(timeslot));
        break;

      case 'saturday':
        this.saturdayTimeslots.push(this.fb.group(timeslot));
        break;

      case 'sunday':
        this.sundayTimeslots.push(this.fb.group(timeslot));
        break;

      default:
        break;
    }
  }

  deleteWeekdayTimeslot(day, index) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    // delete timeslot api
    // if (allDaysClasses[day].at(index).value.isSaved == true) {
    //   this.deleteTimeslot(allDaysClasses[day].at(index).value.slotId);
    // }

    // remove formarray control
    allDaysClasses[day].removeAt(index);

    // if deleting last slot, then unselect day
    if (allDaysClasses[day].value.length === 0) {
      switch (day) {
        case 0:
          this.scheduleDaysStatus.monday = false;
          break;

        case 1:
          this.scheduleDaysStatus.tuesday = false;
          break;

        case 2:
          this.scheduleDaysStatus.wednesday = false;
          break;

        case 3:
          this.scheduleDaysStatus.thursday = false;
          break;

        case 4:
          this.scheduleDaysStatus.friday = false;
          break;

        case 5:
          this.scheduleDaysStatus.saturday = false;
          break;

        case 6:
          this.scheduleDaysStatus.sunday = false;
          break;

        default:
          break;
      }
    }
  }

  mapImageUrl(event) {
    this.classSchedule.image = event;
  }

  dayToggle(day) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    let allDays = [
      'monday',
      'tuesday',
      'wednesday',
      'thursday',
      'friday',
      'saturday',
      'sunday'
    ];

    if (allDaysClasses[day].value.length === 0) {
      this.addWeekdayTimeslot(allDays[day]);
    }

    // check validity of daysSchedule -- check if at least one day is selected
    this.isDaysScheduleValid = false;
    for (var property in this.scheduleDaysStatus) {
      if (this.scheduleDaysStatus[property]) {
        this.isDaysScheduleValid = true;
      }
    }
  }

  createAllClassSchedules(mondayClasses) {
    this.mondayClassSchedule = this.fb.group({mondayClasses: this.fb.array([])});

    this.tuesdayClassSchedule = this.fb.group({tuesdayClasses: this.fb.array([])});

    this.wednesdayClassSchedule = this.fb.group({wednesdayClasses: this.fb.array([])});

    this.thursdayClassSchedule = this.fb.group({thursdayClasses: this.fb.array([])});

    this.fridayClassSchedule = this.fb.group({fridayClasses: this.fb.array([])});

    this.saturdayClassSchedule = this.fb.group({saturdayClasses: this.fb.array([])});

    this.sundayClassSchedule = this.fb.group({sundayClasses: this.fb.array([])});

    this.addWeekdayTimeslot('monday');
    this.addWeekdayTimeslot('tuesday');
    this.addWeekdayTimeslot('wednesday');
    this.addWeekdayTimeslot('thursday');
    this.addWeekdayTimeslot('friday');
    this.addWeekdayTimeslot('saturday');
    this.addWeekdayTimeslot('sunday');
  }

  createPlanPrices(prices) {
    this.plansForm = this.fb.group({allPlans: this.fb.array([])});
  }

  createPlanPackPrices(prices) {
    this.planPackForm = this.fb.group({allPlanPack: this.fb.array([])});
  }

  ngOnInit() {
    this.localeService.use('en-gb');
    this.createAllClassSchedules([]);
    this.createPlanPrices([]);
    this.createPlanPackPrices([]);

    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.generalFunctions.plan_details = null;

    // create schedule route
    if (this.router.url.includes('/create')) {
      this.isNewSchedule = true;
      this.getAllServices();
      this.getTrainers();
      this.getZoomUsers();
    //   this.getMembershipPacks();
      this.getMembershipPlans();

      this.getAllFacility();
      this.prepareZoom();
      this.getPolicy();
    } else {
      this.isNewSchedule = false;

      this.classId = this.activatedRoute.snapshot.paramMap.get('id');

      this.pageLoader = true;
      this.http.getData(`classes/${this.classId}?center_id=${this.center_id}`).subscribe(response => {
        var res = response;
        this.classDetails = res.data;

        // initialize edit class object
        this.classSchedule.color = this.classDetails.color;
        this.classSchedule.name = this.classDetails.name;
        this.classSchedule.description = this.classDetails.description;
        this.classSchedule.max_allowed = this.classDetails.max_allowed;
        this.classSchedule.level = this.classDetails.level;
        this.classSchedule.price_type = this.classDetails.price_type;
        this.classSchedule.recurring_period = this.classDetails.recurring_period;
        this.classSchedule.is_online = this.classDetails.is_online == 1 ? true : false;
        this.classSchedule.event_app_id = this.classDetails.event_app_id;
        this.classSchedule.policy_id = this.classDetails.policy_id;
        this.classSchedule.is_featured = this.classDetails.is_featured ? 1 : 0;
        if (this.classSchedule.price_type == 3 || this.classSchedule.price_type == 2) {
          this.priceType = 7;
        } else if (this.classDetails.price_type == 4 || this.classSchedule.price_type == 5) {
          this.priceType = 6;
        } else if (this.classDetails.price_type == 1) {
          this.priceType = 1;
        }
        this.loaded = true;
        this.classSchedule.image = this.classDetails.image;
        // this.classSchedule.users = this.classDetails.users;
        this.startDate = new Date(this.classDetails.starts_at);
        this.isVisible = this.classDetails.visibility === 1
          ? true
          : false;

        if (this.classDetails.ends_at !== null) {
          this.isClassEndDate = true;
          this.endDate = new Date(this.classDetails.ends_at);
        }

        this.prepareScheduleForm();
        this.getAllServices();
        this.getTrainers();
        this.getZoomUsers();
        // this.getMembershipPacks();
        this.getMembershipPlans();
        this.getPolicy();
        this.getAllFacility();
        this.prepareZoom();
        // this.preparePricingForm();
        // this.pageLoader = false;
      }, error => {
        let msg;
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }
  }

  ngOnChanges(e) {}

  removeFile() {
    this.classSchedule.image = null;
    this.classDetails.image = null;
    this.noImage = true;
  }

  getTrainers() {
    this.http.getData('staff?center_id=' + this.center_id).subscribe(response => {
      this.trainers = response.data;
      this.prepareTrainersMultiselect();
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  getPolicy() {
    this.http.getData('policies?center_id=' + this.center_id).subscribe(response => {
        this.policy = response.data;
        this.preparePolicySelect();
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
      }, () => {});
  }

  preparePolicySelect() {
   this.policyDropdown =  this.policy.map( pol =>  {
       return {'label' :  pol.name, 'value' : pol.id};
    })
    if (this.isNewSchedule) {
      const policy =   this.policy.filter(pol => pol.is_default);
      this.classSchedule.policy_id = policy[0]?.id;
    }
  }


  getZoomUsers() {
    this.http.getData('apps/zoom/users/map?center_id=' + this.center_id).subscribe(success => {
        this.zoomUsers = success.users;
       this.zoomUsers.forEach(staff => {
            if (staff.zoom_user) {
                staff.zoomId = staff.zoom_user.id;
            } else {
                staff.zoomId = null;
            }
        });
        this.prepareZoomMultiselect();


      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
  }

  prepareZoomMultiselect() {

    for (let i = 0; i < this.zoomUsers.length; i++) {
        if(this.zoomUsers[i].zoomId)
        {
            let trainer = {
                label: '',
                value: 0
              };

              trainer.label = this.zoomUsers[i].name
              trainer.value = this.zoomUsers[i].id;
              this.zoomUsersDropdown.push(trainer);
        }

      }

  }

  getAllFacility() {
    this.http.getData(`facilities?center_id=${this.center_id}`).subscribe(response => {
      this.facilities = response.data;
      this.prepareFacility();
    }, err => {});
  }

  prepareZoom() {
    this.http.getData(`apps?center_id=${this.center_id}`).subscribe(success => {
        success = success;
        const zoom =  success.apps.filter(app => app.app.name === 'Zoom');

        if (zoom.length > 0) {
            let val = {
                label: 'Zoom meeting (Automatic)',
                value: zoom[0]?.app?.id
              };

              this.zoomId =  zoom[0]?.app?.id;
              this.zoomDropdown.push(val);
        }
      }, error => {
        this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
      });

      let val = {
          label : 'Add Link Manually',
            value : null
          };

      this.zoomDropdown.push(val);
  }

  prepareFacility() {
    if (this.facilities.length > 0) {
      for (let i = 0; i < this.facilities.length; i++) {
        let category = {
          label: '',
          value: 0
        };

        category.label = this.facilities[i].name;
        category.value = this.facilities[i].id;

        this.facilityDropdown.push(category);
      }

      if (!this.isNewSchedule) {
        this.classSchedule.facility_id = this.classDetails.facility_id;
      }
    }
    else {
      let category = {
        label: '',
        value: ''
      };
      category.label = 'No facility found, click to add new';
      category.value = 'add';
      this.facilityDropdown.push(category);
    }
  }

  classModeChanged(event) {

    this.classSchedule.users = [];

  }

  prepareTrainersMultiselect() {
    for (let i = 0; i < this.trainers.length; i++) {
      let trainer = {
        label: '',
        value: 0
      };

      trainer.label = this.trainers[i].first_name + ' ' + this.trainers[i].last_name;
      trainer.value = this.trainers[i].id;

      this.trainersDropdown.push(trainer);
    }

    if (!this.isNewSchedule) {
      this.prepareSelectedTrainers();
    }
  }

  prepareSelectedTrainers() {
    for (let i = 0; i < this.classDetails.users.length; i++) {
      this.classSchedule.users.push(this.classDetails.users[i].id);
    }

  }

  getAllServices() {
    this.http.getData('center/' + this.center_id + '/services').subscribe(response => {
      this.allServices = response;

      for (let i = 0; i < this.allServices.length; i++) {
        let service = this.allServices[i];

        if (service.service.code === 'CLASSES') {
          this.classesServiceId = service.service_id;
          break;
        }
      }

      this.getCategories();
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  getCategories() {
    this.http.getData('categories?center_id=' + this.center_id + '&service_id=' + this.classesServiceId).subscribe(response => {
      this.categories = response.data;
      this.prepareCategoriesDropdown();
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  prepareCategoriesDropdown() {
    for (let i = 0; i < this.categories.length; i++) {
      let category = {
        label: '',
        value: 0
      };
      category.label = this.categories[i].name;
      category.value = this.categories[i].id;
      this.categoriesDropdown.push(category);
    }

    if (!this.isNewSchedule) {
      this.classSchedule.category_id = this.classDetails.category_id;
    }

    this.pageLoader = false;
  }

  getMembershipPlans() {
    let reqObj = {
      filterBy: {
        applicable_services: [ServiceId.SERVICE_ID_CLASS]
      }
    };
    this.http.sendData('plan?center_id=' + this.center_id, reqObj).subscribe(response => {
      this.membershipPlans = response.data.filter(plan => plan.type === MembershipTypes.PLAN || plan.type === MembershipTypes.SUBSCRIPTION);
      this.membershipPacks = response.data.filter(pack => pack.type === MembershipTypes.PACK);

      this.memberships = response.data;

    //   this.createPricingPlansArray();
      this.createMembershipsArray()
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

//   getMembershipPacks() {
//     let reqObj = {
//       filterBy: {
//         applicable_services: [ServiceId.SERVICE_ID_CLASS]
//       }
//     };
//     this.http.sendData('packs?center_id=' + this.center_id, reqObj).subscribe(response => {
//       var res = response;
//       this.membershipPacks = res.data;
//       this.createPricingPackArray();
//     }, err => {
//       const msg = err;
//       this.generalFunctions.openToast(msg, 3000, 'error');
//     }, () => {});
//   }

  createPricingPackArray() {
    // this.getServiceGroups();

    // let newPriceNeo = new Price();

    // for (let i = 0; i < this.membershipPacks.length; i++) {
    //   newPriceNeo.planId = this.membershipPacks[i].id;
    //   newPriceNeo.planName = this.membershipPacks[i].name;
    //   newPriceNeo.isChecked = false;
    //   newPriceNeo.price = 0;
    //   newPriceNeo["type"] = "pack";
    //   this.planPrices.push(this.fb.group(newPriceNeo));
    //   this.planPackPrices.push(this.fb.group(newPriceNeo));
    // }
  }

  createNewPricingPackArray(){


      let newServicePacks = this.serviceGroup;
      this.serviceGroup.forEach((element, index) => {
        newServicePacks[index].pack = [];
        this.membershipPacks.forEach((e, i) => {
          if (e.service_group_id == element.id) {

            newServicePacks[index].pack.push({
                planId : e.id,
                planName : e.name,
                isChecked : false,
                price : 0,
                type : 'pack',
              });
          }
        });
      });
    this.newPricingService = this.newPricingService.concat(newServicePacks);

  }

  createNewPricingPlanArray(){
    let newServicePacks = this.membershipGroup;
    this.membershipGroup.forEach((element, index) => {
      newServicePacks[index].pack = [];
      this.membershipPlans.forEach((e, i) => {
        if (e.service_group_id == element.id) {

          newServicePacks[index].pack.push({
              planId : e.id,
              planName : e.name,
              isChecked : false,
              price : 0,
              type : 'plan',
            });
        }
      });
    });

    this.newPricingService = newServicePacks.concat(this.newPricingService);

  if (!this.isNewSchedule) {
      this.pricingLoader = true;
      setTimeout(() => {
        this.preparePricingForm();
      }, 3000);
  }

}


//   getServiceGroups() {
//     this.http.getData('groups?service_id=4&center_id=' + this.center_id).subscribe(response => {

//     }, err => {});
//   }


createPricingPlansArray() {
    this.getMembershipGroups()
  }


  getMembershipGroups() {
    this.http.getData('groups?service_id=1&center_id=' + this.center_id).subscribe(response => {

    this.serviceGroup = response.data.sort((a, b) => a.order - b.order);
    this.serviceGroup.length = response.data.length;
    this.createNewPricingPackArray();

    this.membershipGroup = response.data.sort((a, b) => a.order - b.order);
    this.membershipGroup.length = response.data.length;
    this.createNewPricingPlanArray();

    }, err => {});
  }


  createMembershipsArray() {
    this.http.getData('groups?service_id=1&center_id=' + this.center_id).subscribe(response => {



        this.membershipsGroup = response.data.sort((a, b) => a.order - b.order);
        this.membershipsGroup.length = response.data.length;
        this.createMembershipsPricingArray();

        }, err => {});
  }


  createMembershipsPricingArray() {
    let newServicePacks = this.membershipsGroup;
    this.membershipsGroup.forEach((element, index) => {
      newServicePacks[index].pack = [];
      this.memberships.forEach((e, i) => {
        if (e.service_group_id == element.id) {

          newServicePacks[index].pack.push({
              planId : e.id,
              planName : e.name,
              isChecked : false,
              price : 0,
              type : 'plan',
            });
        }
      });
    });

    this.newPricingService = newServicePacks.concat(this.newPricingService);

  if (!this.isNewSchedule) {
        this.pricingLoader = true;
        this.preparePricingForm();
  }

}


  prepareScheduleForm() {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];
    for (let i = 0; i < this.classDetails.schedule.length; i++) {
      // remove empty timeslot
      let day = this.classDetails.schedule[i].day;
      allDaysClasses[day - 1].removeAt(0);

      // Toggle selected day card
      switch (day) {
        case 1:
          this.scheduleDaysStatus['monday'] = true;
          break;
        case 2:
          this.scheduleDaysStatus['tuesday'] = true;
          break;
        case 3:
          this.scheduleDaysStatus['wednesday'] = true;
          break;
        case 4:
          this.scheduleDaysStatus['thursday'] = true;
          break;
        case 5:
          this.scheduleDaysStatus['friday'] = true;
          break;
        case 6:
          this.scheduleDaysStatus['saturday'] = true;
          break;
        case 7:
          this.scheduleDaysStatus['sunday'] = true;
          break;
        default:
          // code...
          break;
      }

      // create timeslots in formarray
      for (let j = 0; j < this.classDetails.schedule[i].slots.length; j++) {
        let newTimeslot = new Timeslot();
        let slot = this.classDetails.schedule[i].slots[j];

        let startTime = this.getTimepickerDate(slot.from);
        let endTime = this.getTimepickerDate(slot.to);

        // set values of timeslot object to be inserted into formarray
        newTimeslot = {
          start: startTime,
          end: endTime,
          slotId: this.classDetails.schedule[i].slots[j].id,
          isSaved: true,
          trainers: [this.classDetails.schedule[i].slots[j].user_id],
          level: this.classDetails.schedule[i].slots[j].level,
          room: this.classDetails.schedule[i].slots[j].facility_id,
          max_allowed: this.classDetails.schedule[i].slots[j].max_allowed,
          visibility: this.classDetails.schedule[i].slots[j].visibility == 1
            ? true
            : false
        };

        allDaysClasses[day - 1].push(this.fb.group(newTimeslot));
      }
    }
  }

  preparePricingForm() {
    switch (this.classDetails.price_type) {
      case 1:
        break;
      case 2:
        for (let i = 0; i < this.classDetails.applicable_services.length; i++) {
          let price = this.classDetails.applicable_services[i];

          if (price.customer_type === this.dropinCustomerType) {
            this.isDropinOne = true;
            this.dropinOnePrice = parseInt(price.price);
          }

          if (price.customer_type === this.membersCustomerType) {
            this.isAllMembers = true;
            this.allMembersPrice = parseInt(price.price);
          }
        }
        break;
      case 3:
        let newPrice = new Price();
        for (let i = 0; i < this.classDetails.applicable_services.length; i++) {
          let price = this.classDetails.applicable_services[i];

          // drop-in price
          if (price.customer_type === this.dropinCustomerType) {
            this.isDropinTwo = true;
            this.dropinTwoPrice = parseInt(price.price);
          }

          if (price.customer_type === this.membersCustomerType) {
            for (let j = 0; j < this.planPrices.value.length; j++) {
              if (this.planPrices.value[j].planId === price.service_type_id) {
                newPrice.customerType = price.customer_type;
                newPrice.planId = price.service_type_id;
                newPrice.price = parseInt(price.price);
                newPrice.isChecked = true;
                newPrice.planName = this.planPrices.value[j].planName;
                this.planPrices.setControl(j, this.fb.group(newPrice));
              }
            }
          }
        }
        break;
      case 4:
        let newPlanPrice = new Price();
        for (let i = 0; i < this.classDetails.applicable_services.length; i++) {
          let price = this.classDetails.applicable_services[i];

          // drop-in price
          if (price.customer_type === this.membersCustomerType) {
            for (let j = 0; j < this.planPackPrices.value.length; j++) {
              if (this.planPackPrices.value[j].planId === price.id) {
                newPrice.customerType = price.customer_type;
                newPrice.planId = price.id;
                newPrice.price = parseInt(price.price);
                newPrice.isChecked = true;
                newPrice.planName = this.planPackPrices.value[j].planName;
                this.planPackPrices.setControl(j, this.fb.group(newPlanPrice));
              }
            }
          }
        }
    break;

    case 5:
        for (let i = 0; i < this.classDetails.applicable_services.length; i++) {
          let price = this.classDetails.applicable_services[i];
            this.newPricingService.forEach(group => {
                for (let j = 0; j < group.pack.length; j++) {
                      if (group.pack[j].planId === price.service_type_id) {
                        group.pack[j].customerType = price.customer_type;
                        group.pack[j].planId = price.service_type_id;
                        group.pack[j].price = parseInt(price.price);
                        group.pack[j].isChecked = true;
                        group.pack[j]['type'] = 'plan'
                        group.pack[j].planName = group.pack[j].planName;

                    }
                  }
            });
        }

        break;

      default:
        break;
    }
    this.pricingLoader = false;
  }

  prepareScheduleArray() {
    const formModelMonday = this.mondayClassSchedule.value;
    const formModelTuesday = this.tuesdayClassSchedule.value;
    const formModelWednesday = this.wednesdayClassSchedule.value;
    const formModelThursday = this.thursdayClassSchedule.value;
    const formModelFriday = this.fridayClassSchedule.value;
    const formModelSaturday = this.saturdayClassSchedule.value;
    const formModelSunday = this.sundayClassSchedule.value;

    // To be reviewed -- Deep copies of Form Array
    const timeslotsDeepCopyMonday: Timeslot[] = formModelMonday.mondayClasses.map((timeslot: Timeslot) => Object.assign({}, timeslot));
    // create schedule of all days
    var mondaySlots = {};
    mondaySlots['day'] = 1;
    mondaySlots['slots'] = [];

    var tuesdaySlots = {};
    tuesdaySlots['day'] = 2;
    tuesdaySlots['slots'] = [];

    var wednesdaySlots = {};
    wednesdaySlots['day'] = 3;
    wednesdaySlots['slots'] = [];

    var thursdaySlots = {};
    thursdaySlots['day'] = 4;
    thursdaySlots['slots'] = [];

    var fridaySlots = {};
    fridaySlots['day'] = 5;
    fridaySlots['slots'] = [];

    var saturdaySlots = {};
    saturdaySlots['day'] = 6;
    saturdaySlots['slots'] = [];

    var sundaySlots = {};
    sundaySlots['day'] = 7;
    sundaySlots['slots'] = [];

    let allDaysClasses = [
      {
        formTimeslots: formModelMonday.mondayClasses,
        requestTimeslots: mondaySlots
      }, {
        formTimeslots: formModelTuesday.tuesdayClasses,
        requestTimeslots: tuesdaySlots
      }, {
        formTimeslots: formModelWednesday.wednesdayClasses,
        requestTimeslots: wednesdaySlots
      }, {
        formTimeslots: formModelThursday.thursdayClasses,
        requestTimeslots: thursdaySlots
      }, {
        formTimeslots: formModelFriday.fridayClasses,
        requestTimeslots: fridaySlots
      }, {
        formTimeslots: formModelSaturday.saturdayClasses,
        requestTimeslots: saturdaySlots
      }, {
        formTimeslots: formModelSunday.sundayClasses,
        requestTimeslots: sundaySlots
      }
    ];

    for (let i = 0; i < allDaysClasses.length; i++) {
      for (let j = 0; j < allDaysClasses[i]['formTimeslots'].length; j++) {
        let formTimeslot = allDaysClasses[i]['formTimeslots'][j];
        let requestTimeslot = {};
        let settings = {};
        let startTime = this.getRequestTime(formTimeslot['start']);
        let endTime = this.getRequestTime(formTimeslot['end']);

        requestTimeslot['from'] = startTime;
        requestTimeslot['to'] = endTime;
        console.log('slotId', formTimeslot['slotId']);
        requestTimeslot['id'] = formTimeslot['slotId'];
        requestTimeslot['facility_id'] = formTimeslot['room'];
        requestTimeslot['user_id'] = formTimeslot['trainers'];
        requestTimeslot['max_allowed'] = formTimeslot['max_allowed'];
        requestTimeslot['level'] = formTimeslot['level'];
        requestTimeslot['visibility'] = formTimeslot['visibility']
          ? 1
          : 2;
        requestTimeslot = Object.assign({}, requestTimeslot);
        // requestTimeslot["settings"] = {};

        let reqSlot = Object.assign({}, requestTimeslot);

        allDaysClasses[i]['requestTimeslots']['slots'].push(reqSlot);
        console.log('formTimeslots', reqSlot);
      }
    }

    // Add to 'schedule' array only if particular day checkbox is selected
    if (this.scheduleDaysStatus['monday'])
      this.classSchedule['schedule'].push(mondaySlots);
    if (this.scheduleDaysStatus['tuesday'])
      this.classSchedule['schedule'].push(tuesdaySlots);
    if (this.scheduleDaysStatus['wednesday'])
      this.classSchedule['schedule'].push(wednesdaySlots);
    if (this.scheduleDaysStatus['thursday'])
      this.classSchedule['schedule'].push(thursdaySlots);
    if (this.scheduleDaysStatus['friday'])
      this.classSchedule['schedule'].push(fridaySlots);
    if (this.scheduleDaysStatus['saturday'])
      this.classSchedule['schedule'].push(saturdaySlots);
    if (this.scheduleDaysStatus['sunday'])
      this.classSchedule['schedule'].push(sundaySlots);
    }


    preparePricingArray() {
    let pricingArray = [],
      singlePlan,
      reqPlan;

    const pricePlans = this.plansForm.value.allPlans;
    const pricePlanPack = this.planPackForm.value.allPlanPack;
    const newPricePlanPack  = this.newPricingService;

    for (let i = 0; i < pricePlans.length; i++) {}

    let pricingObject = {};

    // No charge
    if (this.priceType === 1) {
      this.classSchedule.price_type = 1;
      pricingArray = [
        // Price by customer type
      ];
    }
    if (this.priceType == 7) {
      if (this.classSchedule.price_type === 2) {
        // drop-in client
        if (this.isDropinOne) {
          reqPlan = {};
          reqPlan['customer_type'] = this.dropinCustomerType;
          reqPlan['service_type_id'] = '';
          reqPlan['price'] = this.dropinOnePrice;
          pricingArray.push(reqPlan);
        }
        // all members
        if (this.isAllMembers) {
          reqPlan = {};
          reqPlan['customer_type'] = this.membersCustomerType;
          reqPlan['service_type_id'] = '';
          reqPlan['price'] = this.allMembersPrice;
          pricingArray.push(reqPlan); // Price by membership type;
        }
      } else if (this.classSchedule.price_type === 3) {
        // drop-in client
        if (this.isDropinTwo) {
          reqPlan = {};
          reqPlan['customer_type'] = this.dropinCustomerType;
          reqPlan['service_type_id'] = null;
          reqPlan['service_id'] = null;
          reqPlan['price'] = this.dropinTwoPrice;
          pricingArray.push(reqPlan);
        }
        // membership plans
        for (let i = 0; i < pricePlans.length; i++) {
          singlePlan = Object.assign({}, pricePlans[i]);
          reqPlan = {};
          if (singlePlan.isChecked) {
            reqPlan['customer_type'] = this.membersCustomerType;
            reqPlan['service_type_id'] = singlePlan.planId;
            reqPlan['price'] = singlePlan.price;

            reqPlan['service_id'] = singlePlan.type == 'plan'
              ? ServiceId.SERVICE_ID_PLAN
              : singlePlan.type == 'pack'
                ? ServiceId.SERVICE_ID_PACK
                : '';

            pricingArray.push(reqPlan);
          }
        }
      }
    } else if (this.priceType === 6) {
        newPricePlanPack.forEach(group => {
            for (let i = 0; i < group.pack.length; i++) {
                singlePlan = Object.assign({}, group.pack[i]);
                reqPlan = {};
                if (singlePlan.isChecked) {
                  reqPlan['customer_type'] = this.membersCustomerType;
                  reqPlan['service_type_id'] = singlePlan.planId;
                  reqPlan['price'] = singlePlan.price;
                  reqPlan['service_id'] = singlePlan.type == 'plan'
                    ? ServiceId.SERVICE_ID_PLAN
                    : singlePlan.type == 'pack'
                      ? ServiceId.SERVICE_ID_PACK
                      : ServiceId.SERVICE_ID_PACK;
                  pricingArray.push(reqPlan);
                }
              }
        });

    }
    this.classSchedule['pricing'] = Object.assign({}, pricingArray);


    // if (this.classSchedule.price_type === 1) {
    //   pricingArray = [
    //      Price by customer type
    //   ];
    // }
    // else if (this.classSchedule.price_type === 2) {
    //    drop-in client
    //   if (this.isDropinOne) {
    //     reqPlan = {};
    //     reqPlan["customer_type"] = this.dropinCustomerType;
    //     reqPlan["plan_id"] = "";
    //     reqPlan["price"] = this.dropinOnePrice;
    //     pricingArray.push(reqPlan);
    //   }
    //    all members
    //   if (this.isAllMembers) {
    //     reqPlan = {};
    //     reqPlan["customer_type"] = this.membersCustomerType;
    //     reqPlan["plan_id"] = "";
    //     reqPlan["price"] = this.allMembersPrice;
    //     pricingArray.push(reqPlan);  Price by membership type;
    //   }
    // }

    // else if (this.classSchedule.price_type === 3) {
    //    drop-in client
    //   if (this.isDropinTwo) {
    //     reqPlan = {};
    //     reqPlan["customer_type"] = this.dropinCustomerType;
    //     reqPlan["plan_id"] = "";
    //     reqPlan["price"] = this.dropinTwoPrice;

    //     pricingArray.push(reqPlan);
    //   }
    //    membership plans
    //   for (let i = 0; i < pricePlans.length; i++) {
    //     singlePlan = Object.assign({}, pricePlans[i]);
    //     reqPlan = {};
    //     if (singlePlan.isChecked) {
    //       reqPlan["customer_type"] = this.membersCustomerType;
    //       reqPlan["plan_id"] = singlePlan.planId;
    //       reqPlan["price"] = singlePlan.price;

    //       pricingArray.push(reqPlan);
    //     }
    //   }
    // }

    // insert pricing array in request object
    // this.classSchedule['pricing'].push(pricingArray);
  }

  // Function to convert Date object to hh:mm time format
  getRequestTime(date) {
    let hours = date.getHours();
    let mins = date.getMinutes();
    let time;

    hours = hours < 10
      ? '0' + hours
      : hours;
    mins = mins < 10
      ? '0' + mins
      : mins;

    time = hours + ':' + mins;

    return time;
  }

  // convert time string to Date object
  getTimepickerDate(time) {
    let date = new Date();

    date.setHours(parseInt(time.substr(0, 2)));
    date.setMinutes(parseInt(time.substr(3, 2)));

    return date;
  }

  prepareDate(dateInput) {
    let dateOutput = '';

    if (dateInput !== '') {
      dateInput.setHours(12); //avoid decrement of date due to iso string conversion
      dateOutput = dateInput.toISOString().substring(0, 10);
    }

    return dateOutput;
  }

  prepareScheduleRequest() {
    // prepare schedule and pricing arrays
    this.prepareScheduleArray();
    this.preparePricingArray();

    this.changeType == 1
      ? (this.classSchedule.change_type = 'unbooked')
      : (this.classSchedule.change_type = 'booked');
      this.classSchedule.reset_substitutes = this.resetType;
    // prepare start and end date
    this.classSchedule.starts_at = this.prepareDate(this.startDate);
    this.endDate == null
      ? (this.classSchedule.ends_at = null)
      : (this.classSchedule.ends_at = this.prepareDate(this.endDate));

    // set visibility
    this.classSchedule.visibility = this.isVisible
      ? 1
      : 2;
  }

  getFormStatus() {
    let isFormValid = true;

    // check if all input fields are valid
    for (var property in this.validationFields) {
      isFormValid = isFormValid && this.validationFields[property];
      if (!this.validationFields[property]) {
        this.generalFunctions.scrolltoinvalid(property);
        return isFormValid;
      }
    }

    // check if schedule is valid
    this.isDaysScheduleValid = this.getDaysScheduleValidityStatus();
    if (!this.isDaysScheduleValid) {
      this.generalFunctions.scrolltoinvalid('daysSchedule');
    }
    return this.isDaysScheduleValid;
  }

  createSchedule() {
    this.prepareScheduleRequest();
    console.log('this.classSchedule', this.classSchedule);
    this.classSchedule.is_online = this.classSchedule.is_online ? 1 : 0;
    this.classSchedule.is_featured = this.classSchedule.is_featured ? 1 : 0;


    this.http.sendData(`classes?center_id=${this.center_id}`, this.classSchedule).subscribe(response => {
      this.router.navigate(['/client/services/class-schedules']);
      this.generalFunctions.openToast('Class schedule created', 3000, 'success');
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  saveSchedule() {
    this.pop_up_for=null;
    let isFormValid = this.getFormStatus();

    if (!isFormValid) {
      this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
      return;
    }

    this.prepareScheduleRequest();
    this.classSchedule.is_online = this.classSchedule.is_online ? 1 : 0;
    this.classSchedule.is_featured = this.classSchedule.is_featured ? 1 : 0;


    this.http.updateData(`classes/${this.classId}?center_id=${this.center_id}`, this.classSchedule).subscribe(response => {
      this.router.navigate(['/client/services/class-schedules']);
      this.generalFunctions.openToast('Class schedule saved', 3000, 'success');
    }, error => {
      this.generalFunctions.openToast('Unable to save class schedule', 3000, 'error');
    });
  }

  cancelChanges() {
    this.router.navigate(['/client/services/class-schedules']);
  }

  deleteSchedule() {
    this.http.deleteData(`classes/${this.classId}?center_id=${this.center_id}`).subscribe(response => {
      this.router.navigate(['/client/services/class-schedules']);
      this.generalFunctions.openToast('Class schedule deleted', 3000, 'success');
      this.pop_up_for = null;
    }, error => {
      this.pop_up_for = null;

      let msg;
      if (error['errors']) {
        msg = error['errors'][Object.keys(error['errors'])[0]];
      } else {
        msg = error.message;
      }
      this.generalFunctions.openToast(msg, 3000, 'error');
    });
  }

  deleteTimeslot(slotId) {
    this.http.deleteData(`classes/${this.classId}/slot/${slotId}?center_id=${this.center_id}`).subscribe(response => {}, error => {
      let msg;
      if (error['errors']) {
        msg = error['errors'][Object.keys(error['errors'])[0]];
      } else {
        msg = error.message;
      }
      this.generalFunctions.openToast(msg, 3000, 'error');
    });
  }

  getDaysScheduleValidityStatus() {
    let isDaysInvalid = false;
    for (var property in this.scheduleDaysStatus) {
      isDaysInvalid = isDaysInvalid || this.scheduleDaysStatus[property];
    }
    return isDaysInvalid;
  }

  goToNext(current, next) {
    switch (current) {
      case 1:
        this.nextOne = true;

        // Identify first invalid field in the form and take action accordingly
        if (!this.validationFields.className) {
          this.generalFunctions.scrolltoinvalid('className');
          this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
          return;
        } else if (!this.validationFields.classSize) {
          this.generalFunctions.scrolltoinvalid('classSize');
          this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
          return;
        }

        let allDaysClasses = [
          this.mondayTimeslots,
          this.tuesdayTimeslots,
          this.wednesdayTimeslots,
          this.thursdayTimeslots,
          this.fridayTimeslots,
          this.saturdayTimeslots,
          this.sundayTimeslots
        ];

        // Update settings for all timeslots to reflect basic details
        for (let i = 0; i < allDaysClasses.length; i++) {
          for (let j = 0, k = allDaysClasses[i]['controls'].length; j < k; j++) {
            // Set new control with updated settings for timeslot
            let newTimeslot = new Timeslot();

            newTimeslot = {
              // preserve start and end values from formarray
              start: allDaysClasses[i]['controls'][j]['controls'].start.value,
              end: allDaysClasses[i]['controls'][j]['controls'].end.value,
              slotId: allDaysClasses[i]['controls'][j]['controls'].slotId.value,
              isSaved: allDaysClasses[i]['controls'][j]['controls'].isSaved.value,
              // set new settings values taken from basic details
              trainers: '',
              room: '',
              level: this.classSchedule.level,
              max_allowed: '',
              visibility: this.isVisible
            };

            allDaysClasses[i].setControl(j, this.fb.group(newTimeslot));
          }
        }
        break;

      case 2:
        this.nextTwo = true;

        this.isDaysScheduleValid = this.getDaysScheduleValidityStatus();

        if (!this.isDaysScheduleValid) {
          this.generalFunctions.openToast('Please select at least one day for the class schedule', 3000, 'error');
          return;
        }

      default:
        break;
    }

    this.currentSection++;
    document.getElementById(next).click();
  }

  goBack(collapse) {
    this.currentSection--;

    document.getElementById(collapse).click();
  }

  startDateChanged(e) {
    this.endDatepickerConfig['minDate'] = e;
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
      case 'class-name':
        isValid = !this.classSchedule.name.replace(/\s/g, '').length
          ? false
          : true; //check if field contains only whitespaces
        this.validationFields.className = isValid;
        break;

      case 'class-size':
        isValid = this.classSchedule.max_allowed > 0
          ? true
          : false;
        this.validationFields.classSize = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }

  openDeletePop(day, index) {
    this.pop_up_for = 'delete-slot';
    this.deleteSlotDay = day;
    this.deleteSlotIndex = index;
  }

  confirmDeleteSlot() {
    this.deleteWeekdayTimeslot(this.deleteSlotDay, this.deleteSlotIndex);
    this.pop_up_for = 'null';
  }

  checkTheChange() {
    if (this.classSchedule.price_type == 2 || this.classSchedule.price_type == 3) {
      return;
    } else {
      this.classSchedule.price_type = 2;
    }
  }

  changeFacility(event) {
    if (event.value == 'add') {
      this.router.navigate(['/client/services/facility']);
    } else {}
  }

  priceTypeChange() {
    if (this.priceType == 6) {
      this.classSchedule.price_type = 4;
    }
    if (this.priceType === 1) {
      this.classSchedule.price_type = 1;
    }
  }

  applyAll(index) {
    let allDaysClasses = [
      this.mondayTimeslots,
      this.tuesdayTimeslots,
      this.wednesdayTimeslots,
      this.thursdayTimeslots,
      this.fridayTimeslots,
      this.saturdayTimeslots,
      this.sundayTimeslots
    ];

    allDaysClasses.forEach(element => {
      if (element !== allDaysClasses[index]) {
        let length = element.value.length;
        for (let i = 0; i < length; i++) {
          element.removeAt(0);
        }
      }
    });

    allDaysClasses[index].value.forEach(slot => {
      let timeslot = new Timeslot();
      let neto = {
        ...slot
      };
      neto['trainers'] = [neto.trainers];

      timeslot = neto;
      timeslot.slotId = null;
      allDaysClasses.forEach(classes => {
        if (classes !== allDaysClasses[index]) {
          classes.push(this.fb.group(timeslot));
        }
      });
    });
    this.generalFunctions.openToast('Applied to all selected days', 3000, 'success');
  }
}
