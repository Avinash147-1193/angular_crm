import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassScheduleDetailsComponent } from './class-schedule-details.component';

describe('ClassScheduleDetailsComponent', () => {
  let component: ClassScheduleDetailsComponent;
  let fixture: ComponentFixture<ClassScheduleDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassScheduleDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassScheduleDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
