import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClassScheduleListComponent } from './class-schedule-list.component';

describe('ClassScheduleListComponent', () => {
  let component: ClassScheduleListComponent;
  let fixture: ComponentFixture<ClassScheduleListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClassScheduleListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClassScheduleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
