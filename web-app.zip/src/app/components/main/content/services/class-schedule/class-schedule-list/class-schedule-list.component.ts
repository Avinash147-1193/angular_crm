import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {ServerAuthService} from 'app/common/server-auth';
import {GeneralServices} from 'app/common/general-services';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-class-schedule-list',
  templateUrl: './class-schedule-list.component.html',
  styleUrls: ['../../styles/service-list.scss', './class-schedule-list.component.scss']
})
export class ClassScheduleListComponent implements OnInit {
  center_id: any;
  allClasses: any;
  totalClasses: number = 0;
  facilities: any;
  hovered: null;

  constructor(private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private generalFunctions : GeneralServices, private location : Location) {}

  ngOnInit() {
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.getAllFacility();
  }

  getAllFacility() {
    this.http.getData(`facilities?center_id=${this.center_id}`).subscribe(response => {
      this.facilities = response.data;
      this.getClasses();
    }, err => {});
  }

  dropGroup(event){
    moveItemInArray(this.allClasses, event.previousIndex, event.currentIndex);

    const newResObj = Object.values(this.allClasses);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        class_id: element['id'],
        order: index + 1
      };
      arr[index] = obj;
    });
    this.http.updateData('classes/order?center_id=' + this.center_id, {classes : arr}).subscribe(response => {
      console.log('response', response);
    }, err => {
      console.log('err', err);
    });
  }

  getClasses() {
    this.http.getData('classes?center_id=' + this.center_id).subscribe(response => {
      var res = response;
      this.allClasses = res.data.sort((a,b) => {
          return a.order - b.order;
      } )
      this.totalClasses = this.allClasses.length;


     this.calculateOut();


    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  calculateOut(){
    this.allClasses.forEach((element, i) => {
        this.facilities.forEach((element, index) => {
          if (this.allClasses[i].facility_id == element.id) {
            this.allClasses[i].facilityText = element.name;
          }
        });

        this.allClasses[i].newSched = {
          mon: false,
          tue: false,
          wed: false,
          thu: false,
          fri: false,
          sat: false,
          sun: false
        };
        element.schedule.forEach((sched, index) => {
          if (sched.day == 1) {
            this.allClasses[i].newSched.mon = true;
          }
          if (sched.day == 2) {
            this.allClasses[i].newSched.tue = true;
          }
          if (sched.day == 3) {
            this.allClasses[i].newSched.wed = true;
          }
          if (sched.day == 4) {
            this.allClasses[i].newSched.thu = true;
          }
          if (sched.day == 5) {
            this.allClasses[i].newSched.fri = true;
          }
          if (sched.day == 6) {
            this.allClasses[i].newSched.sat = true;
          }
          if (sched.day == 7) {
            this.allClasses[i].newSched.sun = true;
          }
        });
      });
  }
}
