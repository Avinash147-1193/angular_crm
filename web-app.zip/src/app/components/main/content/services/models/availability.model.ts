var startDate = new Date();
startDate.setHours(9, 0, 0);
var endDate = new Date();
endDate.setHours(10, 0, 0);

export class Timeslot {
  start: Date = startDate;
  end: Date = endDate;
  trainers: any = [];
  max_allowed: string = "";
  level: string = "";
  visibility: boolean = false;
  isSaved: boolean = false;
  slotId: string = "";
}

export class Price {
  customerType: number = 2;
  planName: string = "";
  planId: number;
  isChecked: boolean = false;
  price: number = 0;
}
