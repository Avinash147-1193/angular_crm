import {
    Component,

    Input,

    OnInit,
    EventEmitter,
    Output,
    ViewChild,

} from '@angular/core';

import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import {Router, ActivatedRoute} from "@angular/router";
import * as moment from "moment";


@Component({
    selector: 'pos-customer',
    templateUrl: './pos-customer.component.html',
    styleUrls: ['./pos-customer.component.scss']
})
export class PosCustomerComponent implements OnInit {


    constructor(private generalFunctions : GeneralServices, private http : ServerAuthService, private router : Router,) {}
    @Output('selectContact')selectContactEmitter = new EventEmitter();
    @Output('clearContact')clearContact = new EventEmitter();

    @ViewChild("contact_results_ul")contact_results_ul;

    moment: any=moment;


    selected_contact:any=null;
    showContactDetails: boolean=false;
    contact_selection_mode:boolean = false;
    pos_search_contact: string = "";
    contact_results: any = [];
    serachFilter: any = {
        filterBy: {
          query: null
        },
        sortBy: {},
        page: 1,
        include: "address"
      };
      include_center: any = null;

    toggleCustomerSelectMode(value:boolean|null|undefined){
        const new_value = (value==null|| value==undefined)? !this.contact_selection_mode: value;
        this.contact_selection_mode = new_value;
    }

    toggleSelectModeFromParent(value:boolean|null|undefined){
        const new_value = value==null || value==undefined? !this.contact_selection_mode: value;
        this.contact_selection_mode = new_value;
        if(new_value === false){
            this.contact_results = [];
            this.pos_search_contact = "";
        }
    }


    selectContact(contact){
        this.selectContactEmitter.emit(contact);
        this.toggleCustomerSelectMode(false);
    }


    loadingContacts = false;

      //SEARCH CONTACT
  fetchResults(e) {
    if (this.pos_search_contact.length < 2) {
      this.contact_results = [];
    }
    if (this.pos_search_contact.length > 2) {
      this.loadingContacts = true;
      this.serachFilter["filterBy"]["query"] = this.pos_search_contact;
      this.http.sendData("contact/search" + this.include_center, this.serachFilter).subscribe(success => {
        this.contact_results = success.data;
        this.loadingContacts = false;
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });
    }
  }


  setCustomer(customer){
    // this.toggleCustomerSelectMode(false)
    this.selected_contact = customer;
  }

  clearCustomer(emit=true){
    this.selected_contact=null;
    this.pos_search_contact="";
    this.serachFilter = {
      filterBy: {
        query: null
      },
      sortBy: {},
      page: 1,
      include: "address"
    };
    if(emit) this.clearContact.emit(true);
  }


  addCustomer() {
    var bool = true;
    this.generalFunctions.addCustomer(bool);
    this.router.navigate(["../client/customers/add"]);
  }


  viewCustomerProfile() {
    var id = this.selected_contact["id"];
    this.router.navigate(["../client/customers", id]);
  }




    ngOnInit() {
        this.include_center = this.generalFunctions.includeCenter();


    }

}
