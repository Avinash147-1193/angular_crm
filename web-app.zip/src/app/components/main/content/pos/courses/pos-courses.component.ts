import {
    Component,

    Input,

    OnInit,
    EventEmitter,
    Output,

} from '@angular/core';

const MAX_QUANTITY = {
    'MEMBERSHIP_PLANS': 1,
    'SERVICEPACKS': -1
}
import * as moment from 'moment';
//imidiate
//first_use

@Component({
    selector: 'pos-courses',
    templateUrl: './pos-courses.component.html',
    styleUrls: ['./pos-courses.component.scss']
})
export class PosCoursesComponent implements OnInit {
    @Input() newCourses: any = [];
    @Input() currency: any = "";
    @Output('addItemToCart') addItemToCart = new EventEmitter();

    moment: any = moment;

    addToCart(data){ 
        this.addItemToCart.emit({type:'COURSES', max_allowed: -1, data, start_at: moment(data.starts_at)});

    }




    ngOnInit() {

    }

}
