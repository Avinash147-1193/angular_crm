import {
  Component,
  OnInit,
  ViewChild,
  ViewEncapsulation,
  AfterViewInit,
  ElementRef,
  ChangeDetectorRef,
  Input
} from "@angular/core";
import {NgForm} from "@angular/forms";

import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "../../../../common/general-services";
import {GiftCardService, ServerAuthService} from "../../../../common/server-auth";
import {SelectItem, SelectItemGroup} from "primeng/api";
import {FormsModule} from "@angular/forms";


import {Observable, Subscriber} from "rxjs";

import * as moment from "moment";
import { PosAddCardComponent } from "./pos-add-card/pos-add-card.component";
import { PosCustomerComponent } from "./customer-profile/pos-customer.component";
import { PosCartComponent } from "./cart/pos-cart.component";

interface ValidationSubValues {
  active: boolean,
  data: any,
  new_date?: any,
};
interface ValidationData {
  memberships: ValidationSubValues,
  subscriptions: ValidationSubValues,
  packs: ValidationSubValues,
  oneOffs: ValidationSubValues,
  trials: ValidationSubValues,
}

@Component({templateUrl: "pos-new.component.html", styleUrls: ["pos.component.scss"], encapsulation: ViewEncapsulation.None})
export class PosComponent implements OnInit {

  moment: any = moment;

  is_overlay_active: boolean = false;

  customer_validation_data: ValidationData = {
    memberships: {
      active: false,
      data: null
    },
    subscriptions: {
      active: false,
      data: null
    },
    packs: {
      active: false,
      data: null
    },
    oneOffs: {
      active: false,
      data: null
    },
    trials: {
      active: false,
      data: null
    },
  };
  popup_data: any;
  paymentModal: boolean = false;
  error: any;
  checkout: any;
  @ViewChild("customer_select") customer_select: PosCustomerComponent;
  @ViewChild("cart_component") cart_component: PosCartComponent;
  editInfoCardItem: boolean = false;
  pos_search_contact: string = "";
  show_payment_types: boolean = false;
  is_transaction_successful: boolean = false;
  pos_stage_three: boolean = false;
  pos_stage_four: boolean = false;
  paymentFailed: boolean = false;
  pay_now: boolean = false;
  cart_empty: boolean = true;

  contact_selection_mode: boolean = false;
  once_selected: boolean = false;
  parent_prod_selected: string = "membership";
  membership_sec_tab_selected: string = "none";
  pt_sec_tab_selected: string = "none";

  aside_in_discount_mode: boolean = false;
  manual_disc_amount_type_st: any = "percent";
  clear_past_dues: boolean = false;

  direct_contact_mode: boolean = false;

  split_payments: boolean = true;
  part_payments: boolean = false;
  multi_membership: boolean = false;
  tax_applicable: boolean = false;
  isContactSelected: boolean = false;
  tax: any = "";


  duration_type_name: Array<string> = ["month", "week", "days"];
  contact_color: object = {
    hot: "#de474c",
    normal: "#ffbc00",
    cold: "#43bf81",
    expired: "#ced0da",
    upcoming: "#f8b100",
    freezed: "#f8b100",
    active: "#00b898",
    billing_issue: "#de474c"
  };

  send_invoice_to_email: string = "";

  fullDateToday: Date = new Date();

  contact_results: any = null;
  received_memberships_data: any = [];
  received_pt_data: any = [];
  received_discount_data: any = null;
  received_payment_mode_data: any = null;
  isGCard: false;


  currency: any = null;

  serachFilter: any = {
    filterBy: {
      query: null
    },
    sortBy: {},
    page: 1,
    include: "address"
  };

  selected_contact: any = {
    id: null,
    contact: ""
  };

  cart_data: any = {
    contact_id: null,

    items: [],

    payments: {
      amount_total: 0,
      amount_due: 0,
      methods: [
        {
          mode: "cash",
          amount: 0,
          realization: "immediate"
        }
      ]
    }
  };

  demo_card_aside: any = [
    {
      type: "membership",
      membership_id: 0,
      membership_name: "",
      duration_id: 0,
      duration_value: 0,
      duration_type: 0,
      duration_price: 0,
      starts_at: null,
      tax_applicable: false,
      discount: {
        type: "manual",
        discount_id: null,
        discount_code: "diwali",
        amount_type: "fixed",
        discount_amount: 3000
      }
    }
  ];
  demo_discount_aside: any = {};

  include_center: any = null;
  centerId: any;

  upgradeOldMembership: any = {
    id: null,
    data: null
  };



  groups: any;
  coursesGroup: any;
  newMembershipPlan: any = [];
  newCourses: any;

  note: any;
  noteId: any;
  paymentReady: boolean = false;

  addedCardId: any;
  adyenToken = false;
  paymentMode = null;
  remaining: any = 0;

  //PAYMENT METHODS BOXES

  @ViewChild("contact_results_ul")contact_results_ul;

  @ViewChild("item_container")item_container;
  @ViewChild("sub_total")sub_total;
  @ViewChild("tax_collected")tax_collected;
  @ViewChild("discount_number")discount_number;
  @ViewChild("sum_total")sum_total;

  @ViewChild("complete_sale")complete_sale;
  @ViewChild("ajax_sreen")ajax_sreen;

  @ViewChild("cardInfo")cardInfo: ElementRef;
  @ViewChild("addCardComponent")addCardComponent: PosAddCardComponent;

  @Input()adyenData;

  isAddCard: boolean = true;

  allServices: any = [];
  membershipPlans: any = [];

  courses: any = [];

  totalPlans: number = 0;
  totalPacks: number = 0;
  cardSubTotal: number = 0;
  cardTotalDiscount: number = 0;
  cardTaxCollected: number = 0;
  cardSumTotal: number = 0;
  isMembershipSelected: boolean = false;
  selectedMembershipId: any = 0;
  selectedMembershipPrice: any = 0;
  pop_up_for: any = null;
  popUpClose: any = false;
  routeLink: any = "";

  serviceCenterId: number;
  serviceCodes: any = [];

  discountView: boolean = false;

  showCardOverlay: boolean = false;

  startDatepickerConfig: any = {
    showWeekNumbers: false,
    containerClass: "theme-default"
    // minDate: (new Date())
  };

  discountCodes: any;

  customDiscountTypes: any = [
    {
      label: "",
      value: "currency"
    }, {
      label: "%",
      value: "percent"
    }
  ];

  discountIndex: any;

  startDate: any;

  isPaymentMethodsVisible: boolean = false;
  availablePaymentModes: any = [];
  enabledPaymentModes: SelectItemGroup[] = [];

  pendingSaleId: any;
  pendingAmountDue: any;
  cartTaxTotal: any;
  closestExpiry: any = {
    date: "",
    status: false
  };
  newStart: any;
  startedSale: boolean = false;
  stripeOn: boolean = false;
  newTag: boolean = false;
  savedCards: any = [];
  startPayment: boolean = false;
  totalCart: any = {
    discountType: "code",
    discountId: null,
    discountValue: 0,
    discountAvailable: false
  };


  searchterm = '';

  cartDiscount: boolean = false;
  paid = 0;
  due = 0;
    gCards: any;
    newCards: { count: number; cards: any[]; id: number; name: string; order: number; service_id: number; }[];
    gCardValidity: any;
    is_cart_recurring: boolean = false;


  // tslint:disable-next-line: max-line-length
  constructor(private gCardService: GiftCardService, private generalFunctions : GeneralServices, private route : ActivatedRoute, private router : Router, private http : ServerAuthService, private cd : ChangeDetectorRef) {
    // EVENT LISTENER FOR PAYMENT METHOD BOX
    this.gCardService.sub.subscribe((obj) =>  console.log('triggered in pos again', obj))

  }




  addCardError(data) {
    this.saleInProgress = false;
    this.generalFunctions.openToast('error', 3000, data.message);
  }

  addCardSuccess(data) {
    this.generalFunctions.openToast("Card successfully added for the customer", 2000, "success");
    this.addedCardId = data.addedCardId;
    this.completeTransaction();
  }





  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.centerId = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;
    this.customDiscountTypes[0].label = this.currency;
    this.getMembershipGroups();
    this.getCoursesGroups();
    this.getAllServices();
    this.getMemberships();
    this.getDiscounts();
    this.getPaymentModes();
    this.getSettings();
    this.getCenterData();
    this.getCards();

    this.route.queryParams.subscribe(params => {
      if (params["id"]) {
        this.selectContact(params["id"]);
      }

      if (params.new) {
        this.newTag = true;
      }
    });

    this.route.params.subscribe(params => {
      if (params["id"]) {
        this.direct_contact_mode = true;
        this.selectContact(params["id"]);
      }
    });
    this.checkCustomer("");
  }





  toggleSearch() {
    this.pos_search_contact = "";

    this.contact_results = [];
    this.contact_selection_mode = !this.contact_selection_mode;
  }



  getCenterData() {
    this.http.getData("center/" + this.centerId).subscribe(success => {
      this.tax = success.data.tax_percentage;
      if (success.data.gateway === 'stripe' || success.data.gateway === 'adyen') {
          //stripeOn specifies both if adyen or stripe is connected

          this.paymentSettings.enableCardOnline = true;
          this.paymentSettings.cardMode = success.data.gateway;

        this.stripeOn = true;
        this.paymentMode = success.data.gateway;
        this.isAddCard = true;
      } else {
        this.stripeOn = false;
        this.isAddCard = false;
      }


    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      return false;
    });
  }



  getStripe() {
    this.http.getData("center/stripe/" + this.centerId).subscribe(success => {});
  }

  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
      success = success;
      this.tax_applicable = success.tax.enabled;
      this.paymentSettings.activatePartialPayment = success.pos.payments.pending_enabled;
      this.multi_membership = success.administration.memberships.multi_memberships;
      this.availablePaymentModes = success.pos.payments.available_modes;
    }, error => {
      this.generalFunctions.openToast("Unable to load settings!", 3000, "error");
    });
  }

  getAllCards() {
    this.savedCards = [];
    this.paymentSettings.savedCards = [];
    if (this.paymentSettings.enableCardOnline) {
      this.http.getData("contact/" + this.cart_data.contact_id + "/payment/sources" + this.include_center).subscribe(success => {
        this.savedCards = success.data;

        success.data.forEach((element, index) => {
          let card = element;
          card.mode = "scard";
          card.code = element.brand.split(' ')[0];
          card.label = element.brand + " xxxx xxxx xxxx " + element.last4;
          card.value = element.id;
          this.paymentSettings.savedCards.push(card);
        });

      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
      });
    }
  }

  //if stripe connected show add card and saved card
  //if stripe is connected and no saved card then just show add card
  //if stripe not connected you won't have saved cards so need not to show saved card


paymentSettings: any = {


  paymentAmount: 0.00,
  paymentSelected: null,
  paymentInfo: {
    discountInfo: {},
    gCardDiscount : 0
  },
  savedCards: [],
  hasRecurringMembership: false,


  enableCardOnline: false,
  cardMode : '',
  otherPaymentMethods: [],
  activatePartialPayment: false,
  }



  preparePaymentModes(data) {
    this.paymentSettings.paymentInfo = data.paymentInfo;
    this.paymentSettings.paymentInfo.paymentAmount = data.paymentInfo.totalCartAmount;
    this.paymentSettings.paymentInfo.gCardDiscount = 0;
    this.paymentSettings.cartData = data.cartData;

    const hasRecurringMembership = data.cartData.items.filter((item) => item.data.is_recurring === 1 || item.data.is_recurring === true).length > 0;

    this.paymentSettings.hasRecurringMembership = hasRecurringMembership;

    this.paymentModal = true;
    console.log('prepare payment modes')

  }

  saleInProgress: boolean = false;

  completeSale(form = null) {
      let btn = document.querySelector('#b-t-n');
      if(!btn.classList.contains('active')  ){
    if (
      (this.paymentSettings.paymentSelected === 'add-card' && this.addCardComponent.haserror()) ||
        this.paymentSettings.paymentSelected == null ||
          this.paymentSettings.paymentInfo.paymentAmount == null ||
            (this.paymentSettings.paymentInfo.paymentAmount > this.paymentSettings.paymentInfo.totalCartAmount)) {
              return;
            }
        }

    if (!this.saleInProgress) {
        this.saleInProgress = true;
        if (this.paymentSettings.paymentSelected === 'add-card') {

            this.addCardComponent.submit()

        } else {
          this.completeTransaction();
        }
    }
  }

  // GET ALL SERVICES FOR THIS CENTER
  getAllServices() {
    this.http.getData("center/" + this.centerId + "/services").subscribe(success => {
      this.allServices = success;
      this.createServiceCodes();
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  createServiceCodes() {
    this.serviceCenterId = this.allServices[0].center_id;

    for (let i = 0; i < this.allServices.length; i++) {
      let service = this.allServices[i];
      let code = {};
      code["code"] = service.service.code;
      code["serviceId"] = service.service_id;
      this.serviceCodes.push(code);
    }
  }

  getMembershipGroups() {
    this.http.getData("groups?service_id=1&center_id=" + this.centerId).subscribe(response => {
      this.groups = response.data.sort((a, b) => a.order - b.order);
      this.groups.length = response.data.length;
      this.getMemberships();
    }, err => {});
  }
  getCoursesGroups() {
    this.http.getData("groups?service_id=6&center_id=" + this.centerId).subscribe(response => {
      this.coursesGroup = response.data.sort((a, b) => a.order - b.order); ;
      this.getCourses();
    }, err => {});
  }
  //GET MEMBERSHIPS DATA
  getMemberships() {
    this.http.sendData("plan" + this.include_center, "").subscribe(success => {
      success.data.forEach((item, index) => {
        if (item.staff_id) {
          this.received_pt_data.push(item);
        } else {
          this.received_memberships_data.push(item);
        }
      });
      this.membershipPlans = success.data.sort((a, b) => a.order - b.order); ;
      this.prepareNewObject();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  prepareNewObject() {
    let newMembershipPlans = this.groups;

    let searchString = this.searchterm.toLowerCase().trim()
    this.groups?.forEach((element, index) => {
      newMembershipPlans[index].plans = [];
      this.membershipPlans.forEach((e, i) => {
        if (e.service_group_id == element.id)  {
          if (searchString && searchString.length > 1) {
              if (e.name.toLowerCase().includes(searchString) || e.id.toString() == searchString) {
                newMembershipPlans[index].plans.push(e);
              }
          } else {
            newMembershipPlans[index].plans.push(e);
          }
        }
      });
    });
    this.newMembershipPlan = newMembershipPlans;
  }

  getCourses() {
    this.http.sendData("courses" + this.include_center, { filterBy: { visibility: 1 }}).subscribe(success => {
      this.courses = success.data.sort((a, b) => a.order - b.order);
      this.prepareNewCoursesObject();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  getCards() {
    this.http.sendData("cards" + this.include_center, {}).subscribe(success => {
        this.gCards = success.data.sort((a, b) => a.order - b.order);
        this.prepareCardsObject();
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
      });
  }

  prepareCardsObject() {

    let obj = [{'count': 0,
    'cards': [],
    'id': 250,
    'name': "",
    'order': 1,
    'service_id': 6}];
    obj[0].cards.push(...this.gCards);
    console.log(obj)
    this.newCards = obj;
    // let newCourses = [];
    // let searchString = this.searchterm.toLowerCase().trim();

    // if(this.coursesGroup?.length > 0){
    //     this.coursesGroup.forEach((element, index) => {
    //       newCourses[index].courses = [];
    //         this.courses.forEach((e, i) => {
    //           if (e.service_group_id.id == element.id) {
    //             if(searchString && searchString.length > 1){
    //               if(e.name.toLowerCase().includes(searchString)|| e.id.toString() == searchString)
    //               {
    //                 newCourses[index].courses.push(e);
    //               }
    //           }else{
    //             newCourses[index].courses.push(e);
    //           }

    //           }
    //         });
    //       });
    //       this.newCourses = newCourses;
    // }
  }


  prepareNewCoursesObject() {
    let newCourses = this.coursesGroup;
    let searchString = this.searchterm.toLowerCase().trim();

    if (this.coursesGroup?.length > 0) {
        this.coursesGroup.forEach((element, index) => {
          newCourses[index].courses = [];
            this.courses.forEach((e, i) => {
              if (e.service_group_id.id == element.id) {
                if (searchString && searchString.length > 1) {
                  if (e.name.toLowerCase().includes(searchString) || e.id.toString() == searchString) {
                    newCourses[index].courses.push(e);
                  }
              } else {
                newCourses[index].courses.push(e);
              }

              }
            });
          });
          this.newCourses = newCourses;
          console.log('c=>', this.newCourses);
    }

  }

  getDiscounts() {
    this.http.getData("discount" + this.include_center).subscribe(success => {
      this.discountCodes = success.data;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  //GET PAYMENT METHODS
  getPaymentModes() {
    this.http.getData("pos/payment/methods" + this.include_center).subscribe(success => {
      this.received_payment_mode_data = success.data;
      this.received_payment_mode_data.forEach((item, index) => {
        if (item.status) {
          item["state"] = item["status"];
          if (item.mode === 'pay_later') {
            // this.paymentSettings.activatePartialPayment = true;
          } else {
            this.paymentSettings.otherPaymentMethods.push({...item});
          }}
      });
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }


  addCardData: any = {};
  selectContact(id) {
    this.http.getData("contact/" + id + this.include_center + "&include=memberships").subscribe(success => {
      this.selected_contact = success.data;

      this.addCardData = {
        contact_id: success.data['id'], include_center: this.include_center
      }
      this.customer_select.setCustomer(success.data);
      const oneOffs = success.data.memberships.data.filter(
        (membership) => ((membership.type === 1 ) && (membership.is_recurring === 0) && (membership.expired_at.length == 0))
      )
      const packs = success.data.memberships.data.filter(
        (membership) => membership.service_type === 2 && membership.expired_at.length == 0
      )
      const trials = success.data.memberships.data.filter(
        (membership) => (membership.is_trial || membership.is_trial === 1)
      )

      let max_date = moment().subtract(1, 'day');


      oneOffs.filter((sub) => sub.status == 1).forEach(membership => {
          const expires_at = moment(membership.expires_at);
            max_date = expires_at.isAfter(max_date) ? expires_at : max_date;
        });

      const subscriptionEndpoint = 'contact/' + id + '/subscriptions' + this.include_center;
      this.http.getData(subscriptionEndpoint).subscribe(({data}) => {
          let subscriptions = data.filter(
              (membership) => {
                return membership.expired_at.length === 0
              }
            )
            subscriptions = subscriptions.map((sub) => {
              return {...sub, service_type: 'MEMBERSHIP_PLANS', is_recurring: true};
            })

            subscriptions.filter((sub) => sub.status == 1).forEach(sub => {
              const expires_at = moment(sub.expires_at);
              max_date = expires_at.isAfter(max_date) ? expires_at : max_date;
            });



            this.startDate = max_date.add(1, 'day').format("DD MMM YYYY");
            this.startDatepickerConfig = {...this.startDatepickerConfig, minDate: new Date(this.startDate)}

            const memberships = [...oneOffs, ...subscriptions].sort((a, b) => moment(a.expires_at).diff(moment(b.expires_at)))


            this.customer_validation_data = {
              memberships: {
                active: memberships.length > 0,
                new_date: max_date.add(1, 'day'),
                data: memberships

              },
              subscriptions: {
                active: subscriptions.length > 0,
                new_date: max_date.add(1, 'day'),
                data: subscriptions
              },
              packs: {
                active: packs.length > 0,
                data: packs
              },
              oneOffs: {
                active: oneOffs.length > 0,
                data: oneOffs
              },
              trials: {
                active: trials.length > 0,
                data: trials
              },
            };

       })

      this.fill_pos_with_contact(id);
      this.getAllCards();
      this.direct_contact_mode = false;
    }, error => {
      var msg;
      if (error.status_code == 404) {
        msg = "Customer not found in the databse!";
      } else {
        msg = error.message;
      }
      this.generalFunctions.openToast(msg, 3000, "error");
      this.router.navigate(["../"], {
        queryParams: {},
        relativeTo: this.route
      });
    });
  }

  fill_pos_with_contact(id) {
    this.once_selected = true;
    this.contact_selection_mode = false;
    this.cart_data["center_contact_id"] = id;
    this.cart_data["contact_id"] = id;
    this.pos_search_contact = "";
  }

  /* POS PRODUCT SECTION FUNCTIONS */




  getDetailsAndAddItemtoCart(item_data, validated = false) {
      this.editInfoCardItem = false;
    const isItemPresent = this.cart_data.items.filter((item) =>
      item.data.id === item_data.data.id && item.type === item_data.type
    ).length > 0

    if (isItemPresent) {
      this.generalFunctions.openToast(`${item_data.data.name}  already added to cart`, 3000, "error");
      return;
    }
    if (this.selected_contact.id) {
      this.pop_up_for = null;
      if (!validated) {
        if (this.customer_validation_data.trials.active) {
          const is_same_trial = this.customer_validation_data.trials.data.filter((item) => item.service_model.id == item_data.data.id).length;
          if (is_same_trial > 0) {
            this.popup_data = item_data;
            this.pop_up_for = "trial";
            return;
          }
        }
      }
      if (item_data.type === 'MEMBERSHIP_PLANS') {
          this.startDatepickerConfig = {...this.startDatepickerConfig, minDate: new Date(this.startDate)}
          item_data.start_at = this.startDate;
          this.popup_data = item_data;
          this.pop_up_for = 'MEMBERSHIP_PLANS';
      } else if (item_data.type === 'SERVICEPACKS') {
        if ( item_data.data.settings.start_type === 'immediate' && item_data.data.type == 2) {
          item_data.start_at = moment().format('DD MMM YYYY');
          this.startDatepickerConfig = {...this.startDatepickerConfig, minDate: moment().toDate()}
          this.popup_data = item_data;
          this.pop_up_for = 'MEMBERSHIP_PLANS';
        } else {
          this.addItemToCart(item_data);
        }
      }  else if (item_data.type === 'GIFT_CARDS') {
          this.startDatepickerConfig = {...this.startDatepickerConfig, minDate: moment().toDate()}
          this.popup_data = item_data;
          this.pop_up_for = 'GIFT_CARDS';
          this.popup_data.from_name = this.selected_contact.contact.data.first_name + ' ' + this.selected_contact.contact.data.last_name
      } else {
        this.addItemToCart(item_data);
      }
    } else {
      this.customer_select.toggleCustomerSelectMode(true);
    }
  }



  addItemToCart(item_data) {

    // MEMBERSHIP_PLANS

    // type, max_allowed: MAX_QUANTITY[type], data

    // SERVICEPACKS

    item_data.totalAmount = item_data.data.amount;

    if (item_data.type === 'MEMBERSHIP_PLANS') {
      if (item_data.data.settings.pay_on_first) {
        const endOfMonth = moment(item_data.start_at).endOf('month');
        const startDate = moment(item_data.start_at);
        const timeLeftInMonth = endOfMonth.diff(startDate, 'second', true);
        const totalsecondsInCurrentMonth = moment().daysInMonth() * 86400;
        const monthlyAmount = item_data.data.amount / item_data.data.duration;
        const totalAmount = (monthlyAmount / totalsecondsInCurrentMonth) * timeLeftInMonth;
        item_data.totalAmount = totalAmount;
        item_data.totalAmountForPos = item_data.data.amount;
      } else {
        item_data.totalAmount = item_data.data.amount;
        item_data.totalAmountForPos = item_data.data.amount;
      }
    } else if (item_data.type === 'SERVICEPACKS') {
      item_data.totalAmountForPos = item_data.data.amount;
      item_data.totalAmount = item_data.data.amount;
      // item_data.start_at = item_data.data.settings.start_type === 'immediate' ? new Date().toJSON().slice(0, 10): '';
    } else if (item_data.type === 'COURSES') {
      item_data.totalAmountForPos = item_data.data.amount;
      item_data.totalAmount = item_data.data.amount;
    } else if (item_data.type === 'GIFT_CARDS') {

        if (!item_data.to_name || item_data.to_name.length < 1){
            this.generalFunctions.openToast('Please enter a valid recepient name', 3000, 'error');
            return;
        }
        if (!this.validateEmail(item_data.email)) {
            this.generalFunctions.openToast('Please enter a valid email', 3000, 'error');
            return;
        }
        if (!item_data.from_name || item_data.from_name.length < 1){
            this.generalFunctions.openToast('Please enter a valid sender name', 3000, 'error');
            return;
        }

        item_data.totalAmountForPos = item_data.data.amount;
        item_data.totalAmount = item_data.data.amount;
        item_data.name = item_data.data.title;
        item_data.price = item_data.data.amount;
        item_data.to_name = item_data.to_name;
        item_data.from_name = item_data.from_name,
        item_data.email = item_data.email,
        item_data.message = item_data.message,
        item_data.send_on = item_data.start_at,
        item_data.current_value = item_data.data.amount
        this.pop_up_for=null;

      }
      console.log('item_data,popup_data', item_data);

    const same_type_items = this.cart_data.items.filter((item) => item.type === item_data.type).length;
    if (item_data.max_allowed === -1) {
      this.cart_data.items.push(item_data);
    } else {
      if (item_data.max_allowed === same_type_items) {
        let index = this.cart_data.items.reverse().findIndex(item => item.type === item_data.type);
        this.cart_data.items.splice(index, 1);
        this.cart_data.items.reverse();
      }
      this.cart_data.items.push(item_data);
    }
    this.cart_component.calculatePaymentInfo()
  }

  popup_data_index: number;

  editCardItem(i) {
    this.popup_data_index = i;
    this.popup_data = this.cart_data.items[i];
    this.editInfoCardItem = true;
    if (this.cart_data.items[i].type === 'MEMBERSHIP_PLANS' || this.cart_data.items[i].type === 'SERVICEPACKS') {
      this.pop_up_for = 'MEMBERSHIP_PLANS';
    } else if (this.cart_data.items[i].type === 'COURSES') {
      this.pop_up_for = 'COURSES';
    } else if (this.cart_data.items[i].type === 'GIFT_CARDS') {
        this.pop_up_for = 'GIFT_CARDS';
      }

  }

  navigationList = ['memberships', 'courses', 'gift cards'];
  currentPage = 'memberships';

  validateEmail(email) {
    var re = /\S+@\S+\.\S{2,}/;
    return re.test(email);
  }

  filterItemData(page) {
    switch (page) {
      case 'memberships': {
        this.prepareNewObject();
        break;
      }
      case 'courses': {
        this.prepareNewCoursesObject();
        break;
      }
      case 'gift cards' : {
          this.prepareCardsObject();
          break;
      }
    }
  }

  changeItemPage(page) {
    this.currentPage = page;
    this.filterItemData(page);
  }



  clearCartItems(data) {
    if (data.hasOwnProperty('all') && data.all === true) {
      this.cart_data.items = [];
    }
    if (data.hasOwnProperty('data')) {
      this.cart_data.items = this.cart_data.items.filter(item => item.data.id !== data.data.id);
    }
    this.cart_component.calculatePaymentInfo()
  }

  getAllDiscounts() {
    this.http.getData("discount" + this.include_center).subscribe(success => {
      return success.data;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      return false;
    });
  }


  addNote() {
    let reqObj = {
      note: this.note
    };
    this.http.patchData(`pos/${this.noteId}/note${this.include_center}`, reqObj).subscribe(response => {
      this.generalFunctions.openToast("Note has been saved", 2000, "success");
    }, err => {});
  }


  addCustomer() {
    var bool = true;
    this.generalFunctions.addCustomer(bool);
    this.router.navigate(["../client/customers/add"]);
  }

  //PAYMENT TRANSACTION COMPLETE


  startNewSale() {
    this.transaction_successful = false;
    this.saleInProgress = false;
    this.paymentModal = false;
    this.paid = 0;
        this.due = 0;
        this.noteId = null;
    this.selected_contact = {
      id: null,
      contact: ""
    };
    this.cart_data = {
      contact_id: null,
      items: [],
      payments: {
        amount_total: 0,
        amount_due: 0,
        methods: [
          {
            mode: "cash",
            amount: 0,
            realization: "immediate"
          }
        ]
      }
    };
    this.paymentSettings.paymentAmount = 0.00;
    this.paymentSettings.paymentSelected = null;
    this.paymentSettings.paymentInfo = {
      discountInfo: {}
    };
    this.paymentSettings.savedCards = [];
    this.paymentSettings.hasRecurringMembership = false;
    this.customer_select.clearCustomer(false);
  }

  transaction_successful: boolean = false;
  completeTransaction() {

      // prepare request object
      let reqObj = this.preparePosSale();


      this.http.sendData("pos/sale" + this.include_center, reqObj).subscribe(success => {
        this.transaction_successful = true;
        this.saleInProgress = false;
        this.paid = success.data.amount_paid;
        this.due = success.data.amount_due;
        this.noteId = success.data.id;
      },
      error => {
        this.generalFunctions.openToast(error?.message, 3000, "error");
        this.paymentFailed = true;
        this.saleInProgress = false;
      });

  }

  // checking if the card is already existing or newly added



  preparePosSale() {

    let center_contact_id = this.cart_data.contact_id;

    let transactionData: any = {};

    if (this.paymentSettings.paymentSelected === 'add-card') {
      transactionData.card_id = this.addedCardId;
      transactionData.mode = "online";
      transactionData.method = this.paymentSettings.cardMode;
    } else if (this.paymentSettings.paymentSelected?.startsWith('svd_crd_')) {
      transactionData.card_id = this.paymentSettings.paymentSelected.split('svd_crd_')[1];
      transactionData.mode = "online";
      transactionData.method = this.paymentSettings.cardMode;
    } else {
      transactionData.mode = "offline";
      transactionData.method = this.paymentSettings.paymentSelected;

    }
    let amount_due;

    if(this.paymentSettings.paymentInfo?.gCardDiscount > 0 ){
        amount_due = +(this.paymentSettings.paymentInfo.totalCartAmount - (this.paymentSettings.paymentInfo.paymentAmount + this.paymentSettings.paymentInfo.gCardDiscount)).toFixed(2);

    } else {
        amount_due = +(this.paymentSettings.paymentInfo.totalCartAmount - this.paymentSettings.paymentInfo.paymentAmount).toFixed(2);

    }


    let amountToCharge = this.paymentSettings.paymentInfo.totalAmountForPos - amount_due;

    let amount_total = this.paymentSettings.paymentInfo.totalAmountForPos;

    if (this.paymentSettings.paymentInfo.discountInfo.discountAvailable) {
      amountToCharge = amountToCharge - this.paymentSettings.paymentInfo.discountInfo.discount_amount;
      amount_total = amount_total - this.paymentSettings.paymentInfo.discountInfo.discount_amount;
    }

    if (this.paymentSettings.paymentInfo?.gCardDiscount > 0) {
        amountToCharge = amountToCharge - this.paymentSettings.paymentInfo.gCardDiscount ;
        amount_total = amount_total;

    }

    if (this.paymentSettings.paymentInfo?.gCardDiscount > 0) {
        console.log('token',this.cart_data.payments.gift_card_token )
        if (this.cart_data.payments.gift_card_token?.length > 0) {
            if(this.paymentSettings.paymentInfo?.gCardDiscount === this.paymentSettings.paymentInfo.totalAmountForPos){
                console.log('transactionData', transactionData)
                transactionData.method = 'gift_card';
                transactionData.mode = "offline";
            }
        }
    }

    let payments: any = {
      amount_total: parseFloat(amount_total.toFixed(2)),
      amount_due: amount_due,

      methods: [
        {
          ...transactionData,
          amount: parseFloat(amountToCharge.toFixed(2)),
          realization: "immediate",
        }
      ]
    }

    if (this.paymentSettings.paymentInfo?.gCardDiscount > 0) {
        console.log('token',this.cart_data.payments.gift_card_token )
        if (this.cart_data.payments.gift_card_token?.length > 0) {
            payments['gift_card_token'] =  this.cart_data.payments.gift_card_token;

        }
    }


    if (this.paymentSettings.paymentInfo.discountInfo.discountAvailable) {
      payments.discount = {
        "type": this.paymentSettings.paymentInfo.discountInfo.type,
        "discount_code": this.paymentSettings.paymentInfo.discountInfo.discount_code,
        "value": this.paymentSettings.paymentInfo.discountInfo.value,
        "value_type": this.paymentSettings.paymentInfo.discountInfo.value_type,
        "discount_amount": parseFloat(this.paymentSettings.paymentInfo.discountInfo.discount_amount.toFixed(2))
      }
    }

    let items = [];
    let cart_items_data = this.paymentSettings.cartData.items;

    for (let i = 0; i < cart_items_data.length; i++) {
      let service_id: any = '';
      let type = cart_items_data[i].type;
      if (type === 'SERVICEPACKS' || type === 'MEMBERSHIP_PLANS') {
        type = 'MEMBERSHIP_PLANS';
      }
      if (type === 'COURSES') {
        service_id = 6;
      }

      if(type === "GIFT_CARDS"){
          service_id = 8;
            console.log('cart_items_data[i]', cart_items_data[i])

            items.push({
                sale_type: "purchase",
                send_on: cart_items_data[i].start_at ? moment(cart_items_data[i].start_at).format("Y-MM-DD") : moment().format("Y-MM-DD") ,
                service_id: service_id,
                service_type_id: cart_items_data[i].data.id,
                tax_applicable: false,
                to_name : cart_items_data[i].to_name,
                from_name :  cart_items_data[i].from_name,
                email :  cart_items_data[i].email,
                message : cart_items_data[i].message,
                // current_value :  cart_items_data[i].data.value
              })

      } else {
      for (let j = 0; j < this.serviceCodes.length; j++) {
        if (type == this.serviceCodes[j].code) {
          service_id = this.serviceCodes[j].serviceId;
          break;
        }
      }}

      if(type !== "GIFT_CARDS") {
      items.push({
        sale_type: "purchase",
        starts_at: cart_items_data[i].start_at ? moment(cart_items_data[i].start_at).format("Y-MM-DD") : moment().format("Y-MM-DD") ,
        service_id: service_id,
        service_type_id: cart_items_data[i].data.id,
        tax_applicable: false


      })}


    }
    return ({payments, center_contact_id, items});
  }

  viewCustomerProfile() {
    var id = this.cart_data["contact_id"];
    this.router.navigate(["../client/customers", id]);
  }


  changePaymentMethod(method) {
    this.paymentSettings.paymentSelected = method;
  }










        checkCustomer(contact) {
          if (contact) {
            this.isContactSelected = true;
          } else {
            this.isContactSelected = false;
          }
        }

     toggleOverlay(value: boolean|null) {
      const new_value = value === undefined ? !this.is_overlay_active : value;
        this.is_overlay_active = new_value
    }

    cardValue(event) {
            console.log('info => ',this.paymentSettings.paymentInfo )
            this.cart_data.payments['gift_card_token'] = event.card_number;
            const discount = Number(event.current_value);
            let amt = this.paymentSettings.paymentInfo.totalCartAmount;
            this.paymentSettings.paymentInfo.paymentAmount = amt;
            this.remaining = 0;
            if (discount > this.paymentSettings.paymentInfo.totalCartAmount) {
                const val = this.paymentSettings.paymentInfo.totalCartAmount;
                this.paymentSettings.paymentInfo.gCardDiscount = val;
                this.paymentSettings.paymentInfo.paymentAmount =  0;
                this.remaining = discount - this.paymentSettings.paymentInfo.gCardDiscount;
            } else {
                this.paymentSettings.paymentInfo.gCardDiscount = discount;
                this.paymentSettings.paymentInfo.paymentAmount = this.paymentSettings.paymentInfo.paymentAmount - discount;
                this.remaining = 0;

            }
            // this.checkCart()
            console.log('remaining', this.remaining)

        }

        removeGift() {
            if (this.paymentSettings.paymentInfo?.gCardDiscount > 0) {
                    delete(this.cart_data.payments.gift_card_token);
                    this.isGCard = false;
                    // const val =  this.paymentSettings.paymentInfo.gCardDiscount + this.paymentSettings.paymentInfo.amount_due;
                    this.paymentSettings.paymentInfo.gCardDiscount = 0;
                    this.remaining = 0;
                    // this.paymentSettings.paymentInfo.paymentAmount =  val + this.paymentSettings.paymentInfo.paymentAmount;
                    this.paymentSettings.paymentInfo.paymentAmount = this.paymentSettings.paymentInfo.totalCartAmount
            }
        }

    showOptions(event){
        if(!event.checked){
            if (this.paymentSettings.paymentInfo?.gCardDiscount > 0) {

                delete(this.cart_data.payments.gift_card_token);
                this.remaining = 0;
                this.paymentSettings.paymentInfo.gCardDiscount = 0;
                this.paymentSettings.paymentInfo.paymentAmount = this.paymentSettings.paymentInfo.totalCartAmount
        }
        }
    }

    checkCart(){
        console.log('cart data => ', this.cart_data.items);
        const meta = JSON.parse(JSON.stringify(this.cart_data.items))
        let data = meta.filter(cart => cart.type == "MEMBERSHIP_PLANS" && cart.data?.is_recurring == 1)
        console.log(data);
        console.log('cart data => ', this.cart_data.items);

        if(data.length > 0) {
            this.is_cart_recurring = true;
        }else{
            this.is_cart_recurring = false;
        }
    }
}








