import {
    Component,
    Input,
    EventEmitter,
    Output,


} from '@angular/core';

import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import {Router, ActivatedRoute} from "@angular/router";
import * as moment from 'moment';



@Component({
    selector: 'pos-cart',
    templateUrl: './pos-cart.component.html',
    styleUrls: ['./pos-cart.component.scss']
})
export class PosCartComponent{



    constructor(private generalFunctions : GeneralServices, private http : ServerAuthService, private router : Router,) {}
    // @Output('selectContact')selectContactEmitter = new EventEmitter();
    @Output('clearCartItems')clearCartItems = new EventEmitter();
    @Output('editCardItem')editCardItem = new EventEmitter();
    @Output('startPayment')startPayment = new EventEmitter();
    // @Input('cart_data') cart_data: any = [];
    @Input('selected_contact') selected_contact: any | null = null;
    @Input('currency') currency: any;
    @Input('tax') tax_percent: any;
    @Input('discountCodes') discountCodes: any;
    paymentInfo:any = {
      totalCartAmount: 0.00,
      totalTax:0.00,
      discountInfo: {
        discount_amount: 0.00,
        discountType: "code",
        discountId: null,
        discountValue: 0,
        discountAvailable: false
      }
    }
    moment: any = moment;
    private _cart_data: any = [];


    cartDiscount:boolean=false;


    @Input() set cartData(value: any) {
      this._cart_data = value;
      this.calculatePaymentInfo();
   }
   get cartData(): any {
     return this._cart_data;
   }

   clearCart(data:any){
    this.clearCartItems.emit(data)

   }

   updateTax(total, discount: any=null) {


    let totalAmountForPos = this.paymentInfo.totalAmountForPos;
    if(discount){
      totalAmountForPos = this.paymentInfo.totalAmountForPos - discount;
    }


    this.paymentInfo = {
      ...this.paymentInfo,
      totalAmountForPos: totalAmountForPos,
      discountInfo: discount? discount: {...this.paymentInfo.discountInfo},
      totalCartAmount: parseFloat(parseFloat(total).toFixed(2)),
      totalTax:this.generalFunctions.calculateTax(this.tax_percent, total)
    }
  }

  editCard(i){
    this.editCardItem.emit(i);

  }

  charge() {

    this.startPayment.emit({
      paymentInfo: {...this.paymentInfo, discountInfo: {...this.paymentInfo.discountInfo}},
      cartData:{...this._cart_data}
    })

  }

  removeDiscount(){
    this.paymentInfo= {
      ...this.paymentInfo,
      discountInfo: {
        discountType: "code",
        discountId: null,
        discountValue: 0,
        discountAvailable: false
      }
    };
    this.calculatePaymentInfo();
  }


  showDiscountPopup(){
    this.cartDiscount = this._cart_data.items.length>0;
  }

   calculatePaymentInfo(){
     let value = this._cart_data;

     this.paymentInfo.discountInfo = {
      discountType: "code",
      discountId: null,
      discountValue: 0,
      discountAvailable: false,
      discount_amount: 0,
    };


    let totalAmountForPos = 0;



    let totalCartAmount = 0.00;
    for (let i = 0; i < value.items.length; i++) {
      totalCartAmount += value.items[i].totalAmount;
      totalAmountForPos += value.items[i].totalAmountForPos;
    }
    this.paymentInfo.totalAmountForPos = totalAmountForPos;

    this.updateTax(parseFloat(totalCartAmount.toFixed(2)));
    this.applyDiscountToCart();
   }



   applyDiscountToCart() {
    let value,
      mode,
      code,
      type,
      applicable_type,
      applicable_services,
      tags_type,
      tags;
    if (this.paymentInfo.discountInfo.discountId && this.paymentInfo.discountInfo.discountType == "code") {
      this.discountCodes.forEach(discount => {
        if (discount.id == this.paymentInfo.discountInfo.discountId) {
          value = discount.value;
          mode = discount.value_type;
          code = discount.code;
          applicable_type = discount.applicable_type;
          applicable_services = discount.applicable_services;
          type = "code";
          tags_type = discount.customer_applicable_type;
          tags = discount.applicable_customer_tags.length > 0
            ? discount.applicable_customer_tags
            : [];
        }
      });
    }
    if (this.paymentInfo.discountInfo.discountType == "percent" || this.paymentInfo.discountInfo.discountType == "price") {
      value = this.paymentInfo.discountInfo.discountValue;
      mode = this.paymentInfo.discountInfo.discountType == "price"
        ? "fixed"
        : "percent";
      code = "";
      type = "manual";
      applicable_type = 1;
    }
    this.cartDiscount = false;
    this.updateDiscountedCartTotal(value, mode, code, type, applicable_type, applicable_services, tags_type, tags);
  }


  updateDiscountedCartTotal(value, mode, code, type, applicable_type, applicable_services, tags_type, tags) {
    if (tags_type == 2) {
      let tagEligibility = false;
      if (this.selected_contact.contact.data.tags.length > 0) {
        tags.forEach(tag => {
          this.selected_contact.contact.data.tags.forEach(contactTag => {
            if (tag.id === contactTag.id) {
              tagEligibility = true;
            }
          });
        });
      }
      if (!tagEligibility) {
        this.paymentInfo.discountInfo = {
          discountType: "code",
          discountId: null,
          discountValue: 0,
          discountAvailable: false,
          discount_amount: 0
        };
        this.generalFunctions.openToast("Discount is not applicable", 3000, "error");
        return;
      }
    }

    if (applicable_type == 1) {
      let cardSumTotal = 0;
      let actualPrice = 0;
      for (let i = 0; i < this._cart_data.items.length; i++) {
        cardSumTotal += this._cart_data.items[i].totalAmount;
        actualPrice += this._cart_data.items[i].totalAmount;
      }
      if (mode == "percent") {
        if(value > 100) {
          this.paymentInfo.discountInfo = {
            discountType: "code",
            discountId: null,
            discountValue: 0,
            discount_amount: 0,
            discountAvailable: false
          };
            this.generalFunctions.openToast("Discount of more than 100% is not valid", 3000, "error");
            return;
        }
        else {
            cardSumTotal = cardSumTotal - cardSumTotal * value / 100;

        }
      } else if (mode == "fixed") {
        if (value > cardSumTotal) {
          this.paymentInfo.discountInfo = {
            discountType: "code",
            discountId: null,
            discountValue: 0,
            discountAvailable: false,
            discount_amount: 0,

          };
          this.generalFunctions.openToast("Discount value can not be greater than cart value", 3000, "error");
          this.updateTax(cardSumTotal);
          return;
        } else {
          cardSumTotal = cardSumTotal - value;
        }
      }
      let discount = {
        type: type,
        discount_code: code,
        value: value,
        value_type: mode,
        discount_amount: actualPrice - cardSumTotal,
        discountAvailable: true
      };
      // this.cart_data.payments["discount"] = discount;
      this.paymentInfo.discountInfo = discount;
      this.updateTax(cardSumTotal);
    } else if (applicable_type == 3) {
      let cardSumTotal = 0;
      let actualPrice = 0;
      let itemDiscountedPrice = 0;
      for (let i = 0; i < this._cart_data.items.length; i++) {
        // cardSumTotal += this.cart_data.items[i].discountedPrice;
        actualPrice += this._cart_data.items[i].totalAmount;

        if (this._cart_data.items[i].type == "SERVICEPACKS") {
          applicable_services.forEach(service => {
            if (service.service_id == 1) {
              if (service.id == this._cart_data.items[i].data.id) {
                itemDiscountedPrice += this._cart_data.items[i].totalAmount;
              }
            }
          });
        }
        if (this._cart_data.items[i].type == "MEMBERSHIP_PLANS") {
          applicable_services.forEach(service => {
            if (service.service_id == 1) {
              if (service.id == this._cart_data.items[i].data.membership_id) {
                itemDiscountedPrice += this._cart_data.items[i].totalAmount;
              }
            }
          });
        }
      }



      if (itemDiscountedPrice == 0) {
        this.paymentInfo.discountInfo = {
          discountType: "code",
          discountId: null,
          discountValue: 0,
          discountAvailable: false,
          discount_amount: 0,
        };
        this.generalFunctions.openToast("Discount code not applicable on any cart item", 3000, "error");
        cardSumTotal = actualPrice;
        this.updateTax(cardSumTotal);
        return;
      }


      if (mode == "percent") {
        cardSumTotal = actualPrice - itemDiscountedPrice * value / 100;
      } else if (mode == "fixed") {
        if (value >= itemDiscountedPrice) {
          this.paymentInfo.discountInfo = {
            discountType: "code",
            discountId: null,
            discountValue: 0,
            discountAvailable: false,
            discount_amount: 0,
          };
          this.generalFunctions.openToast("Applicable discount value is greater than the applicable item value", 4000, "error");
          cardSumTotal = actualPrice;
          this.updateTax(cardSumTotal);
          return;
        } else {
          cardSumTotal = itemDiscountedPrice - value;
        }
      }
      let discount = {
        type: type,
        discount_code: code,
        value: value,
        value_type: mode,
        discount_amount: parseFloat((actualPrice - cardSumTotal).toFixed(2)),
        discountAvailable: true
      };

      this.updateTax(cardSumTotal, discount);
    }
  }




}
