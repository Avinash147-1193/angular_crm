import {
    Component,
    OnDestroy,


    Input,
    AfterViewInit,
    ElementRef,
    ChangeDetectorRef,
    OnInit,
    EventEmitter,
    Output,
    ViewChild,

} from '@angular/core';

import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import {SelectItem, SelectItemGroup} from "primeng/api";
import {FormsModule, NgForm} from "@angular/forms";

const MAX_QUANTITY = {
    'MEMBERSHIP_PLANS': 1,
    'SERVICEPACKS': -1
}
import * as moment from 'moment';
//imidiate
//first_use

@Component({
    selector: 'pos-add-card',
    templateUrl: './pos-add-card.component.html',
    styleUrls: ['./pos-add-card.component.scss']
})
export class PosAddCardComponent implements OnDestroy, AfterViewInit {
    @Input() type: any = [];
    @Input() addCardData: any = {}
    @Output('addCardError') addCardError = new EventEmitter();
    @Output('addCardSuccess') addCardSuccess = new EventEmitter();

    moment: any = moment;
    card: any = null;
    elements: any;
    cardHandler = this.onChange.bind(this);
    error: string;
    adyenToken:any;


    @ViewChild("cardInfo")cardInfo: ElementRef;
    @ViewChild("checkoutForm")checkoutForm;


    constructor(private generalFunctions : GeneralServices, private route : ActivatedRoute, private router : Router, private http : ServerAuthService, private cd : ChangeDetectorRef) {

      }


    haserror(){
        return !!this.error;
    }


    onChange({error}) {
        if (error) {
          this.error = error.message;
        } else {
          this.error = null;
        }
        this.cd.detectChanges();
      }


      submit(){
        if(this.type == 'adyen'){
            this.adyenAddCard();
          }else if(this.type == 'stripe'){
            this.stripeAddCard()
          }

      }


      addCard(token) {
        this.http.sendData("contact/" + this.addCardData.contact_id + "/payment/sources" + this.addCardData.include_center , {token: token}).subscribe(success => {
          this.addCardSuccess.emit({addedCardId: success.data.id})
        }, error => {
           this.addCardError.emit(error)
           this.generalFunctions.openToast(error.message, 3000, "error");

        });
      }

      getAdyenToken() {
        this.http.getData('apps' + this.addCardData.include_center).subscribe(success => {
            const adyen = success.apps.filter(app => app.app.name === 'Adyen')
            let adyenConnected;
            let adyenData;
            adyen.length > 0 ? adyenConnected = true : adyenConnected = false;
            if (adyenConnected) {
                adyenData = adyen[0].settings.client_id;
                this.adyenToken =  adyenData;
            }
            this.adyenToken =  false;
          }, error => {
            this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
            this.adyenToken =  false;
          });
      }




    ngAfterViewInit() {

      if(this.type=='stripe'){
        const style = {
            base: {
              lineHeight:"24px",
              backgroundColor:  '#f5f6fa',
              fontSize: "14px",
              "::placeholder": {
                fontSize: "14px",
                color: "#7e95a3"
              }
            }
          };
          this.card = elements.create("card", {style});
          this.cardInfo.nativeElement.focus();
          this.card.mount(this.cardInfo.nativeElement);
          this.card.addEventListener("change", this.cardHandler);
        } else if(this.type == 'adyen'){
            this.getAdyenToken();
          }
    }

    ngOnDestroy() {
        if(this.card){
          this.card.removeEventListener("change", this.cardHandler);
          this.card.destroy();
        }
    }
    aValidCard = false;
    adyenValidationEvent(event) {
        this.aValidCard = event;
    }
    adyenAddCard() {
        let token;
        if (this.aValidCard['isValid']) {
            token = this.aValidCard['data']['paymentMethod'];
            this.addCard(token);
        } else {
            this.addCardError.emit({message: 'Please input valid card details'})
            return;
        }
    }




    async stripeAddCard() {
        const {token, error} = await stripe.createToken(this.card);
        if (error) {
            this.addCardError.emit({message: 'Error adding card'})
        } else {
          this.addCard(token.id);
        }
      }

}
