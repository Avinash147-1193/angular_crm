import {
    Component,

    Input,

    OnInit,
    EventEmitter,
    Output,
    SimpleChanges,
    OnChanges,

} from '@angular/core';

const MAX_QUANTITY = {
    'MEMBERSHIP_PLANS': 1,
    'SERVICEPACKS': -1
}
import * as moment from 'moment';
//imidiate
//first_use

@Component({
    selector: 'pos-g-cards',
    templateUrl: './pos-g-cards.component.html',
    styleUrls: ['./pos-g-cards.component.scss']
})
export class PosGCards implements OnInit, OnChanges {
    @Input() newCards: any = [];
    @Input() currency: any = "";
    @Output('addItemToCart') addItemToCart = new EventEmitter();

    moment: any = moment;

    addToCart(data){
        this.addItemToCart.emit({type:'GIFT_CARDS', max_allowed: -1, data});

    }

    ngOnInit() {

    }
    ngOnChanges(changes: SimpleChanges): void {
        console.log(changes);
        console.log(this.newCards)

    }

}
