import {
    Component,

    Input,

    OnInit,
    EventEmitter,
    Output,

} from '@angular/core';

const MAX_QUANTITY = {
    'MEMBERSHIP_PLANS': 1,
    'SERVICEPACKS': -1
}

//imidiate
//first_use

@Component({
    selector: 'pos-memberships',
    templateUrl: './pos-memberships.component.html',
    styleUrls: ['./pos-memberships.component.scss']
})
export class PosMembershipsComponent implements OnInit {
    @Input() newMembershipPlan: any = [];
    @Input() currency: any = "";
    @Output('addItemToCart') addItemToCart = new EventEmitter();

    addToCart(data){
        let type = ''

        if(data.type === 2){
            type="SERVICEPACKS";

        }else{
            type = "MEMBERSHIP_PLANS"
        }
        this.addItemToCart.emit({type, max_allowed: MAX_QUANTITY[type], data});

    }




    ngOnInit() {


    }

}
