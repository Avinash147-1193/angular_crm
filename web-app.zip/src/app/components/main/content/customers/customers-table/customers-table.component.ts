import {Component, OnInit, ViewChild} from "@angular/core";
import {Router, ActivatedRoute, Params} from "@angular/router";
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import {Constants} from "../../../../../constants";

import {Observable, fromEvent} from "rxjs";
import {truncate} from "fs";
import {arch, constants} from "os";

@Component({templateUrl: "./customers-table.component.html", styleUrls: ["./customers-table.component.scss"]})
export class CustomersTableComponent implements OnInit {
  tab_id: any = "member";
  summary: any = {};
  open_filter = false;
  customers_data: any = null;
  search_customer_text: any;

  page_data_loaded: boolean = false;
  type_loaded: boolean = false;
  server_request: boolean = true;

  true: boolean = true;
  false: boolean = false;
  null: any = null;

  no_more_results: boolean = false;
  include_center: any = null;

  filterActive: String = "active";
  filterScreenActive: boolean = false;
  isFilterActive: boolean = false;
  actualFilterObj: any = {
    period: {
      type: "added_on",
      from: null,
      to: null
    }
  };
  virtualFilterObj: any = {
    period: {
      type: "added_on",
      from: null,
      to: null
    }
  };

  statuses_count: object = {
    total: 0,
    "1": 0,
    "2": 0,
    "3": 0,
    "4": 0,
    "5": 0
  };

  statuses: any = [
    {
      value: Constants.ACTIVE,
      name: "Active",
      checked: false
    }, {
      value: Constants.INACTIVE,
      name: "Inactive",
      checked: false
    },

    // {
    //   value: Constants.UPCOMING,
    //   name: "Upcoming",
    //   checked: false
    // }, {
    //   value: Constants.PAUSED,
    //   name: "Paused",
    //   checked: false
    // },
    {
      value: Constants.BILLING_ISSUE,
      name: "Billing issue",
      checked: false
    }
  ];

  archived: boolean = false;
  drop_in: boolean = false;

  params: any = {
    filterBy: {
      type: "1"
    },
    sortBy: {},
    page: 1
  };

  biometricEnabled: boolean = false;

  enlarged_photo_popup: boolean = false;
  show_image_url: any = null;
  loaded: boolean;
  pagination : any;
  loadingMore : boolean = false;

  @ViewChild("customer_statuses")customer_statuses;

  constructor(private router : Router, private route : ActivatedRoute, private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {
    this.loaded = false;
    this.include_center = this.generalFunctions.includeCenter();
    this.getTypeCount();
    this.route.queryParams.subscribe(params => {
      if (params["filter"]) {
        this.params.filterBy["status"] = params["filter"];
        setTimeout(() => {
          var lis = this.customer_statuses.nativeElement.children;
          Array.prototype.forEach.call(lis, (item, index) => {
            item.classList.remove("on");
          });
          lis[0].parentElement.querySelectorAll('[data-status="' + params["filter"] + '"]')[0].classList.add("on");
        }, 400);
      }
      this.getSettings();
      this.getFirstData();
      // this.getCustomers();
    });
  }

  openFilters() {
    this.open_filter = true;
  }

  contentScroll(e) {
    // this.generalFunctions.breadcrumbToggle(e);
    var el = e.target;
    var totalHeight = el.scrollHeight;
    var scrolled = el.scrollTop;
    var boxHeight = el.clientHeight;
    if (this.no_more_results) {
      return false;
    }
    if (totalHeight - 8 < scrolled + boxHeight) {
      this.loadMoreData();
    }
  }

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
      success = success;
      this.biometricEnabled = success.attendance.biometric.enabled;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  getStatusesCount() {
    this.http.getData("customer/statuses" + this.include_center).subscribe(data => {
      this.statuses_count["total"] = data.total;
      data.data.forEach((item, index) => {
        this.statuses_count[item.status] = item.count;
      });
    }, error => {
      var msg = "Unable to fetch data!";
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {});
  }

  getFirstData() {
    this.customers_data = null;
    this.server_request = true;
    this.no_more_results = false;
    this.params["page"] = 1;
    if (this.tab_id == "drop-in") {
      this.params.filterBy.type = [3];
    }
    if (this.tab_id == "member" && !this.drop_in) {
      this.params.filterBy.type = [1, 3];
    } else {
      this.params.filterBy.type = [3];
    }

    this.getStatusesCount();
    this.http.sendData("contact/search" + this.include_center , this.params).subscribe(success => {
      success = success;
      this.loaded = true;
      this.customers_data = success.data;

	  this.pagination = success.meta.pagination;
    //   if (this.tab_id == "member") {
    //     this.appendMembership();
    //   }
      this.generateColor(this.customers_data);
	  this.getFirstTypeCount();
	  const currentPage = success.meta.pagination.current_page;
      const totalPages = success.meta.pagination.total_pages;
      if (currentPage >= totalPages) {
        this.no_more_results = true;
        this.params["page"] = 1;
      } else {
        this.params["page"] += 1;
      }
    }, err => {
      var msg = err.message;
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {
      this.page_data_loaded = true;
      this.server_request = false;
    });
  }

//   appendMembership() {
//     for (let i = 0; i < this.customers_data.length; i++) {
//       if (this.customers_data[i].memberships.data.length > 0) {
//         for (let j = 0; j < this.customers_data[i].memberships.data.length; j++) {
//           if (this.customers_data[i].memberships.data[j].service_type == "MEMBERSHIP_PLANS" && this.customers_data[i].memberships.data[j].status == 1) {
//             this.customers_data[i].active_membership = this.customers_data[i].memberships.data[j];
//           } else {
//             if ((this.customers_data[i].memberships.data[j].service_type == "MEMBERSHIP_PLANS" && this.customers_data[i].memberships.data[j].status == 2) || 3 || 4 || 5) {
//               this.customers_data[i].active_membership = this.customers_data[i].memberships.data[j];
//             } else {
//               if (this.customers_data[i].memberships.data[j].service_type == "SERVICEPACKS") {
//                 this.customers_data[i].active_membership = this.customers_data[i].memberships.data[j];
//               }
//             }
//           }
//         }
//       } else {
//         this.customers_data[i].active_membership = null;
//       }
//       console.log("this.customers_data[i].active_membership", this.customers_data[i].active_membership);
//     }
//   }

  generateColor(id) {
    id.forEach((element, index) => {
      let colorCode = element.id % 10;
      this.customers_data[index].colorCode = colorCode;
    });
  }

  loadMoreData() {
	  this.loadingMore = true;
    if (!this.no_more_results && !this.server_request) {
      this.server_request = true;
      this.http.sendData("contact/search" + this.include_center, this.params).subscribe(success => {
		success = success;
		this.loadingMore = false;
		this.customers_data = this.customers_data.concat(success.data);
		this.pagination = success.meta.pagination;
        var currentPage = success.meta.pagination.current_page;
        var totalPages = success.meta.pagination.total_pages;
        if (currentPage >= totalPages) {
          this.no_more_results = true;
          this.params["page"] = 1;
        } else {
          this.params["page"] += 1;
        }
      }, error => {
        error = error;
        var msg = error.message;
        this.generalFunctions.openToast(msg, 3000, "error");
      }, () => {
        this.server_request = false;
      });
    }
  }

  filterQuery(e) {
    this.generalFunctions.isFilled(e);
    if (e.target.value.length > 0) {
      this.params.filterBy.query = this.search_customer_text;
    } else {
      delete this.params.filterBy["query"];
    }
    this.getFirstData();
  }

  filterStatus(e) {
    var li = e.target.nodeName == "LI"
      ? e.target
      : e.target.parentElement;
    var sib = li.parentElement.children;
    Array.prototype.forEach.call(sib, (item, index) => {
      item.classList.remove("on");
    });
    li.classList.add("on");

    var status = li.getAttribute("data-status");
    this.filterActive = status;
    this.params.filterBy.status = status;
    if (status == "none") {
      delete this.params.filterBy["status"];
    }

    this.getFirstData();
  }

  sortByColumn(e) {
    if (e.target.classList.contains("active")) {
      var x = e.target.getAttribute("data-column");
      if (e.target.classList.contains("asc")) {
        e.target.classList.remove("asc");
        e.target.classList.add("desc");
        this.params.sortBy[x] = "desc";
      } else if (e.target.classList.contains("desc")) {
        e.target.classList.remove("desc");
        e.target.classList.add("none");
        delete this.params.sortBy[x];
      } else if (e.target.classList.contains("none")) {
        e.target.classList.remove("none");
        e.target.classList.add("asc");
        this.params.sortBy[x] = "asc";
      }
    } else {
      this.params.sortBy = {};
      Array.prototype.forEach.call(e.target.parentElement.children, (item, index) => {
        item.classList.remove("active", "asc", "desc", "none");
      });
      e.target.classList.add("active", "asc");
      var x = e.target.getAttribute("data-column");
      this.params.sortBy[x] = "asc";
    }
    this.getFirstData();
  }

  showFilters() {
    this.filterScreenActive = true;
    this.virtualFilterObj = JSON.parse(JSON.stringify(this.actualFilterObj));
  }

  pullStatus() {
    let statusArray = [];
    console.log("this.statuses", this.statuses);
    for (let i = 0; i < this.statuses.length; i++) {
      console.log("this.statuses[i]", this.statuses[i]);
      if (this.statuses[i].checked == true) {
        statusArray.push(this.statuses[i].value);
      }
    }
    return statusArray;
  }

  resetArchivedOnly() {
    if (this.archived) {
      this.statuses = [
        {
          value: Constants.ACTIVE,
          name: "Active",
          checked: false
        }, {
          value: Constants.INACTIVE,
          name: "Inactive",
          checked: false
        }, {
          value: Constants.BILLING_ISSUE,
          name: "Billing issue",
          checked: false
        }
      ];
      this.drop_in = false;
      delete this.params.filterBy.expired_in;
      delete this.params.filterBy.added_in;
    } else if (this.drop_in) {
      this.statuses = [
        {
          value: Constants.ACTIVE,
          name: "Active",
          checked: false
        }, {
          value: Constants.INACTIVE,
          name: "Inactive",
          checked: false
        }, {
          value: Constants.BILLING_ISSUE,
          name: "Billing issue",
          checked: false
        }
      ];
      this.archived = false;
      delete this.params.filterBy.expired_in;
      delete this.params.filterBy.added_in;
    }
  }

  applyFilters() {
    if (this.archived) {
      this.params.filterBy.status = ["6"];
      // delete this.params.filterBy.status;
    } else {
      delete this.params.filterBy.status;
      if (this.pullStatus().length > 0) {
        this.params.filterBy.status = this.pullStatus();
      } else {
        delete this.params.filterBy.status;
      }
    }
    this.getTypeCount();
    this.open_filter = false;
    this.getFirstData();
    this.filterScreenActive = false;
    console.log("this.archived, this.params.filterBy", this.archived, this.params.filterBy);
  }

  trackRadio(val) {
    console.log("this.params.filterBy.expired_in.value", this.params.filterBy.expired_in);
    if (val == 1) {
      delete this.params.filterBy.added_in;
    }
    if (val == 2) {
      delete this.params.filterBy.expired_in;
    }
  }

  resetFilter() {
    this.statuses = [
      {
        value: Constants.ACTIVE,
        name: "Active",
        checked: false
      }, {
        value: Constants.INACTIVE,
        name: "Inactive",
        checked: false
      }, {
        value: Constants.BILLING_ISSUE,
        name: "Billing issue",
        checked: false
      }
    ];
    this.archived = false;
    this.drop_in = false;

    delete this.params.filterBy.expired_in;
    delete this.params.filterBy.added_in;
    delete this.params.filterBy.status;
    delete this.params.status;
    this.getTypeCount();
    this.getFirstData();
    this.open_filter = false;
    this.filterScreenActive = false;
  }

  //dj code

  getCustomers() {
    this.http.sendData("contact/search" + this.include_center + "&include=memberships", this.params).subscribe(success => {
      success = success;
    //   this.customers_data = success.data;
    //     this.customers_data[0].tags[0] = {'client_id': 79,
    //     'created_at': "2020-10-13 13:29:17",
    //     'deleted_at': null,
    //     'id': 543,
    //     'is_system': 1,
    //     'name': "Unpaid Dues",
    //     'pivot': {center_contact_id: 4171, tag_id: "543"},
    //     'tag_color': null,
    //     'updated_at': "2020-10-13 13:29:17"}
      this.customers_data.forEach((element, i) => {
        element.memberships.data.forEach((item, j) => {
          if (item.service_type == "MEMBERSHIP_PLANS" && item.status == 1) {
            this.customers_data[i].membership = item;
            console.log("this.customers_data", this.customers_data[i]);
          }
        });
      });

      console.log("this.customers_data", this.customers_data);
    }, err => {
      var msg = err.message;
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {
      this.page_data_loaded = true;
      this.server_request = false;
    });
  }

  getFirstTypeCount() {
    delete this.params.filterBy["type"];
    if (this.archived) {
      this.params.filterBy.status = [Constants.ARCHIVED];
    } else {
      this.params.filterBy.status = [Constants.ACTIVE, Constants.INACTIVE, Constants.PAUSED, Constants.UPCOMING, Constants.BILLING_ISSUE];
    }
    this.http.sendData("contact/counts" + this.include_center, this.params).subscribe(success => {
      this.summary["type"] = success.data;
      console.log("this.summary.type", this.summary.type);
      this.type_loaded = true;
    }, err => {
      var msg = err.message;
      this.generalFunctions.openToast(msg, 3000, "error");
    });
  }

  getTypeCount() {
    delete this.params.filterBy["type"];

    this.http.sendData("contact/counts" + this.include_center, this.params).subscribe(success => {
      this.summary["type"] = success.data;
      console.log("this.summary.type", this.summary.type);
      this.type_loaded = true;
    }, err => {
      var msg = err.message;
      this.generalFunctions.openToast(msg, 3000, "error");
    });
  }
}
