import { Directive, ElementRef } from '@angular/core'

@Directive({
    selector : '[regionTextStyle]',
})

export class TextRegion {
    constructor(el: ElementRef) {
        el.nativeElement.style.fontSize = '11px';
        el.nativeElement.style.color = '#7e95a3';

    }

}
