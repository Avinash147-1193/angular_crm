export * from './customers-detail.component'
