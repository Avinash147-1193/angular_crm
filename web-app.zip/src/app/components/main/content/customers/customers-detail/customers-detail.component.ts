import {
    Component,
    OnInit,
    ViewChild,
    OnDestroy,
    ViewEncapsulation,
    ElementRef,
    AfterViewInit,
    ChangeDetectorRef
  } from '@angular/core';
  import {Router, ActivatedRoute, Params} from '@angular/router';
  import {GeneralServices} from '../../../../../common/general-services';
  import {ServerAuthService} from '../../../../../common/server-auth';
  import {NgForm} from '@angular/forms';
  import {RefundType, MembershipTypes} from '../../../../../constants';

  import * as moment from 'moment';
  import {isNull} from 'util';
  import {SelectItem} from 'primeng/api';
  import {AddTagComponent} from '../../../../feature/add-tag/add-tag.component';
  import {MembershipConstants, SubscriptionConstants} from '../../../../../constants'

  @Component({
    templateUrl: './customers-detail.component.html',
    styleUrls: ['./customers-detail.component.scss', '../../services/styles/profiles.scss'],
    encapsulation: ViewEncapsulation.None})

  export class CustomersDetailComponent implements OnInit,
  OnDestroy {
    @ViewChild('ajax_loader')ajax_loader;
    @ViewChild('gender_container')gender_container;
    @ViewChild('phone')phone;
    @ViewChild('email')email;
    @ViewChild('pincode')pincode;
    @ViewChild('emergency_contact_phone')emergency_contact_phone;

    @ViewChild('video')video;
    @ViewChild('canvas')canvas;
    @ViewChild('photo_tag')photo_tag;

    @ViewChild('selected_image')selected_image;
    @ViewChild('cardInfo')cardInfo: ElementRef;

    @ViewChild('dd')dd;

    primary_tab_selected = 'summary';
    membership_history = false;
    pt_history = false;
    credit_history = false;
    profile_details_edit = false;
    transaction_filter = 'all';
    transaction_filter_array: Array<string> = ['all'];
    transaction_count: object = {
      total: 0,
      billing_issue: 0
    };

    availableChannels: any = [
      {
        label: 'Mail',
        value: 'mail'
      }, {
        label: 'SMS',
        value: 'sms'
      }
    ];

    selectedChannel = '';

    true = true;
    false = false;
    null: any = null;
    show_update_profile_picture_popup = false;

    customer_id: any = null;
    customer_data: any = null;
    customerBooking: any = {
      past: [],
      upcoming: []
    };
    customerCourse: any = {
        past: [],
        upcoming: []
      };
    bookingMode: any = 'upcoming';
    include_center: any = null;
    updated_data: any = {};

    show_pop_up = false;
    pop_up_for: any = null;
    tool_tip_for: any = null;
    currency: any = null;

    sms_count = 1;
    sms_length = 140;

    videoStream: any = null;

    popup_action: any = null;

    staff_list: any = [];
    lead_stages: any = [];
    lead_sources: any = [];

    sms_data: any = {
      message: '',
      signature: true
    };

    freeze_data: any = {
      id: null,
      starts_at: null,
      ends_at: null,
      m_start: null,
      m_expiry: null
    };

    unfreeze_data: any = {
      id: null,
      name: null,
      obj: null
    };

    extend_data: any = {
      starts_at: null,
      expires_at: null,
      m_start: null,
      m_expiry: null,
      plan_type: null,
      plan_name: null
    };
    edit_credit: any = {
      amount: null,
      action: 'credit'
    };

    credit_data: any = {
      customerId: null,
      creditId: null,
      setFlag: true,
      setCurrent: null
    };

    task_data: any = {
      id: null,
      type: 'phone',
      remind_on: null,
      comment: null,
      client_id: null
    };

    stage_change_data: any = {
      type: 'stage',
      comment: null,
      old_stage: null,
      new_stage: null
    };

    assign_data: any = {
      type: 'transfer',
      old_assigned_to: null,
      new_assigned_to: null
    };

    comment_data: any = {
      type: 'comment',
      comment: null
    };

    convert_to_lead_data: any = {
      assigned_to: null,
      source: null,
      stage: null
    };

    writeoff_modal_mode = false;
    writeoff_calculation = false;
    writeoff_confirmation = false;
    writeoff_complete = false;

    net_writeoff = 0;
    total_writeoff = 0;
    write_off_id: any = null;

    webcam_initiate = false;
    photo_selected = false;
    photo_captured = false;

    isCameraAdapted = true;

    enlarged_photo_popup = false;

    emergency_contact_enabled = true;
    medical_history_enabled = true;
    membership_id_enabled = true;

    emergency_contact_mandatory = true;
    medical_history_mandatory = true;
    membership_id_mandatory = true;

    attendance_id_enabled = true;
    photo_enabled = true;
    photo_mandatory = true;

    phoneChange = false;
    phoneChangeStep = 1;
    newPhone: any = null;
    newPhoneOtp: any = null;

    freeze_enabled = false;
    extend_enabled = false;

    customer_tasks_incomplete: any = [];
    customer_tasks_complete: any = [];

    add_task_in_stage = false;
    add_task_in_comment = false;
    refundAllowed = false;
    refundCancelAllowed = false;
    cancelMembershipId: any;
    cancellationCreditTable = false;
    smsNum: any = 0;

    // payments tab vars
    selectedTab = 'orders';
    isOrderOverlay = false;
    allOrders: any = [];
    allPayments: any = [];
    selectedOrder: any = {};
    selectedOrderIndex: any;
    orderDetailsView = 'sale-details';
    writeOffStage = 0;
    writeOffAmount: any;
    writeOffProceed = false;
    clearDuePaymentMethod = '';
    clearDueAmount: any;
    clearDueDate = '';
    clearDueProceed = false;
    messageDetails: any = {
      message: '',
      subject: '',
      channel: 'mail'
    };
    validationFields: any = {
      writeOffAmount: false,
      clearDueAmount: false,
      customerEmail: false
    };

    availablePaymentModes: any = {};
    enabledPaymentModes: any = {};
    enabledCollectModes: any = {};
    refundPaymentModes: any = {};

    refundCart: any = {
      items: [],
      id: '',
      refundCartTotal: 0,
      intendedRefund: 0
    };
    refundOverlay = false;
    refundThis: any = [];
    preparedArray: any = [];
    refundPhase: any;
    selectedMode: any = {};
    itemInCart: boolean;
    taxEnabled: boolean;
    taxes: any;
    deleteId: any;
    invoiceEmail: any;
    groupMessage: any = {
      subject: '',
      channel: 'email',
      message: '',
      fromEmail: ''
    };
    senderId: any = [];

    card: any;
    cardHandler = this.onChange.bind(this);
    error: string;

    index: any;
    token: any;
    stripeConnected: boolean;
    cardDetails: any;
    currentCard: any = null;
    savedCards: any;
    addingCard: any = false;
    dropdownLoaded: any = false;
    creditUsage: Object;
    serviceCount = {
      membership: 0,
      recurring: 0
    };

    phonePrefix: any;

    cars: SelectItem[] = [];

    selectedCar: any = {};

    tags: any = [];

    isTags = false;
    mailChimp = false;

    navigationList: Array<string> = [];
    bookingNav: Array<string> = ['upcoming', 'past'];
    paymentNav: Array<string> = ['orders', 'payments']
    view: any = '';
    bookingView: any = 'upcoming';
    paymentView: any = 'orders'
    membership_history_recurring: any;

    dobDatepickerConfig = {
      showWeekNumbers: false,
      containerClass: 'theme-default',
    };


    membershipStatus: any = MembershipConstants;
    subscriptionStatus: any = SubscriptionConstants;
    subscription: any = [];
    currentSubscription: any;
    centerId: any;
    retryingPayment = false;
    completingDue = false;
    subscriptionWriteoff = false;

    pause = {
        starts: null,
        ends: null,
        current: null,
        pauseStartMode: null,
        name: null,
        endMin: null,
        startMin: null,
        status: null,
        gap: null,
        nextBilling: null,
        currentBilling: null,
        id: null,
        freezeLog: null
    }
    removePauseStage = null;
    paymentMode = null;
    adyenCardData = null;
    course_history = false;
    hovered = false;

    @ViewChild(AddTagComponent)
    private addTag: AddTagComponent;
      cancelCourseId: any;


    // tslint:disable-next-line: max-line-length
    constructor(private router: Router,
        private route: ActivatedRoute,
         private generalFunctions: GeneralServices,
         private http: ServerAuthService,
         private cd: ChangeDetectorRef) {}

    ngOnInit() {
    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
     this.include_center = this.generalFunctions.includeCenter();
     this.getSettings();
      this.getCenterData();
      this.getTags();
      this.getApps();



      this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
      this.phonePrefix = JSON.parse(localStorage.getItem('localization'))['country']['isd_code'];

      this.route.params.subscribe(params => {
        this.customer_id = params['id'];
        this.getCustomerData(this.customer_id);
      });

      this.route.queryParams.subscribe(params => {
        if (params['tab']) {
          this.primary_tab_selected = params['tab'];
        }
        if (params['sale']) {
          this.primary_tab_selected = 'payments';
          this.findSale(params.sale);
        }
      });

      document.addEventListener('click', event => {
        this.documentClickHandler(event);
        this.hovered = false;
      });

      this.getLeadStages();
      this.preparePaymentModes();

    }

    // tslint:disable-next-line: use-life-cycle-interface
    ngAfterViewInit() {
      const style = {
        base: {
          lineHeight: '24px',
          fontSize: '14px',
          '::placeholder': {
            color: '#546a7b'
          }
        }
      };
      this.card = elements.create('card', {
        hidePostalCode: true,
        style
      });
      this.cardInfo.nativeElement.focus();
      this.card.mount(this.cardInfo.nativeElement);
      this.card.addEventListener('change', this.cardHandler);
    }

    ngOnDestroy() {
      this.card.removeEventListener('change', this.cardHandler);
      this.card.destroy();
      this.stopWebcam();
    }

    onChange({error}) {
      if (error) {
        this.error = error.message;
      } else {
        this.error = null;
      }
      this.cd.detectChanges();
    }

    async onSubmit(form: NgForm) {
      this.addingCard = true;
      const {token, error} = await stripe.createToken(this.card);
      if (error) {
        this.addingCard = false;
      } else {
        this.addCard(token.id);
      }
    }

    adyenAddCard() {
        this.addingCard = true;

        if (this.adyenCardData['isValid']) {
            const token = this.adyenCardData['data']['paymentMethod'];
            this.addCard(token);
        } else {
            this.addingCard = false;
            this.generalFunctions.openToast('Please enter a valid card', 3000, 'error');
        }
    }


    getApps() {
        this.http.getData('apps' + this.include_center).subscribe(success => {
            success = success;
            const chimp = success.apps.filter(app => app.app.name === 'Mailchimp')
            this.mailChimp = chimp.length > 0;

          }, error => {
            this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
          });
      }

    triggerView(event) {
      this.view = event;
      if (this.view == 'bookings') {
          this.bookingView = 'upcoming'
      }
    }

    triggerBookingView(event) {
        this.bookingView = event
    }

    triggerPaymentView(event) {
        this.paymentView = event;
    }

    getCenterData() {
      this.http.getData(`center/${this.centerId}` + this.include_center).subscribe(success => {
        //stripeconnected checks for any gateway be it adyen or stripe

        success.data.gateway === 'adyen' || success.data.gateway === 'stripe'
          ? (this.stripeConnected = true)
          : (this.stripeConnected = false);
        this.paymentMode = success.data.gateway;


        if (this.stripeConnected) {
          this.getCard();
        }


        // this.senderId = success.data.channels;

        let senderId = success.data.settings.automations.channels.sms;

        if (senderId === 1) {
          this.senderId.push('sms')
        }
      }, error => {});
    }





    adyenValidationEvent(event) {
        console.log('event', event)

        this.adyenCardData = event;
    }


    groupMessageClick() {
      if (this.senderId.includes('sms')) {
        this.groupMessage.channel = 'sms';
        this.messageDetails.message = '';
      }
    }

    callDateFormatter(date) {
      return moment(date).format('DD MMM YYYY');
    }
    /* ----- GENERAL USEFUL FUNCTION FOR THE COMPONENT ----- */

    contentScroll(e) {
      // this.generalFunctions.breadcrumbToggle(e);
    }
    isFilled(e) {
      this.generalFunctions.isFilled(e);
    }
    toggleCustomTicTac(e) {
      this.generalFunctions.toggleCustomTicTac(e);
    }
    autoIncreaseSize(e) {
      const textarea = e.target,
        height = textarea.offsetHeight;
      textarea.style.height = '16px';
      textarea.style.height = textarea.scrollHeight + 5 + 'px';
      // textarea.style.maxHeight = textarea.scrollHeight+"px";
      this.isFilled(e);
    }

    countMessage(e) {
      this.autoIncreaseSize(e);
      const SMSCount = Math.ceil(e.target.value.length / 140);
      if (SMSCount) {
        this.sms_count = SMSCount;
        this.sms_length = SMSCount * 140;
      }
    }

    smsCounter(data) {
      data.length == 0
        ? (this.smsNum = 0)
        : (this.smsNum = Math.floor(data.length / 160) + 1);
    }

    documentClickHandler(e) {
      Array.prototype.forEach.call(document.getElementsByClassName('more-options-list'), (item, index) => {
        item.classList.contains('display-none')
          ? ''
          : item.classList.add('display-none');
      });
      if (e.target.parentElement) {
        if (e.target.parentElement.classList.contains('more-options-icon')) {
          const list = this.generalFunctions.parents(e.target)[1].getElementsByClassName('more-options-list')[0];
          list.classList.remove('display-none');
        }
      }
    }

    // GET SETTINGS
    getSettings() {
      // SEND HTTP REQUEST AND GET MEMBERSHIP SETTINGS
      this.http.getData('settings' + this.include_center).subscribe(success => {
        success = success;
        this.photo_enabled = success.contacts.img_data.enabled;
        this.photo_mandatory = success.contacts.img_data.mandatory;

        this.emergency_contact_enabled = success.contacts.emergencyContact.enabled;
        this.medical_history_enabled = success.contacts.medical_history.enabled;
        this.membership_id_enabled = success.contacts.custom_fields.membership_id.enabled;

        this.emergency_contact_mandatory = success.contacts.emergencyContact.mandatory;
        this.medical_history_mandatory = success.contacts.medical_history.mandatory;
        this.membership_id_mandatory = success.contacts.custom_fields.membership_id.mandatory;
        // change this after debugging
        this.freeze_enabled = success.administration.memberships.freeze_enabled;
        this.extend_enabled = success.administration.memberships.extend_enabled;

        this.attendance_id_enabled = success.attendance.biometric.enabled;
        this.taxEnabled = success.tax.enabled;
        this.taxes = success.taxes.percentage;

        // payment modes
        this.availablePaymentModes = success.pos.payments.available_modes;
      }, error => {
        this.generalFunctions.openToast('Unable to load settings!', 3000, 'error');
      });
    }

    getCustomerBookings(id) {
      this.customerBooking.upcoming = [];
      this.customerBooking.past = [];
      const endpoint = 'contact/' + id + '/bookings' + this.include_center;
      const date = new Date();
      this.http.getData(endpoint).subscribe(data => {
        const bookings = data.data;
        bookings.forEach(booking => {
          if (moment().diff(booking.event.starts_at, 'minutes') <= 0 && booking.status !== 3) {


                this.customerBooking.upcoming.push(booking);

          } else {


                this.customerBooking.past.push(booking);

          }
        });

        this.customerBooking.past = this.customerBooking.past.sort((a, b) => {
          return (<any>moment(b.event.starts_at) - <any>moment(a.event.starts_at) );
        });

        this.customerBooking.upcoming = this.customerBooking.upcoming.sort( (a, b) => {
            return (<any>moment(a.event.starts_at) - <any>moment(b.event.starts_at))
        });


        },
        err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
        });


    }

              goToEvent(event) {
                this.router.navigate(['/client/calendar'], {
                  queryParams: {
                    event: event
                  }
                });
              }

              getCustomerData(id) {
                this.getCustomerBookings(id);
                const endpoint = 'contact/' + id + this.include_center + '&include=activities,emergencyContact,address,memberships,credits';
                const subscriptionEndpoint = 'contact/' + id + '/subscriptions' + this.include_center;
                const courseEndpoint = 'contact/' + id + '/courses' + this.include_center;

                // let endpoint = 'contact/' + id + '/subscriptions'+this.include_center;
                this.http.getData(endpoint).subscribe(data => {
                    // debugger;
                  this.customer_data = data;
                  if (this.customer_data.data.type == 3 && this.customer_data.data.memberships.data.length === 0) {
                    if (this.customerBooking.past.length > 0 || this.customerBooking.upcoming.length > 0) {
                      this.primary_tab_selected = 'bookings';
                    } else {
                      this.primary_tab_selected = 'payments';
                    }
                  }
                  this.areMembershipsExpired();
                  this.catogorizeMembership(this.customer_data.data['memberships']);

                  this.customer_data.data['service_packs'] = {};
                  this.customer_data.data['service_packs']['data'] = [];

                  for (let i = 0; i < this.customer_data.data.credits.data.length; i++) {
                    if (this.customer_data.data.credits.data[i].is_cancelation_credit == true) {
                      this.cancellationCreditTable = true;
                    }
                  }
                  if (!this.customer_data.data.custom_fields) {
                    this.customer_data.data.custom_fields = {
                      membership_id: null
                    };
                  }

                  let ptIndexes = [];
                  this.customer_data.data.memberships.data.forEach((item, index) => {
                    if (item.service_model.type === MembershipTypes.PACK) {
                      ptIndexes.push(index);
                      this.customer_data.data['service_packs']['data'].push(item);
                    }
                  });

                  if (ptIndexes.length != 0) {
                    for (let i = ptIndexes.length - 1; i >= 0; i--) {
                      this.customer_data.data.memberships.data.splice(ptIndexes[i], 1);
                    }
                    ptIndexes = [];
                    this.customer_data.data.memberships.data.forEach((item, index) => {
                      if (item.service_model.type === MembershipTypes.PACK) {
                        ptIndexes.push(index);
                        this.customer_data.data['service_packs']['data'].push(item);
                      }
                    });
                    if (ptIndexes.length != 0) {
                      for (let i = ptIndexes.length - 1; i >= 0; i--) {
                        this.customer_data.data.memberships.data.splice(ptIndexes[i], 1);
                      }
                    }
                  }
                  const k = [];
                  for (let j = 0; j < this.availableChannels.length; j++) {
                    if (this.customer_data.data.channels.includes(this.availableChannels[j].value)) {
                      k.push(this.availableChannels[j]);
                    }
                  }
                  this.availableChannels = k;
                  this.getSales();
                  this.getPayments();
                  this.getCenterData();
                  this.navigationList.length > 0 ? '' : this.organizeNavigation();
                },
                err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                }, () => {});

                this.http.getData(subscriptionEndpoint).subscribe(({data}) => {
                    this.subscription = data;
                 })
                 this.http.getData(courseEndpoint).subscribe((data) => {
                    this.translateCourseRaw(data.courses)
                 })
              }

              translateCourseRaw(data){
                  this.customerCourse.upcoming = [];
                  this.customerCourse.past = [];


                data.forEach(booking => {
                    console.log('booking', booking)
                    if (moment().diff(booking.ends_at, 'minutes') <= 0) {
                          this.customerCourse.upcoming.push(booking);
                    } else {
                          this.customerCourse.past.push(booking);
                    }
                  });
                  console.log('this.customerCourse', this.customerCourse)
              }


              organizeNavigation() {
                //   if (this.customer_data.data.type !== 3 ) {
                //       this.navigationList.push('summary');
                //       this.view = 'summary'
                //   } else if ( (this.customerBooking.past.length > 0 || this.customerBooking.upcoming.length > 0 )) {
                //       this.view = 'bookings'
                //   } else {
                //       this.view = 'payments'
                //   }
                this.navigationList.push('summary');
                this.view = 'summary'
                //this.customerBooking.past.length > 0 || this.customerBooking.upcoming.length > 0 ? this.navigationList.push('bookings') : ''
                 this.navigationList.push('bookings');

                this.navigationList.push('payments');
                this.navigationList.push('timeline');
                this.navigationList.push('details');
              }

              catogorizeMembership(data) {
                if (data.data.length > 0) {
                  data.data.forEach(element => {
                    if (element.is_recurring == 1) {
                      this.serviceCount.recurring++;
                    } else if (element.is_recurring == 0) {
                      this.serviceCount.membership++;
                    }
                  });
                }
              }
              getLeadStages() {
                this.http.getData('leads/stages_sources' + this.include_center).subscribe(success => {
                  success = success;
                  this.lead_stages = success.data.stages;
                  this.lead_sources = success.data.sources;
                  this.convert_to_lead_data['stage'] = this.lead_stages[0].code;
                  this.convert_to_lead_data['source'] = this.lead_sources[0].code;
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }
              // getTasks() {
                // 	this.http
                // 		.getData(
                // 			"contact/" + this.customer_id + "/tasks" + this.include_center
                // 		)
                // 		.subscribe(
                // 			success => {
                // 				success = success;
                // 				this.customer_tasks_incomplete = [];
                // 				this.customer_tasks_complete = [];
                // 				success.data.forEach((item, index) => {
                // 					if (!item.status) {
                // 						this.customer_tasks_incomplete.push(item);
                // 					} else {
                // 						this.customer_tasks_complete.push(item);
                // 					}
                // 				});
                // 			},
                // 			err => {
                // 				this.generalFunctions.openToast(err.message, 3000, "error");
                // 			}
                // 		);
                // }

              markTaskComplete(taskId) {
                this.http.patchData('contact/' + this.customer_id + '/task/' + taskId + this.include_center, null).subscribe(success => {
                  success = success;
                  this.customer_tasks_incomplete = [];
                  this.customer_tasks_complete = [];
                  success.data.forEach((item, index) => {
                    if (!item.status) {
                      this.customer_tasks_incomplete.push(item);
                    } else {
                      this.customer_tasks_complete.push(item);
                    }
                  });
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              openTaskEditPopup( taskAction, taskId, taskType, taskRemind, taskComment, taskClient ) {
                this.show_pop_up = true;
                this.pop_up_for = 'task';
                this.popup_action = taskAction;
                this.task_data['id'] = taskId;
                this.task_data['type'] = taskType;
                this.task_data['remind_on'] = taskRemind;
                this.task_data['comment'] = taskComment;
                this.task_data['client_id'] = taskClient;
                if (taskClient == null) {
                  this.task_data['client_id'] = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
                }
              }

              addTask() {
                const obj = JSON.parse(JSON.stringify(this.task_data));
                const valid = this.validateTaskObject(obj);
                if (!valid) {
                  return false;
                }
                if (obj['client_id'] == 'none') {
                  delete obj['client_id'];
                }

                const taskReminder = this.generalFunctions.convertDateToISOFormat(obj['remind_on']);
                obj['remind_on'] = taskReminder['date'] + ' ' + taskReminder['time'];

                this.http.sendData('contact/' + this.customer_id + '/task' + this.include_center, obj).subscribe(success => {
                  success = success;
                  this.customer_tasks_incomplete.push(success.data);
                  this.resetPopup();
                  this.generalFunctions.openToast('Task is succesfully added!', 3000, 'success');
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              sendInvoice() {
                if (!this.validationFields.customerEmail) {
                  this.generalFunctions.openToast('Please enter a valid email', 3000, 'error');
                } else {
                  const reqObj = {
                    email: this.invoiceEmail
                  };
                  this.http.sendData(`pos/invoice/${this.selectedOrder.id}/email${this.include_center}`, reqObj).subscribe(success => {
                    this.generalFunctions.openToast('Invoice sent to the email!', 3000, 'success');
                    this.cancelRefund();
                  }, err => {
                    this.cancelRefund();
                  });
                }
              }

              updateTask() {
                const obj = JSON.parse(JSON.stringify(this.task_data));
                const valid = this.validateTaskObject(obj);
                if (!valid) {
                  return false;
                }
                if (obj['client_id'] == 'none') {
                  delete obj['client_id'];
                }

                const taskReminder = this.generalFunctions.convertDateToISOFormat(obj['remind_on']);
                obj['remind_on'] = taskReminder['date'] + ' ' + taskReminder['time'];

                this.http.updateData('contact/' + this.customer_id + '/task/' + obj['id'] + this.include_center, obj).subscribe(success => {
                  success = success;
                  this.customer_tasks_incomplete.forEach((item, index) => {
                    if (item.uuid == success.data.uuid) {
                      this.customer_tasks_incomplete[index] = success.data;
                    }
                  });
                  this.resetPopup();
                  this.generalFunctions.openToast('Task is succesfully updated!', 3000, 'success');
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              deleteTask() {
                const obj = JSON.parse(JSON.stringify(this.task_data));
                const taskId = obj['id'];
                this.http.deleteData('contact/' + this.customer_id + '/task/' + taskId + this.include_center).subscribe(success => {
                  success = success;
                  this.customer_tasks_incomplete.forEach((item, index) => {
                    if (item.uuid == taskId) {
                      this.customer_tasks_incomplete.splice(index, 1);
                    }
                  });
                  this.resetPopup();
                  this.generalFunctions.openToast('Task is succesfully deleted!', 3000, 'success');
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              validateTaskObject(obj) {
                if (!obj['remind_on']) {
                  this.generalFunctions.openToast('Tell us the time to remind you!', 2000, 'error');
                  return false;
                }
                if (!obj['client_id']) {
                  this.generalFunctions.openToast('Select a staff to assign!', 2000, 'error');
                  return false;
                }
                return true;
              }

              resetPopup() {
                this.show_pop_up = false;
                this.popup_action = null;
                this.pop_up_for = null;
                this.add_task_in_stage = false;
                this.add_task_in_comment = false;
                this.task_data['id'] = null;
                this.task_data['type'] = 'phone';
                this.task_data['remind_on'] = null;
                this.task_data['comment'] = null;
                this.task_data['client_id'] = JSON.parse(localStorage.getItem('currentUser'))['client_id'];

                this.stage_change_data['type'] = 'stage';
                this.stage_change_data['comment'] = null;
                this.stage_change_data['old_stage'] = null;
                this.stage_change_data['new_stage'] = null;

                this.assign_data['type'] = 'transfer';
                this.assign_data['old_assigned_to'] = null;
                this.assign_data['new_assigned_to'] = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
                this.assign_data['comment'] = null;

                this.comment_data['type'] = 'comment';
                this.comment_data['comment'] = null;
              }

              editProfileDetails() {
                const clone = JSON.parse(JSON.stringify(this.customer_data['data']));

                this.updated_data['id'] = clone['id'];

                // this.router
                // .navigate(["/edit/"+this.updated_data["id"]],
                // 	{queryParams:
                // 		{},
                // 		relativeTo : this.route
                // 	}
                // )
                this.updated_data['medical_history'] = clone['medical_history'];
                this.updated_data['contact'] = clone['contact']['data'];
                this.updated_data['address'] = clone['address']['data'];
                this.updated_data['added_via'] = 'customer_form';
                if (this.membership_id_enabled) {
                  this.updated_data['custom_fields'] = clone['custom_fields'];
                }
                if (this.emergency_contact_enabled) {
                  if (clone['emergencyContact']['data'].length != 0) {
                    this.updated_data['emergencyContact'] = clone['emergencyContact']['data'];
                  } else {
                    this.updated_data['emergencyContact'] = {
                      first_name: null,
                      last_name: null,
                      phone: null,
                      relationship: null
                    };
                  }
                }

                this.profile_details_edit = true;
              }

              addComment() {
                const objStage = JSON.parse(JSON.stringify(this.comment_data));
                const objTask = JSON.parse(JSON.stringify(this.task_data));

                if (this.add_task_in_comment) {
                  const valid = this.validateTaskObject(objTask);
                  if (!valid) {
                    return false;
                  }
                  if (objTask['client_id'] == 'none') {
                    delete objTask['client_id'];
                  }

                  const taskReminder = this.generalFunctions.convertDateToISOFormat(objTask['remind_on']);
                  objTask['remind_on'] = taskReminder['date'] + ' ' + taskReminder['time'];
                  objStage['task'] = objTask;
                }

                this.http.sendData('contact/' + this.customer_id + '/activity' + this.include_center, objStage).subscribe(success => {
                  success = success;
                  this.customer_data.data.activities.data.unshift(success.data);
                  this.generalFunctions.openToast('Comment is successfully added in customer activity!', 2000, 'success');
                  this.getCustomerData(this.customer_id);
                  this.resetPopup();
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              areMembershipsExpired() {
                if (this.customer_data.data.memberships.data.filter(function (obj) {
                  return (obj.status == '1' || obj.status == '2' || obj.status == '3' || obj.status == '4');
                }).length == 0) {
                  return true;
                }

                return false;
              }

              checkExpiredPacks() {
                if (this.customer_data.data.service_packs.data.filter(function (obj) {
                  return (obj.status == '1' || obj.status == '2' || obj.status == '3' || obj.status == '4');
                }).length == 0) {
                  return true;
                } else {
                  return false;
                }
              }

              getTransactionCount(data) {
                const transactions = data;
                let total = 0;
                let billingIssue = 0;
                transactions.forEach((item, index) => {
                  total += 1;
                  parseInt(item.sale.data.amount_due)
                    ? (billingIssue += 1)
                    : '';
                });
                this.transaction_count['total'] = total;
                this.transaction_count['billing_issue'] = billingIssue;
              }

              getCustomerTransactionData(id) {
                const endpoint = 'contact/' + id + '/transactions' + this.include_center;

                this.http.getData(endpoint).subscribe(data => {
                  this.customer_data['data']['transactions'] = data.data;
                  this.getTransactionCount(data.data);
                }, err => {
                  // this.generalFunctions.openToast(err.message, 3000, "error");
                  // this.router
                  // 	.navigate(['../../customers'],
                  // 		{queryParams:
                  // 			{},
                  // 			relativeTo : this.route
                  // 		}
                  // 	);
                }, () => {});
              }

              onProfileImageLoad(e) {
                const el = e.target;
                el.classList.add('active');
              }

              updateProfile(e, id) {
                let msg: string = null;

                const obj = JSON.parse(JSON.stringify(this.updated_data));

                if (!this.emergency_contact_enabled) {
                  delete obj['emergencyContact'];
                }
                if (this.emergency_contact_enabled && !this.emergency_contact_mandatory) {
                  const touched = obj['emergencyContact']['last_name'] || obj['emergencyContact']['first_name'] || obj['emergencyContact']['phone'] || obj['emergencyContact']['relationship'];
                  const untouched = !obj['emergencyContact']['last_name'] && !obj['emergencyContact']['first_name'] && !obj['emergencyContact']['phone'] && !obj['emergencyContact']['relationship'];

                  const alltouched = obj['emergencyContact']['last_name'] && obj['emergencyContact']['first_name'] && obj['emergencyContact']['phone'] && obj['emergencyContact']['relationship'];

                  if (touched && !alltouched) {
                    msg = 'Enter all values for emergency contact';
                  }
                  if (untouched) {
                    obj['emergencyContact'] = null;
                  }
                }

                if (!this.membership_id_enabled) {
                  delete obj['custom_fields'];
                }

                if (msg) {
                  this.generalFunctions.openToast(msg, 3000, 'error');
                  return false;
                }

                if (obj['contact']['date_of_birth']) {
                  const dob = this.generalFunctions.convertDateToISOFormat(obj['contact']['date_of_birth']);
                  obj['contact']['date_of_birth'] = dob['date'];
                }

                this.ajax_loader.nativeElement.classList.add('active');
                e.target.classList.add('loading-ajax');

                const endpoint = 'contact/' + id + this.include_center + '&include=emergencyContact,address,memberships';

                this.http.updateData(endpoint, obj).subscribe(data => {
                  this.customer_data = data;
                  this.customer_data.data['service_packs'] = {};
                  this.customer_data.data['service_packs']['data'] = [];
                  if (!this.customer_data.data.custom_fields) {
                    this.customer_data.data.custom_fields = {
                      membership_id: null
                    };
                  }
                  const ptIndexes = [];
                  this.customer_data.data.memberships.data.forEach((item, index) => {
                    if (item.staff_id) {
                      ptIndexes.push(index);
                      this.customer_data.data['service_packs']['data'].push(item);
                    }
                  });
                  if (ptIndexes.length != 0) {
                    for (let i = ptIndexes.length - 1; i >= 0; i--) {
                      this.customer_data.data.memberships.data.splice(ptIndexes[i], 1);
                    }
                  }
                  this.generalFunctions.openToast('Data updated successfully!', 3000, 'success');
                  this.profile_details_edit = false;
                  e.target.classList.remove('loading-ajax');
                  this.ajax_loader.nativeElement.classList.remove('active');

                  this.getCustomerTransactionData(id);
                }, error => {
                  this.ajax_loader.nativeElement.classList.remove('active');
                  e.target.classList.remove('loading-ajax');
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              clearDues(id) {
                this.router.navigate([
                  '../../pos', id
                ], {
                  queryParams: {},
                  relativeTo: this.route
                });
              }

              pausePopup(id, start, expiry, row) {
                this.pause['name'] = row.name;
                this.pause['id'] = row.latest_membership.id;
                this.pause['ends'] = moment().add(4, 'days').toDate();
                this.pause['starts'] = moment().add(1, 'days').toDate();
                this.pause['pauseStartMode'] = 'today';
                this.pause['startMin'] = moment().toDate();
                this.pause['endMin'] = moment(start).add(4, 'days').format('YYYY-MM-DD');
                this.pause['status'] = row.status;
                this.pause['gap'] = '4 days';
                this.pause['currentBilling'] = moment(row.latest_membership.recurring_charge.next_billing_at).toDate();
                this.pause['nextBilling'] =  row.latest_membership.recurring_charge.next_billing_at  ?
                moment(row.latest_membership.recurring_charge.next_billing_at).format('DD MMM, YYYY') : null;
                this.show_pop_up = true;
                if (row.latest_membership.status !== 8 && row.status !== 6) {
                    this.pop_up_for = 'freeze';
                    this.changePauseText();
                } else if (row.latest_membership.status === 8 && row.status !== 6) {
                    this.pop_up_for = 'freeze-scheduled';
                    this.pause['freezeLog'] = row.latest_membership.freeze_log;
                    let days = moment(this.pause.freezeLog.ends_at).diff(moment(this.pause.freezeLog.starts_at), 'days');
                    this.pause.nextBilling =  moment(this.pause.currentBilling).format('DD MMM, YYYY');
                    let gDate = 0;
                    (days < 0) ? gDate = 0 : gDate = days;
                    this.pause.gap = gDate + ' days';
                } else if (row.status  === 6) {
                    this.pop_up_for = 'freezed';
                    this.pause['freezeLog'] = row.latest_membership.freeze_log;
                    this.pause.freezeLog.ends_at = moment(this.pause.freezeLog.ends_at);
                    let d = moment(this.pause.freezeLog.ends_at).diff(moment(this.pause.freezeLog.starts_at), 'hours');
                    d %24 > 0 ?  d = ~~(d / 24) + 1 : d = d/24;
                    let days =  d;

                    this.pause.nextBilling = moment(this.pause.currentBilling).format('DD MMM, YYYY');
                    let gDate = 0;
                    (days < 0) ? gDate = 0 : gDate = days;
                    this.pause.gap = gDate + ' days';
                }

              }

              changePauseText() {
                  console.log('pause', this.pause);
                  if (this.pause.pauseStartMode === 'today') {
                    console.log('check', moment(this.pause.ends).diff(moment(), 'days'));
                    let d = moment(this.pause.ends).diff(moment(), 'hours');
                    d%24 > 0 ?  d = ~~(d /24) + 1 : d = d/24;
                    let days = d;
                    this.pause.nextBilling = moment(this.pause.currentBilling).add(days, 'days').format('DD MMM, YYYY');
                    let gDate = 0;
                    (days < 0) ? gDate = 0 : gDate = days;
                    this.pause.gap = gDate + ' days';
                  } else {
                    console.log('check', moment(this.pause.ends).diff(this.pause.starts, 'days'));
                    // const days = moment(this.pause.ends).diff(this.pause.starts, 'days');
                    let d = moment(this.pause.ends).diff(moment(this.pause.starts), 'hours');
                    d%24 > 0 ?  d = ~~(d /24) + 1 : d = d/24;
                    let days = d;

                    this.pause.nextBilling = moment(this.pause.currentBilling).add(days, 'days').format('DD MMM, YYYY');
                    let gDate = 0;
                    (days < 0) ? gDate = 0 : gDate = days;
                    this.pause.gap = gDate + ' days';
                  }
              }

              pauseApp() {
                this.pop_up_for = null;
                this.show_pop_up = false;
                console.log('this.pause', this.pause)

                const endpoint = 'memberships/' + this.pause['id'] + '/freeze' + this.include_center;
                // const obj = JSON.parse(JSON.stringify(this.freeze_data));
                const obj = {
                    starts_at: this.pause.pauseStartMode === 'today' ? moment().format('YYYY-MM-DD') : moment(this.pause.starts).format('YYYY-MM-DD'),
                    ends_at: moment(this.pause.ends).format('YYYY-MM-DD')
                }
                console.log('obj :>> ', obj);
                this.http.sendData(endpoint, obj).subscribe(success => {
                  this.generalFunctions.openToast(success.message, 3000, 'success');
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });

              }

              removePause() {
                this.pop_up_for = null;
                this.show_pop_up = false;
                const endpoint = 'memberships/' + this.pause['id'] + '/unfreeze' + this.include_center;
                const obj = {};
                this.http.sendData(endpoint, obj).subscribe(success => {
                  this.generalFunctions.openToast(success.message, 3000, 'success');
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              extendPopup(id, start, expiry, credit, customerId, planType, planName) {
                this.extend_data['plan_type'] = planType;
                this.extend_data['plan_name'] = planName;
                this.extend_data['id'] = id;
                this.extend_data['m_expiry'] = expiry;
                this.extend_data['m_start'] = start;
                this.extend_data['expires_at'] = new Date(expiry);
                const futureStartAtDate = new Date(moment(start).add('weeks', 5).format('DD MMM YYYY'));
                // let futureStartAtDate = new Date(moment(start).locale("en").add(1, 'm').format("MMM DD, YYYY HH:MM"))
                this.extend_data['starts_at'] = new Date(start);
                if (credit[0] == undefined) {
                  this.credit_data['setFlag'] = false;
                  this.credit_data['creditId'] = null;
                  this.edit_credit['amount'] = null;
                } else {
                  this.credit_data['creditId'] = credit[0].id;
                  this.edit_credit['amount'] = credit[0].balance;
                  this.credit_data['setFlag'] = true;
                  this.credit_data['setCurrent'] = credit[0].balance;
                }

                this.credit_data['customerId'] = customerId;
                this.pop_up_for = 'extend';
                this.show_pop_up = true;
              }

                extendPopupRecurring(id, start, expiry, credit, customerId, planType, planName, payFirst) {
                this.extend_data['plan_type'] = planType;
                this.extend_data['plan_name'] = planName;
                this.extend_data['id'] = id;
                this.extend_data['m_expiry'] = new Date(expiry);
                this.extend_data['m_start'] = start;
                this.extend_data['expires_at'] = new Date(expiry);
                this.extend_data['pay_on_first'] = payFirst;
                const futureStartAtDate = new Date(moment(start).add('weeks', 5).format('DD MMM YYYY'));
                this.extend_data['starts_at'] = new Date(start);
                if (credit.balance === undefined) {
                  this.credit_data['setFlag'] = false;
                  this.credit_data['creditId'] = null;
                  this.edit_credit['amount'] = null;
                  console.log('this.credit_data', this.credit_data)
                } else {
                  this.credit_data['creditId'] = credit.id;
                  this.edit_credit['amount'] = credit.balance;
                  this.credit_data['setFlag'] = true;
                  this.credit_data['setCurrent'] = credit.balance;
                }

                this.credit_data['customerId'] = customerId;
                this.pop_up_for = 'extend';
                this.show_pop_up = true;
              }

              unfreezePopup(id, name) {
                this.pop_up_for = 'unfreeze';
                this.show_pop_up = true;
                this.unfreeze_data['id'] = id;
                this.unfreeze_data['name'] = name;
              }

              freezeMembership(e) {
                let err = null;

                if (this.freeze_data['starts_at']) {
                  const start = this.generalFunctions.convertDateToISOFormat(this.freeze_data['starts_at']);
                  const newmin = parseInt(start['time'].split(':')[1], 10);
                  const pad = function (n) {
                    return n < 10
                      ? '0' + n
                      : n;
                  };
                  start['time'] = [
                    start['time'].split(':')[0],
                    pad(newmin + 1).toString(),
                    start['time'].split(':')[2]
                  ].join(':');
                  this.freeze_data['starts_at'] = start['date'] + ' ' + start['time'];
                } else {
                  err = 'Enter freeze start date';
                }

                if (this.freeze_data['ends_at']) {
                  const end = this.generalFunctions.convertDateToISOFormat(this.freeze_data['ends_at']);
                  const newmin = parseInt(end['time'].split(':')[1], 10);
                  const pad = function (n) {
                    return n < 10
                      ? '0' + n
                      : n;
                  };
                  end['time'] = [
                    end['time'].split(':')[0],
                    pad(newmin + 1).toString(),
                    end['time'].split(':')[2]
                  ].join(':');
                  this.freeze_data['ends_at'] = end['date'] + ' ' + end['time'];
                } else {
                  err = 'Enter freeze end date';
                }

                if (err) {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                  return false;
                }
                const endpoint = 'membership/' + this.freeze_data['id'] + '/freeze' + this.include_center;
                const obj = JSON.parse(JSON.stringify(this.freeze_data));

                this.http.sendData(endpoint, obj).subscribe(success => {
                  success = success;
                  const msg = 'Membership is successfully freezed';
                  this.generalFunctions.openToast(msg, 3000, 'success');
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              unfreezeMembership(e) {
                const endpoint = 'membership/' + this.unfreeze_data['id'] + '/unfreeze' + this.include_center;
                const obj = this.unfreeze_data['obj'];

                this.http.sendData(endpoint, obj).subscribe(success => {
                  const msg = 'Membership is successfully unfreezed';
                  this.generalFunctions.openToast(msg, 3000, 'success');
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              extendMembership(e) {
                let err = null;

                if (this.extend_data['expires_at']) {
                  const expiry = this.generalFunctions.convertDateToISOFormat(this.extend_data['expires_at']);
                  this.extend_data['expires_at'] = expiry['date'];
                } else {
                  err = 'Enter new expiry date';
                }

                if (this.extend_data['starts_at']) {
                  const start = this.generalFunctions.convertDateToISOFormat(this.extend_data['starts_at']);
                  this.extend_data['starts_at'] = start['date'];
                } else {
                  err = 'Enter new start date';
                }

                if (err) {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                  return false;
                }

                if (!(this.extend_data.plan_type == 'servicePack' && this.extend_data.m_expiry == '')) {
                    const endpoint = 'memberships/' + this.extend_data['id'] + '/extend' + this.include_center;
                    const obj = JSON.parse(JSON.stringify(this.extend_data));

                    this.http.sendData(endpoint, obj).subscribe(success => {
                      const msg = 'Membership is successfully extended';
                      this.generalFunctions.openToast(msg, 3000, 'success');


                    }, error => {
                      this.generalFunctions.openToast(error.message, 3000, 'error');
                    });
                }

                const endpointOne = 'credits/' + this.credit_data['customerId'] + '/update/' + this.credit_data['creditId'] + this.include_center;

                const objOne = JSON.parse(JSON.stringify(this.edit_credit));
                this.http.patchData(endpointOne, objOne).subscribe(success => {
                    const msg = 'Membership is successfully extended';
                    this.generalFunctions.openToast(msg, 3000, 'success');
                }, error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');
                });

                this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
              }


              extendRecurring(e) {
                let err = null;

                // if (this.extend_data['expires_at']) {
                //   const expiry = this.generalFunctions.convertDateToISOFormat(this.extend_data['expires_at']);
                //   this.extend_data['expires_at'] = expiry['date'];
                // } else {
                //   err = 'Enter new expiry date';
                // }


                // if (err) {
                //   this.generalFunctions.openToast(err.message, 3000, 'error');
                //   return false;
                // }

                // const reqObj = {
                //     expires_at : this.extend_data.expires_at,
                // }

                // const endpoint = 'memberships/' + this.extend_data['id'] + '/extend' + this.include_center;
                // this.http.sendData(endpoint, reqObj).subscribe(success => {
                //   const msg = 'Membership is successfully extended';
                //   this.router.navigate(['../../refresh'], {
                //     queryParams: {
                //       url: 'customers/' + this.customer_id
                //     },
                //     relativeTo: this.route
                //   });
                // }, error => {
                //   this.generalFunctions.openToast(error.message, 3000, 'error');
                // });


                const endpointOne = 'credits/' + this.credit_data['customerId'] + '/update/' + this.credit_data['creditId'] + this.include_center;
                const objOne = JSON.parse(JSON.stringify(this.edit_credit));
                this.http.patchData(endpointOne, objOne).subscribe(success => {
                const msg = 'Subscription credit is successfully extended';
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                  this.generalFunctions.openToast(msg, 3000, 'success');

                }, error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');

                });
              }

              sendSMS(e) {
                if (!this.sms_data) {
                  this.generalFunctions.openToast('Enter message', 3000, 'error');
                  return false;
                }
                this.http.sendData('contact/' + this.customer_id + '/message' + this.include_center, this.sms_data).subscribe(success => {
                  this.generalFunctions.openToast('Message successfully sent', 3000, 'success');
                  this.sms_data['message'] = null;
                  this.show_pop_up = false;
                  this.pop_up_for = null;
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              showPdf(id) {
                const endpoint = 'pos/invoice/' + id + this.include_center;
                this.http.getData(endpoint).subscribe(success => {
                  success = success;
                  window.open('data:application/pdf;base64,' + success.data);
                }, error => {
                  if (error.status_code == 404) {
                    this.generalFunctions.openToast('Invoice not available!', 3000, 'error');
                  }
                });
              }

              completeWriteoff(e) {
                const endpoint = 'pos/' + this.write_off_id + '/writeoff' + this.include_center;
                const obj = {};
                obj['amount'] = this.net_writeoff;
                this.http.sendData(endpoint, obj).subscribe(success => {
                  success = success.data;
                  this.net_writeoff = 0;
                  this.total_writeoff = 0;
                  this.writeoff_modal_mode = false;
                  this.writeoff_calculation = false;
                  this.writeoff_confirmation = false;
                  this.write_off_id = null;
                  this.getCustomerData(this.customer_data.data.id);
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              openPhotoPopup() {
                this.webcam_initiate = true;
                const width = 400;
                let height = 400;
                setTimeout(() => {
                  navigator.mediaDevices.getUserMedia({video: true, audio: false}).then(stream => {
                    this.video.nativeElement.srcObject = stream;
                    this.videoStream = stream;
                    this.video.nativeElement.play();
                  }).catch(err => {
                    this.isCameraAdapted = false;
                  });

                  this.video.nativeElement.addEventListener('canplay', e => {
                    // height = this.video.nativeElement.videoHeight / (this.video.nativeElement.videoWidth/width);
                    height = width;
                    if (isNaN(height)) {
                      height = width;
                    }

                    this.video.nativeElement.setAttribute('width', width);
                    this.video.nativeElement.setAttribute('height', height);
                  }, false);
                }, 200);
              }

              takePicture() {
                const context = this.canvas.nativeElement.getContext('2d');
                this.canvas.nativeElement.width = 400;
                this.canvas.nativeElement.height = 400;
                context.drawImage(this.video.nativeElement, -66.66, 0, 533.33, 400);

                const data = this.canvas.nativeElement.toDataURL('image/png');
                this.photo_tag.nativeElement.setAttribute('src', data);
                this.photo_captured = true;
              }


              changePicture() {
                const context = this.canvas.nativeElement.getContext('2d');
                context.fillStyle = '#AAA';
                context.fillRect(0, 0, 0, 0);

                const data = this.canvas.nativeElement.toDataURL('image/png');
                this.photo_tag.nativeElement.removeAttribute('src');
                this.photo_captured = false;
              }

              stopWebcam() {
                if (this.videoStream) {
                  this.videoStream.getTracks()[0].stop();
                }
                this.webcam_initiate = false;
              }

              onFileChanged(event) {
                const file = event.target.files[0],
                  reader = new FileReader(),
                  obj = {
                    photo: ''
                  };

                if (![
                  'jpeg',
                  'jpg',
                  'png',
                  'JPEG',
                  'PNG',
                  'JPG'
                ].includes(file.name.substring(file.name.indexOf('.') + 1))) {
                  this.generalFunctions.openToast('Invalid file format', 3000, 'error');
                } else {
                  reader.readAsDataURL(file);
                  reader.onload = function () {
                    updatePhoto(reader.result.toString());
                  };

                  const updatePhoto = string => {
                    this.http.patchData('contact/' + this.customer_id + '/photo' + this.include_center, {photo: string}).subscribe(success => {
                      this.customer_data.data.contact.data.image_url = success.image_url;
                      this.generalFunctions.openToast('Profile picture successfully updated', 3000, 'success');
                      event.target.classList.remove('loading-ajax');
                      this.show_update_profile_picture_popup = false;
                    }, error => {
                      this.generalFunctions.openToast(error.message, 3000, 'error');
                    });
                  };
                }
              }

              enlargePhoto() {
                this.enlarged_photo_popup = true;
              }

              sendConfirmationOtp() {
                let err = null;
                if (!this.newPhone) {
                  err = 'Enter phone number!';
                } else {
                  if (this.newPhone.toString().length < 10) {
                    err = 'Enter valid phone number!';
                  }
                }
                if (err) {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                  return false;
                }

                const phone = this.newPhone;
                this.http.getData('otp/request/?phone=' + phone).subscribe(success => {
                  this.phoneChangeStep = 2;
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              changePhoneNo() {
                let err = null;
                if (!this.newPhone) {
                  err = 'Enter OTP!';
                } else {
                  if (this.newPhone.toString().length < 4) {
                    err = 'Enter valid OTP!';
                  }
                }
                if (err) {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                  return false;
                }
                const obj = {};
                const endpoint = 'contact/' + this.customer_id + '/phone' + this.include_center;

                obj['phone'] = this.newPhone;
                obj['otp'] = this.newPhoneOtp;
                this.http.patchData(endpoint, obj).subscribe(success => {
                  this.phoneChange = false;
                  this.phoneChangeStep = 1;
                  this.newPhone = null;
                  this.newPhoneOtp = null;
                  this.generalFunctions.openToast('Phone number is successfully updated!', 3000, 'success');
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'customers/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              directToUpgrade(membershipId) {
                this.router.navigate([
                  '../../pos', this.customer_id
                ], {
                  queryParams: {
                    upgradeMembershipId: membershipId
                  },
                  relativeTo: this.route
                });
              }

              convert_to_lead() {
                const endpoint = 'contact/' + this.customer_id + '/convertToLead' + this.include_center;
                this.http.patchData(endpoint, this.convert_to_lead_data).subscribe(success => {
                  this.generalFunctions.openToast('Convert to  Lead Successfully!', 3000, 'success');
                  this.resetPopup();
                  this.router.navigate(['../../refresh'], {
                    queryParams: {
                      url: 'prospects/' + this.customer_id
                    },
                    relativeTo: this.route
                  });
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              getSales() {
                this.http.getData(`contact/${this.customer_id}/sales` + this.include_center).subscribe(response => {
                  this.allOrders = response.data;
                }, error => {
                });
              }

              getPayments() {
                this.http.getData(`contact/${this.customer_id}/payments` + this.include_center).subscribe(response => {
                  this.allPayments = response.data;
                }, error => {
                  console.log(error);
                });
              }

              getPaymentStatusOfOrder(index) {
                const order = this.allOrders[index];
                let status;

                if (order.amount_due > 0) {
                  status = {
                    label: 'PARTIALLY PAID',
                    value: 'partially-paid'
                  };
                } else {
                  status = {
                    label: 'PAID',
                    value: 'paid'
                  };
                }

                this.allOrders[index].pay_status = status;

                return status;
              }

              getStatusOfPayment(index) {
                const statusValue = this.allPayments[index].status;
                let status = '';

                switch (statusValue) {
                  case 1:
                    status = 'paid';
                    break;

                  case 2:
                    status = 'processing';
                    break;

                  case 3:
                    status = 'failed';
                    break;

                  default:
                    status = 'unknown';
                    break;
                }

                this.allPayments[index].statusValue = status;

                return status;
              }

              getReadableDateTime(dateTimeString) {
                const date = new Date(dateTimeString);
                const months = [
                  'Jan',
                  'Feb',
                  'Mar',
                  'Apr',
                  'May',
                  'Jun',
                  'Jul',
                  'Aug',
                  'Sep',
                  'Oct',
                  'Nov',
                  'Dec'
                ];
                const meridian = 'am';
                let readableDateTime = '';

                const timeString = dateTimeString.substr(11, 5);
                const dateString = `${dateTimeString.substr(8, 2)} ${
                months[date.getMonth()]} ${date.getFullYear()}`;

                readableDateTime = timeString + ', ' + dateString;

                return readableDateTime;
              }

              openOrderOverlay(index) {



                this.selectedOrder = this.allOrders[index];
                console.log(this.selectedOrder);
                this.selectedOrder.taxAmount = this.generalFunctions.calculateTax(this.taxes, this.selectedOrder.amount_paid);
                this.checkAllRefunded(this.selectedOrder);
                this.selectedOrderIndex = index;
                this.isOrderOverlay = true;
                this.refundCart = {
                  items: [],
                  id: '',
                  refundCartTotal: 0,
                  intendedRefund: 0
                };
                this.subscriptionWriteoff = false;
                this.selectedOrder.items.data.forEach((e) => {
                    console.log('=>', e.service_data);
                })
                this.getSubscriptionStatus(this.selectedOrder.items, this.selectedOrder.id);
              }

              getSubscriptionStatus(items, id) {
                console.log('items', items, id)
                let itemId = items.data.filter(item => item.service_data.is_recurring === 1);
                if (itemId.length > 0) {
                    this.http.getData(`pos/${id}/items/${itemId[0].id}/subscription` + this.include_center).subscribe(
                        response => {
                            if (response.subscription.status === 4) {
                                this.subscriptionWriteoff = true;
                            }
                        },
                        err => {
                            console.log('err.message', err.message)
                        })
                }
              }

              openPaymentOverlay(id) {
                let index;
                this.allOrders.forEach((element, i) => {
                  if (element.id == id) {
                    index = i;
                    return;
                  }
                });
                this.selectedOrder = this.allOrders[index];
                console.log('selectedOrder', this.selectedOrder);
                this.selectedOrder.taxAmount = this.generalFunctions.calculateTax(this.taxes, this.selectedOrder.amount_paid);
                this.checkAllRefunded(this.selectedOrder);
                this.getSubscriptionStatus(this.selectedOrder.items, this.selectedOrder.id);
                this.selectedOrderIndex = index;
                this.isOrderOverlay = true;
                this.subscriptionWriteoff = false;

                this.refundCart = {
                  items: [],
                  id: '',
                  refundCartTotal: 0,
                  intendedRefund: 0
                };

              }

              checkAllRefunded(order) {
                let countRefund = 0;
                let countCancelled = 0;
                order.items.data.forEach(element => {
                  if (element.status == 2) {
                    countRefund = countRefund + 1;
                  }
                  if (element.status == 3) {
                    countCancelled = countCancelled + 1;
                  }
                });
                if (countRefund == order.items.data.length) {
                  this.refundAllowed = true;
                } else {
                  this.refundAllowed = false;
                }
                if (countCancelled == order.items.data.length) {
                  this.refundCancelAllowed = true;
                } else {
                  this.refundCancelAllowed = false;
                }
              }
              closeOrderOverlay() {
                if (this.orderDetailsView === 'sale-details') {
                  this.isOrderOverlay = false;
                  this.refundOverlay = false;
                  this.refundPhase = null;
                  this.refundThis = [];
                  this.preparedArray = [];
                  this.refundCart = {
                    items: [],
                    id: '',
                    refundCartTotal: 0,
                    intendedRefund: 0
                  };
                }
                this.refundOverlay = false;
                this.refundPhase = null;
                this.refundThis = [];
                this.preparedArray = [];
                this.refundCart = {
                  items: [],
                  id: '',
                  refundCartTotal: 0,
                  intendedRefund: 0
                };
              }

              savePaymentNote() {
                const reqObj = {
                  note: this.selectedOrder.notes
                };
                this.http.patchData(`pos/${this.selectedOrder.id}/note` + this.include_center, reqObj).subscribe(response => {
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              startWriteOff() {
                this.orderDetailsView = 'write-off';
                this.writeOffStage = 1;
                this.writeOffAmount = this.selectedOrder.amount_due;
              }

              proceedWriteOff() {
                this.writeOffProceed = true;
                if (!this.validationFields.writeOffAmount) {
                  // this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                  return;
                }
                this.writeOffStage = 2;
              }

              confirmWriteOff() {
                this.orderDetailsView = 'sale-details';
                const reqObj = {
                  amount: this.writeOffAmount
                };
                this.http.sendData('pos/' + this.selectedOrder.id + '/writeoff' + this.include_center, reqObj).subscribe(response => {
                  this.selectedOrder = response.data;
                  this.resetWriteOff();
                  this.getCustomerData(this.customer_id);
                  this.generalFunctions.openToast('Write off successfull!', 3000, 'success');
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              cancelWriteOff() {
                this.orderDetailsView = 'sale-details';
                this.resetWriteOff();
              }

              resetWriteOff() {
                this.writeOffAmount = '';
                this.writeOffProceed = false;
              }

              formValidate(field) {
                let isValid = true;

                switch (field) {
                  case 'customer-email':
                    isValid = !this.invoiceEmail.replace(/\s/g, '').length || !this.validateEmail(this.invoiceEmail)
                      ? false
                      : true;
                    this.validationFields.customerEmail = isValid;
                    break;

                  case 'write-off-amount':
                    isValid = this.writeOffAmount > 0
                      ? true
                      : false;
                    this.validationFields.writeOffAmount = isValid;
                    break;

                  case 'clear-due-amount':
                    isValid = this.clearDueAmount > 0 && this.clearDueAmount <= this.selectedOrder.amount_due
                      ? true
                      : false;
                    this.validationFields.clearDueAmount = isValid;
                    break;

                  default:
                    break;
                }

                return !isValid;
              }

              validateEmail(email) {
                const re = /\S+@\S+\.\S+/;
                return re.test(email);
              }

              refreshSalesAndPayments() {
                this.getCustomerData(this.customer_id);
                this.getSales();
                this.getPayments();
              }

              startCollectDue() {
                this.orderDetailsView = 'collect-due';
                this.preparePaymentModes();
                this.clearDueAmount = this.selectedOrder.amount_due;

                // prepare start date for clear due
                const d = new Date();
                const months = [
                  'Jan',
                  'Feb',
                  'Mar',
                  'Apr',
                  'May',
                  'Jun',
                  'Jul',
                  'Aug',
                  'Sep',
                  'Oct',
                  'Nov',
                  'Dec'
                ];
                this.clearDueDate = `${d.getDate()} ${
                months[d.getMonth()]} ${d.getFullYear()}`;
              }

              preparePaymentModes() {
                if (this.stripeConnected) {
                  this.http.getData('contact/' + this.customer_id + '/payment/sources' + this.include_center).subscribe(success => {
                    this.savedCards = success.data;
                    this.savedCards.length = success.data.length;
                    if (this.orderDetailsView === 'collect-due'){
                        this.sculptSimpleDropdown()
                    } else {
                        this.sculptDropdownWithout();
                    }
                  }, error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');
                  });
                } else {
                  this.savedCards = [];
                  this.savedCards.length = 0;
                  if (this.orderDetailsView === 'collect-due'){
                    this.sculptSimpleDropdown()
                    } else {
                        this.sculptDropdownWithout();
                    }
                //   this.sculptSimpleDropdown()

                }
                this.addingCard = false;
                this.show_pop_up = false;
                this.popup_action = null;
                this.pop_up_for = null;

              }



              sculptSimpleDropdown() {
                  this.enabledCollectModes = [];

                  const genObj = {
                    label: '',
                    value: '',
                    items: []
                  };

                  const genObjo = {
                    label: '',
                    value: '',
                    items: []
                  };
                  if (this.stripeConnected) {
                        if (this.savedCards.length > 0) {
                            this.enabledCollectModes[0] = genObjo;
                            this.enabledCollectModes[1] = genObj;
                        }
                        else {
                            this.enabledCollectModes[0] = genObj;
                        }

                    }
                    else {
                        this.enabledCollectModes[0] = genObj;
                    }
                  if (this.savedCards.length > 0 && this.stripeConnected) {
                    this.savedCards.forEach((element, index) => {
                      const i = 1;
                      const card = element;
                      card.mode = 'scard';
                      card.code = element.brand.split(' ')[0];
                      card.label = 'Saved card ending ' + element.last4;
                      card.value = element.id;
                      this.enabledCollectModes[i].items.push(card);
                    });
                    if (!this.currentCard) {
                      this.clearDuePaymentMethod = this.savedCards[0].id;
                    }
                  }
                    if (this.stripeConnected && this.savedCards.length > 0) {
                            if (!this.currentCard) {
                            this.clearDuePaymentMethod = this.savedCards[0].id;
                            this.dropdownLoaded = true;
                            } else {
                            this.clearDuePaymentMethod = this.currentCard;
                            this.dropdownLoaded = true;
                            }
                        } else {
                            this.clearDuePaymentMethod = 'cash';
                            this.dropdownLoaded = true;
                        }
                        console.log('this.enabledCollectModes', this.enabledCollectModes)


                        let paymentMode;
                        // tslint:disable-next-line: forin
                        console.log('this.availablePaymentModes', this.availablePaymentModes)
                        for (var mode in this.availablePaymentModes) {
                          if (this.availablePaymentModes[mode].status) {
                            paymentMode = this.availablePaymentModes[mode];

                            if (paymentMode.code === 'credit' || paymentMode.code === 'pay_later') {
                              continue;
                            }

                            paymentMode.label = paymentMode.name;
                            paymentMode.value = paymentMode.code;

                            this.enabledCollectModes[0].items.push(paymentMode);
                          }
                        }

                        console.log('this.enabledCollectModes', this.enabledCollectModes)

              }

              sculptDropdownWithout() {
                this.enabledPaymentModes = [];

                const genObj = {
                  label: '',
                  value: '',
                  items: []
                };

                const genObjo = {
                  label: '',
                  value: '',
                  items: []
                };
                if (this.stripeConnected) {
                      if (this.savedCards.length > 0) {
                          this.enabledPaymentModes[0] = genObjo;
                          this.enabledPaymentModes[1] = genObj;
                      }
                  }

                if (this.savedCards.length > 0 && this.stripeConnected) {
                  this.savedCards.forEach((element, index) => {
                    const i = 1;
                    const card = element;
                    card.mode = 'scard';
                    card.code = element.brand.split(' ')[0];
                    card.label = 'Saved card ending ' + element.last4;
                    card.value = element.id;
                    this.enabledPaymentModes[i].items.push(card);
                  });
                  if (!this.currentCard) {
                    this.clearDuePaymentMethod = this.savedCards[0].id;
                  }
                }
                  if (this.stripeConnected && this.savedCards.length > 0) {
                          if (!this.currentCard) {
                          this.clearDuePaymentMethod = this.savedCards[0].id;
                          this.dropdownLoaded = true;
                          } else {
                          this.clearDuePaymentMethod = this.currentCard;
                          this.dropdownLoaded = true;
                          }
                      } else {
                          this.clearDuePaymentMethod = 'cash';
                          this.dropdownLoaded = true;
                      }

            }



              completeCollectDue() {
                this.clearDueProceed = true;
                this.completingDue = true;
                const reqObj = {
                  amount: this.clearDueAmount,
                  payment_method_code: this.clearDuePaymentMethod,
                  card_id: ''
                };
                reqObj.payment_method_code.includes('card_')
                  ? ((reqObj.card_id = this.clearDuePaymentMethod), (reqObj.payment_method_code = 'stripe'))
                  : delete reqObj.card_id;

                this.http.sendData('pos/' + this.selectedOrder.id + '/due' + this.include_center, reqObj).subscribe(response => {
                  this.selectedOrder = response.data;
                  this.resetCollectDue();
                  this.refreshSalesAndPayments();
                  this.orderDetailsView = 'sale-details';
                  this.completingDue = false;

                  this.generalFunctions.openToast('Clear due successfull!', 3000, 'success');
                }, err => {
                    this.completingDue = false;

                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              retryPayment() {
                  this.clearDueProceed = true;
                    this.retryingPayment = true;
                  const reqObj = {
                    source: this.clearDuePaymentMethod
                  };


                  this.http.sendData(`pos/${this.selectedOrder.id}/payment/retry${this.include_center}`, reqObj).subscribe(response => {
                    // this.selectedOrder = response.data;
                    setTimeout(() => {
                        this.refreshSalesAndPayments();
                    }, 8000);
                    this.orderDetailsView = 'sale-details';
                    this.generalFunctions.openToast(response.message, 3000, 'success');
                    this.retryingPayment = false;
                  }, err => {
                    this.generalFunctions.openToast(err.message, 3000, 'error');
                    this.retryingPayment = false;
                  });
                }

              cancelCollectDue() {
                this.orderDetailsView = 'sale-details';
                this.resetCollectDue();
              }

              resetCollectDue() {
                this.clearDueAmount = '';
                this.clearDuePaymentMethod = '';
                this.clearDueProceed = false;
              }

              changePaymentMethod(e) {
                if (e.value == 'add') {
                  this.pop_up_for = 'add-card';
                } else {
                  this.pop_up_for = null;
                }
              }

              updateMessageContent(e) {
                this.messageDetails.message = e;
              }

              sendMessage() {
                  this.messageDetails.channel = this.groupMessage.channel;
                if ((this.messageDetails.subject == '' && this.messageDetails.channel == 'email') || this.messageDetails.message == '') {
                  this.generalFunctions.openToast('Please fill in the required fields', 3000, 'error');
                  return;
                }

                // rewritting the value of channel because of changes made to api

                this.messageDetails.channel == 'email' ? this.messageDetails.channel = 'mail' : '';
                this.http.sendData('contact/' + this.customer_id + '/message' + this.include_center, this.messageDetails).subscribe(response => {
                  this.generalFunctions.openToast('Message has been sent', 3000, 'success');
                  this.show_pop_up = false;
                  this.pop_up_for = null;
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              openRefund() {
                if (this.selectedOrder.discount_value_type == 'fixed') {
                  this.refundOverlay = true;
                  this.prepareEntireCartForRefund();
                } else {
                  this.refundOverlay = true;
                  this.refundPhase = null;
                }
              }

              prepareEntireCartForRefund() {
                  this.refundPhase = 1;
                  this.selectedOrder.items.data.forEach(innerElement => {
                  this.refundCart.id = this.selectedOrder.id;
                  this.refundCart.items.push(innerElement);
                });
                this.calculateTotal();
                this.prepareRefundModes();
              }

              clickableCart(i, item) {
                this.refundThis[i] = !this.refundThis[i];
                if (this.refundThis[i]) {
                  this.preparedArray.push(item.id);
                } else {
                  if (this.preparedArray.includes(item.id)) {
                    this.preparedArray = this.preparedArray.filter(element => {
                      return item.id !== element;
                    });
                  } else {
                    this.generalFunctions.openToast('Something is wrong', 1500, 'error');
                  }
                }
              }

              refundCheckout() {
                if (this.preparedArray.length <= 0) {
                  this.generalFunctions.openToast('please select atlest one item to refund', 3000, 'error');
                } else {
                  this.refundPhase = 1;
                  this.preparedArray.forEach(element => {
                    this.selectedOrder.items.data.forEach(innerElement => {
                      if (innerElement.id == element) {
                        this.refundCart.id = this.selectedOrder.id;
                        this.refundCart.items.push(innerElement);
                      }
                    });
                  });

                  this.calculateTotal();
                  this.prepareRefundModes();
                }
              }

              prepareRefundModes() {
                const paymentFrom = [];
                this.selectedOrder.payments.data.forEach(payment => {
                  const obj = {
                    method: '',
                    amount: '',
                    type: '',
                    mode: ''
                  };
                  obj.method = payment.payment_method.code;
                  obj.amount = payment.amount;
                  obj.type = payment.type;
                  obj.mode = payment.payment_method.mode;
                  if (paymentFrom.length == 0) {
                    paymentFrom.push(obj);
                  } else {
                    for (let i = 0; i < paymentFrom.length; i++) {
                      if (obj.method === paymentFrom[i].method) {
                        if (obj.type == RefundType.REFUND) {
                          paymentFrom[i].amount = parseFloat(paymentFrom[i].amount) - parseFloat(obj.amount);
                          break;
                        } else if (obj.type == RefundType.PAIDDUE || obj.type == RefundType.PAID) {
                          paymentFrom[i].amount = parseFloat(obj.amount) + parseFloat(paymentFrom[i].amount);
                          break;
                        }
                      }
                      if (i == paymentFrom.length - 1 && obj.method !== paymentFrom[i].method) {
                        paymentFrom.push(obj);
                        break;
                      }
                    }
                  }

                  this.sculptRefundDropdown(paymentFrom);
                });
              }

              sculptRefundDropdown(paymentFrom) {
                this.refundPaymentModes = paymentFrom.map(element => {
                  return {
                    label: element.method + ' - ' + element.amount,
                    value: {
                      method: element.method,
                      amount: element.amount,
                      mode: element.mode
                    }
                  };
                });
                this.selectedMode = this.refundPaymentModes[0].value;
              }

              calculateTotal() {
                this.refundCart['refundDiscountTotal'] = 0;
                this.refundCart.items.forEach(element => {
                  this.refundCart.refundCartTotal += element.total;
                });
                if (this.selectedOrder.discount_value_type == 'percent') {
                  this.refundCart.items.forEach(element => {
                    this.refundCart['refundDiscountTotal'] += parseFloat(element.cart_discount_amount);
                  });
                }
                if (this.selectedOrder.discount_value_type == 'fixed') {
                  this.refundCart['refundDiscountTotal'] = parseFloat(this.selectedOrder.discount_value);
                  this.refundCart.refundCartTotal = this.refundCart.refundCartTotal - this.selectedOrder.discount_value;
                }
                this.refundCart.intendedRefund = this.refundCart.refundCartTotal;
              }

              confirmRefund(refundCart) {
                this.refundPhase = 2;
              }

              refundConfirmed() {
                const reqObj = {
                  amount: this.refundCart.intendedRefund,
                  payments: {
                    mode: this.selectedMode.mode,
                    method: this.selectedMode.method
                  },
                  items: []
                };
                this.refundCart.items.forEach((element, index) => {
                  reqObj.items[index] = element.id;
                });

                this.http.sendData('pos/' + this.refundCart.id + '/refund' + this.include_center, reqObj).subscribe(response => {
                  this.refundPhase = 3;

                  this.getSales();
                  this.getPayments();
                  this.getCustomerData(this.customer_id);

                  this.generalFunctions.openToast('Your refund has been processed', 3000, 'success');
                }, err => {
                  this.cancelRefund();
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              refundPaid() {
                this.refundPhase = 4;
              }

              resetRefund() {
                this.refundCart = {
                  items: [],
                  id: '',
                  refundCartTotal: 0,
                  intendedRefund: 0
                };
              }

              cancelRefund() {
                this.orderDetailsView = 'sale-details';
                this.refundOverlay = false;
                this.refundThis = [];
                this.preparedArray = [];
                this.refundCart = {
                  items: [],
                  id: '',
                  refundCartTotal: 0,
                  intendedRefund: 0
                };
              }

              doneRefund() {
                this.getSales();
                this.getPayments();
              }

              cancelMembership(id) {
                this.cancelMembershipId = id;
              }
              cancelCourse(row) {
                  this.cancelCourseId = {
                      bookingId : row.booking_instance.id,
                      eventId : row.event_instance.id
                  };
              }

              confirmCancel() {
                this.pop_up_for = null;
                this.http.getData('memberships/' + this.cancelMembershipId + '/cancel' + this.include_center).subscribe(success => {
                  this.generalFunctions.openToast(success.message, 3000, 'success');
                  this.getCustomerData(this.customer_id);
                  this.addTag.getContactTags();
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                  this.customer_id = this.customer_id
                });
              }
              confirmCancelCourse() {
                this.pop_up_for = null;

                this.http.deleteData(`bookings/${this.cancelCourseId.eventId}/cancel/${this.cancelCourseId.bookingId}${this.include_center}`).subscribe(response => {
                    this.generalFunctions.openToast('Course has been cancelled', 3000, 'success');
                    this.getCustomerData(this.customer_id);
                    this.addTag.getContactTags();
                  }, err => {
                    this.generalFunctions.openToast(err.message, 3000, 'error');

                  });
              }

              cancelSubscription() {
                this.pop_up_for = null;
                this.http.getData('memberships/' + this.cancelMembershipId + '/cancel' + this.include_center).subscribe(success => {
                  this.generalFunctions.openToast(success.message, 3000, 'success');
                  this.getCustomerData(this.customer_id);
                  this.addTag.getContactTags();
                }, err => {
                  this.generalFunctions.openToast('Something went wrong', 3000, 'error');
                  this.customer_id = this.customer_id
                });
              }

              cancelrecurringMembership(row) {
                  console.log('row', row)
                this.cancelMembershipId = row.latest_membership.id;
                if (row.service_model.settings?.min_cycles) {
                    if (row.memberships.length <= row.service_model.settings?.min_cycles) {
                        this.generalFunctions.openToast('Please complete the minimum cycles to cancel.', 3000, 'success');
                    } else {
                        this.pop_up_for = 'cancel-recurring-membership';
                        this.show_pop_up = true;
                    }
                } else {
                    this.pop_up_for = 'cancel-recurring-membership';
                    this.show_pop_up = true;
                }

              }


              noUpcomingMembership() {
                this.pop_up_for = null;
              }

              findSale(id) {
                this.getPayments();
                this.http.getData(`contact/${this.customer_id}/sales` + this.include_center).subscribe(response => {
                  this.allOrders = response.data;
                  for (let i = 0; i < this.allOrders.length; i++) {
                    if (this.allOrders[i].sale_id == id) {
                      this.openOrderOverlay(i);
                      return;
                    }
                  }
                }, error => {
                  console.log(error);
                });
              }

              deleteCustomer() {
                this.http.deleteData(`contact/${this.deleteId}${this.include_center}`).subscribe(response => {
                  this.pop_up_for = null;
                  this.generalFunctions.openToast('Customer has been deleted successfully', 3000, 'success');
                  this.router.navigate(['../client/customers']);
                }, error => {
                  this.pop_up_for = null;

                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              unarchiveCustomer(id) {
                this.http.getData(`contact/${id}/unarchive` + this.include_center).subscribe(response => {
                  this.generalFunctions.openToast('customer has been unarchived', 3000, 'success');

                  this.router.navigate(['../client/customers']);
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }

              newFileUpload(event) {
                const fSize = event.target.files[0].size;

                if (event.target.files && event.target.files[0] && fSize < 2000000) {
                  const file = event.target.files[0];
                  const fileType = file.type.split('/');
                  const uploadData = new FormData();
                  uploadData.append('image', file);
                  uploadData.append('type', 'contacts');
                  this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
                    this.saveImage(response.url);
                  }, error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');
                  });
                } else {
                  this.generalFunctions.openToast('Please upload a image of size 2mb or less', 3000, 'error');
                }
              }

              saveImage(url) {
                const obj = {
                  image_url: url
                };
                const endPoint = `contact/${this.customer_id}/image` + this.include_center;
                this.http.patchData(endPoint, obj).subscribe(success => {
                  this.generalFunctions.openToast('Profile picture has been updated successfully', 3000, 'success');
                  this.getCustomerData(this.customer_id);
                  this.show_update_profile_picture_popup = false;
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }
              selectPicture(e) {
                const src = this.photo_tag.nativeElement.getAttribute('src');
                e.target.classList.add('loading-ajax');
                const data = this.canvas.nativeElement.toDataURL('image/png');
                this.photo_tag.nativeElement.removeAttribute('src');
                const obj = {};
                const endpoint = 'contact/' + this.customer_id + '/photo' + this.include_center;
                obj['photo'] = src;
                const uploadData = new FormData();
                uploadData.append('blob', src);
                uploadData.append('type', 'contacts');

                this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
                  const context = this.canvas.nativeElement.getContext('2d');
                  context.fillStyle = '#AAA';
                  context.fillRect(0, 0, 0, 0);
                  this.photo_captured = false;
                  this.photo_selected = true;
                  this.stopWebcam();
                  this.saveImage(response.url);
                }, error => {
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                  this.stopWebcam();
                  this.photo_captured = false;
                  this.photo_selected = true;
                  this.webcam_initiate = false;
                });
              }

              addCard(token) {
                this.http.sendData('contact/' + this.customer_id + '/payment/sources' + this.include_center + '&include=memberships,attendances,credits', {token: token}).subscribe(success => {
                  this.generalFunctions.openToast('Card successfully added for the customer', 2000, 'success');
                  this.card.clear();
                  this.currentCard = success.data.id;
                  this.preparePaymentModes();
                  this.getCard();
                  this.addingCard = false;
                }, error => {
                this.card.clear()
                  this.preparePaymentModes();
                  this.addingCard = false;
                  this.generalFunctions.openToast(error.message, 3000, 'error');
                });
              }
              getCard() {
                if (this.stripeConnected) {
                  this.http.getData('contact/' + this.customer_id + '/payment/sources' + this.include_center + '&include=memberships,attendances,credits').subscribe(success => {
                    this.cardDetails = success.data;
                    this.savedCards = success.data;
                    this.preparePaymentModes();
                  },
                   error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');
                  });
                }
              }

              deleteCard(id) {
                this.http.deleteData('contact/' + this.customer_id + '/payment/sources/' + id + this.include_center).subscribe(success => {
                  this.generalFunctions.openToast('Card has been deleted successfully', 3000, 'success');
                  this.getCard();
                }, err => {
                  this.generalFunctions.openToast(err, 3000, 'error');
                });
              }

              callEstimatedExpiry(duration, date) {
                const split = duration.split(' ');
                return new Date(moment(date).add(split[1], split[0]).format('DD MMM YYYY'));
              }

              formatStartEnds(start, end) {
                const startTime = moment(start).format('hh:mm a');
                const endTime = moment(end).format('hh: mm a');
                const startDate = moment(start).format('D MMM');
                return `${startTime} - ${endTime} ${startDate}`;
              }

              formStartFormat(start) {
                return `${moment(start).format('hh:mm a')}  ${moment(start).format('D MMM')}`;
              }

              startDateFormat(start) {
                return `${moment(start).format('dddd, Do MMM\'YY')}`;
              }
              getCreditsUsage(membership, recurring = false) {
                this.creditUsage = {};
                if (!recurring) {
                    this.http.getData(`memberships/${membership.id}/credits${this.include_center}`).subscribe(response => {
                        const creditHistory = response.data[0];
                        this.creditUsage['name'] = membership.membership;
                        this.creditUsage['start'] = membership.starts_at;
                        this.creditUsage['end'] = membership.expires_at;
                        this.creditUsage['balance'] = creditHistory.balance;
                        this.creditUsage['logs'] = creditHistory.logs;
                        this.creditUsage['amt'] = creditHistory.logs[0].amount;
                        this.creditUsage['logs'].forEach(element => {
                          if (element.action == 'credit' && !isNull(element.event.id) && element.event.length == 0) {
                            this.creditUsage['total'] = element['amount'];
                          }
                        });
                      }, err => {
                          this.generalFunctions.openToast(err.message,3000,'error');
                      });
                }
                else {
                    if (membership.latest_membership.credit) {
                        this.creditUsage['name'] = membership.name;
                        this.creditUsage['start'] = membership.starts_at;
                        this.creditUsage['end'] = membership.expires_at;
                        this.creditUsage['balance'] =  membership.latest_membership.credit.balance;
                        this.creditUsage['logs'] = membership.latest_membership.credit.logs;
                        this.creditUsage['amt'] = membership.latest_membership.credit.logs[0].amount;
                        this.creditUsage['logs'].forEach(element => {
                          if (element.action == 'credit' && !isNull(element.event_id) ) {
                            this.creditUsage['total'] = element['amount'];
                          }
                        });
                    }
                    else {
                        this.pop_up_for = null;
                        this.show_pop_up =  false;
                    }

                }

              }

              getRecurringCreditsUsage() {

              }

              isArray(obj: any) {
                return Array.isArray(obj);
              }

              openDropdown() {
                this.dd.click();
              }

              addTo(data) {
                this.tags.push(data);
                this.http.sendData(`contact/${this.customer_id}/tags/attach${this.include_center}`, {tag_id: data.label.id}).subscribe(response => {
                  this.generalFunctions.openToast('Tags updated successfully', 3000, 'success');
                }, err => {
                  this.generalFunctions.openToast(err.message, 3000, 'error');
                });
              }

              detachTag(tag) {
                this.http.updateData(`contact/${this.customer_id}/tags/detach${this.include_center}`, {tag_id: tag.label.id}).subscribe(response => {
                  this.generalFunctions.openToast('Tags updated successfully', 3000, 'success');
                }, err => {});
              }

              getTags() {
                this.http.getData(`tags${this.include_center}`).subscribe(response => {
                  const tags = response.tags;
                  tags.forEach(tag => {
                    const template = {
                      label: tag.name,
                      value: {
                        id: tag.id,
                        data: tag
                      }
                    };
                    this.cars.push(template);
                  });
                  this.isTags = true;
                }, err => {});
              }

              pluralize(duration) {
                let [num, period] = duration.split(' ');
                if (num === '1') {
                    if (period === 'months'){
                        period = 'month';
                        return `${num} ${period}`;
                    }
                    if (period === 'days'){
                        period = 'day';
                        return `${num} ${period}`;

                    }
                    if (period === 'weeks'){
                        period = 'week'
                        return `${num} ${period}`
                    }
                } else {
                    return `${num} ${period}`
                }


              }

              findIf(payments) {
                 let arr =  payments.data.filter(payment =>  payment.status === 3);
                 return arr.length > 0 ? true : false
              }



              findIfAny() {
                this.customer_data.data.gift_card_details.data = this.customer_data.data.gift_card_details.data.filter((i) => i.current_value >= 1)
                return this.customer_data.data.gift_card_details.data.length > 0 ? true : false;
              }

              findIfRecurring(items) {
                  return items.filter(item => item.service_data.is_recurring === 1).length > 0;
               }
               formattedDateTimeString(date) {
                   console.log('date', date)
                   if(date){
                let newDate = {
                  date: moment(date).format('DD MMM '),
                  time: moment(date).format('hh:mm a')
                };
                return newDate;
              }
            }

            setHovered() {
                this.hovered = true;
            }

            copyToBoard(str) {
                const el = document.createElement('textarea');
                el.value = str;
                el.setAttribute('readonly', '');
                el.style.position = 'absolute';
                el.style.left = '-9999px';
                document.body.appendChild(el);
                el.select();
                document.execCommand('copy');
                document.body.removeChild(el);
                this.generalFunctions.openToast('Copied to clipboard', 3000, 'success');
              }
          }

