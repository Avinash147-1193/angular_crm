


import {
    Component, Input
  } from '@angular/core';

  import {MembershipConstants, SubscriptionConstants} from '../../../../../constants';
  @Component({
    selector: 'app-pill',
    template: `
    <div *ngIf="type === 'membership'">
        <span class="pill active" *ngIf="status === membershipStatus.ACTIVE">Active</span>
        <span class="pill inactive" *ngIf="status === membershipStatus.EXPIRED">Expired</span>
        <span class="pill upcoming" *ngIf="status === membershipStatus.UPCOMING">Upcoming</span>
        <span class="pill paused" *ngIf="status === membershipStatus.FREEZED">Paused</span>
        <span class="pill billing-issue" *ngIf="status === membershipStatus.BILLING_ISSUE">Overdue</span>
        <ng-container *ngIf="status === membershipStatus.CANCELED">
            <span class="pill inactive"> Expired</span>
            <span class="pill inactive"> Cancelled at {{expires | date:'dd MMM'}}</span>
        </ng-container>
        <ng-container *ngIf="status === membershipStatus.CANCELATION_SCHEDULED">
            <span class="pill active">Active</span>
            <span class="pill inactive">Cancels {{expires | date:'dd MMM'}} </span>
        </ng-container>
    </div>
    <div *ngIf="type === 'subscription'">
        <span class="pill active" *ngIf="status === subscriptionStatus.ACTIVE">
            Active
        </span>

        <span class="pill paused" *ngIf="pause"> Pause scheduled</span>
        <span class="pill inactive" *ngIf="status === subscriptionStatus.EXPIRED">Expired</span>
        <span class="pill upcoming" *ngIf="status === subscriptionStatus.UPCOMING">Upcoming</span>
        <span class="pill paused" *ngIf="status === subscriptionStatus.PAUSED">Paused</span>
        <span class="pill  billing-issue" *ngIf="status === subscriptionStatus.BILLING_ISSUE">Overdue</span>
        <ng-container *ngIf="status === subscriptionStatus.CANCELED">
            <span class="pill inactive"> Expired</span>
            <span class="pill inactive"> Cancelled at {{expires | date:'dd MMM'}}</span>
        </ng-container>
        <ng-container *ngIf="status === subscriptionStatus.CANCELATION_SCHEDULED">
            <span class="pill active">Active</span>
            <span class="pill inactive">Cancels {{expires | date:'dd MMM'}} </span>
        </ng-container>
    </div>
    `,
    })

  export class PillComponent {
     membershipStatus: any = MembershipConstants;
     subscriptionStatus: any = SubscriptionConstants;
     @Input() status: any;
     @Input() expires: null;
     @Input() pause = false;
     @Input() type: any = 'membership';
    };
