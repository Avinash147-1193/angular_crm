import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './customers.component.html'
})
export class CustomersComponent implements OnInit {


	constructor() { }

	ngOnInit() {
	}


}
