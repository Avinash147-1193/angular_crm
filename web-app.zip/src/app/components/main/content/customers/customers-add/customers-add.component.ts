import {Component, OnInit, ViewChild, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import * as moment from 'moment';
//copy
import {
    SelectItem
} from 'primeng/api';
import {
    COUNTRIES
} from '../../../../../countries';

import {
    CODES
} from '../../../../../phonecodes';

@Component({templateUrl: './customers-add.component.html', styleUrls: ['./customers-add.component.scss']})
export class CustomersAddComponent implements OnInit {

  null: any = null;
  true: boolean = true;
  false: boolean = false;

  emergency_contact_enabled: boolean = true;
  medical_history_enabled: boolean = true;
  membership_id_enabled: boolean = true;

  emergency_contact_mandatory: boolean = true;
  medical_history_mandatory: boolean = true;
  membership_id_mandatory: boolean = true;

  attendance_id_enabled: boolean = true;
  photo_enabled: boolean = true;
  photo_mandatory: boolean = true;

  universal_contact: any = {
    found: false,
    type: null
  };
  center_contact: any = {
    found: false,
    type: 'customer'
  };
  include_center: any = null;

  prospect_to_customer: boolean = false;
  prospect_id: any = null;

  webcam_initiate: boolean = false;
  photo_selected: boolean = false;
  photo_captured: boolean = false;

  isCameraAdapted: boolean = true;
  videoStream: any = null;

  heyLoaderImage: boolean = false;
  fileLoaded: any = null;
  uploadFlag: any = null;
  show_pic_popup: any = false;

  editCustomer: boolean = false;
  customerId: any;
  customer_data: any = {
    contact: {
      phone: '',
      email: '',
      first_name: '',
      last_name: '',
      gender: '',
      date_of_birth: '',
      image_url: null,
      phone_prefix:''
    },
    address: {
      pincode: '',
      address: '',
      city: '',
      state: '',
      country:''
    },
    emergencyContact: {
      first_name: '',
      last_name: '',
      phone: '',
      relationship: ''
    },
    medical_history: '',
    custom_fields: {
      membership_id: ''
    },
    attendee_id: ''
  };
  dobDatepickerConfig = {
    showWeekNumbers: false,
    maxDate: new Date(),
    containerClass: 'theme-default'
  };

  validationCheck: boolean = false;
  validationFields: any = {
    customer_email: false,
    customer_phone: false,
    customer_fname: false,
    customer_lname: false,
    customer_gender: false,
    customer_dob: false,
    customer_address: false,
    customer_city: false,
    customer_state: false,
    customer_pincode: false,
    emergency_number: false,
    emergency_fname: false,
    emergency_lname: false,
    medical_history: false,
    membership_id: false,
    emergency_relation: false
  };

  @ViewChild('phone')phone;
  // @ViewChild('phone_confirmation') phone_confirmation;
  @ViewChild('gender_container')gender_container;

  @ViewChild('first_name')first_name;
  @ViewChild('last_name')last_name;
  @ViewChild('email')email;

  @ViewChild('customer_city')customer_city;
  @ViewChild('customer_state')customer_state;

  @ViewChild('video')video;
  @ViewChild('canvas')canvas;
  @ViewChild('photo_tag')photo_tag;

  @ViewChild('selected_image')selected_image;

  emailCheckLoader: boolean = true;
  checkExisting: boolean = false;
  checkLoader: boolean = false;
  existingType: any = '3';
  foundCenter: any = {
    type: 1
  };
  existing_customer: any = {
    first_name: '',
    last_name: '',
    id: '',
    contact_id: ''
  };

  //copy
  countryCodesDropdown: SelectItem[] = [];
  countriesDropdown: SelectItem[] = [];

  countries: any = COUNTRIES;
  codes: any = CODES;
  onceLoaded = false;



  constructor(private location: Location,
    private generalFunctions: GeneralServices,
    private http: ServerAuthService,
    private router: Router,
    private route: ActivatedRoute) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getSettings();

    if (this.router.url.includes('edit')) {
      this.editCustomer = true;
      this.customerId = this.route.snapshot.paramMap.get('id');
      this.emailCheckLoader = false;
      this.getCustomer(this.customerId);
    }
    this.route.queryParams.subscribe(params => {
      if (params['prospect']) {
        this.getProspectData(params['prospect']);
      } else {
        this.prospect_to_customer = false;
      }
    });

    this.prepareCountriesDropdown()

  }



  //copy
  prepareCountriesDropdown() {
    for (let i = 0; i < this.countries.length; i++) {
        let country = {
            label: '',
            value: 0
        };
        // country name
        country.label = this.countries[i].name;
        country.value = this.countries[i].id;
        this.countriesDropdown.push(country);
    }

    for (let i = 0; i < this.codes.length; i++) {

        let code = {
            label: '',
            value: 0
        };
        // country code
        code.label = this.codes[i].isd_code;
        code.value = this.codes[i].id;
        this.countryCodesDropdown.push(code);
    }

    if (!this.editCustomer) {
        const localization = JSON.parse(localStorage.getItem('localization'));
        this.customer_data.contact.phone_prefix = String( localization.country.isd_code);
        this.customer_data.address.country = String( localization.country.name);
    }
    setTimeout(() => {
        this.onceLoaded = true;
    }, 1);
}


  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  toggleCustomTicTac(e) {
    this.generalFunctions.toggleCustomTicTac(e);
  }

  autoIncreaseSize(e) {
    var textarea = e.target,
      height = textarea.offsetHeight;
    textarea.style.height = '16px';
    textarea.style.height = textarea.scrollHeight + 'px';
    textarea.style.maxHeight = textarea.scrollHeight + 'px';
    this.isFilled(e);
  }

  getCustomer(id) {
    this.http.getData(`contact/${id}` + this.include_center + '&include=activities,emergencyContact,address,memberships')
    .subscribe(success => {
      success = success;
      this.customer_data.contact = success.data.contact.data;
      this.customer_data.address = success.data.address.data;

      //copy

      let cdr = this.countryCodesDropdown.filter(obj => obj.label === success.data.contact.data.phone_prefix)
      if (cdr.length <= 0) {
        this.countryCodesDropdown.push({label: '+0000', value: '+0000' })
      }
      this.customer_data.contact.phone_prefix = success.data.contact.data.phone_prefix;
      this.customer_data.address.country = success.data.address.data.country;

      this.customer_data.contact.date_of_birth = success.data.contact.data.date_of_birth !== ''
        ? new Date(success.data.contact.data.date_of_birth)
        : '';
      this.customer_data.emergencyContact = success.data.emergencyContact.data;
    }, error => {
      this.generalFunctions.openToast('Unable to load customers!', 3000, 'error');
    });
  }

  mapImageUrl(event) {
    this.customer_data.contact.image_url = event;
  }

  getSettings() {
    this.http.getData('settings' + this.include_center).subscribe(success => {
      success = success;
      this.photo_enabled = success.contacts.img_data.enabled;
      this.photo_mandatory = success.contacts.img_data.mandatory;
      this.emergency_contact_enabled = success.contacts.emergencyContact.enabled;
      this.medical_history_enabled = success.contacts.medical_history.enabled;
      this.membership_id_enabled = success.contacts.custom_fields.membership_id.enabled;
      this.emergency_contact_mandatory = success.contacts.emergencyContact.mandatory;
      this.medical_history_mandatory = success.contacts.medical_history.mandatory;
      this.membership_id_mandatory = success.contacts.custom_fields.membership_id.mandatory;
      // this.attendance_id_enabled = success.attendance.biometric.enabled;
      this.attendance_id_enabled = false;
    }, error => {
      this.generalFunctions.openToast('Unable to load settings!', 3000, 'error');
    });
  }



  getProspectData(id) {
    this.prospect_id = id;
    var endpoint = 'contact/' + id + this.include_center + '&include=address';

    this.http.getData(endpoint).subscribe(data => {
      if (data.data.added_via != 'prospect_form') {
        this.router.navigate([
          '../../pos', data.data.id
        ], {
          queryParams: {},
          relativeTo: this.route
        });
      } else {
        this.customer_data['added_via'] = 'customer_form';
        this.customer_data['contact'] = data.data.contact.data;
        // this.customer_data["contact"]["phone_confirmation"] = parseInt(this.customer_data["contact"]["phone"]);
        this.phone.nativeElement.value = this.customer_data['contact']['phone'];
        // this.phone_confirmation.nativeElement.value = this.customer_data["contact"]["phone_confirmation"];
        if (!(data.data.address.data.length == 0)) {
          this.customer_data['address'] = data.data.address.data;
        }
        this.prospect_to_customer = true;
        setTimeout(() => {
          this.checkinput();
        }, 20);
      }
    }, err => {
      this.prospect_to_customer = false;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  routeBack() {
    this.location.back();
  }

  checkinput() {
    var els = document.querySelectorAll('.input-field input, .input-field textarea');
    Array.prototype.forEach.call(els, (item, index) => {
      if (item.value != '') {
        item.dispatchEvent(new Event('keyup'));
      }
    });
  }

  // addNewCustomer(form,e){
  addNewCustomer() {
    this.validationCheck = true;
    if (!(this.validationFields.customer_email

          && this.validationFields.customer_fname
           && this.validationFields.customer_lname

            )) {
                 this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                 return;
    }

    var clone = Object.assign({}, this.customer_data),
      obj = clone;

    if (!this.emergency_contact_enabled) {
      delete obj['emergencyContact'];
    }

    let msg = null;
    if (!this.medical_history_enabled) {
      delete obj['medical_history'];
    }
    else if (this.medical_history_enabled && !obj.medical_history) {
      msg = 'Since the medical history is enabled in settings please fill medical history details';
    }
    if (!this.membership_id_enabled) {
      delete obj['custom_fields'];
    }
    else if (this.membership_id_enabled && !obj.custom_fields.membership_id) {
      msg = 'Since membership id is enabled in settings please fill membership details';
    }
    if (!this.emergency_contact_enabled) {
      delete obj['custom_fields'];
    }
    else if (this.emergency_contact_enabled && !(obj.emergencyContact.first_name || obj.emergencyContact.last_name || obj.emergencyContact.phone || obj.emergency_contact_enabled.relationship)) {
      msg = 'Since emergency contact is enabled in settings please fill all emergency contact details';
    }
    if (!this.attendance_id_enabled) {
      delete obj['attendee_id'];
    }
    // if((!this.photo_enabled)){
    // 	delete obj["contact"]["img_data"];
    // }

    if (msg) {
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    // 	if(this.photo_enabled&&this.photo_mandatory&&!this.customer_data['contact']['img_data']){
    // 		this.generalFunctions.openToast("Upload customer image!",3000,"error");
    // 		return false;
    // 	}
    var dob = this.customer_data.contact.date_of_birth;
    if (dob) {
      dob = this.generalFunctions.convertDateToISOFormat(dob);
      this.customer_data.contact.date_of_birth = dob['date'];
    }

    // 	if((!this.universal_contact.found)){
    // 		this.customer_data.contact.phone = parseInt(this.customer_data.contact.phone);
    // 	  this.customer_data.contact.phone_confirmation = parseInt(this.customer_data.contact.phone_confirmation);
    // }

    // if(!this.prospect_to_customer){
    if (!this.prospect_to_customer) {
      this.http.sendData('customer' + this.include_center, obj).subscribe(success => {
        this.generalFunctions.openToast('Contact details updated', 3000, 'success');
        this.router.navigate([
          '/client/pos', success.data.id
        ], {
          queryParams: {
            new: 'true'
          },
          relativeTo: this.route
        });
      }, error => {
        var msg = error.message;
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    } else {
      this.http.updateData('contact/' + this.prospect_id + this.include_center, obj).subscribe(success => {
        this.generalFunctions.openToast('Contact details updated', 3000, 'success');
        this.router.navigate([
          '/client/pos', success.data.id
        ], {
          queryParams: {},
          relativeTo: this.route
        });
      }, error => {
        var msg = error.message;
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }
  }

  updateCustomer() {
    this.validationCheck = true;
    if (!(this.validationFields.customer_email
        && this.validationFields.customer_fname
        && this.validationFields.customer_lname)) {
      this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
      return;
    }
    this.customer_data['added_via'] = 'customer_form';
    var clone = Object.assign({}, this.customer_data),
      obj = clone;

    if (!this.emergency_contact_enabled) {
      delete obj['emergencyContact'];
    }

    let msg = null;
    if (!this.medical_history_enabled) {
      delete obj['medical_history'];
    } else if (this.medical_history_enabled && !obj.medical_history) {
      msg = 'Since the medical history is enabled in settings please fill medical history details';
    }
    if (!this.membership_id_enabled) {
      delete obj['custom_fields'];
    } else if (this.membership_id_enabled && !obj.custom_fields.membership_id) {
      msg = 'Since membership id is enabled in settings please fill membership details';
    }
    if (!this.emergency_contact_enabled) {
      delete obj['custom_fields'];
    } else if (this.emergency_contact_enabled && !(obj.emergencyContact.first_name || obj.emergencyContact.last_name || obj.emergencyContact.phone || obj.emergency_contact_enabled.relationship)) {
      msg = 'Since emergency contact is enabled in settings please fill all emergency contact details';
    }
    if (!this.attendance_id_enabled) {
      delete obj['attendee_id'];
    }

    if (msg) {
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    var dob = this.customer_data.contact.date_of_birth;
    if (dob) {
      dob = this.generalFunctions.convertDateToISOFormat(dob);
      this.customer_data.contact.date_of_birth = dob['date'];
    }
    this.http.updateData('contact/' + this.customerId + this.include_center, obj).subscribe(success => {
      this.generalFunctions.openToast('Contact details updated!', 3000, 'success');
      this.router.navigate([
        '/client/customers', success.data.id
      ], {
        queryParams: {},
        relativeTo: this.route
      });
    }, error => {
      var msg = error.message;
      this.generalFunctions.openToast(msg, 3000, 'error');
    });
  }

  parseDate(date) {
    var d = new Date(date);
    return d;
  }

  // phoneEdit(e){
  // 	this.isFilled(e);
  // 	if(this.center_contact["found"]||this.universal_contact.found){
  // 		this.resetForm();
  // 	}
  //  Validate input values
  // 	var el = e.target;
  // 	var val = el.value;
  // 	val = val.replace(/[_-]/g, "").toString();
  // 	var len = val.length;

  // 	(len<10&&len>0)?el.classList.add('invalid'):el.classList.remove('invalid');

  // 	if(len==1){
  // 		this.customer_data.contact.phone = val;
  // 		return false;
  // 	}

  // 	var posX = e.target.selectionStart;

  // 	var code = e.keyCode || e.charCode|| e.which;

  //  current model value
  // 	var t = (this.customer_data.contact.phone)?this.customer_data.contact.phone.toString():"";

  // 	if(posX>3){posX-=1}
  // 	if(posX>6){posX-=1}

  // 	if(code>=48 && code<=57&&t.length<10){
  // 		t=[t.slice(0,posX),String.fromCharCode(code),t.slice(posX)].join("");
  // 	}else if(code == 8&&t.length<11){
  // 		t=[t.slice(0,posX),t.slice(posX+1)].join("");
  // 	}else if(code == 46&&t.length<11){
  // 		t=[t.slice(0,posX+1),t.slice(posX+2)].join("");
  // 	}else if(code == 88&&t.length<11){
  // 		return false;
  // 	}

  // 	this.customer_data.contact.phone = t;

  // 	var size = val.length;
  // 	if(size>3){size+=1}
  // 	if(size>6){size+=1}

  // 	e.target.selectionStart = size;
  // 	e.target.selectionEnd = size;
  // 	if((code==8&&size==4) || (code==8&&size==8)){
  // 		e.target.selectionStart = size-1;
  // 		e.target.selectionEnd = size-1;
  // 	}
  // }

  centerContactFound(id, type, added_via, name) {
    this.center_contact['found'] = true;
    this.center_contact['type'] = type;
    this.universal_contact['found'] = false;
    this.center_contact['name'] = name;
    this.center_contact['added_via'] = added_via;
  }

  universalContactFound(data, id) {
    this.center_contact['found'] = false;
    this.universal_contact['found'] = true;
    this.customer_data.contact.first_name = data.first_name;
    this.customer_data.contact.last_name = data.last_name;
    this.customer_data.contact.email = data.email;
    this.customer_data.contact.gender = data.gender;
    this.customer_data.contact.date_of_birth = data.date_of_birth;

    setTimeout(() => {
      this.first_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.last_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.email.nativeElement.dispatchEvent(new Event('keyup'));
    }, 200);
  }

  resetForm() {
    this.universal_contact['found'] = false;
    this.center_contact['found'] = false;
    this.customer_data.contact.first_name = null;
    this.customer_data.contact.last_name = null;
    this.customer_data.contact.email = null;
    this.customer_data.contact.gender = null;
    this.customer_data.contact.date_of_birth = null;

    setTimeout(() => {
      this.first_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.last_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.email.nativeElement.dispatchEvent(new Event('keyup'));
    }, 200);
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
      case 'customer-email':
        isValid = !this.customer_data.contact.email.replace(/\s/g, '').length || !this.validateEmail(this.customer_data.contact.email)
          ? false
          : true;
        this.validationFields.customer_email = isValid;
        break;

      case 'customer-phone':
        isValid = !this.validatePhone(this.customer_data.contact.phone)
          ? false
          : true;
        this.validationFields.customer_phone = isValid;
        break;

      case 'customer-fname':
        isValid = !this.customer_data.contact.first_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_fname = isValid;
        break;

      case 'customer-lname':
        isValid = !this.customer_data.contact.last_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_lname = isValid;
        break;

      case 'customer-gender':
        isValid = !this.customer_data.contact.gender.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_gender = isValid;
        break;

      case 'customer-dob':
        // isValid = (!this.customer_data.contact.date_of_birth.replace(/\s/g, '').length)  ? false : true;
        isValid = this.checkDob(this.customer_data.contact.date_of_birth);

        this.validationFields.customer_dob = isValid;
        break;

      case 'customer-address':
        isValid = !this.customer_data.address.address.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_address = isValid;
        break;

      case 'customer-city':
        isValid = !this.customer_data.address.city.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_city = isValid;
        break;
      case 'customer-state':
        isValid = !this.customer_data.address.state.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_state = isValid;
        break;

      case 'customer-pincode':
        isValid = !this.customer_data.address.pincode.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_pincode = isValid;
        break;

      case 'emergency-number':
        isValid = !this.validatePhone(this.customer_data.emergencyContact.phone)
          ? false
          : true;
        this.validationFields.emergency_number = isValid;
        break;

      case 'emergency-Fname':
        isValid = !this.customer_data.emergencyContact.first_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.emergency_fname = isValid;
        break;

      case 'emergency-Lname':
        isValid = !this.customer_data.emergencyContact.last_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.emergency_lname = isValid;
        break;

      case 'medical-History':
        isValid = !this.customer_data.medical_history.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.medical_history = isValid;
        break;

      case 'custom-Field':
        isValid = !this.customer_data.custom_fields.membership_id.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.membership_id = isValid;
        break;

      case 'emergency-relationship':
        isValid = !this.customer_data.emergencyContact.relationship.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.emergency_relation = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }
  validateEmail(email) {
    var re = /\S+@\S+\.\S{2,}/;
    return re.test(email);
  }
  validatePhone(phone) {
    if (this.numberCounter(phone) < 7 || this.numberCounter(phone) > 10) {
      return false;
    } else
      return true;
    }

  numberCounter(n) {
    var count = 0;
    if (n >= 1)
      ++count;

    while (n / 10 >= 1) {
      n /= 10;
      ++count;
    }

    return count;
  }

  checkDob(date) {
    var timestamp = Date.parse(date);

    if (isNaN(timestamp) == false) {
      var d = new Date(timestamp);
      return true;
    } else {
      return false;
    }
  }

  checkEmail() {
    let validation = !this.customer_data.contact.email.replace(/\s/g, '').length || !this.validateEmail(this.customer_data.contact.email)
      ? false
      : true;
    validation
      ? this.getEmailData(this.customer_data.contact.email)
      : (this.checkLoader = false);
  }

  getEmailData(email) {
    this.checkLoader = true;

    setTimeout(() => {
      this.getStaffData(email);
    }, 1200);
  }

  getStaffData(email) {
    this.http.getData('clients/contact?client_id=' + JSON.parse(localStorage.getItem('currentUser')).client_id + '&email=' + encodeURIComponent(this.customer_data.contact.email)).subscribe(success => {
      success = success.contact;
      console.log('success["first"]', success);
      this.checkLoader = false;
      if (!success['first_name']) {
        this.checkExisting = false;
        this.emailCheckLoader = false;
        this.existingType = '3';

        this.existing_customer.first_name = '';
        this.existing_customer.last_name = '';
        this.existing_customer.id = '';
        this.existing_customer.contact_id = '';

        return;
      }

      this.existing_customer.first_name = success.first_name;
      this.existing_customer.last_name = success.last_name;
      this.existing_customer.contact_id = success.id;

      this.existingType = '2';

      success.centers.forEach(center => {
        if (center.uuid == JSON.parse(localStorage.getItem('currentUser')).center_id) {
          this.existingType = '1';
          this.existing_customer.id = center.pivot.id;

          this.getRegions(center.uuid, center.pivot.type);
          return;
        }
      });

      if (this.existingType == 2) {
        this.existing_customer.id = success.centers[0].pivot.id;

        this.getRegions(success.centers[0].uuid, success.centers[0].pivot.type);
      }
    });

    this.checkExisting = true;
    this.emailCheckLoader = true;
  }

  getRegions(id, type) {
    let centerFound;
    this.http.getData('regions').subscribe(success => {
      success.forEach(element => {
        element.centers.forEach(center => {
          if (center.uuid == id) {
            centerFound = center;
            this.foundCenter = centerFound;
            this.foundCenter['type'] = type;
          }
        });
      });
    }, error => {});
  }

  addExisting() {
    this.http.sendData('customer' + this.include_center, {contact_id: this.existing_customer.contact_id}).subscribe(success => {
      this.generalFunctions.openToast('Customer added successfully!', 3000, 'success');

      this.router.navigate([
        '/client/pos', success.data.id
      ], {
        queryParams: {
          new: 'true'
        },
        relativeTo: this.route
      });
    }, error => {
      this.generalFunctions.openToast('Error adding customer', 3000, 'error');
    });
  }
}
