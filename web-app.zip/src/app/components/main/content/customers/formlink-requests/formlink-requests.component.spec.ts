import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormlinkRequestsComponent } from './formlink-requests.component';

describe('FormlinkRequestsComponent', () => {
  let component: FormlinkRequestsComponent;
  let fixture: ComponentFixture<FormlinkRequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormlinkRequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormlinkRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
