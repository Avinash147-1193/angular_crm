import { Component, OnInit, ViewChild} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { GeneralServices } from '../../../../../common/general-services';
import { ServerAuthService } from '../../../../../common/server-auth';

@Component({
	templateUrl: './formlink-requests.component.html',
	styleUrls: ['./formlink-requests.component.css']
})
export class FormlinkRequestsComponent implements OnInit {

	customers_data: any = null;
	search_customer_text:any;
	
	page_data_loaded:boolean = false; 

	rows: any = [1,2,3,4];

	server_request:boolean = true;

	no_more_results:boolean = false;
	include_center: any = null;

	initial_load: any  = 'submitted';
	count: any  = {
		"submitted": 0,
		"pending":0
	}

	endpoint: any = null;

	params: any = {
		"source":'direct',
		"type":null,
		"page": 1,
		"query":null
	};

	constructor(
		private router : Router,
		private route: ActivatedRoute,
		private generalFunctions: GeneralServices,
	 	private http: ServerAuthService
		) { }

	ngOnInit() {
		this.include_center = this.generalFunctions.includeCenter();
		this.getFirstData();

		document.addEventListener("click",(event)=>{
		  	this.documentClickHandler(event);
		})
	}

	contentScroll(e) { 
		// this.generalFunctions.breadcrumbToggle(e);
		var el = e.target;
		var totalHeight = el.scrollHeight;
		var scrolled = el.scrollTop;
		var boxHeight = el.clientHeight;
		if(this.no_more_results){
			return false;
		}
		if((totalHeight-8) < (scrolled)+(boxHeight)){
			this.loadMoreData();
		} 
	}

	isFilled(e){
		this.generalFunctions.isFilled(e);
	}

	documentClickHandler(e){
		Array.prototype.forEach
			.call(document.getElementsByClassName("more-options-list"), 
					(item,index)=>{
				item.classList.contains("display-none") ? "" : item.classList.add("display-none") ;
					}
				)
		if(e.target.parentElement){
			if(e.target.parentElement.classList.contains('more-options-icon')){
				var list = this.generalFunctions
							.parents(e.target)[1]	
							.getElementsByClassName("more-options-list")[0];
				list.classList.remove("display-none") ;
			}
		}
	}

	getFirstData(){
		this.customers_data = null;
		this.server_request =  true;
		this.no_more_results = false;
		this.params["page"] = 1;
		this.covertToValidEndpoint();
	 	this.http.getData(this.endpoint)
			.subscribe(
			  	(success)=>{
			    		success = success;
			    		this.customers_data = success.data;

			    		success.meta.type_counts.data.forEach((item,index)=>{
			    			this.count[item.type]=item.count;
			    		})

			 		this.no_more_results = true;
			 		this.params["page"] = 1;
			  	},
			  	(err)=>{
			    		var msg = err.message;
			   		this.generalFunctions.openToast(msg,3000,"error");
			  	},()=>{
			    		this.page_data_loaded = true;
			    		this.server_request = false;
			  	}
			)
	}

	covertToValidEndpoint(){
		this.params["type"] = this.initial_load;
		var result = "contact/formlink"
		result = result+this.include_center
					+'&source='+this.params['source']
					+'&type='+this.params["type"]
					+"&page="+this.params["page"];
		if(this.params['query']){
			result = result+'&query='+this.params["query"];
		}
		this.endpoint = result;
	}

	loadMoreData(){
		this.covertToValidEndpoint();
		if(!this.no_more_results && !this.server_request){
			this.server_request = true;
	   		this.http.getData(this.endpoint)
			 	.subscribe(
					(success)=>{
					    success = success;
					    this.customers_data = this.customers_data.concat(success.data);
					    var currentPage = success.meta.pagination.current_page;
					    var totalPages = success.meta.pagination.total_pages;
					    if(currentPage >= totalPages){
						   this.no_more_results = true;
						   this.params["page"] = 1;
					    }else{
						   this.params["page"] = parseInt(this.params["page"]) + 1;
					    }
					},
					(error)=>{
					    error = error;
					    var msg = error.message;
					    this.generalFunctions.openToast(msg,3000,"error");
					},
					()=>{
					    this.server_request = false;  
					}
			     )
		}
	}

	filterQuery(e){
		this.generalFunctions.isFilled(e);
		if(e.target.value.length>0){
			this.params["query"] = this.search_customer_text;
		}else{
			delete this.params['query'];
		}
		this.getFirstData();
	}

	filterStatus(e){
		var li = (e.target.nodeName=='LI')?e.target: e.target.parentElement;
		var type = li.getAttribute("data-type");
		this.initial_load = type;
		this.params['type'] = this.initial_load;
		this.getFirstData();
	}

	resendFormLink(no){
		var obj = {};
		obj["phone"] = no;
		this.http.sendData('contact/add'+this.include_center,obj)
			.subscribe(
				(success)=>{
					var msg = "Formlink is resent to " + no +" succesfully.";
					this.generalFunctions.openToast(msg,3000,"success");
				},
				(err)=>{
					this.generalFunctions.openToast(err.message,3000,"error");
				}
			)
	}

	deleteFormLink(id,no){
		var endpoint = 'contact/formlink/'+id+this.include_center;
		this.http.deleteData(endpoint)
			.subscribe(
				(success)=>{
					var msg = "Formlink to " + no +" is succesfully deleted.";
					this.generalFunctions.openToast(msg,3000,"success");
					this.router
						.navigate(
							['../../refresh'], 
							{queryParams:
								{url: 'customers/formlink'}, 
								relativeTo: this.route
							}
						);
				},(error)=>{
					this.generalFunctions.openToast(error.message,3000,"success");
				}
			)
	}

}
