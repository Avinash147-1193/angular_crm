import {Component, OnInit} from '@angular/core';
import {ServerAuthService} from 'app/common/server-auth';
import {GeneralServices} from 'app/common/general-services';
import * as moment from 'moment';

@Component({selector: 'app-tasks-list', templateUrl: './tasks-list.component.html', styleUrls: ['./tasks-list.component.scss','../../services/styles/services.scss']})
export class TasksListComponent implements OnInit {
  centerId: string = '';
  allTasks: any = [];
  totalTasks: number = 0;
  tasksCountsResponse: any = {};
  taskTypes: any = [];

  tasksFilter: any = {};
  filteredTaskType: string = 'all';
  navigationActive: string = 'all';
  pop_up_for: any = null;
  animate: any = false;
  animateType: any = null;
  animateIndex: any = null;

  constructor(private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit() {
    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];

    this.getTasksCounts();
    this.getTasks('all');
  }

  getTasks(filterType) {
    switch (filterType) {
      case 'all':
        this.navigationActive = 'all';
        this.filteredTaskType = 'all';
        this.tasksFilter = {};
        break;

        case 'active':
            this.navigationActive = 'active';
            this.filteredTaskType = 'active';
            this.tasksFilter = {

            };
            break;

      case 'overdue':
        this.navigationActive = 'overdue';
        this.filteredTaskType = 'overdue';
        this.tasksFilter = {
          filterBy: {
            status: 3
          }
        };
        break;

      case 'complete':
        this.navigationActive = 'complete';
        this.filteredTaskType = 'complete';
        this.tasksFilter = {
          filterBy: {
            status: 2
          }
        };
        break;

      case 'today':
        this.navigationActive = 'today';
        this.filteredTaskType = 'overdue';
        let today = this.getTodayDate();
        this.tasksFilter = {
          filterBy: {
            due_date: today
          }
        };
        break;

      case 'tomorrow':
        this.navigationActive = 'tomorrow';
        this.filteredTaskType = 'overdue';
        let tomorrow = this.getTomorrowDate();
        this.tasksFilter = {
          filterBy: {
            due_date: tomorrow
          }
        };
        break;

      default:
        // code...
        break;
    }

    this.http.sendData('tasks?center_id=' + this.centerId, this.tasksFilter).subscribe(response => {

      this.allTasks = response.data;
      if (this.filteredTaskType === 'active') {
          this.allTasks = this.allTasks.filter(task => task.status !== 2)
      }
      console.log(this.allTasks);
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  getTasksCounts() {
    this.http.getData('tasks/counts?center_id=' + this.centerId).subscribe(response => {
      this.tasksCountsResponse = response;
    //   this.tasksCountsResponse['all'] = this.tasksCountsResponse['all'] - this.tasksCountsResponse['complete'];
      console.log(this.tasksCountsResponse);
      this.prepareTaskTypes();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  prepareTaskTypes() {
      this.taskTypes = [];
    for (var type in this.tasksCountsResponse) {
      // ignore complete tasks in left side filters
      if (type === 'complete') {
        continue;
      }

      let count = this.tasksCountsResponse[type];
      let task = {
        type: type,
        count: count
      };

      this.taskTypes.push(task);
    }
  }

  getStatus(index) {
    let task = this.allTasks[index];
    let dueDate = moment(task.due_date);
    let status = '';

    // let today = new Date();
    // today.setHours(0, 0, 0, 0);
    let timeDiff = moment().diff(dueDate, 'days')
    // let timeDiff = today.getTime() - dueDate.getTime();
    // let diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

    if (task.status === 2) {
      status = 'complete';
    } else if (timeDiff > 0) {
      status = 'overdue';
    } else {
      if (task.remind_on) {
        status = 'reminder';
        // let timeText = this.getTimeText(task);
        // let date = this.getDateText(task.remind_on.substr(0, 10));
        // task.reminderText = `${timeText}, ${date}`;
      } else {
        status = 'active';
      }
    }
    return status;
  }

  getReminder(date){
    return moment(date).format('hh:mm a, Do MMM')
  }


  getDateText(dateString) {

    return moment(dateString).format('Do MMM');
  }

  getDateYear(dateString){
    return moment(dateString).format('YYYY');
  }
  getTodayDate() {
    let now = moment();

    let dateString = now.format('YYYY-MM-DD');

    return dateString;
  }

  getTomorrowDate() {
    let now = moment();
    now.add(1, 'days');

    let dateString = now.format('YYYY-MM-DD');

    return dateString;
  }

  markComplete(statusCode, id) {
    new Audio('https://www.soundjay.com/button/sounds/button-30.mp3').play();

    let reqObj = {
        status: statusCode
    };
    this.http.patchData(`tasks/${id}/complete?center_id=${this.centerId}`, reqObj)
        .subscribe(
            (response) => {
                this.getTasks(this.navigationActive);
                this.getTasksCounts();
                    if (statusCode == 1) {
                        this.generalFunctions.openToast('Task marked as incomplete', 3000, 'success');

                    } else {
                        this.generalFunctions.openToast('Task marked as completed', 3000, 'success');
                    }
                       setTimeout(() => {
                            this.animate = false;
                            this.animateIndex = null;
                        }, 3000);
            },
            (error) => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
}
}
