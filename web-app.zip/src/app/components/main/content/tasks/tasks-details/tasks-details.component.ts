// tslint:disable: indent

import { Component, OnInit, OnChanges, ViewChild, ElementRef, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GeneralServices } from 'app/common/general-services';
import { ServerAuthService } from 'app/common/server-auth';
import { SelectItem } from 'primeng/api';
import * as moment from 'moment';


@Component({
	selector: 'app-tasks-details',
	templateUrl: './tasks-details.component.html',
	styleUrls: ['../../services/styles/services.scss', './tasks-details.component.scss'],
	encapsulation: ViewEncapsulation.None,
})

export class TasksDetailsComponent implements OnInit, OnChanges {
    pop_up_for: any = null;
	currency: any;
	center_id: any;
	isNewTask: boolean = true;
	taskId: string = '';
	pageLoader: boolean = false;
	staffLoader: boolean = false;

	taskDetails: any = {
		name: '',
		due_date: '',
		reminder_date: '',
		reminder_time: '',
		staffId: 0,
		description: '',
		isTaskComplete: false
	}

	taskDetailsResponse: any;

	reminderTime: any;

	validationFields: any = {
		taskName: false,
		dueDate: false,
		staffMember: false
	}

	staffMembers: any;
	staffDropdown: SelectItem[] = [];

	dueDatepickerConfig = {
		showWeekNumbers: false,
		containerClass: 'theme-default',
		// minDate: (moment())
	};

	reminderDatepickerConfig = {
		showWeekNumbers: false,
		containerClass: 'theme-default',
		// minDate: (moment())
	};

	isSetReminder: boolean = false;

	timeDropdown: SelectItem[] = [
		{ label: '00:00', value: '00:00' },
		{ label: '00:30', value: '00:30' },
		{ label: '01:00', value: '01:00' },
		{ label: '01:30', value: '01:30' },
		{ label: '02:00', value: '02:00' },
		{ label: '02:30', value: '02:30' },
		{ label: '03:00', value: '03:00' },
		{ label: '03:30', value: '03:30' },
		{ label: '04:00', value: '04:00' },
		{ label: '04:30', value: '04:30' },
		{ label: '05:00', value: '05:00' },
		{ label: '05:30', value: '05:30' },
		{ label: '06:00', value: '06:00' },
		{ label: '06:30', value: '06:30' },
		{ label: '07:00', value: '07:00' },
		{ label: '07:30', value: '07:30' },
		{ label: '08:00', value: '08:00' },
		{ label: '08:30', value: '08:30' },
		{ label: '09:00', value: '09:00' },
		{ label: '09:30', value: '09:30' },
		{ label: '10:00', value: '10:00' },
		{ label: '10:30', value: '10:30' },
		{ label: '11:00', value: '11:00' },
		{ label: '11:30', value: '11:30' },
		{ label: '12:00', value: '12:00' },
		{ label: '12:30', value: '12:30' },
		{ label: '13:00', value: '13:00' },
		{ label: '13:30', value: '13:30' },
		{ label: '14:00', value: '14:00' },
		{ label: '14:30', value: '14:30' },
		{ label: '15:00', value: '15:00' },
		{ label: '15:30', value: '15:30' },
		{ label: '16:00', value: '16:00' },
		{ label: '16:30', value: '16:30' },
		{ label: '17:00', value: '17:00' },
		{ label: '17:30', value: '17:30' },
		{ label: '18:00', value: '18:00' },
		{ label: '18:30', value: '18:30' },
		{ label: '19:00', value: '19:00' },
		{ label: '19:30', value: '19:30' },
		{ label: '20:00', value: '20:00' },
		{ label: '20:30', value: '20:30' },
		{ label: '21:00', value: '21:00' },
		{ label: '21:30', value: '21:30' },
		{ label: '22:00', value: '22:00' },
		{ label: '22:30', value: '22:30' },
		{ label: '23:00', value: '23:00' },
		{ label: '23:30', value: '23:30' },
	];

	isContactOverlay: boolean = false;
	isContactSearchEnabled: boolean = false;
	isContactSelected: boolean = false;
	searchCustomerTimeout: any = null;
	searchContactInput: any;
	contactResults: any = [];
	contactsDropdown: any;
	selectedContact: any;

	nextOne: boolean = false;

	constructor(
		private generalFunctions: GeneralServices,
		private router: Router,
		private http: ServerAuthService,
		private activatedRoute: ActivatedRoute,
	) { }

	ngOnInit() {
		this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
		this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];

		if (this.router.url.includes('/tasks/create')) {
			this.isNewTask = true;
			this.getStaffMembers();
		}
		else {
			this.isNewTask = false;

			this.taskId = this.activatedRoute.snapshot.paramMap.get('id')
			console.log(this.taskId);

			this.pageLoader = true;
			this.staffLoader = true;

			this.http.getData(`tasks/${this.taskId}?center_id=${this.center_id}`)
				// this.http.getData(`tasks?center_id=${this.center_id}`)
				.subscribe(
					(response) => {
						this.taskDetailsResponse = response.data;
						let td = this.taskDetailsResponse;

						// prepare edit task details form
						this.taskDetails.name = td.name;
						this.taskDetails.description = td.description;
						this.taskDetails.due_date = moment(td.due_date);
						this.taskDetails.isTaskComplete = (td.status === 1) ? false : true;
						this.taskDetails.logs = td.logs;

						if (td.remind_on && td.remind_on !== '') {
							this.isSetReminder = true;
							this.taskDetails.reminder_date = moment(td.remind_on.substr(0, 10));
							this.taskDetails.reminder_time = td.remind_on.substr(11, 5);
						}

						this.getStaffMembers();
						this.prepareContactSelect();

						console.log(this.taskDetails);
						this.pageLoader = false;

					},
					(error) => {
						this.generalFunctions.openToast(error.message, 3000, 'error');
					}
				);
		}
	}

	ngOnChanges(e) {
		console.log(e);
	}

	searchContactInputChange() {
		clearTimeout(this.searchCustomerTimeout);

		if (this.searchContactInput.length === 0) {
			this.contactResults = [];
		} else if (this.searchContactInput.length > 0) {
			this.searchCustomerTimeout = setTimeout(this.getContacts, 500);
		}
	}


	getContacts = () => {
		let searchFilter = {
			'filterBy': {
				'query': this.searchContactInput
			},
		}
		this.http.sendData('contact/search?center_id=' + this.center_id, searchFilter)
			.subscribe(
				response => {
					this.contactResults = response.data;
					console.log(this.contactResults);

					// this.prepareContactsDropdown();
				},
				err => {
					this.generalFunctions.openToast(err.message, 3000, 'error');
				},
				() => { }
			);
	}

	prepareContactSelect() {

		if (this.taskDetailsResponse.center_contact.length === 0) {
			return;
		}

		this.isContactSelected = true;
		this.selectedContact = this.taskDetailsResponse.center_contact
	}

	getStaffMembers() {
		this.http.getData('staff?center_id=' + this.center_id)
			.subscribe(
				response => {
					this.staffMembers = response.data;
					console.log(this.staffMembers);

					this.prepareStaffMembersDropdown();
				},
				err => {
					this.generalFunctions.openToast(err.message, 3000, 'error');
				},
				() => { }
			);
	}

	prepareStaffMembersDropdown() {
		for (let i = 0; i < this.staffMembers.length; i++) {
			let staffMember = this.staffMembers[i];

			let member = {
				label: '',
				value: 0
			};

			member.label = staffMember.first_name + ' ' + staffMember.last_name;
			member.value = staffMember.id;

			this.staffDropdown.push(member);
		}
		console.log(this.staffDropdown);

		if (!this.isNewTask) {
			this.taskDetails.staffId = this.taskDetailsResponse.staff.id;
			this.staffLoader = false;
		}
	}

	getFormStatus() {
		let isFormValid = true;

		for (var property in this.validationFields) {
			isFormValid = isFormValid && this.validationFields[property];
			if (!this.validationFields[property]) {
				this.generalFunctions.scrolltoinvalid(property);
				break;
			}
		}

		return isFormValid;
	}

	prepareTaskRequest() {
		let reqObj = {};
		reqObj = {
			name: this.taskDetails.name,
			remind_on: '',
			user_id: this.taskDetails.staffId,
			// center_contact_id: this.selectedContact.id,
			description: this.taskDetails.description,
			due_date: moment(this.taskDetails.due_date).format('YYYY-MM-DD')
		}

		if (this.isContactSelected) {
			reqObj['center_contact_id'] = this.selectedContact.id;
		}

		if (this.isSetReminder) {
			reqObj['remind_on'] = moment(this.taskDetails.reminder_date).format('YYYY-MM-DD') + ' ' + this.taskDetails.reminder_time;
		}

		return reqObj;
	}

	createTask() {

		this.nextOne = true;
		let isFormValid = this.getFormStatus();

		if (!isFormValid) {
			this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
			return;
		}

		let reqObj = this.prepareTaskRequest();

		this.http.sendData(`tasks/create?center_id=${this.center_id}`, reqObj)
			.subscribe(
				(response) => {
					this.router.navigate(['/client/tasks']);
					this.generalFunctions.openToast('Task created', 3000, 'success');
				},
				(error) => {
					this.generalFunctions.openToast(error.message, 3000, 'error');
				}
			);
	}

	saveTask() {

		this.nextOne = true;
		let isFormValid = this.getFormStatus();

		if (!isFormValid) {
			this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
			return;
		}

		let reqObj = this.prepareTaskRequest();

		this.http.updateData(`tasks/${this.taskId}?center_id=${this.center_id}`, reqObj)
			.subscribe(
				(response) => {
					console.log(response);
					this.router.navigate(['/client/tasks']);
					this.generalFunctions.openToast('Task saved', 3000, 'success');
				},
				(error) => {
					this.generalFunctions.openToast(error.message, 3000, 'error');
				}
			);
	}

	cancelChanges() {
		this.router.navigate(['/client/tasks']);
	}

	deleteTask() {

		this.http.deleteData(`tasks/${this.taskId}?center_id=${this.center_id}`)
			.subscribe(
				(response) => {
					console.log(response);
					this.router.navigate(['/client/tasks']);
                    this.generalFunctions.openToast('Task deleted', 3000, 'success');
                    this.pop_up_for = null;
				},
				(error) => {
                    this.generalFunctions.openToast(error.message, 3000, 'error');
                    this.pop_up_for = null;
				}
			);
	}

	markComplete(statusCode) {
		let reqObj = {
			status: statusCode
		};
		this.http.patchData(`tasks/${this.taskId}/complete?center_id=${this.center_id}`, reqObj)
			.subscribe(
				(response) => {
					this.taskDetails.isTaskComplete = !this.taskDetails.isTaskComplete;

					if (this.taskDetails.isTaskComplete) {
						this.generalFunctions.openToast('Task marked as completed', 3000, 'success');
						this.router.navigate(['/client/tasks']);
					} else {
                        this.generalFunctions.openToast('Task marked as incomplete', 3000, 'success');
                        this.router.navigate(['/client/tasks']);
					}
				},
				(error) => {
					this.generalFunctions.openToast(error.message, 3000, 'error');
				}
			);
	}

	formValidate(field) {
		let isValid = true;

		switch (field) {
			case 'task-name':
				isValid = (!this.taskDetails.name.replace(/\s/g, '').length) ? false : true; //check if field contains only whitespaces
				this.validationFields.taskName = isValid;
				break;

			case 'due-date':
				isValid = (this.taskDetails.due_date === '') ? false : true; //check if date is selected
				this.validationFields.dueDate = isValid;
				break;

			case 'staff-member':
				isValid = (this.taskDetails.staffId === 0) ? false : true; //check if date is selected
				this.validationFields.staffMember = isValid;
				break;

			default:
				break;
		}

		return !isValid;
	}

	setReminder() {
		this.isSetReminder = true;
	}

	removeReminder() {
		this.isSetReminder = false;
	}

	startContactSearch() {
		console.log('startContactSearch');
		this.isContactOverlay = true;
		this.enableContactSearch();

		// focus input box for contact search
		setTimeout(() => {
			document.getElementById('contact-input').focus();
		}, 1);

	}

	enableContactSearch() {
		this.isContactSearchEnabled = true;
	}

	disableContactSearch() {
		this.isContactSearchEnabled = false;
	}

	selectContact(index) {
		let person = this.contactResults[index];

		this.selectedContact = {
			id: person.id,
			name: person.contact.data.first_name + ' ' + person.contact.data.last_name,
			image: person.contact.data.image_url
		};

		this.isContactSelected = true;
		this.isContactSearchEnabled = false;

		this.resetContactSearch();
		this.closeContactOverlay();
	}

	resetContactSearch() {
		this.contactResults = [];
		this.searchContactInput = '';
	}

	removeContact() {
		this.isContactSelected = false;
		this.selectedContact = null;
	}

	closeContactOverlay() {
		this.isContactOverlay = false;
	}

	clickContactOverlay() {
		this.closeContactOverlay();
		this.disableContactSearch();
		this.resetContactSearch();
		this.removeContact();
	}

	getLoaderStatus() {
		return (this.pageLoader || this.staffLoader);
	}
}
