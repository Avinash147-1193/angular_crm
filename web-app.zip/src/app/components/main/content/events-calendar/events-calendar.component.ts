import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  ViewChild,
  TemplateRef,
  Directive,
  ElementRef,
  AfterViewInit,
  ViewEncapsulation,
  ChangeDetectorRef,
  Input
} from '@angular/core';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours
} from 'date-fns';
import {NgForm} from '@angular/forms';

import {Subject} from 'rxjs';
import * as moment from 'moment';

import {CalendarEvent, CalendarEventAction, CalendarEventTimesChangedEvent, CalendarView} from 'angular-calendar';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {SelectItem, SelectItemGroup} from 'primeng/api';
import {ActivatedRoute} from '@angular/router';

import 'rxjs/add/operator/filter';

import { ConnectionService } from 'ng-connection-service';
import {defineLocale, enGbLocale} from 'ngx-bootstrap/chronos';
import {BsLocaleService} from 'ngx-bootstrap/datepicker';


const colors: any = {
  red: {
    primary: '#ad2121',
    secondary: '#FAE3E3'
  },
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF'
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA'
  }
};

@Component({templateUrl: './events-calendar.component.html', styleUrls: ['./events-calendar.component.scss'],
changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None})
export class EventsCalendarComponent implements OnInit,
AfterViewInit {
  @ViewChild('modalContent')modalContent: TemplateRef<any>;

  view: CalendarView = CalendarView.Week;

  CalendarView = CalendarView;

  viewDate: Date = new Date();

  modalData: {
    action: string;
    event: CalendarEvent;
  };

  filter = {
    filterBy: {
      user_id: [],
      facility_id: []
    }
  };
  colorsArr = ['#ffebeb', '#ffeee0', '#fcfad9', '#eafcd9', '#defcf2', '#e0f4ff', '#e8e9ff', '#f5e8ff', '#ffe6f6', '#f0f0f0', '#f5e8ff', '#ffe6f6', '#f0f0f0'];
  colorsDarkArr = ['#eb6363', '#ff9500', '#ebd700', '#89cc49', '#4bdbab', '#00ace0', '#6b70ff', '#bb6df2', '#ff73cc', '#9c9c9c'];


  actions: CalendarEventAction[] = [
    {
      label: '<i class="fa fa-fw fa-pencil"></i>',
      onClick: ({event} : {
        event: CalendarEvent
      }): void => {
        this.handleEvent('Edited', event);
      }
    }, {
      label: '<i class="fa fa-fw fa-times"></i>',
      onClick: ({event} : {
        event: CalendarEvent
      }): void => {
        this.events = this.events.filter(iEvent => iEvent !== event);
        this.handleEvent('Deleted', event);
      }
    }
  ];

  trainersDropdown: SelectItem[] = [];
  trainersDropdownGroup: any;
  facilities: any;
  facilityDropdown: SelectItem[] = [];

  messageOverlay: boolean = false;
  refresh: Subject<any> = new Subject();

  events: CalendarEvent[] = [];

  activeDayIsOpen: boolean = true;

  centerId: string;
  currency: any;
  classes: any;
  showInitial: boolean = true;
  showFiltersOverlay: boolean = false;
  showClassBookingOverlay: boolean = false;
  showAppointmentBookingOverlay: boolean = false;
  showMessageOverlay: boolean = false;
  showCustomerOverlay: boolean = false;
  pickPtOverlay: boolean = false;
  pickRPTOverlay: boolean = false;
  showCustomerPricing: boolean = false;
  showEditOverlay: boolean = false;
  showOneOfOverlay: boolean = false;
  showPtInitial: boolean = true;
  showPtMessage: boolean = false;
  groupMessage: any = {
    subject: '',
    channel: 'mail',
    message: '',
    fromEmail: ''
  };
  smsNum: any = 0;
  isDisableSubmit: boolean = false;
  pop_up_for: any = null;
  show_pop_up: any = null;
  selectedEventEdit: any;
  members: any;
  selectedEvent: any;
  eventsFetched: any;
  appointmentSlots: any;
  searchCustomerInput: string = '';
  searchCustomerTimeout: any = null;
  customerResults: any = [];
  selectedCustomer: any;
  customerBookingInfo: any = {};
  filterTrainers: any = [];
  filterPT: boolean = false;
  obj: any;
  centerSettings: any;
  senderEmailsDropdown: SelectItem[] = [];

  // availabilityType: string = 'hide';

  smsMessage: any = '';

  searchFilter: any = {
    filterBy: {
      query: null
      //user_id : [],
      //room: []
    },
    sortBy: {},
    page: 1,
    include: 'address'
  };

  yoDisabled: boolean = false;

  calendarFilters = {
    filterPT: false,
    selectedTrainers: [],

    viewSlotsType: 'show'
  };

  tempCalendarFilters = {
    filterPT: false,
    selectedTrainers: [],
    viewSlotsType: 'show'
  };

  allServices: any;
  classesServiceId: any;
  appointmentsServiceId: any;

  checkedinFilter: string = 'all';

  availablePaymentModes: any = [];
  enabledPaymentModes: SelectItemGroup[] = [];
  selectedPaymentMode: string = '';

  classGroups: SelectItem[] = [];
  classGroupsList: any;
  trainersGroup: SelectItem[] = [];
  trainersGroupsList: any;

  membershipsPricingGroup: SelectItem[] = [];
  membershipsPricingList: any;

  requestObject: any;

  // Loaders
  pricingLoader: boolean = false;

  floatingPos: boolean = false;
  disableBooking: boolean = false;
  senderId: any = [];

  //one of class
  defaultDate: Date = new Date();
  defaultDateStart: Date = new Date();
  defaultDateEnds: Date = new Date();
  createClass: any = {
    service_id: 3,
    service_type_id: '',
    date: this.defaultDate,
    starts_at: this.defaultDateStart,
    ends_at: this.defaultDateEnds
  };

  createPt: any = {
    service_id: 2,
    id: '',
    date: this.defaultDate,
    starts_at: this.defaultDateStart,
    duration: '',
    user_id: '',
    is_recurring: false,
    cycles: {
      type: 'weekly',
      offset: 1
    },
    max_occurences: 6,
    days: {
      mon: false,
      tue: false,
      wed: false,
      thu: false,
      fri: false,
      sat: false,
      sun: false
    },
    ends: 'on',
    end_date: this.defaultDateEnds
  };

  recurringPtStaging: boolean = false;
  stageSlots: any;

  startDatepickerConfig = {
	showWeekNumbers: false,

	containerClass: 'theme-default',
	startingDay : 1
  };

  endDatePickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default'
  };
  disableBook: false;

  isAddCard: boolean = false;

  @ViewChild('cardInfo')cardInfo: ElementRef;
  @ViewChild('cardModal')cardModal: ElementRef;
  @ViewChild('dropDown')dropDown: ElementRef;
  card: any;
  cardHandler = this.onChange.bind(this);
  error: string;
  savedCards: any;
  buttonHere: any = null;
  stripeConnected: any = false;
  addingCard: any = false;
  selectedCard: any = null;
  dropdownLoaded: any = false;
  isPayLater: boolean;
  tool_tip_for: any = null;
  selectedCreditModel: any;

  ptDropdown: SelectItem[] = [];
  ptList: any;

  pickedTrainersDropdown: SelectItem[] = [];
  waitlistSettings: any;
  calendarLoader: boolean = true;

  daysModel: [
    'mon',
    'tue',
    'wed',
    'thu',
    'fri',
    'sat',
    'sun'
  ];
  weekDay: any = {
    mon: false,
    tue: false,
    wed: false,
    thu: false,
    fri: false,
    sat: false,
    sun: false
  };
  selectedDays: any = [];
  categories : any;


  addLink: any = false;
  addRecordedLink: any = false;
  link: any = '';
  addSubstitute = false;
  showCourseOverlay = false;
    courseGroupList: any;
    courseGroup:  SelectItem[] = [];
    courseType: SelectItem[] = [];
    courseLoading: boolean = false;
    scheduleLoader: boolean;

  constructor(private el : ElementRef, private localeService : BsLocaleService, private generalFunctions : GeneralServices, private http : ServerAuthService, private cdRef : ChangeDetectorRef, private route : ActivatedRoute, private connectionService: ConnectionService) {
	//time initialization for one of class
	defineLocale('en-gb', enGbLocale);

    this.defaultDateStart.setHours(9, 0, 0);
	this.defaultDateEnds.setHours(10, 0, 0);
  }

  ngOnInit() {
	// console.log('init');
	this.localeService.use('en-gb');

    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.getSenderEmails();
    this.getCenterData();
    this.getAllServices();
    this.getTrainers();
    this.getAllFacility();
	this.getSettings();
	this.getCategory();
    this.route.queryParams.filter(params => params.event).subscribe(params => {
      let event = params.event;
      if (event) {

        setTimeout(() => {
          this.findEventId(event);
        }, 1000);
      }
    });
    document.addEventListener('click', event => {
      this.documentClickHandler(event);
    });
  }

  ngAfterViewInit() {
    this.el.nativeElement.focus();

    const style = {
      base: {
        lineHeight: '24px',
        fontSize: '14px',
        '::placeholder': {
          color: '#546a7b'
        }
      }
    };
    this.card = elements.create('card', {
      hidePostalCode: true,
      style: style
    });
    this.cardInfo.nativeElement.focus();
    this.card.mount(this.cardInfo.nativeElement);
    this.card.addEventListener('change', this.cardHandler);
  }

  ngOnDestroy() {
    if (this.card.removeEventListener('change', this.cardHandler)) {
      this.card.removeEventListener('change', this.cardHandler);
      this.card.destroy();
    }
  }

  onChange({error}) {
    if (error) {
      this.error = error.message;
    } else {
      this.error = null;
    }
    this.cdRef.detectChanges();
  }

  async onSubmit(form : NgForm) {
    this.addingCard = true;
    const {token, error} = await stripe.createToken(this.card);
    if (error) {
      this.addingCard = false;
    } else {
      this.addCard(token.id);
      // ...send the token to the your backend to process the charge
    }
  }



  addCard(token) {
    this.http.sendData('contact/' + this.selectedCustomer.id + '/payment/sources?center_id=' + this.centerId, {token: token}).subscribe(response => {
      this.generalFunctions.openToast('Card successfully added for the customer', 2000, 'success');
      this.cardModal.nativeElement.style.display = 'none';
      this.addingCard = false;
      this.selectedCard = response.data.id;
      this.preparePaymentModes();
    }, error => {
      this.addingCard = false;
      this.cardModal.nativeElement.style.display = 'none';

      this.preparePaymentModes();
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  setView(view : CalendarView) {
    const currentTime = document.getElementsByClassName('cal-current-time-marker');
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  prepareTrainersMultiselect() {
    this.trainersDropdownGroup.forEach(element => {
      let trainer = {
        label: '',
        value: 0
      };
      trainer.label = element.first_name + ' ' + element.last_name;
      trainer.value = element.id;
      this.trainersDropdown.push(trainer);
    });
  }

  getTrainers() {
    this.http.getData('staff?center_id=' + this.centerId).subscribe(response => {
      this.trainersDropdownGroup = response.data;
      this.prepareTrainersMultiselect();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  getCenterData() {
    this.http.getData('center/' + this.centerId).subscribe(success => {
      success.data.gateway_id
        ? (this.stripeConnected = true)
        : (this.stripeConnected = false);
        let senderId = success.data.settings.automations.channels.sms;

      if (senderId == 1) {
        this.senderId.push('sms')
      }
    }, error => {
		this.generalFunctions.openToast(error,3000,'error')
	});
  }


  getCategory(){
	this.http.getData('categories?center_id=' + this.centerId + '&service_id=3'  ).subscribe(response => {
		this.categories = response.data;
	  }, err => {
		err = err;
		this.generalFunctions.openToast(err.message, 3000, 'error');
	  });
  }

  groupMessageClick() {
    if (this.senderId.includes('sms')) {
        this.groupMessage.message = '';
        this.groupMessage.channel = 'sms';

    }
  }

  getAllServices() {
    this.http.getData('center/' + this.centerId + '/services').subscribe(response => {
      this.allServices = response;
      // console.log(this.allServices);

      for (let i = 0; i < this.allServices.length; i++) {
        let service = this.allServices[i];

        if (service.service.code === 'CLASSES') {
          this.classesServiceId = service.service_id;
        } else if (service.service.code === 'APPOINTMENTS') {
          this.appointmentsServiceId = service.service_id;
        }
      }

      this.getEvents();
      this.getAvailableTrainers();
    }, err => {
      err = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  getEvents() {
    let data = {
      filterBy: this.filterQueryRequest(this.viewDate)
    };
    this.http.sendData('events?center_id=' + this.centerId, data).subscribe(response => {
      this.eventsFetched = response.data;
      this.createCalendarEvents();
      const currentTime = document.getElementsByClassName('cal-current-time-marker');
      if (currentTime) {
        currentTime[0].scrollIntoView({block: 'center', behavior: 'smooth'});
      }
    }),
    err => {
		this.generalFunctions.openToast(err.message, 3000,'error');
	},
    () => {};
  }

  scrollV() {
    const currentTime = document.getElementsByClassName('cal-current-time-marker');
    if (currentTime) {
      setTimeout(() => {
        currentTime[0].scrollIntoView({block: 'center', behavior: 'smooth'});
      }, 500);
    }
  }

  getAppointments(selectedTrainers) {
    let reqObj = {
      user_id: selectedTrainers, // array of trainers - selected in filters
      show_unbooked: true // by default fetch all appointment slots
    };

    this.http.sendData('appointments/slots?center_id=' + this.centerId, reqObj).subscribe(response => {
      this.appointmentSlots = response.data;
      // console.log(this.appointmentSlots);

      this.createCalendarAppointments();
    }),
    err => {},
    () => {};
  }

  // createCalendarClasses() {
  // 	for (let i = 0; i < this.classes.length; i++) {
  // 		let singleClass = this.classes[i];
  // 		for (let j = 0; j < singleClass.schedule.length; j++) {
  // 			let singleDay = singleClass.schedule[j];
  // 			for (let k = 0; k < singleDay.slots.length; k++) {
  // 				let slot = singleDay.slots[k];
  // 				let classEvent;
  // 				let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  // 				let months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  // 				let start = this.getCalendarTime(singleDay.day, slot.from);
  // 				let end = this.getCalendarTime(singleDay.day, slot.to);
  // 				let startTime = this.getReadableTime(slot.from);
  // 				let endTime = this.getReadableTime(slot.to);
  // 				let eventFullDate = `${days[start.getDay()]}, ${start.getDate()} ${months[start.getMonth()]} ${start.getFullYear()}`;

  // 				classEvent = {
  // 					'start': start,
  // 					'end': end,
  // 					'title': singleClass.name,
  // 					'startTime': startTime,
  // 					'endTime': endTime,
  // 					'duration': this.getSlotDuration(slot.from, slot.to),
  // 					'eventDate': eventFullDate,
  // 					'color': colors.blue,
  // 					'actions': this.actions
  // 				};

  // console.log(classEvent);
  // 				this.events.push(classEvent);
  // console.log(this.events);
  // 			}
  // 		}
  // 	}

  // 	this.refresh.next();
  // }

  createCalendarEvents() {
    this.events.length = 0;

    for (let i = 0; i < this.eventsFetched.length; i++) {
      let event = this.createCalendarEventsFactory(this.eventsFetched[i]);
      if (event['type'] == 'pt-event' && (event.bookings == undefined || event.bookings.length == 0)) {
        // continue;
      } else {
        // let rand = Math.ceil(Math.random() * 10);

        event['color'] = event['color'] ? this.colorsArr[this.colorsDarkArr.indexOf(event['color'])] :  this.colorsArr[4];
        event['colorDark'] = event['color'] ? this.colorsDarkArr[this.colorsArr.indexOf(event['color'])] : this.colorsDarkArr[4];
        this.events.push(event);
      }
    }

    this.refresh.next();
    this.calendarLoader = false;
    this.cdRef.detectChanges();
  }

  createCalendarEventsFactory(singleEvent) {
    // reset calendar events array

    var days = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    var months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];

    var eventName = singleEvent.name;
    var customerName = singleEvent.name;
    var eventStartsAt = this.getDate(singleEvent.starts_at); // Date object
    var eventEndsAt = this.getDate(singleEvent.ends_at); // Date object

    var startTime = this.getReadableTime(eventStartsAt);
    var endTime = this.getReadableTime(eventEndsAt);
    var eventFullDate = `${
    days[eventStartsAt.getDay()]}, ${eventStartsAt.getDate()} ${
    months[eventStartsAt.getMonth()]} ${eventStartsAt.getFullYear()}`;
    var bookings = singleEvent.bookings;
    var eventType;
    var user = singleEvent.users;
    var isSubmitted = singleEvent.attendance_submitted_at
      ? true
      : false;
    var trainersText = 'No trainer';
    // console.log('evnt', 'starts', moment(eventStartsAt).add(-1, 'hour').format('LLLL'),  eventStartsAt)
    var canSubmitAttendance = moment(moment(eventStartsAt).add(-1, 'hour').format('LLLL')).isSameOrBefore();
    var waitlist_count = singleEvent.waitlist_count;
    // start -- trainers data
    var trainers = singleEvent.users;
    let subTrainers = false;
    // if pt or class different logic else course different logic
    if(singleEvent.service_id === this.classesServiceId || singleEvent.service_id === this.appointmentsServiceId) {
    trainers.filter(trainer => trainer.status === 1 && trainer.type === 2).length > 0 ?  subTrainers = true : subTrainers = false;

      if (!subTrainers) {
        if (trainers[0]) {
          trainersText = trainers[0].type === 1 ? trainers[0].name : ''

          if (trainers.length > 1) {
              trainers.forEach((trainer , i) => {
                  if (i !== 0 && trainer.type === 1) {
                      if(trainers[i-1].type === 1 ){
                        trainersText += `, ${trainer.name}`
                      } else {
                        trainersText += ` ${trainer.name}`
                      }
                  }
              });
          }
        }
      } else {
        if (trainers[0]) {
          trainersText = trainers[0].type === 2 && trainers[0].status === 1
          ? trainers[0].name + ' (sub)'
          : ''

          if (trainers.length > 1) {
              trainers.forEach((trainer , i) => {
                  if (i !== 0 && trainer.type === 2 && trainer.status === 1 ) {
                      if (trainers[i-1].type === 1) {
                        trainersText += `${trainer.name} (sub)`
                      } else if (trainers[i-1].type === 2 && trainers[i-1].status === 2) {
                        trainersText += `${trainer.name} (sub)`
                      } else {
                        trainersText += `, ${trainer.name} (sub)`
                      }
                  }
              });
          }
        }
      }
    } else if (singleEvent.service_id === 6)  {

        if (trainers[0]) {
            trainersText = trainers[0].status === 1 ? trainers[0].name : ''

            if (trainers.length > 1) {
                trainers.forEach((trainer , i) => {
                    if (i !== 0 && trainer.status === 1) {
                        if(trainers[i-1].status === 1 ){
                          trainersText += `, ${trainer.name}`
                        } else {
                          trainersText += ` ${trainer.name}`
                        }
                    }
                });
            }
          }

    }

    // end -- trainers data

    if (singleEvent.service_id === this.classesServiceId ) {
      eventType = 'class-event';
    } else if (singleEvent.service_id === 2) {
      eventType = 'pt-event';
    } else if (singleEvent.service_id === 6) {
        eventType = 'course';
    }
    // console.log('singleEvent.waitlist_count', singleEvent.waitlist_count)
    var calendarEvent = {
      type: eventType,
      eventId: singleEvent.id,
      start: eventStartsAt,
      end: eventEndsAt,
      title: eventName,
      customer: customerName,
      booked_count: singleEvent.booked_count,
      max_allowed: singleEvent.max_allowed,
      startTime: startTime,
      endTime: endTime,
      duration: this.getSlotDuration(eventStartsAt, eventEndsAt),
      eventDate: eventFullDate,
      bookings: bookings,

      imageURL: '/assets/img/sample-user-icon.svg',
      trainersText: trainersText,
      user: user,
      isSubmitted: isSubmitted,
      canSubmitAttendance: canSubmitAttendance,
      waitlist_count : waitlist_count,
        color : singleEvent.color,
    };
    return calendarEvent;
  }

  createCalendarAppointments() {
    // reset calendar events array
    this.events.length = 0;

    for (let i = 0; i < this.appointmentSlots.length; i++) {
      let singleSlot = this.appointmentSlots[i];
      if (singleSlot.type == 2) {
        continue;
      }

      let days = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday'
      ];
      let months = [
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec'
      ];

      let customerName = singleSlot.customer;
      let eventStartsAt = this.getDate(singleSlot.starts_at); // Date object
      let eventEndsAt = this.getDate(singleSlot.ends_at); // Date object

      let startTime = this.getReadableTime(eventStartsAt);
      let endTime = this.getReadableTime(eventEndsAt);
      let eventFullDate = `${
      days[eventStartsAt.getDay()]}, ${eventStartsAt.getDate()} ${
      months[eventStartsAt.getMonth()]} ${eventStartsAt.getFullYear()}`;
      let bookings = singleSlot.bookings;
      let canSubmitAttendance = moment(eventStartsAt).isSameOrBefore();
      let eventType;
      let oneOff = false;

      if (singleSlot.event_id && singleSlot.customer) {
        eventType = 'pt-event';
      } else {
        if (singleSlot.event_id && !singleSlot.customer) {
          oneOff = true;
        }
        eventType = 'pt-unbooked';
      }

      // if(singleSlot.service_id == 2 ){
      // 	console.log(singleSlot);
      // 	eventType = "pt-event";
      // }

      let calendarEvent = {
        oneOff: oneOff,
        type: eventType,
        slotType: singleSlot.type,
        eventId: singleSlot.event_id,
        unavailability_id: singleSlot.unavailability_id,
        slot_id: singleSlot.slot_id,
        appointmentId: singleSlot.appointment_id,
        slottype: singleSlot.type,
        start: eventStartsAt,
        end: eventEndsAt,
        title: customerName,
        customer: customerName,
        trainer: singleSlot.trainer,
        trainersText: singleSlot.trainer,
        startTime: startTime,
        endTime: endTime,
        duration: this.getSlotDuration(eventStartsAt, eventEndsAt),
        eventDate: eventFullDate,
        bookings: bookings,
        isSubmitted: singleSlot.attendance_submitted_at
          ? true
          : false,
        imageURL: '/assets/img/sample-user-icon.svg',
        canSubmitAttendance: singleSlot.attendance_submitted_at
          ? true
          : false && canSubmitAttendance && (Array.isArray(bookings) && bookings.length > 0),
        starts_at: singleSlot.starts_at,
        ends_at: singleSlot.ends_at,
        color: singleSlot.color
      };

      // Hide unbooked slots
      if (this.calendarFilters.viewSlotsType === 'hide') {
        if (eventType === 'pt-event') {
          this.events.push(calendarEvent); // show all slots;
        }
      } else {
        this.events.push(calendarEvent);
      }
    }

    // console.log(this.events);
    this.refresh.next();
  }

  // converts date string of type '2018-11-19 01:00:00' to javascript date object
  getDate(dateString : string) {
    let YYYY = parseInt(dateString.substr(0, 4));
    let MM = parseInt(dateString.substr(5, 2)) - 1;
    let DD = parseInt(dateString.substr(8, 2));
    let hh = parseInt(dateString.substr(11, 2));
    let mm = parseInt(dateString.substr(14, 2));
    let ss = parseInt(dateString.substr(17, 2));

    let date = new Date(YYYY, MM, DD, hh, mm, ss);

    return date;
  }

  getCalendarTime(day, time) {
    let d = new Date();

    // set date for current week based on day (Monday:1, Tuesday:2, etc.)
    d.setDate(d.getDate() + (day + 7 - d.getDay()) % 7);
    // set hours based on time
    d.setHours(time.substr(0, 2));
    // set minutes based on time
    d.setMinutes(time.substr(3, 2));

    return d;
  }

  getReadableTime(date) {
    let hour,
      min,
      meridian,
      result;
    hour = date.getHours();
    min = date.getMinutes();

    if (hour < 12) {
      meridian = 'am';
    } else if (hour === 12) {
      meridian = 'pm';
    } else if (hour > 12) {
      hour = hour % 12;
      meridian = 'pm';
    }
    min = min < 10
      ? '0' + min
      : min;
    result = `${hour}:${min}${meridian}`;
    return result;
  }

  getSlotDuration(startDate, endDate) {
    let duration,
      result;

    // duration in minutes
    duration = (endDate.valueOf() - startDate.valueOf()) / 1000 / 60;

    // hours/mins conversion
    if (duration >= 60) {
      let hours = Math.floor(duration / 60);
      let mins = duration % 60;
      result = mins > 0
        ? `${hours}hr ${mins}mins`
        : `${hours}hr`;
    } else {
      result = `${duration}mins`;
    }

    return result;
  }

  getSlotDurationOld(from, to) {
    let fromDate = new Date();
    let toDate = new Date();
    let duration,
      result;

    fromDate.setHours(from.substr(0, 2));
    fromDate.setMinutes(from.substr(3, 2));
    fromDate.setSeconds(0);

    toDate.setHours(to.substr(0, 2));
    toDate.setMinutes(to.substr(3, 2));
    toDate.setSeconds(0);

    // duration in minutes
    duration = (toDate.valueOf() - fromDate.valueOf()) / 1000 / 60;

    // hours/mins conversion
    if (duration >= 60) {
      let hours = Math.floor(duration / 60);
      let mins = duration % 60;
      result = mins > 0
        ? `${hours}hr ${mins}mins`
        : `${hours}hr`;
    } else {
      result = `${duration}mins`;
    }

    return result;
  }

  getCustomers = () => {
    this.searchFilter['filterBy']['query'] = this.searchCustomerInput;
    this.http.sendData('contact/search?center_id=' + this.centerId, this.searchFilter).subscribe(response => {
      this.customerResults = [];
      this.customerResults = response.data;
      // disable already booked customers
      if (this.selectedEvent.bookings) {
        this.disableBookedCustomers();
      }
      this.cdRef.detectChanges();
      // Tell Angular to detect changes to customer results
    }),
    err => {},
    () => {};
  };

  disableBookedCustomers() {
    for (let i = 0; i < this.customerResults.length; i++) {
      for (let j = 0; j < this.selectedEvent.bookings.length; j++) {
        if (this.customerResults[i].id === this.selectedEvent.bookings[j].center_contact_id && this.selectedEvent.bookings[j].status !== 3) {
          this.customerResults[i].alreadyBooked = true;
        }
      }
    }
    this.customerResults = [...this.customerResults];

  }

  dayClicked({date, events} : {
    date: Date;
    events: CalendarEvent[]
  }): void {
    if (isSameMonth(date, this.viewDate)) {
      this.viewDate = date;
      if ((isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) || events.length === 0) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
    }
  }

  eventTimesChanged({event, newStart, newEnd} : CalendarEventTimesChangedEvent): void {
    event.start = newStart;
    event.end = newEnd;
    this.handleEvent('Dropped or resized', event);
    this.refresh.next();
  }

  handleEvent(action : string, event : CalendarEvent): void {
    if (event['type'] === 'class-event') {
      this.showClassBookingOverlay = true;
      this.getEventInfo(event);
    } else if (event['type'] === 'pt-event') {
      this.showAppointmentBookingOverlay = true;
      this.getPtEventInfo(event);
    } else if (event['type'] === 'pt-unbooked') {
      this.showAppointmentBookingOverlay = true;
      this.getAvailabilitySlotInfo(event);
    } else if (event['type'] === 'course') {
        this.showCourseOverlay = true;
        this.getEventInfo(event);
      }
  }

  addEvent(): void {
    this.events.push({
      title: 'New event',
      start: startOfDay(new Date()),
      end: endOfDay(new Date()),
    //   color: colors.red,
      draggable: true,
      resizable: {
        beforeStart: true,
        afterEnd: true
      }
    });
    this.refresh.next();
  }

  closeFiltersOverlay() {
    this.showFiltersOverlay = false;
  }

  closeClassBookingOverlay() {
    this.showClassBookingOverlay = false;
    this.showInitial = true;
    this.showEditOverlay = false;
    this.showMessageOverlay = false;
    this.addLink = false;
    this.addRecordedLink = false;
  }

  closeCourseBookingOverlay() {
    this.showCourseOverlay = false;
    this.showInitial = true;
    this.showEditOverlay = false;
    this.showMessageOverlay = false;
  }

  closeAppointmentBookingOverlay() {
    this.showAppointmentBookingOverlay = false;
    this.showPtInitial = true;
    this.showPtMessage = false;
  }

  bookCustomer() {
    this.showCustomerOverlay = true;
  }

  closeCustomerOverlay() {
    this.showCustomerOverlay = false;
    this.showCustomerPricing = false;
    this.pickPtOverlay = false;
    this.searchCustomerInput = '';
    this.customerResults = [];
  }

  searchCustomerInputChange() {
    // console.log(this.searchCustomerInput);
    // console.log(this.customerResults);
    clearTimeout(this.searchCustomerTimeout);
    if (this.searchCustomerInput.length < 2) {
      this.customerResults = [];
    } else if (this.searchCustomerInput.length > 2) {
      this.searchCustomerTimeout = setTimeout(() => this.getCustomers(), 30);
    }
  }

  selectCustomer(i) {
    this.resetPaymentOptions();
    this.selectedCustomer = this.customerResults[i];
    this.membershipsPricingGroup = [];
    if (this.selectedEvent.type === 'class-event') {
      this.getClassPricing();
    } else if (this.selectedEvent.type === 'pt-event' || this.selectedEvent.type === 'pt-unbooked') {
      this.getPtPricing();
      // this.getAppointmentPricing();
    }
  }

  searchRPTCustomerInputChange() {
    // console.log(this.searchCustomerInput);
    // console.log(this.customerResults);
    clearTimeout(this.searchCustomerTimeout);
    if (this.searchCustomerInput.length < 2) {
      this.customerResults = [];
    } else if (this.searchCustomerInput.length > 2) {
      this.searchCustomerTimeout = setTimeout(() => this.getRPTCustomers(), 30);
    }
  }

  getRPTCustomers = () => {
    this.searchFilter['filterBy']['query'] = this.searchCustomerInput;
    this.http.sendData('contact/search?center_id=' + this.centerId, this.searchFilter).subscribe(response => {
      this.customerResults = [];
      this.customerResults = response.data;

      this.cdRef.detectChanges();
    }),
    err => {},
    () => {};
  };

  selectRPTCustomer(i) {
    this.resetPaymentOptions();
    this.selectedCustomer = this.customerResults[i];
    this.membershipsPricingGroup = [];

    this.getRPTPricing();
    // this.getAppointmentPricing();
  }

  resetPaymentOptions() {
    this.selectedPaymentMode = '';
  }

  getClassPricing() {
    this.http.getData(`events/${this.selectedEvent.eventId}/price/${this.selectedCustomer.id}?center_id=${this.centerId}`)
    .subscribe(response => {
      let pricingInfo = response;
      //check for dropin or not
      if (pricingInfo.membership.length == 0 && pricingInfo.price == 'invalid') {
        this.buttonHere = 'button-buy';
      } else if (pricingInfo.membership.length > 0) {
        this.prepareBookingDropdwon(pricingInfo);
      } else if (pricingInfo.price === 0) {
        this.buttonHere = 'button-free';
      }
      // this.customerBookingInfo["credits"] = parseInt(pricingInfo.credits);
      // this.customerBookingInfo["membership"] = pricingInfo.membership;
      // if (pricingInfo.price == 'invalid') {
      // 	this.customerBookingInfo["price"] = 'invalid'
      // } else {
      // 	this.customerBookingInfo["price"] = parseInt(pricingInfo.price);
      // }
      this.getSettings();
      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  prepareBookingDropdwon(pricingInfo) {
    pricingInfo.membership.forEach(event => {
      let structure = {
        value: '',
        label: ''
      };
      structure.label = event.service_model.name + ' (' + (
        event.credits !== -1
        ? event.credits
        : 'Unlimited') + ' credits, exp.' + moment(event.expires_at).format('D MMM Y') + ')';
      structure.value = event.credit_id;
      this.membershipsPricingGroup.push(structure);
    });
    this.selectedCreditModel = this.membershipsPricingGroup[0].value;
    this.buttonHere = 'button-credits';
    // this.membershipsPricingGroup.push()
  }

  getAppointmentPricing() {
    this.http.getData(`appointments/${this.selectedEvent.appointmentId}/prices/${this.selectedCustomer.id}?center_id=${this.centerId}`).subscribe(response => {
      let pricingInfo = response;

      this.customerBookingInfo['credits'] = parseInt(pricingInfo.credits);
      this.customerBookingInfo['membership'] = pricingInfo.membership;
      if (pricingInfo.price == 'invalid') {
        this.customerBookingInfo['price'] = 'invalid';
      } else {
        this.customerBookingInfo['price'] = parseInt(pricingInfo.price);
      }

      this.getSettings();

      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  getEventInfo(event) {
    let eventInfo;
    this.selectedEvent = event;

    this.http.getData(`events/${this.selectedEvent.eventId}?center_id=${this.centerId}`).subscribe(response => {
      eventInfo = response.data;

      // Bookings data
      this.selectedEvent.bookings = eventInfo.bookings;
      this.selectedEvent.maxAllowed = eventInfo.max_allowed;
      this.selectedEvent.description = eventInfo.description;
      eventInfo.visibility == 1
        ? (this.selectedEvent.visibility = true)
        : (this.selectedEvent.visibility = false);
      this.selectedEvent.level = eventInfo.service_data[0].level;
      // checkin count
      this.selectedEvent.totalBooked = eventInfo.bookings.length;
      this.selectedEvent.checkedinCount = 0;
      this.selectedEvent.facility_id = eventInfo.facility_id;
      this.selectedEvent.created_at = eventInfo.created_at;
      this.selectedEvent.waitlist_count = eventInfo.waitlist_count;
      this.selectedEvent.booked_count = eventInfo.booked_count;
      this.facilities.forEach(element => {
        if (this.selectedEvent.facility_id == element.id) {
          this.selectedEvent.locationText = element.name;
        }
      });

      this.selectedEvent.is_online = eventInfo.is_online;
      this.selectedEvent.event_app = eventInfo.event_app;
      this.selectedEvent.event_url = eventInfo.event_url;
      this.selectedEvent.recorded_url = eventInfo.recorded_url;

      this.hasEventPast();

      for (let i = 0; i < eventInfo.bookings.length; i++) {
        let booking = eventInfo.bookings[i];
        if (booking.checkin_status === 1) {
          this.selectedEvent.checkedinCount++;
        }
      }
      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  hasEventPast() {
    console.log('this.selectedEvent', this.selectedEvent)
    this.disableBooking = moment().isBefore(moment(this.selectedEvent.end).add(1, 'days'), 'day') && !this.selectedEvent.isSubmitted;
}

  getAvailabilitySlotInfo(event) {
    this.selectedEvent = event;
  }

  getPtEventInfo(event) {
    let eventInfo;
    this.selectedEvent = event;

    this.http.getData(`events/${this.selectedEvent.eventId}?center_id=${this.centerId}`).subscribe(response => {
      eventInfo = response.data;

      // Bookings data
      this.selectedEvent.bookings = eventInfo.bookings;
      this.selectedEvent.is_online = eventInfo.is_online;
      this.selectedEvent.event_app = eventInfo.event_app;
      this.selectedEvent.event_url = eventInfo.event_url;
      this.selectedEvent.maxAllowed = eventInfo.max_allowed;
      this.selectedEvent.facility_id = eventInfo.facility_id;

      this.facilities.forEach(element => {
        if (this.selectedEvent.facility_id == element.id) {
          this.selectedEvent.locationText = element.name;
        }
      });
	  this.hasEventPast();


      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  confirmCustomerBooking(type : string) {
    this.floatingPos = true;
    this.preparePaymentModes();

    // if (this.selectedEvent.type === 'class-event') {
    // 	this.bookEvent(this.selectedPaymentMode);
    // } else if (this.selectedEvent.type === 'pt-event' || this.selectedEvent.type === 'pt-unbooked') {
    // 	this.bookAppointment(this.selectedPaymentMode);
    // }

    //logic for floating pos
  }

  bookPayLater() {
    if (this.selectedEvent.type === 'class-event') {
      this.customerBookingInfo.price = 0;
      this.bookEvent('cash');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && !this.selectedEvent.oneOff)) {
      this.customerBookingInfo.price = 0;
      this.bookAppointment('cash');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && this.selectedEvent.oneOff)) {
      this.customerBookingInfo.price = 0;
      this.bookEvent('cash');
    }
  }

  bookWithCredits() {
	  this.yoDisabled = true;
    if (this.selectedEvent.type === 'class-event') {
      this.bookEvent('credits');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && !this.selectedEvent.oneOff)) {
      this.bookAppointment('credits');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && this.selectedEvent.oneOff)) {
      this.bookEvent('credits');
    }
  }



  bookRPTAppointment(type : string) {
    this.calendarLoader = true;
    this.requestObject = {
      center_contact_id: this.selectedCustomer.id,
      user_id: this.createPt.user_id,
      service_type_id: this.createPt.id,
      sale_data: {
        payment: {
          amount: this.customerBookingInfo.price,
          payment_method: ''
        }
      },
      slots: this.arr
    };

    switch (type) {
      case 'credits':
        this.requestObject.sale_data.payment.payment_method = 'credit';
        this.requestObject.sale_data.payment.payment_mode = 'offline';
        this.requestObject.sale_data.payment.credit_id = this.selectedCreditModel;
        break;

      case 'cash-0':
        this.requestObject.sale_data.payment.payment_method = 'cash';
        this.requestObject.sale_data.payment.payment_mode = 'offline';
        this.requestObject.sale_data.payment.amount = 0;
        break;
    }
    this.http.sendData('bookings/appointment/recurring?center_id=' + this.centerId, this.requestObject).subscribe(response => {
      // let eventId = response.data.event_id;
      // this.selectedEvent.eventId = response.data.event_id;
      // this.selectedEvent.customerId = response.data.center_contact_id;

      this.generalFunctions.openToast('Customer successfully booked', 3000, 'success');
      this.floatingPos = false;
      this.arr = [];
      // go to bookings list
      this.closeCustomerOverlay();
      this.closeAppointmentBookingOverlay();
      this.closeClassBookingOverlay();
      this.closeFiltersOverlay();
      this.recurringPtStaging = false;
	  this.pickRPTOverlay = false;
	  this.yoDisabled = false;


      this.showOneOfOverlay = false;

      this.filterEvents();
      this.calendarLoader = false;
      this.resetPt()

    }, err => {
      this.arr = [];
      this.calendarLoader = false;
      this.generalFunctions.openToast(err.message, 3000, 'error');
      this.resetPt()

    }, () => {});
  }

  completePayment() {
	this.yoDisabled = true;

    if (this.selectedEvent.type === 'class-event') {
      this.bookEvent(this.selectedPaymentMode);
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && !this.selectedEvent.oneOff)) {
      this.bookAppointment(this.selectedPaymentMode);
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && this.selectedEvent.oneOff)) {
      this.bookEvent(this.selectedPaymentMode);
    }
  }

  completeZeroPayment() {
	  this.yoDisabled = true;
    if (this.selectedEvent.type === 'class-event') {
      this.bookEvent('cash-0');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && !this.selectedEvent.oneOff)) {
      this.bookAppointment('cash-0');
    } else if (this.selectedEvent.type === 'pt-event' || (this.selectedEvent.type === 'pt-unbooked' && this.selectedEvent.oneOff)) {
      this.bookEvent('cash-0');
    }
  }
  completeRPTZeroPayment() {
	this.yoDisabled = true;

    this.bookRPTAppointment('cash-0');
  }

  bookRPTWithCredits() {
	this.yoDisabled = true;


    this.bookRPTAppointment('credits');
  }


  cancelAppointment(bookings) {
    let bookedCustomer = bookings[0];
    this.pop_up_for = null;

    this.http.deleteData(`events/${this.selectedEvent.eventId}?center_id=${this.centerId}`).subscribe(response => {
      this.generalFunctions.openToast('Appointment cancelled', 3000, 'success');
      this.showClassBookingOverlay = false;
      this.showCourseOverlay = false;
      this.showAppointmentBookingOverlay = false;
      this.filterEvents();

      // refresh calendar appointments
      // let selectedTrainers = this.getSelectedTrainers();
      // this.getAppointments(selectedTrainers);
      // this.closeAppointmentBookingOverlay();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  setPaymentMode(type) {
    // set payment mode

    if (type.includes('card_')) {
      this.requestObject.payment.payment_mode = 'online';
      this.requestObject.payment.card_id = type;
      this.requestObject.payment.payment_method = 'stripe';
    } else {
      switch (type) {
        case 'credits':
          this.requestObject.payment.payment_method = 'credit';
          this.requestObject.payment.payment_mode = 'offline';
          this.requestObject.payment.credit_id = this.selectedCreditModel;
          break;

        case 'cash':
          this.requestObject.payment.payment_method = 'cash';
          this.requestObject.payment.payment_mode = 'offline';
          break;

        case 'cash-0':
          this.requestObject.payment.payment_method = 'cash';
          this.requestObject.payment.payment_mode = 'offline';
          this.requestObject.payment.amount = 0;
          break;

        case 'card':
          this.requestObject.payment.payment_method = 'card';
          this.requestObject.payment.payment_mode = 'offline';

          break;

        case 'paytm':
          this.requestObject.payment.payment_method = 'paytm';
          this.requestObject.payment.payment_mode = 'offline';

          break;

        default:
          this.requestObject.payment.payment_method = 'cash';
          this.requestObject.payment.payment_mode = 'offline';

          break;
      }
    }
  }

  bookEvent(type) {
    this.requestObject = {
      center_contact_id: this.selectedCustomer.id,
      event_id: this.selectedEvent.eventId,
      payment: {
        amount: this.customerBookingInfo.price,
        payment_method: ''
      }
    };

    this.setPaymentMode(type);

    this.http.sendData('bookings/event?center_id=' + this.centerId, this.requestObject).subscribe(response => {
      this.generalFunctions.openToast('Customer successfully booked', 3000, 'success');
      this.closeCustomerOverlay();
      this.closeAppointmentBookingOverlay();
      // this.closeClassBookingOverlay();
      this.closeFiltersOverlay();
      this.floatingPos = false;
      this.selectedCreditModel = null;
      this.getEventInfo(this.selectedEvent);
	  this.filterEvents();
	  this.yoDisabled = false;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  bookAppointment(type : string) {
    this.requestObject = {
      center_contact_id: this.selectedCustomer.id,
      // appointment_id: this.selectedEvent.appointmentId,
      // slot_id: this.selectedEvent.slot_id,
      // starts_at: this.selectedEvent.starts_at,
      // ends_at: this.selectedEvent.ends_at,
      event_id: this.selectedEvent.id,
      payment: {
        amount: this.customerBookingInfo.price,
        payment_method: ''
      }
    };

    this.setPaymentMode(type);
    this.http.sendData('bookings/appointment?center_id=' + this.centerId, this.requestObject).subscribe(response => {
      // let eventId = response.data.event_id;
      this.selectedEvent.eventId = response.data.event_id;
      this.selectedEvent.customerId = response.data.center_contact_id;
      this.generalFunctions.openToast('Customer successfully booked', 3000, 'success');
      this.floatingPos = false;
      // go to bookings list
      this.closeCustomerOverlay();
      this.closeAppointmentBookingOverlay();
      this.closeClassBookingOverlay();
      this.closeFiltersOverlay();
      // this.getPtEventInfo(this.selectedEvent);
      this.filterEvents();
	  this.showOneOfOverlay = false;
      this.yoDisabled = false;
      this.recurringPtStaging = false;
      this.resetPt();
      // refresh calendar appointments
      // let selectedTrainers = this.getSelectedTrainers();
      // this.getAppointments(selectedTrainers);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  checkinCustomer(booking, option, mode) {
    let reqObj = {};
    // tslint:disable-next-line: max-line-length
    this.http.patchData(`bookings/${booking.event_id}/update/${booking.id}/${option}?center_id=` + this.centerId, reqObj).subscribe(response => {
      let customerName = booking.center_contact.contact.first_name + ' ' + booking.center_contact.contact.last_name;
      if (option === 'checkin') {
        booking.checkin_status = 1;
        this.selectedEvent.checkedinCount = isNaN(this.selectedEvent.checkedinCount)
          ? 0
          : this.selectedEvent.checkedinCount + 1;

        if (mode == 'all') {
          this.generalFunctions.openToast('Checked in all', 3000, 'success');
        } else {
          this.generalFunctions.openToast(`${customerName} checked-in`, 3000, 'success');
        }
      } else if (option === 'uncheck') {
        booking.checkin_status = 0;
        this.selectedEvent.checkedinCount = isNaN(this.selectedEvent.checkedinCount)
          ? 0
          : this.selectedEvent.checkedinCount - 1;
        if (mode == 'all') {
          this.generalFunctions.openToast('Un Checked all', 3000, 'success');
        } else {
          this.generalFunctions.openToast(`${customerName} unchecked`, 3000, 'success');
        }
      }

      this.cdRef.detectChanges();
    }),
    err => {
      this.generalFunctions.openToast('checkin failed', 3000, 'error');
    },
    () => {};
  }

  checkAll(allBooking, option) {
	this.selectedEvent.checkedinCount  = 0;
    allBooking.forEach(element => {
      if (element.status == 1) {
        this.checkinCustomer(element, option, 'all');
      }
	});

    this.pop_up_for = null;
  }

  unCheckAll(allBooking, option) {
    allBooking.forEach(element => {
      if (element.status == 1) {
        this.checkinCustomer(element, option, 'all');
      }
    });
    this.pop_up_for = null;
  }

  getAvailableTrainers() {
    this.http.getData(`appointments?center_id=${this.centerId}`).subscribe(response => {
      this.filterTrainers = response.data;

      for (let i = 0; i < this.filterTrainers.length; i++) {
        this.filterTrainers[i].checked = true;
      }

      // this.cdRef.detectChanges();
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  getSettings() {
    this.pricingLoader = true;
    //SEND HTTP REQUEST AND GET CART SETTINGS
    this.http.getData(`settings?center_id=${this.centerId}`).subscribe(success => {
      success = success;
      this.availablePaymentModes = success.pos.payments.available_modes;
      this.isPayLater = success.pos.payments.pending_enabled;
      this.waitlistSettings = success.administration.classes.waitlist;
      // this.preparePaymentModes();
    }, error => {
      this.generalFunctions.openToast('Unable to load settings!', 3000, 'error');
    });
  }

  preparePaymentModes() {
    if (this.stripeConnected) {
      this.http.getData('contact/' + this.selectedCustomer.id + '/payment/sources?center_id=' + this.centerId).subscribe(success => {
        this.savedCards = success.data;
        this.savedCards.length = success.data.length;
        this.sculptDropdown();
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
    } else {
      this.savedCards = [];

      this.savedCards.length = 0;
      this.sculptDropdown();
    }
  }

  sculptDropdown() {
    //step 1
    this.enabledPaymentModes = [];

    let genObj = {
      label: '',
      value: '',
      items: []
    };
    let genObjo = {
      label: '',
      value: '',
      items: []
    };
    if (this.stripeConnected) {
      let addObj = {
        label: '',
        value: '',
        items: [
          {
            label: 'Add Card',
            value: 'add'
          }
        ]
      };
      this.enabledPaymentModes[0] = addObj;

      //stripe connected and card exists
      if (this.savedCards.length > 0) {
        this.enabledPaymentModes[1] = genObjo;
        this.enabledPaymentModes[2] = genObj;
      } else {
        this.enabledPaymentModes[1] = genObj;
      }
    } else {
      this.enabledPaymentModes[0] = genObj;
    }

    if (this.stripeConnected) {
      this.enabledPaymentModes[0].items[0]['mode'] = 'Add Card';
      this.enabledPaymentModes[0].items[0]['code'] = 'add';
    }

    if (this.savedCards.length > 0 && this.stripeConnected) {
      this.savedCards.forEach((element, index) => {
        let i = 1;
        let card = element;
        card.mode = 'scard';
        card.code = element.brand.split(' ')[0];
        card.label = 'Saved card ending ' + element.last4;
        card.value = element.id;
        this.enabledPaymentModes[i].items.push(card);
      });
    }

    for (var mode in this.availablePaymentModes) {
      let i;
      this.stripeConnected
        ? this.savedCards.length > 0
          ? (i = 2)
          : (i = 1)
        : (i = 0);

      if (this.availablePaymentModes[mode].status) {
        if (this.availablePaymentModes[mode].code !== 'credit' && this.availablePaymentModes[mode].code !== 'pay_later') {
          let paymentMode = this.availablePaymentModes[mode];
          paymentMode.label = paymentMode.name;
          paymentMode.value = paymentMode.code;
          this.enabledPaymentModes[i].items.push(paymentMode);
        }
      }
    }

    if (!this.stripeConnected) {
      this.selectedPaymentMode = 'cash';
    }

    //default value for the dropdown
    if (this.savedCards.length > 0 && this.stripeConnected) {
      if (!this.selectedCard) {
        this.selectedPaymentMode = this.savedCards[0].id;

        this.dropdownLoaded = true;
        this.cdRef.detectChanges();
      } else {
        this.selectedPaymentMode = this.selectedCard;

        this.dropdownLoaded = true;
        this.cdRef.detectChanges();
      }
    } else {
      this.selectedPaymentMode = 'cash';

      this.dropdownLoaded = true;
      this.cdRef.detectChanges();
    }
  }

  changePaymentMethod(e) {
    if (e.value == 'add') {
      this.cardModal.nativeElement.style.display = 'block';
      this.isAddCard = true;
      this.pop_up_for = 'add-card';
    } else {
      this.cardModal.nativeElement.style.display = 'block';
      this.isAddCard = false;
      this.pop_up_for = null;
    }
  }

  openFiltersModal() {
    this.showFiltersOverlay = true;
    // this.tempCalendarFilters.filterPT = this.calendarFilters.filterPT;
    // this.tempCalendarFilters.viewSlotsType = this.calendarFilters.viewSlotsType;
    // this.tempCalendarFilters.selectedTrainers = this.getSelectedTrainers();
  }

  // closeFiltersModal(action) {
  // 	this.closeFiltersOverlay();

  // 	if (action === "cancel") {
  // 		this.calendarFilters.filterPT = this.tempCalendarFilters.filterPT;
  // 		this.calendarFilters.viewSlotsType = this.tempCalendarFilters.viewSlotsType;

  // 		for (let i = 0; i < this.filterTrainers.length; i++) {
  // 			this.filterTrainers[i].checked = false;
  // 			for (let j = 0; j < this.tempCalendarFilters.selectedTrainers.length; j++) {
  // 				if (this.filterTrainers[i].id === this.tempCalendarFilters.selectedTrainers[j]) {
  // 					this.filterTrainers[i].checked = true;
  // 				}
  // 			}
  // 		}
  // 	} else if (action === "apply") {
  // 		this.applyFilters();
  // 	} else if (action === "reset") {
  // 		this.resetFilters();
  // 	}
  // }

  applyNewFilter(action) {
    this.closeFiltersOverlay();
    if (action === 'apply') {
      this.filterEvents();
    } else if (action === 'reset') {
      this.resetFilters();
    }
  }

  getSelectedTrainers() {
    let selected = [];
    for (let i = 0; i < this.filterTrainers.length; i++) {
      if (this.filterTrainers[i].checked === true) {
        selected.push(this.filterTrainers[i].user.id);
      }
    }
    return selected;
  }

  resetFilters() {
    // reset calendar filters

    // reset checked boolean for all trainers
    for (let i = 0; i < this.trainersDropdownGroup.length; i++) {
      this.trainersDropdownGroup[i].checked = false;
    }

    for (let i = 0; i < this.facilities.length; i++) {
      this.facilities[i].checked = false;
	}

		this.categories.map((category) => category.checked = false)
    // get events for default view of calendar
    this.getEvents();
  }

  // applyFilters() {
  // 	let selectedTrainers = this.getSelectedTrainers();
  // 	if (this.calendarFilters.filterPT) {
  // 		this.getAppointments(selectedTrainers);

  // 	} else {
  // 		this.getEvents();
  // 	}
  // }


  filterEvents() {
    this.calendarLoader = true;
    let userId = [],
	  facilityId = [], categoryId = [];
    this.trainersDropdownGroup.forEach(trainer => {
      if (trainer.hasOwnProperty('checked')) {
        if (trainer.checked) {
          userId.push(trainer.id);
        }
      }
    });

    this.facilities.forEach(facility => {
      if (facility.hasOwnProperty('checked')) {
        if (facility.checked) {
          facilityId.push(facility.id);
        }
      }
	});


	categoryId = this.categories.filter((category) => category.checked == true).map((item) => item.id);

	// this.categories.forEach(facility => {
	// 	if (facility.hasOwnProperty("checked")) {
	// 	  if (facility.checked) {
	// 		console.log("this.facility", facility);
	// 		facilityId.push(facility.id);
	// 	  }
	// 	}
	//   });

    let reqObj = {
      filterBy: {
        user_id: userId,
		facility_id: facilityId,
		category_id : categoryId,
		start_date : this.filterQueryRequest(this.viewDate).start_date,
		end_date : this.filterQueryRequest(this.viewDate).end_date,

      }
	};

	let data = {
		filterBy: this.filterQueryRequest(this.viewDate)
	  };

    userId.length === 0
      ? delete reqObj['filterBy']['user_id']
      : '';
    facilityId.length === 0
      ? delete reqObj['filterBy']['facility_id']
	  : '';
	categoryId.length === 0
	  ? delete reqObj['filterBy']['category_id']
	  : '';

    this.filter = reqObj;

    this.http.sendData('events?center_id=' + this.centerId, reqObj).subscribe(response => {
      this.eventsFetched = response.data;
      this.createCalendarEvents();
      this.calendarLoader = false;
    }),
    err => {},
    () => {};
  }

  filterCheckedin() {}

  isVisible(booking) {
    if (this.checkedinFilter === 'all') {
      return true;
    } else if (this.checkedinFilter === 'checked-in') {
      if (booking.checkin_status === 1) {
        return true;
      } else {
        return false;
      }
    } else if (this.checkedinFilter === 'not-checked-in') {
      if (booking.checkin_status === 0) {
        return true;
      } else {
        return false;
      }
    }
  }

  dayToggle(day) {
    if (day) {
      if (this.weekDay[this.daysModel[day]] == true) {
        this.selectedDays.push(day + 1);
      }
    }
  }

  goToDay(day) {
    this.view = CalendarView.Day;
    this.viewDate = day.date;
    this.getEvents();
  }

  showMessageOver() {
    this.showMessageOverlay = true;
    this.showEditOverlay = false;
    this.showInitial = false;
  }
  showPtMessageOver() {
    this.showPtInitial = false;
    this.showPtMessage = true;
  }
  updateMessageContent(e) {
    this.groupMessage.message = e;
  }

  deleteClass() {
    this.pop_up_for = 'delete';
  }
  deleteCourse() {
    this.pop_up_for = 'delete-course';
  }

  editClassInstance() {
    this.showEditOverlay = true;
    this.showInitial = false;
    this.showMessageOverlay = false;
    let subs = this.selectedEvent.user.filter((obj) => obj.type === 2 && obj.status === 1);
    subs.length > 0 ? this.addSubstitute = true : this.addSubstitute = false;
    console.log(this.selectedEventEdit);
    this.selectedEventEdit = Object.assign({}, this.selectedEvent);

    this.prepareSelectedTrainers();
    // this.prepareFacility();
  }

  removeSubs() {
    this.addSubstitute = false;
    this.selectedEventEdit.substitutes = [];
  }

  prepareSelectedTrainers() {
    this.selectedEventEdit.user = [];
    this.selectedEventEdit.substitutes = [];
    let isSub = false;
    this.selectedEvent.user.filter(el => el.type === 2 && el.status === 1).length > 0 ? isSub = true : isSub = false;


        for (let i = 0; i < this.selectedEvent.user.length; i++) {
            if (this.selectedEvent.user[i].type === 1 ){
                this.selectedEventEdit.user.push(this.selectedEvent.user[i].id);
            }
            else if(this.selectedEvent.user[i].type === 2 && this.selectedEvent.user[i].status === 1 ){
                this.selectedEventEdit.substitutes.push(this.selectedEvent.user[i].id);
            }

        }


  }
  editClass(data) {
    var reqObj = {
      name: data.title,
      description: data.description,
      users: data.substitutes.length > 0 ? [] : data.user,
      substitutes : data.substitutes.length === 0 ?  [] : data.substitutes,
      starts_at: this.prepareDate(data.start),
      ends_at: this.prepareDate(data.end),
      max_allowed: data.maxAllowed,
      facility_id: data.facility_id,
      level: data.level,
      visibility: data.visibility == true
        ? 1
        : 2,
    event_url : data.event_url,
    recorded_url : data.recorded_url
    };
    if (this.getBookingStatus(this.selectedEvent.bookings).booked <= reqObj.max_allowed) {
      this.http.updateData(`events/${data.eventId}?center_id=` + this.centerId, reqObj).subscribe(response => {
        // this.getAllServices();
        // this.getEventInfo(this.selectedEvent);
        this.filterEvents();
        this.generalFunctions.openToast('Changes saved for this event instance', 3000, 'success');
        this.showClassBookingOverlay = false;
        this.showCourseOverlay = false;
        this.showEditOverlay = false;
        this.showInitial = true;

      }),
      err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
      }
    } else {
      this.generalFunctions.openToast('Event size must be greater than booked', 3000, 'error');
    }
  }

  prepareDate(dateInput) {
    let dateOutput = '';
    if (dateInput !== '') {
      var d = moment(dateInput);
      dateOutput = d.format('Y-MM-D HH:mm:ss');
    }
    return dateOutput;
  }

  sendGroupMsg() {
    if (this.groupMessage.channel == 'email') {
      if (this.groupMessage.subject.length == 0) {
        this.generalFunctions.openToast('You will not be able to send emails without subject', 3000, 'error');
        return;
      }
    }
    this.showInitial = true;
    this.showMessageOverlay = false;
    this.showClassBookingOverlay = false;
    this.showCourseOverlay = false;
    this.showPtInitial = true;
    this.showPtMessage = false;
    this.showAppointmentBookingOverlay = false;
    this.http.sendData(`events/${this.selectedEvent.eventId}/message?center_id=` + this.centerId, this.groupMessage)
    .subscribe(response => {
      this.generalFunctions.openToast('Your message has been sent', 3000, 'success');
    }),
    err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    };
  }

  deleteClassI() {
    this.pop_up_for = null;
    this.http.deleteData(`events/${this.selectedEvent.eventId}?center_id=` + this.centerId).subscribe(response => {
      this.generalFunctions.openToast('Event has been deleted successfully', 3000, 'success');
      this.showClassBookingOverlay = false;
      this.showCourseOverlay = false;
      this.showAppointmentBookingOverlay = false;
      // this.getAllServices();
      this.filterEvents();
    }),
    err => {
      this.pop_up_for = null;
      this.generalFunctions.openToast('Error in deleting the event', 3000, 'error');
    };
  }
  sendGroupPtMsg() {
    if (this.groupMessage.subject == '' || this.groupMessage.message == '') {
      this.generalFunctions.openToast('Please fill in both the fields', 3000, 'error');
    }
    this.http.sendData('contact/' + this.selectedEvent.customerId + '/message?center_id=' + this.centerId, this.groupMessage).subscribe(response => {
      this.generalFunctions.openToast('Message has been sent', 3000, 'success');
    }, error => {
      this.generalFunctions.openToast(error, 3000, 'error');
    });
  }
  submitAttendance() {
    this.pop_up_for = null;
    this.http.getData(`events/${this.selectedEvent.eventId}/attendance/submit?center_id=` + this.centerId).subscribe(response => {
      this.generalFunctions.openToast(response.message, 3000, 'success');
      this.pop_up_for = null;
      this.filterEvents();

      setTimeout(() => {
        this.generalFunctions.openToast('Submitted attendance processed.', 3000, 'success');
        this.filterEvents();
      }, 15000);
      this.showClassBookingOverlay = false;
      this.showCourseOverlay = false;
      this.showAppointmentBookingOverlay = false;
      this.isDisableSubmit = true;
    }),
    error => {
      this.generalFunctions.openToast('Error submitting attendance', 3000, 'error');
      this.pop_up_for = null;
    };
  }

  deletePtI() {
    this.pop_up_for = null;
    if (this.selectedEvent.oneOff) {
      this.http.deleteData(`events/${this.selectedEvent.eventId}?center_id=${this.centerId}`).subscribe(response => {
        // console.log(response);
        this.generalFunctions.openToast('Appointment deleted', 3000, 'success');
        this.filterEvents();
        this.showAppointmentBookingOverlay = false;
      }, err => {
        const msg = err;
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    } else {
      let reqObj = {
        type: 2,
        starts_at: this.selectedEvent.starts_at,
        ends_at: this.selectedEvent.ends_at
      };
      this.http.sendData(`appointments/${this.selectedEvent.appointmentId}/unavailability?center_id=` + this.centerId, reqObj).subscribe(response => {
        this.filterEvents();
        this.generalFunctions.openToast('Appointment deleted', 3000, 'success');
        this.showAppointmentBookingOverlay = false;
      }),
      err => {};
    }
  }

  blockPt() {
    this.pop_up_for = null;
    // console.log("selected event" + this.selectedEvent.appointmentId);
    this.http.sendData(`appointments/${this.selectedEvent.appointmentId}/unavailability?center_id=` + this.centerId, {
      type: 1,
      starts_at: this.selectedEvent.starts_at,
      ends_at: this.selectedEvent.ends_at
    }).subscribe(response => {
      // console.log("deleted");
      this.getAppointments({});

      this.showAppointmentBookingOverlay = false;
    }),
    err => {};
  }

  unblockPt() {
    this.pop_up_for = null;
    this.http.deleteData(`appointments/${this.selectedEvent.appointmentId}/unavailability/${this.selectedEvent.unavailability_id}?center_id=` + this.centerId).subscribe(response => {
      this.getAppointments({});

      this.showAppointmentBookingOverlay = false;
    }),
    err => {};
  }

  smsCounter(data) {
    data.length == 0
      ? (this.smsNum = 0)
      : (this.smsNum = Math.floor(data.length / 160) + 1);
  }

  getSenderEmails() {
    this.http.getData('center/' + this.centerId + '?center_id=' + this.centerId).subscribe(response => {
      this.centerSettings = response.data;
      for (let i = 0; i < this.centerSettings.client.emails.length; i++) {
        if (this.centerSettings.client.emails[i].status != 1) {
          continue;
        }

        let event = {
          label: '',
          value: 0
        };

        event.label = this.centerSettings.client.emails[i].email;
        event.value = this.centerSettings.client.emails[i].email;

        this.senderEmailsDropdown.push(event);
      }
    }, err => {
      this.generalFunctions.openToast(err, 3000, 'error');
    }, () => {});
  }


  getClasses() {
    this.http.getData('classes?center_id=' + this.centerId).subscribe(response => {
      this.classGroupsList = response.data;
      this.classGroups = [];

      this.classGroupsList.forEach((element, index) => {
        let event = {
          label: '',
          value: 0
        };
        event.label =`${this.classGroupsList[index].name}`  ;
        event.value = this.classGroupsList[index].id;
        this.classGroups.push(event);
      });
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
      return err;
    }, () => {});
  }

  //trainers name with appointement id for one off pt
  prepareTrainers() {
    this.getAvailableTrainers();

    this.trainersGroupsList = this.filterTrainers;
    this.trainersGroup = [];
    // console.log('this.filterTrainers', this.filterTrainers)

    this.trainersGroupsList.forEach(element => {
      let trainer = {
        label: '',
        value: 0
      };
      trainer.label = element.user.first_name + ' ' + element.user.last_name;
      trainer.value = element.id;
      this.trainersGroup.push(trainer);
    });
  }

  openAddEvent() {
    this.defaultDateStart.setHours(9, 0, 0);
    this.defaultDateEnds.setHours(10, 0, 0);
    this.createClass = {
      service_id: 3,
      service_type_id: '',
      date: this.defaultDate,
      starts_at: this.defaultDateStart,
      ends_at: this.defaultDateEnds
    };

    this.getClasses();
    this.getAllPt();
    this.getCourses();
    // this.prepareTrainers();
    this.showOneOfOverlay = true;
  }

  getAllPt() {
    this.http.getData('appointments?center_id=' + this.centerId).subscribe(response => {
      this.ptDropdown = [];
      this.createPtDropdown(response.data);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  getCourses() {
    this.http.getData('groups?service_id=6&center_id=' + this.centerId).subscribe(response => {
        this.courseGroupList = response.data;
        this.courseGroup = [];

        this.courseGroupList.forEach((element, index) => {
          let event = {
            label: '',
            value: 0
          };
          event.label =`${this.courseGroupList[index].name}`  ;
          event.value = this.courseGroupList[index].id;
          this.courseGroup.push(event);
        });
      }, err => {
        const msg = err;
        this.generalFunctions.openToast(msg, 3000, 'error');
      }, () => {});
  }

  courseGroupSet() {
    this.courseLoading = true;
      let reqObj = {filterBy: {group_id: this.createClass.service_group_id}}
    this.http.sendData('courses?center_id=' + this.centerId, reqObj).subscribe(response => {

        let data = response.data;
        this.courseType = [];
        data.forEach((element, index) => {
          let event = {
            label: '',
            value: 0
          };
          event.label =`${data[index].name}`;
          event.value = data[index].id;
          this.courseType.push(event);

        });
        this.courseLoading = false;
        this.cdRef.detectChanges();

      }, err => {

        this.courseLoading = false;
        this.cdRef.detectChanges();

        this.generalFunctions.openToast(err.message, 3000, 'error');
      }, () => {});
  }

  createPtDropdown(data) {
    data.forEach(element => {
      let obj = {
        label: element.name,
        value: element.id,
        user_id: element.user_id,
        duration: element.duration
      };
      this.ptDropdown.push(obj);
    });
  }

  fetchTrainersForPt() {
    let item = [];
    item = this.ptDropdown.filter(element => {
      return this.createPt.id == element.value;
    });
    this.createPt.duration = item[0].duration + ' mins';
    this.sculptPickedTrainers(item[0].user_id);
  }

  sculptPickedTrainers(ids) {
    this.pickedTrainersDropdown = [];
    this.trainersDropdownGroup.forEach(element => {
      ids.forEach(id => {
        if (id == element.id) {
          let obj = {
            label: element.first_name,
            value: element.id
          };
          this.pickedTrainersDropdown.push(obj);
        }
      });
    });
  }


  selectPtCustomer() {
    let req = Object.assign({}, this.createPt);
    req.date = moment(req.date).format('Y-MM-D');
    req.service_type_id = req.id;
    req.starts_at = this.getRequestTime(req.starts_at);
    // delete req.id;
    delete req.cycles;
    delete req.max_occurences;
    delete req.days;
    delete req.end_date;
    delete req.ends;
    delete req.start_date;
    this.pickPtOverlay = true;

    this.http.sendData(`events/create?center_id=` + this.centerId, req).subscribe(response => {
      this.selectedEvent = response.data;
      this.selectedEvent.type = 'pt-unbooked';
      // console.log('selectedEvent', this.selectedEvent);
    }, error => {
      console.log(error);
    }, () => {});
  }

  arr = [];
  selectCustomerRPT() {
      console.log('rpt')
    this.pickRPTOverlay = true;
  }

  pushSlots(slot) {
    if (slot.checked == true) {
      this.arr.forEach((el, i) => {
        if (el.id == slot.id) {
          return;
        }
      });
      this.arr.push(slot);
    } else if (slot.checked == false) {
      this.arr.forEach((el, i) => {
        if (el.id == slot.id) {
          this.arr.splice(i, 1);
          return;
        }
      });
    }
  }

  counter: any = 0;
  createPtSchedule() {
    this.scheduleLoader = true;
    let reqObj = {
      ...this.createPt
    };

    this.stageSlots = {
        slots: [],
        is_recurring : reqObj.is_recurring
      };
    if (reqObj.is_recurring) {
        reqObj.end_date = moment(reqObj.end_date).format('Y-MM-D');
        reqObj.ends == 'on'
          ? delete reqObj.max_occurences
          : delete reqObj.end_date;
        delete reqObj.ends;
        reqObj.start_date = moment(reqObj.date).format('Y-MM-D');

        reqObj.service_type_id = reqObj.id;
        reqObj.starts_at = this.getRequestTime(reqObj.starts_at);

        reqObj.days = [];
        let n = 1;

        // tslint:disable-next-line: forin
        for (let k in this.createPt.days) {
          if (this.createPt.days[k] == true) {
            reqObj.days.push(n);
          }
          n++;
        }
    } else {
        delete reqObj.days;
        delete reqObj.cycles;
        delete reqObj.max_occurences;
        delete reqObj.end_date;
        delete reqObj.ends;

        reqObj.start_date = moment(reqObj.date).format('Y-MM-D');

        reqObj.service_type_id = reqObj.id;
        reqObj.starts_at = this.getRequestTime(reqObj.starts_at);
    }

    this.http.sendData(`events/appointments/slots?center_id=${this.centerId}`, reqObj).subscribe(response => {
      this.stageSlots = {
        slots: [],
        is_recurring : reqObj.is_recurring
      };
      let i = 0;
      this.counter = 0;
      response.slots.forEach(element => {
        if (element.is_available) {
          element.checked = true;
        } else {
          this.counter = this.counter + 1;
          element.checked = false;
        }
        element.id = i++;
        this.stageSlots.slots.push(element);
        // console.log('this.stageSlots', this.stageSlots)
      });

      this.stageSlots.slots.forEach(slot => {
        if (slot.checked == true) {
          this.arr.push(slot);
        }
      });
      this.cdRef.detectChanges();

      this.recurringPtStaging = true;
      this.cdRef.detectChanges();
      this.scheduleLoader = false;
    }, err => {
        this.scheduleLoader = false;

        this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  getPtPricing() {
    this.http.getData(`events/${this.selectedEvent.id}/price/${this.selectedCustomer.id}?center_id=${this.centerId}`).subscribe(response => {
      let pricingInfo = response;
      if (pricingInfo.membership.length == 0 && pricingInfo.price == 'invalid') {
        this.buttonHere = 'button-buy';
      } else if (pricingInfo.membership.length > 0) {
        this.prepareBookingDropdwon(pricingInfo);
      } else if (pricingInfo.price === 0) {
        this.buttonHere = 'button-free';
      }
      this.getSettings();
      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  getRPTPricing() {
    this.http.getData(`appointments/${this.createPt.id}/prices/${this.selectedCustomer.id}?center_id=${this.centerId}`).subscribe(response => {
      let pricingInfo = response;
      //check for dropin or not
      if (pricingInfo.membership.length == 0 && pricingInfo.price == 'invalid') {
        this.buttonHere = 'button-buy';
      } else if (pricingInfo.membership.length > 0) {
        this.prepareRPTBookingDropdwon(pricingInfo);
      } else if (pricingInfo.price === 0) {
        this.buttonHere = 'button-free';
      }
      this.getSettings();
      this.cdRef.detectChanges();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  prepareRPTBookingDropdwon(pricingInfo) {
    pricingInfo.membership.forEach(event => {
      let structure = {
        value: '',
        label: ''
      };
      structure.label = event.service_model.name + ' (' + (
        event.credits !== -1
        ? event.credits
        : 'Unlimited') + ' credits, exp.' + moment(event.expires_at).format('D MMM Y') + ')';
      structure.value = event.credit_id;
      this.membershipsPricingGroup.push(structure);
    });
    this.selectedCreditModel = this.membershipsPricingGroup[0].value;
    this.buttonHere = 'button-credits';
    // this.membershipsPricingGroup.push()
  }

  createOneOfClass() {
    this.createClass.date = moment(this.createClass.date).format('Y-MM-D');
    this.createClass.starts_at = this.getRequestTime(this.createClass.starts_at);
    this.createClass.ends_at = this.getRequestTime(this.createClass.ends_at);
    // console.log('this.createClass', this.createClass);
    this.showOneOfOverlay = false;

    this.http.sendData(`events/create?center_id=${this.centerId}`, this.createClass).subscribe(success => {
      this.generalFunctions.openToast('One off class has been created', 3000, 'success');
      this.filterEvents();

      if (success.data.service_id === this.classesServiceId) {
        let event = this.createCalendarEventsFactory(success.data);
        this.handleEvent('Clicked', event);
      } else if (success.data.service_id === this.appointmentsServiceId) {}
    }, err => {
      this.generalFunctions.openToast(err.msg, 3000, 'error');
      this.filterEvents();
    });
  }

  createOneOfCourse() {
    console.log('this.createClass', this.createClass)
    this.createClass.date = moment(this.createClass.date).format('Y-MM-D');
    this.createClass.starts_at = this.getRequestTime(this.createClass.starts_at);
    this.createClass.ends_at = this.getRequestTime(this.createClass.ends_at);
    // console.log('this.createClass', this.createClass);
    this.showOneOfOverlay = false;

    this.http.sendData(`events/create?center_id=${this.centerId}`, this.createClass).subscribe(success => {
      this.generalFunctions.openToast('Course event has been created', 3000, 'success');
      this.filterEvents();

        let event = this.createCalendarEventsFactory(success.data);
        this.handleEvent('Clicked', event);

    }, err => {
      this.generalFunctions.openToast(err.msg, 3000, 'error');
      this.filterEvents();
    });
}

  formattedTimeString(date) {
    let newDate = {
      date: moment(date).format('DD MMM YYYY'),
      time: moment(date).format('hh:mm a')
    };
    return newDate;
  }

  formattedDateTimeString(date) {
    let newDate = {
      date: moment(date).format('DD MMM '),
      time: moment(date).format('hh:mm a')
    };
    return newDate;
  }

  createOneOfPt() {
    this.createClass.date = moment(this.createClass.date).format('Y-MM-D');
    this.createClass.starts_at = this.getRequestTime(this.createClass.starts_at);
    this.createClass.ends_at = this.getRequestTime(this.createClass.ends_at);
    // console.log('this.createClass', this.createClass);
    this.showOneOfOverlay = false;

    this.http.sendData(`events/create?center_id=${this.centerId}`, this.createClass).subscribe(success => {
      this.generalFunctions.openToast('One off pt has been created', 3000, 'success');
      this.filterEvents();
      if (success.data.service_id === this.classesServiceId) {
        let event = this.createCalendarEventsFactory(success.data);
        this.handleEvent('Clicked', event);
      } else if (success.data.service_id === this.appointmentsServiceId) {
        // this.openPt(success.data.users[0].id);
      }
    }, err => {
      this.generalFunctions.openToast(err.msg, 3000, 'error');
      this.filterEvents();
    });
  }

  openPt(id) {
    this.calendarFilters.filterPT = true;
    if (this.calendarFilters.filterPT) {
      this.getAppointments([id]);
    } else {
      this.filterEvents();
    }
  }

  getRequestTime(date) {
    let hours = date.getHours();
    let mins = date.getMinutes();

    let time;
    hours = hours < 10
      ? '0' + hours
      : hours;
    mins = mins < 10
      ? '0' + mins
      : mins;
    time = hours + ':' + mins + ':00';

    return time;
  }

  findEventId(id) {
//We need to send filterby oibject to open the calendar event roaster but the issue is we dont have the event week to pass to the calendar events api
    console.log('We need to send filterby oibject to open the calendar event roaster but the issue is we dont have the event week to pass to the calendar events api');
    this.getAllServices();
    console.log('Trying to fetch this event', id)
    let data = {
        filterBy: this.filterQueryRequest(this.viewDate)
      };
    console.log('felter',data)
    this.http.sendData('events?center_id=' + this.centerId, data).subscribe(response => {
      let events = response.data;
      events.forEach(element => {
        // console.log('element', element)
        if (element.id == id) {
          let properEvent = this.createCalendarEventsFactory(element);
          this.handleEvent('Clicked', properEvent);
        }
      });
    }, err => {});
  }

  documentClickHandler(e) {
    Array.prototype.forEach.call(document.getElementsByClassName('more-options-list'), (item, index) => {
      item.classList.contains('display-none')
        ? ''
        : item.classList.add('display-none');
    });
    if (e.target.parentElement) {
      if (e.target.parentElement.classList.contains('more-options-icon')) {
        var list = this.generalFunctions.parents(e.target)[1].getElementsByClassName('more-options-list')[0];
        list.classList.remove('display-none');
      }
    }
  }

  cancelCustomer(bookingId, eventId) {
    this.http.deleteData(`bookings/${eventId}/cancel/${bookingId}?center_id=${this.centerId}`).subscribe(response => {
      this.generalFunctions.openToast('Booking has been cancelled', 3000, 'success');
      this.filterEvents();
      this.getEventInfo(this.selectedEvent);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
      this.filterEvents();
      this.getEventInfo(this.selectedEvent);
    }, () => {
        setTimeout(() => {
            this.filterEvents();
            this.getEventInfo(this.selectedEvent);
        }, 5000);
    });
  }

  getAllFacility() {
    this.http.getData(`facilities?center_id=${this.centerId}`).subscribe(response => {
      this.facilities = response.data;
      this.prepareFacility();
    }, err => {});
  }

  prepareFacility() {
    for (let i = 0; i < this.facilities.length; i++) {
      let category = {
        label: '',
        value: 0
      };

      category.label = this.facilities[i].name;
      category.value = this.facilities[i].id;

      this.facilityDropdown.push(category);
    }
  }

  getBookingStatus(data) {
    let count = {
      booked: 0,
      cancelled: 0,
      waitlist: 0
    };
    data.forEach(element => {
      if (element.status == 1) {
        count.booked++;
      }
      if (element.status == 3) {
        count.cancelled++;
      }
      if (element.status == 2) {
        count.waitlist++;
      }
    });
    return count;
  }

  parseInto(str) {
    return Number.parseInt(str);
  }

  toggleLoader(iten) {
	this.calendarLoader = true;
	this.applyNewFilter('apply');
  }

  filterQueryRequest(item) {
    let viewRange: any = {};
    let days = [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ];
    let months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    let offset,
      weekStart,
      weekEnd;

    if (true) {
      let date = item;
      offset = date.getDay();
      let weekStart = moment(date);
      let weekEnd = moment(date);

      if (offset === 0) {
        weekStart.subtract(6, 'days');
        weekEnd.add(0, 'days');
      } else {
        weekStart.subtract(offset - 1, 'days');
        weekEnd.add(7 - offset, 'days');
      }
      viewRange['start_date'] = weekStart.format('DD') + '-' + weekStart.format('MM') + '-' + weekStart.format('YYYY');
      viewRange['end_date'] = weekEnd.format('DD') + '-' + weekEnd.format('MM') + '-' + weekEnd.format('YYYY');
    }
    return viewRange;
  }

  openLoader() {
    this.calendarLoader = !this.calendarLoader;
    this.cdRef.detectChanges();
  }

  showFormat(slot) {
    return {
      date: moment(slot.date).format('ddd, Do MMM'),
      time: `${moment(slot.starts_at).format('hh:mm a')} - ${moment(slot.ends_at).format('hh:mm a')}`
    };
  }

  checkModel(selectedCreditModel) {
    let model;
    this.membershipsPricingGroup.forEach(el => {
      if (selectedCreditModel == el.value) {
        model = el.label;
      }
    });
    // 5 credits < 5 class = false
    return model.split('(')[1].split(' ')[0] < this.arr.length;
  }

  checkSlots(days) {
    for (const day in days) {
      // console.log(this.createPt.days[day]);
      if (this.createPt.days[day] == true) {
        return false;
      }
    }
    return true;
  }

  findServiceTrainer() {
    let trainer,
      service;
    this.pickedTrainersDropdown.forEach(el => {
      if (this.createPt.user_id == el.value) {
        trainer = el.label;
      }
    });
    this.ptDropdown.forEach(el => {
      if (this.createPt.id == el.value) {
        service = el.label;
      }
    });
    return `${service} with ${trainer}`;
  }

  saveLink(data , mode){
    if(mode == 'save' && !this.validURL(data.event_url)) {
        this.generalFunctions.openToast('Please enter a valid URL', 3000, 'error');
        return;
    }
      var reqObj = {
        name: data.title,
        description: data.description,
        users: data.user,
        starts_at: this.prepareDate(data.start),
        ends_at: this.prepareDate(data.end),
        max_allowed: data.maxAllowed,
        facility_id: data.facility_id,
        level: data.level,
        visibility: data.visibility == true
          ? 1
          : 2,
        event_url : mode == 'save'  ? data.event_url  : null
      };
        this.http.updateData(`events/${data.eventId}?center_id=` + this.centerId, reqObj).subscribe(response => {
          this.addLink = false;
          if(mode == 'remove'){
            this.selectedEvent.event_url = null;
          }
          this.filterEvents();
          this.generalFunctions.openToast('Changes saved for online event', 3000, 'success');
        }),
        err => {
          this.generalFunctions.openToast(err, 3000, 'error');
        };


  }


  saveTempLink(data,link, mode){
    if(mode == 'save' && !this.validURL(link)) {
        this.generalFunctions.openToast('Please enter a valid URL', 3000, 'error');
        return;
    }
      var reqObj = {
        name: data.title,
        description: data.description,
        users: data.user,
        starts_at: this.prepareDate(data.start),
        ends_at: this.prepareDate(data.end),
        max_allowed: data.maxAllowed,
        facility_id: data.facility_id,
        level: data.level,
        visibility: data.visibility == true
          ? 1
          : 2,
        event_url : mode == 'save'  ? link  : null
      };
        this.http.updateData(`events/${data.eventId}?center_id=` + this.centerId, reqObj)
        .subscribe(response => {
          if (mode == 'remove') {
            this.selectedEvent.event_url = null;
          }
          this.filterEvents();
          this.selectedEvent.event_url = link;
          link = '';
          this.addLink = false;
          this.generalFunctions.openToast('Changes saved for online event', 3000, 'success');
        }),
        err => {
          this.generalFunctions.openToast(err.message, 3000, 'error');
        };
  }

  generateLink(event){

    this.http.getData(`events/${event.eventId}/zoom?center_id=` + this.centerId).subscribe(response => {
        this.generalFunctions.openToast('New zoom link generated', 3000, 'success');
        this.selectedEvent.event_url = response.data.event_url;
        this.filterEvents();
    }),err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
      };

  }

  saveRecordedLink(data,link, mode){
    if(mode == 'save' && !this.validURL(link)) {
        this.generalFunctions.openToast('Please enter a valid URL', 3000, 'error');
        return;
    }
      var reqObj = {
        name: data.title,
        description: data.description,
        users: data.user,
        starts_at: this.prepareDate(data.start),
        ends_at: this.prepareDate(data.end),
        max_allowed: data.maxAllowed,
        facility_id: data.facility_id,
        level: data.level,
        visibility: data.visibility == true
          ? 1
          : 2,
        event_url : data.event_url,
        recorded_url : mode == 'save'  ? link  : null
      };
        this.http.updateData(`events/${data.eventId}?center_id=` + this.centerId, reqObj)
        .subscribe(response => {
          if (mode == 'remove') {
            this.selectedEvent.recorded_url = null;
          }
          this.filterEvents();
          this.selectedEvent.recorded_url = link;
          link = '';
          this.addRecordedLink = false;
          this.generalFunctions.openToast('Changes saved for online event', 3000, 'success');
        }),
        err => {
            this.addRecordedLink = false;

          this.generalFunctions.openToast(err.message, 3000, 'error');
        };
  }



  copyToBoard(str) {
    const el = document.createElement('textarea');
    el.value = str;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    this.generalFunctions.openToast('Copied to clipboard', 3000, 'success');
  }

   validURL(str) {
    const pattern = new RegExp('^(https?:\\/\\/)'+ // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
      '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!pattern.test(str);
  }

  isLessThan24Hrs(event){
    const today = moment();
    const eventDay = event.start;

    var duration = moment.duration(today.diff(eventDay))
    var hours = duration.asHours();
    return !(hours <= -24);
  }

  isEventOver(event){
    const today = moment();
    const eventDay = event.end;
    var duration = moment.duration(today.diff(eventDay))
    var hours = duration.asHours();
    console.log(hours >= 0)
    return hours >= 0;
  }

  moveToConfirmed(bookingId, eventId) {
    this.http.getData(`bookings/${eventId}/book/waitlist/${bookingId}?center_id=${this.centerId}`).subscribe(response => {
        this.generalFunctions.openToast('Booking has been confirmed', 3000, 'success');
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
      }, () => {
        this.filterEvents();
        this.getEventInfo(this.selectedEvent);
      });
  }

  resetPt() {
    this.createPt = {
        service_id: 2,
        id: '',
        date: this.defaultDate,
        starts_at: this.defaultDateStart,
        duration: '',
        user_id: '',
        is_recurring: false,
        cycles: {
          type: 'weekly',
          offset: 1
        },
        max_occurences: 6,
        days: {
          mon: false,
          tue: false,
          wed: false,
          thu: false,
          fri: false,
          sat: false,
          sun: false
        },
        ends: 'on',
        end_date: this.defaultDateEnds
      };
  }

}
