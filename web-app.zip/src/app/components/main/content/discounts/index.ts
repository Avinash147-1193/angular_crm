export * from './discounts.component';
