export * from "./discounts-table.component";
