import {Component, OnInit, ElementRef, ViewChild} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import * as moment from "moment";

@Component({templateUrl: "./discounts-table.component.html", styleUrls: ["./discounts-table.component.scss"]})
export class DiscountsTableComponent implements OnInit {
  discountRows: Array<object> = null;
  sort_type: number = 0;
  key: any;
  dt: any;
  search_discount_name: string = "";
  search_filter: boolean = false;

  show_pop_up: boolean = false;

  popup_data: any = {};
  include_center: any = null;

  today: Date = new Date();

  currency = null;
  discountData: any;

  @ViewChild("ajax_sreen")ajax_sreen;

  constructor(private router : Router, private route : ActivatedRoute, private generalFunctions : GeneralServices, private http : ServerAuthService, private el : ElementRef) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getDiscounts();
    console.log(this.discountRows);

    this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;
  }

  /* ----- GENERAL USEFUL FUNCTION FOR THE COMPONENT ----- */

  getDiscounts() {
    this.http.getData("discount" + this.include_center).subscribe(success => {
      this.discountData = success.data;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    }, () => {});
  }

  newFormat(date) {
    return moment(date).format("MMM D");
  }
}
