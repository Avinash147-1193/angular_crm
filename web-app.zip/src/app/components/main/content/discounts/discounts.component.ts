import { Component, OnInit } from '@angular/core';
import { GeneralServices } from '../../../../common/general-services'

@Component({
  templateUrl: './discounts.component.html'
})
export class DiscountsComponent implements OnInit {

  	constructor(
  		private generalFunctions: GeneralServices
  	) {
  	}

  	ngOnInit() {
  	}

}
