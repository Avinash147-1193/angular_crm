import {Component, OnInit, ElementRef, ViewChild, ViewEncapsulation} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import {SelectItem} from 'primeng/api';
import {MembershipTypes} from '../../../../../constants'


@Component({templateUrl: './discount-create.component.html', styleUrls: ['./discount-create.component.scss'], encapsulation: ViewEncapsulation.None})
export class DiscountCreateComponent implements OnInit {
  discountData: any = {
    code: '',
    value: null,
    value_type: 'percent',
    applicable_type: 1,
    starts_at: Date.now(),
    start_time: '',
    expires_at: Date.now(),
    expire_time: '',
    once_per_user: false,
    once_per_order: false,
    usage_limit: false,
    max_redemptions: 0,
    applicable_services: [],
    customer_applicable_type: 1,
    share_type: 'region',
    applicable_tags: []
  };
  pop_up_for : any = null;

  validationFields: any = {};
  pop_up_AddServices: boolean = false;

  isSetEndDate: boolean = false;
  setMax_Redemptions: boolean = false;
  valueTypes: string[] = ['percent', 'fixed'];

  applies: string[] = ['Entire order', 'Specific groups', 'Specific services and products'];
  Date_Types: string[] = ['Start', 'End'];

  createClass = {
    date: Date.now()
  };

  timeDropdown: SelectItem[] = [
    {
      label: '00:00',
      value: '00:00'
    }, {
      label: '00:30',
      value: '00:30'
    }, {
      label: '01:00',
      value: '01:00'
    }, {
      label: '01:30',
      value: '01:30'
    }, {
      label: '02:00',
      value: '02:00'
    }, {
      label: '02:30',
      value: '02:30'
    }, {
      label: '03:00',
      value: '03:00'
    }, {
      label: '03:30',
      value: '03:30'
    }, {
      label: '04:00',
      value: '04:00'
    }, {
      label: '04:30',
      value: '04:30'
    }, {
      label: '05:00',
      value: '05:00'
    }, {
      label: '05:30',
      value: '05:30'
    }, {
      label: '06:00',
      value: '06:00'
    }, {
      label: '06:30',
      value: '06:30'
    }, {
      label: '07:00',
      value: '07:00'
    }, {
      label: '07:30',
      value: '07:30'
    }, {
      label: '08:00',
      value: '08:00'
    }, {
      label: '08:30',
      value: '08:30'
    }, {
      label: '09:00',
      value: '09:00'
    }, {
      label: '09:30',
      value: '09:30'
    }, {
      label: '10:00',
      value: '10:00'
    }, {
      label: '10:30',
      value: '10:30'
    }, {
      label: '11:00',
      value: '11:00'
    }, {
      label: '11:30',
      value: '11:30'
    }, {
      label: '12:00',
      value: '12:00'
    }, {
      label: '12:30',
      value: '12:30'
    }, {
      label: '13:00',
      value: '13:00'
    }, {
      label: '13:30',
      value: '13:30'
    }, {
      label: '14:00',
      value: '14:00'
    }, {
      label: '14:30',
      value: '14:30'
    }, {
      label: '15:00',
      value: '15:00'
    }, {
      label: '15:30',
      value: '15:30'
    }, {
      label: '16:00',
      value: '16:00'
    }, {
      label: '16:30',
      value: '16:30'
    }, {
      label: '17:00',
      value: '17:00'
    }, {
      label: '17:30',
      value: '17:30'
    }, {
      label: '18:00',
      value: '18:00'
    }, {
      label: '18:30',
      value: '18:30'
    }, {
      label: '19:00',
      value: '19:00'
    }, {
      label: '19:30',
      value: '19:30'
    }, {
      label: '20:00',
      value: '20:00'
    }, {
      label: '20:30',
      value: '20:30'
    }, {
      label: '21:00',
      value: '21:00'
    }, {
      label: '21:30',
      value: '21:30'
    }, {
      label: '22:00',
      value: '22:00'
    }, {
      label: '22:30',
      value: '22:30'
    }, {
      label: '23:00',
      value: '23:00'
    }, {
      label: '23:30',
      value: '23:30'
    }
  ];
  check = true;
  currency: any;
  location: any;
  region: any;

  startDatepickerConfig = {
    showWeekNumbers: false,
    minDate: new Date(),
    containerClass: 'theme-default'
  };
  center_id: any;
  isCreate: any;
  discountId: any;
  dataLoaded: boolean = false;
  applicables: any;
  bounceApplicable: any = [];
  serviceModal: boolean = false;
  planData: any;
  packData: any;
  allServices: any;
  constructor(private router : Router, private route : ActivatedRoute, private generalFunctions : GeneralServices, private http : ServerAuthService, private el : ElementRef) {}

  ngOnInit() {
    this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.discountData.start_time = new Date().getHours() + ':00';
    this.discountData.expire_time = new Date().getHours() + ':00';
    if (this.router.url.includes('/discounts/create')) {
      this.isCreate = true;
    } else {
      this.isCreate = false;
      this.discountId = this.route.snapshot.paramMap.get('id');
      this.getDiscount();
    }
    this.getCurrentLocation();
  }

  updateDiscount() {
    var start = this.discountData.starts_at;
    var end = this.discountData.expires_at;
    if (start) {
      start = this.generalFunctions.convertDateToISOFormat(start);
      this.discountData.starts_at = start['date'] + ' ' + this.discountData.start_time + ':00';
    }
    if (this.isSetEndDate) {
      if (end) {
        end = this.generalFunctions.convertDateToISOFormat(end);
        this.discountData.expires_at = end['date'] + ' ' + this.discountData.expire_time + ':00';
      }
    } else {
      delete this.discountData.expires_at;
    }

    if (this.discountData.applicable_type == 3) {
      if (this.applicables.length == 0) {
        console.log('select atleast one service or change the type');
      } else {
        this.discountData.applicable_services = [];
        this.applicables.forEach(element => {
          this.discountData.applicable_services.push({service_id: element.service_id, service_type_id: element.service_type_id});
        });
      }
    } else {
      delete this.discountData.applicable_services;
    }

    delete this.discountData.applicable_customer_tags;
    if (this.discountData.customer_applicable_type == 1) {
      delete this.discountData.applicable_tags;
    } else {
      this.discountData.applicable_tags.length == 0
        ? this.generalFunctions.openToast('Please attach tags', 3000, 'error')
        : '';
    }

    this.http.updateData(`discount/${this.discountId}?center_id=${this.center_id}`, this.discountData).subscribe(response => {
      this.router.navigate(['/client/discounts']);
      this.generalFunctions.openToast('Discount updated', 3000, 'success');
    }, error => {
      let msg;
      if (error['errors']) {
        msg = error['errors'][Object.keys(error['errors'])[0]];
      } else {
        msg = error.message;
      }
      this.generalFunctions.openToast(msg, 3000, 'error');
    });
  }

  deleteDiscount() {
    this.http.deleteData(`discount/${this.discountId}?center_id=${this.center_id}`).subscribe(response => {
      this.generalFunctions.openToast('Discount deleted', 3000, 'success');
      this.router.navigate(['/client/discounts']);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.router.navigate(['/client/discounts']);
    });
  }

  getDiscount() {
    this.http.getData(`discount/${this.discountId}?center_id=${this.center_id}`).subscribe(response => {
      this.discountData = response.data;
      this.discountData['start_time'] = response.data.starts_at.split(' ')[1].split(':')[0] + ':' + response.data.starts_at.split(' ')[1].split(':')[1];
      this.isSetEndDate = response.data.expires_at == null
        ? false
        : true;
      if (this.isSetEndDate) {
        this.discountData['expire_time'] = response.data.expires_at.split(' ')[1].split(':')[0] + ':' + response.data.expires_at.split(' ')[1].split(':')[1];
      }
      this.dataLoaded = true;
      if (this.discountData.applicable_type == 3) {
        this.getServices();
      }
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  prepareApplicable() {
    this.allServices.forEach(allService => {
      this.discountData.applicable_services.forEach(service => {
        if (service.id === allService.id) {
          allService.checked = true;
        }
        // if (service.service_id == 4 && allService.type == 'pack' && service.id == allService.id) {
        //   allService.checked = true;
        // }
      });
    });
    this.mapServices(this.allServices);
  }

  removeApplicable(applicable) {

   this.applicables = this.applicables.filter((applicableItem) => applicable.service_type_id !== applicableItem.service_type_id)
    // this.applicables.forEach(applicables => {
    //   if (applicable.service_type_id === applicables.service_type_id) {
    //     this.applicables.pop(applicables);
    //   }
    // });

    this.bounceApplicable.forEach(element => {
      if (element.id === applicable.service_type_id) {
        element.checked = false;
      }
    //   if (element.id == applicable.service_type_id && element.type == 'pack' && applicable.service_id == 4) {
    //     element.checked = false;
    //   }
    });
  }

  getServices() {
    this.http.sendData('plan?center_id=' + this.center_id, '').subscribe(response => {
        this.planData = response.data.filter((plan) => plan.type === MembershipTypes.PLAN || plan.type === MembershipTypes.SUBSCRIPTION);
        this.packData = response.data.filter((pack) => pack.type === MembershipTypes.PACK);
      console.log('this.planData, this.packData', this.planData, this.packData);
      this.createCheckboxes();
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  createCheckboxes() {
    this.allServices = [];
    this.planData.forEach(element => {
      element.type = 'plan';
      element.checked = false;
      this.allServices.push(element);
    });
    this.packData.forEach(element => {
      element.type = 'pack';
      element.checked = false;
      this.allServices.push(element);
    });
    this.prepareApplicable();
  }

  createDiscount() {
    if (this.discountData.value) {

            var start = this.discountData.starts_at;
            var end = this.discountData.expires_at;
            if (start) {
                start = this.generalFunctions.convertDateToISOFormat(start);
                this.discountData.starts_at = start['date'] + ' ' + this.discountData.start_time + ':00';
            }
            if (this.isSetEndDate) {
                if (end) {
                    end = this.generalFunctions.convertDateToISOFormat(end);
                    this.discountData.expires_at = end['date'] + ' ' + this.discountData.expire_time + ':00';
                }
            } else {
                delete this.discountData.expires_at;
            }

            if (this.discountData.applicable_type == 3) {
                if (this.applicables.length == 0) {
                    console.log('select atleast one service or change the type');
                } else {
                    this.applicables.forEach(element => {
                        this.discountData.applicable_services.push({
                            service_id: element.service_id,
                            service_type_id: element.service_type_id
                        });
                    });
                }
            } else {
                delete this.discountData.applicable_services;
            }

            if (this.discountData.customer_applicable_type == 1) {
                delete this.discountData.applicable_tags;
            } else {
                this.discountData.applicable_tags.length == 0 ?
                    this.generalFunctions.openToast('Please attach tags', 3000, 'error') :
                    '';
            }

            this.http.sendData(`discount?center_id=${this.center_id}`, this.discountData).subscribe(response => {
                this.generalFunctions.openToast('Discount saved successfully', 3000, 'success');
                this.router.navigate(['client/discounts']);
            }, error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            });

    } else {
        this.generalFunctions.openToast('Please enter a valid discount value', 3000, 'error');
    }
  }

  dj() {
    if (this.discountData.value) {
      var start = this.discountData.starts_at;
      var end = this.discountData.expires_at;
      if (start) {
        console.log('this.discountData.start_time', this.discountData.start_time);
        start = this.generalFunctions.convertDateToISOFormat(start);
        this.discountData.starts_at = start['date'] + ' ' + this.discountData.start_time + ':00';
      }
      if (this.isSetEndDate) {
        if (end) {
          end = this.generalFunctions.convertDateToISOFormat(end);
          this.discountData.expires_at = end['date'] + ' ' + this.discountData.expire_time + ':00';
        }
      } else {
        delete this.discountData.expires_at;
      }

      if (this.discountData.applicable_type == 3) {
        if (this.applicables.length == 0) {
          console.log('select atleast one service or change the type');
        } else {
          this.applicables.forEach(element => {
            this.discountData.applicable_services.push({service_id: element.service_id, service_type_id: element.service_type_id});
          });
        }
      } else {
        delete this.discountData.applicable_services;
      }

      console.log('this.discountData', this.discountData);
    }
  }

  cancelChanges() {
    this.router.navigate(['/client/discounts']);
  }

  //AUTOMATED CODE GENERATOR
  generateCode(e) {
    var msg: string;
    if (this.discountData['name'] == '') {
      msg = 'Enter discount name!';
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    if (this.discountData['value'] == '') {
      msg = 'Enter discount amount!';
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    if (!/^\d+$/.test(this.discountData['value'])) {
      msg = 'Amount can have only digits!';
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    //let random = randomatic(new Date().toString(), 5);
    this.discountData['code'] = 'DISCOUNT' + Math.floor(Math.random() * 1000) + this.discountData['value'];
  }

  handleTypeChange(e) {}

  popAddServicesModal() {
    this.pop_up_AddServices = true;
  }

  mapServices(event) {
    if (event == 'close') {
      this.serviceModal = false;

      if (this.bounceApplicable.length == 0) {
        this.discountData.applicable_type = 1;
        return;
      }

      this.bounceApplicable.forEach(element => {
        element.checked = false;
      });
      this.applicables.forEach(applicables => {
        this.bounceApplicable.forEach(element => {
          if (element.id === applicables.service_type_id) {
            element.checked = true;
          }
        //   if (element.id == applicables.service_type_id && element.type == 'pack' && applicables.service_id == 4) {
        //     element.checked = true;
        //   }
        });
      });
      return;
    }

    this.serviceModal = false;
    this.bounceApplicable = event;

    let finalObject = [];

    event.forEach(service => {
      if (service.checked == true) {
        finalObject.push({
          service_type_id: service.id,
          service_id: 1,
          service_name: service.name
        });
      }
    });

    this.applicables = finalObject;

    if (this.applicables.length == 0) {
      this.discountData.applicable_type = 1;
    }
  }

  closeServicesModal(event) {
    this.serviceModal = false;
  }

  openAllServices() {
    this.serviceModal = true;
  }

  removeApplicables() {
    this.discountData.applicable_services = [];
    this.applicables = [];
    this.bounceApplicable = [];
  }

  mapTags(event) {
    let tags = [];
    tags = event.map(tag => {
      return tag.label.id;
    });
    this.discountData.applicable_tags = tags;
  }

  getCurrentLocation() {
    this.http.getData(`center/${this.center_id}?center_id=${this.center_id}`).subscribe(response => {
      this.location = response.data.name;
      this.region = response.data.region.name;
    });
  }
}
