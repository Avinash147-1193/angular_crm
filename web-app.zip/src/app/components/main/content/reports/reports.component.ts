import {
	Component,
	OnInit,
	OnChanges,
	ViewChild,
	ElementRef,
	ChangeDetectorRef
} from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { GeneralServices } from "app/common/general-services";
import { ServerAuthService } from "app/common/server-auth";
import { getTreeNoValidDataSourceError } from "@angular/cdk/tree";
import { Response } from "selenium-webdriver/http";

@Component({
	selector: "app-reports",
	templateUrl: "./reports.component.html",
	styleUrls: ["./reports.component.scss"]
})
export class ReportsComponent implements OnInit {
	bsValue = new Date();
	bsRangeValue: Date[];
	maxDate = new Date();
	center_id: any;
	reportsData: any;
	currency: any;
	constructor(
		private router: Router,
		private route: ActivatedRoute,
		private http: ServerAuthService,
		private generalFunctions: GeneralServices
	) {
		this.maxDate.setDate(this.maxDate.getDate() + 7);
		this.bsRangeValue = [this.bsValue, this.maxDate];
	}

	ngOnInit() {
		this.center_id = JSON.parse(localStorage.getItem("currentUser"))[
			"center_id"
		];
		this.currency = JSON.parse(
			localStorage.getItem("localization")
		).currency.symbol;

		this.getReports();
	}

	getReports() {
		this.http
			.sendData(`reports/sales?center_id=${this.center_id}`, [])
			.subscribe(
				response => {
					console.log("response", response);
					this.reportsData = response.data;
				},
				err => {}
			);
	}
}
