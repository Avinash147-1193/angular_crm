import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-detailed-reports',
  templateUrl: './detailed-reports.component.html',
  styleUrls: ['./detailed-reports.component.scss']
})
export class DetailedReportsComponent implements OnInit {

    reportMode: any;


    constructor(private route: ActivatedRoute) { }

    ngOnInit(): void {

        this.route.queryParamMap.subscribe(params => {
            const routeIncludes = {
              ...params.keys,
              ...params
            };

            this.reportMode = routeIncludes['params'].mode;

          });
    }

}
