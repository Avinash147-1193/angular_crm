import {Component, OnInit, ViewEncapsulation, ElementRef, ViewChild} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "app/common/general-services";
import {ServerAuthService} from "app/common/server-auth";
import {SelectItem} from "primeng/api";
import * as moment from "moment";


@Component({
  selector: 'app-reports-customer',
  templateUrl: './reports-customer.component.html',
  styleUrls: ['./reports-customer.component.scss,../../../styles/reports.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ReportsCustomerComponent implements OnInit {

    reportMode: any;
    bsValue = new Date();
    bsRangeValue: Date[];
    maxDate = new Date();
    startEndDate: any;
    center_id: any;
    currency: any;
    reportsPagination: any;
    reportsData: any;
    reportsSummary: any;
    pop_custom: boolean = false;
    reqState: any = {};
    dateRangeDropdown: any = [
      {
        label: "Today",
        value: "today"
      }, {
        label: "Yesterday",
        value: "yesterday"
      }, {
        label: "Last 7 days",
        value: "last7"
      }, {
        label: "Last 30 days",
        value: "last30"
      }, {
        label: "Last 60 days",
        value: "last60"
      }, {
        label: "Last 90 days",
        value: "last90"
      }
    ];


    colDropdown: SelectItem[] = [

    ];

    colSelected : any

    descendingOrder: boolean;
    DatepickerConfig = {
      showWeekNumbers: false,
      containerClass: "theme-default"
    };
    sortTable = {
      created_at: false,
      id: false,
      subtotal: false,
      discount: false,
      amount_refunded: false,
      amount_total: false,
      amount_write_off: false,
      amount_due: false,
      tax: false
    };
    sortTablePayment = {
      created_at: false,
      payment_id: false,
      sale_id: false,
      amount: false
    };
    populateSummary: boolean;
    populateBody: boolean;
    @ViewChild("mainScreen", {
      read: ElementRef,
      static: false
    })
    elementView: ElementRef;
    hovered : boolean = false;
    viewHeight: number = 22;
    hoveredLeft : boolean = false;
    hoveredRight : boolean = true;

    query = {
      condition: 'and',
      rules: [
        {field: 'age', operator: 'equal to', value: '20'},
        {field: 'gender', operator: '>=', value: 'm'}
      ]
    };



    constructor(
        private router : Router,
        private route : ActivatedRoute,
        private http : ServerAuthService,
        private generalFunctions : GeneralServices) {
      this.bsRangeValue = [this.bsValue, this.maxDate];
    }

    ngOnInit() {
      this.center_id = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
      this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;
      this.route.queryParamMap.subscribe(params => {
        let routeIncludes = {
          ...params.keys,
          ...params
        };




        if (routeIncludes["params"].mode == "sale") {
          this.reportMode = "sale";
          this.saleWithFilter([]);


        }

        if (routeIncludes["params"].mode == "payment") {
          this.reportMode = "payment";
          this.paymentWithFilter([]);

          this.colDropdown = [{
              label : "Sale id",
              value : "sale_id"
          },{
              label : "Customer",
              value : "customer"
          },{
              label : "Status",
              value : "status"
          },{
              label : "Mode",
              value : "mode"
          },{
              label : "Type",
              value : "type"
          },{
              label : "Amount",
              value : 'amount'
          }]
            this.colSelected = ['sale_id','customer','status','mode','type','amount']
        }
      });

      this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      this.descendingOrder = false;
      this.populateSummary = false;
      this.populateBody = false;

    }

    ngAfterViewInit(): void {
      //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
      //Add 'implements AfterViewInit' to the class.


    }
    ngAfterViewChecked(): void {

      //Called after every check of the component's view. Applies to components only.
      //Add 'implements AfterViewChecked' to the class.
      // this.viewHeight = this.elementView.nativeElement.offsetHeight;
    }
    exportReport() {
      let mode;
      this.reportMode === "sale"
        ? (mode = "sales")
        : this.reportMode === "payment"
          ? (mode = "payments")
          : null;
      this.http.sendData(`reports/${mode}?export=true&center_id=${this.center_id}`, this.reqState).subscribe(response => {

        var str = response.url;
        var res = str.split("/");
        let name = res[res.length - 1];
        this.download(response.url, name);


      }, err => {});
    }

    updateTimeline(range, sort, type) {


        this.populateBody = false;

        let start = moment(this.bsRangeValue[0]).format("YYYY-MM-DD");
        let end = moment(this.bsRangeValue[1]).format("YYYY-MM-DD");
        let reqObj = {};
        let sortBy = sort;

        if (sortBy !== null) {
          this.resetSortTable(sort);
          console.log("this.sortTable", this.sortTable);
          if (this.sortTable[sort]) {
            reqObj["sortBy"] = {
              [sort]: "desc"
            };
          } else {
            reqObj["sortBy"] = {
              [sort]: "asc"
            };
          }
        }
        reqObj["starts_at"] = start;
        reqObj["ends_at"] = end;
        this.reqState = reqObj;
        this.customerReports(reqObj);





      if (this.reportMode === "sale") {
        if (type == null) {
          this.sortTable = {
            created_at: false,
            id: false,
            subtotal: false,
            discount: false,
            amount_refunded: false,
            amount_total: false,
            amount_write_off: false,
            amount_due: false,
            tax: false
          };
        }

        this.populateBody = false;

        let start = moment(this.bsRangeValue[0]).format("YYYY-MM-DD");
        let end = moment(this.bsRangeValue[1]).format("YYYY-MM-DD");
        let reqObj = {};
        let sortBy = sort;

        if (sortBy !== null) {
          this.resetSortTable(sort);
          console.log("this.sortTable", this.sortTable);
          if (this.sortTable[sort]) {
            reqObj["sortBy"] = {
              [sort]: "desc"
            };
          } else {
            reqObj["sortBy"] = {
              [sort]: "asc"
            };
          }
        }
        reqObj["starts_at"] = start;
        reqObj["ends_at"] = end;
        this.reqState = reqObj;
        this.saleWithFilter(reqObj);
      }

      if (this.reportMode == "payment") {
        if (type == null) {
          this.sortTablePayment = {
            created_at: false,
            payment_id: false,
            sale_id: false,
            amount: false
          };
        }

        this.populateBody = false;

        let start = moment(this.bsRangeValue[0]).format("YYYY-MM-DD");
        let end = moment(this.bsRangeValue[1]).format("YYYY-MM-DD");
        let reqObj = {};
        let sortBy = sort;

        if (sortBy !== null) {
          this.resetPaymentSortTable(sort);
          if (this.sortTablePayment[sort]) {
            reqObj["sortBy"] = {
              [sort]: "desc"
            };
          } else {
            reqObj["sortBy"] = {
              [sort]: "asc"
            };
          }
        }
        reqObj["starts_at"] = start;
        reqObj["ends_at"] = end;
        this.reqState = reqObj;

        this.paymentWithFilter(reqObj);
      }


    }


    customerReports(reqObj){
        this.http.sendData(`reports/customers?center_id=${this.center_id}`,reqObj).subscribe(response => {
            this.reportsData = response.data;
            this.reportsPagination = response.meta.pagination;
            this.populateBody = true;
            console.log('this.reportsData', this.reportsData)
        })
        // this.http.sendData(`reports/customers/summary?center_id=${this.center_id}`, reqObj).subscribe(response => {
        //     this.populateSummary = true;
        //     this.reportsSummary = response.data;
        //   }, err => {})

          setTimeout(() => {
            var hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
            this.hoveredLeft = this.hoveredRight = hs;
        }, 1000);
    }
    paymentWithFilter(reqObj) {
      this.http.sendData(`reports/payments?center_id=${this.center_id}`, reqObj).subscribe(response => {
        this.pop_custom = false;
        this.reportsData = response.data;
        this.reportsPagination = response.meta.pagination;
        this.populateBody = true;

      }, err => {});

      this.http.sendData(`reports/payments/summary?center_id=${this.center_id}`, reqObj).subscribe(response => {
        this.populateSummary = true;
        this.reportsSummary = response.data;
      }, err => {});

      setTimeout(() => {
          var hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
          this.hoveredLeft = this.hoveredRight = hs;
      }, 1000);

    }


    saleWithFilter(reqObj) {
      this.http.sendData(`reports/sales?center_id=${this.center_id}`, reqObj).subscribe(response => {
        this.pop_custom = false;
        this.reportsData = response.data;
        this.reportsPagination = response.meta.pagination;
        this.populateBody = true;


      }, err => {});

      this.http.sendData(`reports/sales/summary?center_id=${this.center_id}`, reqObj).subscribe(response => {
        this.populateSummary = true;
        this.reportsSummary = response.data;
      }, err => {});

      setTimeout(() => {
          var hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
          this.hoveredLeft = this.hoveredRight = hs;
      }, 1000);

    }

    loadMore(mode) {
      let urlAppend = this.reportsPagination.current_page + 1;
      this.http.sendData(`reports/${mode}?page=${urlAppend}&center_id=${this.center_id}`, this.reqState).subscribe(response => {
        this.reportsData = this.reportsData.concat(response.data);
        this.reportsPagination["count"] += response.meta.pagination.count;
        this.reportsPagination["current_page"] = response.meta.pagination.current_page;
        this.reportsPagination["links"] = response.meta.pagination.links;
        this.reportsPagination["per_page"] = response.meta.pagination.per_page;
        this.reportsPagination["total"] = response.meta.pagination.total;
        this.reportsPagination["total_page"] = response.meta.pagination.total_page;

      }, err => {});
    }

    //helpers
    download(url, name) {
      let a = document.createElement("a");
      a.setAttribute("href", url);
      a.setAttribute("target", "_blank");
      a.setAttribute("download", name);
      document.querySelector(".link-container").appendChild(a);
      a.click();
      let container = document.querySelector(".link-container");
    }

    updateSettings(mode) {
      if (mode == "last7") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.maxDate.setDate(this.maxDate.getDate() - 7);
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
      if (mode == "last30") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.maxDate.setDate(this.maxDate.getDate() - 30);
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
      if (mode == "last60") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.maxDate.setDate(this.maxDate.getDate() - 60);
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
      if (mode == "last90") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.maxDate.setDate(this.maxDate.getDate() - 90);
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
      if (mode == "today") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
      if (mode == "yesterday") {
        this.bsValue = new Date();
        this.maxDate = new Date();
        this.maxDate.setDate(this.maxDate.getDate() - 1);
        this.bsValue.setDate(this.bsValue.getDate() - 1);
        this.bsRangeValue = [this.maxDate, this.bsValue];
        this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
      }
    }

    updateStartEnd(start, end) {
      this.startEndDate = moment(start).format("DD-MMM-YYYY") + " to " + moment(end).format("DD-MMM-YYYY");
    }

    resetSortTable(sort) {
      for (var key in this.sortTable) {
        if (this.sortTable.hasOwnProperty(key)) {
          if (key == sort) {
            this.sortTable[sort] = !this.sortTable[sort];
          } else {
            this.sortTable[key] = false;
          }
        }
      }
    }

    resetPaymentSortTable(sort) {
      for (var key in this.sortTablePayment) {
        if (this.sortTablePayment.hasOwnProperty(key)) {
          if (key == sort) {
            this.sortTablePayment[sort] = !this.sortTablePayment[sort];
          } else {
            this.sortTablePayment[key] = false;
          }
        }
      }
    }

    takeToSale(sale_id, id) {
      this.router.navigate([`/client/customers/${id}`], {
        queryParams: {
          sale: sale_id
        }
      });
    }

    scrollRight(){
      this.elementView.nativeElement.scrollLeft += 150;
      this.hoveredLeft = true;
      let element = this.elementView.nativeElement;
      var hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
      this.hoveredRight = true;
      if (Math.round(element.scrollWidth) - Math.round(element.scrollLeft) == element.clientWidth){
          this.hoveredRight = false;
      }

    }
    scrollLeft(){
      this.hoveredRight = true;
      let element = this.elementView.nativeElement;
      this.hoveredLeft = true;
      if ( Math.round(element.scrollLeft) == 0 ){
          this.hoveredLeft = false;
      }
      this.elementView.nativeElement.scrollLeft -= 150;
    }

    updateTable(){
        this.customerReports(this.reqState);
    }

    checkSale(data){
        return this.colSelected.includes(data)
    }

}
