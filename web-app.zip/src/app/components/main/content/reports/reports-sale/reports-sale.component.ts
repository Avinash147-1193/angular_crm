import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import { ActivatedRoute} from '@angular/router';
@Component({selector: 'app-reports-sale', templateUrl: './reports-sale.component.html', styleUrls: ['./reports-sale.component.scss'], encapsulation: ViewEncapsulation.None})
export class ReportsSaleComponent implements OnInit {
  reportMode: any;
//   bsValue = new Date();
//   bsRangeValue: Date[];
//   maxDate = new Date();
//   startEndDate: any;
//   center_id: any;
//   currency: any;
//   reportsPagination: any;
//   reportsData: any;
//   reportsSummary: any;
//   pop_custom = false;
//   reqState: any = {};
//   dateRangeDropdown: any = [
//     {
//       label: 'Today',
//       value: 'today'
//     }, {
//       label: 'Yesterday',
//       value: 'yesterday'
//     }, {
//       label: 'Last 7 days',
//       value: 'last7'
//     }, {
//       label: 'Last 30 days',
//       value: 'last30'
//     }, {
//       label: 'Last 60 days',
//       value: 'last60'
//     }, {
//       label: 'Last 90 days',
//       value: 'last90'
//     }
//   ];


//   defaultFilterData = {
//       data: {
//           rules: [
//               {
//                   'field': 'order_date',
//                   'operator': 'on',
//                   'value': '2020-05-30'
//               }
//           ]
//           ,
//           condition: 'and'
//       },
//       filters: [
//           {
//               'name': 'Order date',
//               'field': 'order_date',
//               'type': 'date',
//               'show_currency': false,
//               'is_selectable': false,
//               'is_link': false,
//               'is_sortable': false
//           },
//           {
//               'name': 'Order number',
//               'field': 'id',
//               'type': 'number',
//               'show_currency': false,
//               'is_selectable': false,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Order amount',
//               'field': 'amount_total',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': false,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Name',
//               'field': 'contact_name',
//               'type': 'text',
//               'show_currency': false,
//               'is_selectable': false,
//               'is_link': false,
//               'is_sortable': false
//           },
//           {
//               'name': 'Email',
//               'field': 'contact_email',
//               'type': 'text',
//               'show_currency': false,
//               'is_selectable': false,
//               'is_link': false,
//               'is_sortable': false
//           },
//           {
//               'name': 'Discount value',
//               'field': 'discount_amount',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Tax collected',
//               'field': 'tax',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Payment amount due',
//               'field': 'amount_due',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Write-off amount',
//               'field': 'amount_write_off',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Refund amount',
//               'field': 'amount_refunded',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           },
//           {
//               'name': 'Net payment amount',
//               'field': 'amount_paid',
//               'type': 'number',
//               'show_currency': true,
//               'is_selectable': true,
//               'is_link': false,
//               'is_sortable': true
//           }
//       ],
//       handleValueChange: (value) => {
//           console.log('from reports:', value);
//       }

//   }


//   colDropdown: SelectItem[] = [

//   ];

//   colSelected: any

//   descendingOrder: boolean;
//   DatepickerConfig = {
//     showWeekNumbers: false,
//     containerClass: 'theme-default'
//   };
//   sortTable = {
//     created_at: false,
//     id: false,
//     subtotal: false,
//     discount: false,
//     amount_refunded: false,
//     amount_total: false,
//     amount_write_off: false,
//     amount_due: false,
//     tax: false
//   };
//   sortTablePayment = {
//     created_at: false,
//     payment_id: false,
//     sale_id: false,
//     amount: false
//   };
//   populateSummary: boolean;
//   populateBody: boolean;
//   @ViewChild('mainScreen', {
//     read: ElementRef,
//     static: false
//   })
//   elementView: ElementRef;
//   hovered = false;
//   viewHeight = 22;
//   hoveredLeft = false;
//   hoveredRight = true;

//   query = {
//     condition: 'and',
//     rules: [
//       {field: 'age', operator: 'equal to', value: '20'},
//       {field: 'gender', operator: '>=', value: 'm'}
//     ]
//   };

//   config: QueryBuilderConfig = {
//     fields: {
//       age: {name: 'Age', type: 'number', operators: ['equal to', 'more than', 'less than']},
//       gender: {
//         name: 'Gender',
//         type: 'category',
//         operators: ['equal to', 'more than', 'less than'],
//         options: [
//           {name: 'Male', value: 'm'},
//           {name: 'Female', value: 'f'}
//         ]
//       }
//     }
//   }


  constructor(
      private route: ActivatedRoute) { }

  ngOnInit() {
    // this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    // this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
    this.route.queryParamMap.subscribe(params => {
      const routeIncludes = {
        ...params.keys,
        ...params
      };

      this.reportMode = routeIncludes['params'].mode;

    });

    // this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
    // this.descendingOrder = false;
    // this.populateSummary = false;
    // this.populateBody = false;

  }



//   exportReport() {
//     let mode;
//     this.reportMode === 'sale'
//       ? (mode = 'sales')
//       : this.reportMode === 'payment'
//         ? (mode = 'payments')
//         : null;
//     this.http.sendData(`reports/${mode}?export=true&center_id=${this.center_id}`, this.reqState).subscribe(response => {

//       const str = response.url;
//       const res = str.split('/');
//       const name = res[res.length - 1];
//       this.download(response.url, name);

//       //   if (mode == "sales") {
//       //     console.log("this.reportsExport", response.url);
//       //     var str = response.url;
//       //     var res = str.split("/");

//       //     let name = res[res.length - 1];
//       //     console.log("name", name);
//       //     this.download(response.url, name);
//       //   }
//       //   if (mode == "payments") {
//       //     console.log("payments");
//       //     console.log("url", response);
//       //     let blob = new Blob([response], {type: "text/csv"});

//       //     let url = window.URL.createObjectURL(blob);

//       //     if (navigator.msSaveOrOpenBlob) {
//       //       navigator.msSaveBlob(blob, "doc.csv");
//       //     } else {
//       //       let a = document.createElement("a");
//       //       a.href = url;
//       //       a.download = "doc.csv";
//       //       document.body.appendChild(a);
//       //       a.click();
//       //       document.body.removeChild(a);
//       //       console.log("a", a);
//       //     }
//       //     window.URL.revokeObjectURL(url);
//       //   }
//     }, err => {});
//   }

//   updateTimeline(range, sort, type) {
//     if (this.reportMode === 'sale') {
//       if (type == null) {
//         this.sortTable = {
//           created_at: false,
//           id: false,
//           subtotal: false,
//           discount: false,
//           amount_refunded: false,
//           amount_total: false,
//           amount_write_off: false,
//           amount_due: false,
//           tax: false
//         };
//       }

//       this.populateBody = false;

//       const start = moment(this.bsRangeValue[0]).format('YYYY-MM-DD');
//       const end = moment(this.bsRangeValue[1]).format('YYYY-MM-DD');
//       const reqObj = {};
//       const sortBy = sort;

//       if (sortBy !== null) {
//         this.resetSortTable(sort);
//         console.log('this.sortTable', this.sortTable);
//         if (this.sortTable[sort]) {
//           reqObj['sortBy'] = {
//             [sort]: 'desc'
//           };
//         } else {
//           reqObj['sortBy'] = {
//             [sort]: 'asc'
//           };
//         }
//       }
//       reqObj['starts_at'] = start;
//       reqObj['ends_at'] = end;
//       this.reqState = reqObj;
//       this.saleWithFilter(reqObj);
//     }

//     if (this.reportMode == 'payment') {
//       if (type == null) {
//         this.sortTablePayment = {
//           created_at: false,
//           payment_id: false,
//           sale_id: false,
//           amount: false
//         };
//       }

//       this.populateBody = false;

//       const start = moment(this.bsRangeValue[0]).format('YYYY-MM-DD');
//       const end = moment(this.bsRangeValue[1]).format('YYYY-MM-DD');
//       const reqObj = {};
//       const sortBy = sort;

//       if (sortBy !== null) {
//         this.resetPaymentSortTable(sort);
//         if (this.sortTablePayment[sort]) {
//           reqObj['sortBy'] = {
//             [sort]: 'desc'
//           };
//         } else {
//           reqObj['sortBy'] = {
//             [sort]: 'asc'
//           };
//         }
//       }
//       reqObj['starts_at'] = start;
//       reqObj['ends_at'] = end;
//       this.reqState = reqObj;

//       this.paymentWithFilter(reqObj);
//     }
//   }

//   paymentWithFilter(reqObj) {
//     this.http.sendData(`reports/payments?center_id=${this.center_id}`, reqObj).subscribe(response => {
//       this.pop_custom = false;
//       this.reportsData = response.data;
//       this.reportsPagination = response.meta.pagination;
//       this.populateBody = true;

//     }, err => {});

//     this.http.sendData(`reports/payments/summary?center_id=${this.center_id}`, reqObj).subscribe(response => {
//       this.populateSummary = true;
//       this.reportsSummary = response.data;
//     }, err => {});

//     setTimeout(() => {
//         const hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
//         this.hoveredLeft = this.hoveredRight = hs;
//     }, 1000);

//   }


//   saleWithFilter(reqObj) {
//     this.http.sendData(`reports/sales?center_id=${this.center_id}`, reqObj).subscribe(response => {
//       this.pop_custom = false;
//       this.reportsData = response.data;
//       this.reportsPagination = response.meta.pagination;
//       this.populateBody = true;


//     }, err => {});

//     this.http.sendData(`reports/sales/summary?center_id=${this.center_id}`, reqObj).subscribe(response => {
//       this.populateSummary = true;
//       this.reportsSummary = response.data;
//     }, err => {});

//     setTimeout(() => {
//         const hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
//         this.hoveredLeft = this.hoveredRight = hs;
//     }, 1000);

//   }

//   loadMore(mode) {
//     const urlAppend = this.reportsPagination.current_page + 1;
//     this.http.sendData(`reports/${mode}?page=${urlAppend}&center_id=${this.center_id}`, this.reqState).subscribe(response => {
//       this.reportsData = this.reportsData.concat(response.data);
//       this.reportsPagination['count'] += response.meta.pagination.count;
//       this.reportsPagination['current_page'] = response.meta.pagination.current_page;
//       this.reportsPagination['links'] = response.meta.pagination.links;
//       this.reportsPagination['per_page'] = response.meta.pagination.per_page;
//       this.reportsPagination['total'] = response.meta.pagination.total;
//       this.reportsPagination['total_page'] = response.meta.pagination.total_page;

//     }, err => {});
//   }

//   // helpers
//   download(url, name) {
//     const a = document.createElement('a');
//     a.setAttribute('href', url);
//     a.setAttribute('target', '_blank');
//     a.setAttribute('download', name);
//     document.querySelector('.link-container').appendChild(a);
//     a.click();
//     const container = document.querySelector('.link-container');

//     // a.removeChild(a);
//   }

//   updateSettings(mode) {
//     if (mode == 'last7') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.maxDate.setDate(this.maxDate.getDate() - 7);
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//     if (mode == 'last30') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.maxDate.setDate(this.maxDate.getDate() - 30);
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//     if (mode == 'last60') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.maxDate.setDate(this.maxDate.getDate() - 60);
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//     if (mode == 'last90') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.maxDate.setDate(this.maxDate.getDate() - 90);
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//     if (mode == 'today') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//     if (mode == 'yesterday') {
//       this.bsValue = new Date();
//       this.maxDate = new Date();
//       this.maxDate.setDate(this.maxDate.getDate() - 1);
//       this.bsValue.setDate(this.bsValue.getDate() - 1);
//       this.bsRangeValue = [this.maxDate, this.bsValue];
//       this.updateStartEnd(this.bsRangeValue[0], this.bsRangeValue[1]);
//     }
//   }

//   updateStartEnd(start, end) {
//     this.startEndDate = moment(start).format('DD-MMM-YYYY') + ' to ' + moment(end).format('DD-MMM-YYYY');
//   }

//   resetSortTable(sort) {
//     for (const key in this.sortTable) {
//       if (this.sortTable.hasOwnProperty(key)) {
//         if (key == sort) {
//           this.sortTable[sort] = !this.sortTable[sort];
//         } else {
//           this.sortTable[key] = false;
//         }
//       }
//     }
//   }

//   resetPaymentSortTable(sort) {
//     for (const key in this.sortTablePayment) {
//       if (this.sortTablePayment.hasOwnProperty(key)) {
//         if (key == sort) {
//           this.sortTablePayment[sort] = !this.sortTablePayment[sort];
//         } else {
//           this.sortTablePayment[key] = false;
//         }
//       }
//     }
//   }

//   takeToSale(sale_id, id) {
//     this.router.navigate([`/client/customers/${id}`], {
//       queryParams: {
//         sale: sale_id
//       }
//     });
//   }

//   scrollRight() {
//     this.elementView.nativeElement.scrollLeft += 150;
//     this.hoveredLeft = true;
//     const element = this.elementView.nativeElement;
//     const hs = this.elementView.nativeElement.scrollWidth > this.elementView.nativeElement.clientWidth;
//     this.hoveredRight = true;
//     if (Math.round(element.scrollWidth) - Math.round(element.scrollLeft) == element.clientWidth) {
//         this.hoveredRight = false;
//     }

//   }
//   scrollLeft() {
//     this.hoveredRight = true;
//     const element = this.elementView.nativeElement;
//     this.hoveredLeft = true;
//     if ( Math.round(element.scrollLeft) == 0 ) {
//         this.hoveredLeft = false;
//     }
//     this.elementView.nativeElement.scrollLeft -= 150;
//   }

//   updateTable() {
//       this.saleWithFilter(this.reqState);
//   }

//   checkSale(data) {
//       return this.colSelected.includes(data)
//   }
}
