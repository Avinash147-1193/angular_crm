import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-home',
  templateUrl: './reports-home.component.html',
  styleUrls: ['./reports-home.component.scss']
})
export class ReportsHomeComponent implements OnInit {

reportsList: any = []
  constructor() {
    this.reportsList = [
        {
            heading: 'Financial Reports',
            desc: 'Keep track of your orders and payments. View your tax collection, total refunds, failed payments are more.',
            reports: [
                {name: 'Total sales', link: 'sales', availability: true},
                {name: 'Payments', link: 'payments', availability: true},
                {name: 'Gift card report', link: 'gift_card', availability: true}

            ]

        },
        {
            heading: 'Membership & Subscription Reports',
            desc: 'View all the active, upcoming and expired memberships. Keep track of your active subscriptions. View remaining credits and expiry date of services packs.',
            reports: [
                {name: 'Memberships', link: 'memberships', availability: true },
                {name: 'Subscriptions', link: 'subscriptions', availability: true},

            ]

        },
        {
            heading: 'Activity Reports',
            desc: 'Gain insights on how your customers bookings your services. Find how your class andn appointment service is performing.',
            reports: [
                {name: 'Bookings by class events', link: 'classes', availability: true },
                {name: 'Bookings by appointment events', link: 'appointments', availability: true},
                {name: 'Bookings by customer', link: 'bookings_by_customer', availability: true },

                {name: 'All cancellations', link: 'cancelations', availability: true },
                {name: 'All no shows', link: 'noshows', availability: true },

            ]

        },
        {
            heading: 'Customer Reports',
            desc: 'Analyse your customer data to discover how they are interacting with your business.  ',
            reports: [
                {name: 'Customer data', link: 'customers', availability: true},
                {name: 'Customers with amount due', link: '', availability: false},
                {name: 'Referral report', link: 'referral', availability: true},

            ]

        },
        {
            heading: 'Lead Reports',
            desc: 'Follow how your prospects are moving through the sales funnel. Track how productive your sales team is.',
            reports: [
                {name: 'Lead data', link: 'leads', availability: true},
                {name: 'Lead by stage', link: '', availability: false },
                {name: 'Lead by staff assigned', link: '', availability: false},
            ]
        },
        {
            heading: 'Communication logs',
            desc: 'View all the communication logs created and sent to your customers and staffs.',
            reports: [
                {name: 'Email logs', link: 'notifications', availability: true},

            ]
        },



    ]
   }

  ngOnInit() {
  }

}
