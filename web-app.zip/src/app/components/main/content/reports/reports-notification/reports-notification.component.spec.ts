import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsNotificationComponent } from './reports-notification.component';

describe('ReportsNotificationComponent', () => {
  let component: ReportsNotificationComponent;
  let fixture: ComponentFixture<ReportsNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsNotificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
