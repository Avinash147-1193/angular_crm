import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-reports-notification',
  templateUrl: './reports-notification.component.html',
  styleUrls: ['./reports-notification.component.scss']
})
export class ReportsNotificationComponent implements OnInit {
    reportMode: any;



  constructor(
    private route: ActivatedRoute) { }

ngOnInit() {
  this.route.queryParamMap.subscribe(params => {
    const routeIncludes = {
      ...params.keys,
      ...params
    };
    this.reportMode = routeIncludes['params'].mode;
  });
}
}
