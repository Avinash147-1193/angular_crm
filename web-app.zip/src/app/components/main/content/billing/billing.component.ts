import { Component, OnInit, ChangeDetectorRef, OnDestroy} from '@angular/core';
import {GeneralServices} from '../../../../common/general-services'
import {ServerAuthService} from '../../../../common/server-auth';
import {environment} from '../../../../../environments/environment';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';




@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.scss', '../../../main/content/services/styles/profiles.scss']
})

export class BillingComponent implements OnInit, OnDestroy {

    cbInstance: any;
    session: any;
    subscription: any;
    smsDetails: any;
    sms: any;
    mode = '';
    pricing = [
        {price : '1000 SMS Monthly', time: '$39/month' },
        {price : '2000 SMS Monthly', time: '$59/month' },
        {price : '3000 SMS Monthly', time: '$119/month' }
    ];
    billings = [
        { name: 'Essential', price : '$99', time: 'every month' },
        { name: 'Pro', price : '$199', time: 'every month' },
        { name: 'Premium', price : '$379', time: 'every month' },
    ];
    topup = [
        {price : '1000 SMS', time: '$49' },
        {price : '5000 SMS', time: '$149' }
    ];
    planMode = false;


  constructor(private generalServices: GeneralServices,
    private http: ServerAuthService,
    private route: ActivatedRoute,
    private ref: ChangeDetectorRef) { }

    ngOnInit() {
        this.route.queryParams.subscribe(params => {
            console.log('params', params)
            if (params['reactivationId'] === '1201') {
                this.mode = 'portal';
            }
            if (params['activationId'] === '1201') {
                this.mode = 'checkout-after';

            }
            if (params['purchaseOnTrial'] === '1201') {
                this.mode = 'checkout-before';

            }
        });
        this.cbInstance = window['Chargebee'].init({
        site: environment.chargebee
        });

        this.setSession();
        this.getSubscriptionDetail();
        this.getSmsDetails();

    }
    // tslint:disable-next-line: use-life-cycle-interface
    ngOnDestroy(): void {
        console.log('clearing chargebee')
        this.cbInstance.logout();
    }
    planModeChange() {

        if (this.planMode) {
            this.billings = [
                { name: 'Essential', price : '$948', time: 'every year' },
                { name: 'Pro', price : '$1908', time: 'every year' },
                { name: 'Premium', price : '$3588', time: 'every year' },
            ];
        } else {
            this.billings = [
                { name: 'Essential', price : '$99', time: 'every month' },
                { name: 'Pro', price : '$199', time: 'every month' },
                { name: 'Premium', price : '$379', time: 'every month' },
            ];
        }
    }


    setSession() {
        let x = this;
        this.cbInstance.setPortalSession(function() {
                // return success;
            return x.http.getData(`center/chargebee/portal${x.generalServices.includeCenter()}`).toPromise();
        })
    }

    openPortal() {
        this.openCb()
    }

    openCheckout() {
        let x = this;

       this.cbInstance.logout();
       this.cbInstance.openCheckout({

        hostedPage : () => { return x.http.getData(`center/chargebee/portal${x.generalServices.includeCenter()}`).toPromise() },
         loaded: () => {
           console.log("checkout opened");
         },
         close: () => {
             console.log("checkout closed");
         },
         success: (hostedPageId) => {
           console.log(hostedPageId);
           // Hosted page id will be unique token for the checkout that happened
           // You can pass this hosted page id to your backend
           // and then call our retrieve hosted page api to get subscription details
           // https://apidocs.chargebee.com/docs/api/hosted_pages#retrieve_a_hosted_page
         },
         step: (value) => {
             // value -> which step in checkout
             console.log(value);
         }
       });

    }

    openCb() {
        let x = this;
        let cbPortal = this.cbInstance.createChargebeePortal();
        cbPortal.open({
            close() {
                x.closePortal();
            }
        });
    }

    closePortal() {
        // this.cbInstance.logout();
    }

    getSubscriptionDetail() {
        this.http.getData(`subscription${this.generalServices.includeCenter()}`)
        .subscribe(response => {
            this.subscription = response.subscription;
            this.sms = response.sms_subscription;
            this.subscription.next_billing_at =  this.subscription.next_billing_at ? moment(this.subscription.next_billing_at).format('Do MMM YYYY') : '';
        })
    }

    getSmsDetails(){
        this.http.sendData(`plan/essentialplan${this.generalServices.includeCenter()}`,{})
        .subscribe(response => {
            this.smsDetails = response;
        })
    }


}


