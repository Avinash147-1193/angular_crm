import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {GeneralServices} from '../../../../common/general-services';
import {ServerAuthService} from '../../../../common/server-auth';
import {SelectItem} from 'primeng/api';


@Component({
  selector: 'app-apps',
  templateUrl: './apps.component.html',
  styleUrls: ['./apps.component.scss']
})
export class AppsComponent implements OnInit {
    include_center: any = null;
    zoomIntegrated: any;
    zoomConnected: any = false;
    pop_up_for: any = null;
    navigationList: Array<string> = ['settings', 'about'];
    view = 'settings';
    emails: SelectItem[] = [];
    staffs: any;
    emailId: any;
    chimpConnected = false;
    adyenConnected = false;
    chimpData: any;
    adyenData: any;
    setChimp = false;
    setAdyen = false;



  constructor(private route: ActivatedRoute, private router: Router,
    private generalFunctions: GeneralServices, private http: ServerAuthService) { }

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();

    this.getApps();

    this.route.queryParams.subscribe(params => {
        if (params['app'] === 'zoom') {
            this.pop_up_for = 'zoom'
            // this.zoomConnected  = true;
        }
        if (params['app'] === 'mailchimp') {
            this.setChimp = true;
        }
        if (params['app'] === 'adyen') {
            this.setAdyen = true;
        }
    });
  }

  closeZoom() {
    this.router.navigate([], {
        queryParams: {
         app: null
        },
        queryParamsHandling: 'merge'
      })
      this.pop_up_for = null;
      this.zoomConnected ?  this.view = 'settings' : this.view = 'about';
}

  getApps() {
    this.http.getData('apps' + this.include_center).subscribe(success => {
        const zoom =  success.apps.filter(app => app.app.name === 'Zoom');
        const chimp = success.apps.filter(app => app.app.name === 'Mailchimp')
        const adyen = success.apps.filter(app => app.app.name === 'Adyen')

        zoom.length > 0 ? this.zoomConnected = true : this.zoomConnected = false;
        if (!this.zoomConnected) {
            this.view = 'about';
        }
        if (this.zoomConnected) {
            this.getZoomUsers();
        }

        chimp.length > 0 ? this.chimpConnected = true : this.chimpConnected = false;
        if (this.chimpConnected) {
            this.chimpData = chimp[0];
            if (this.setChimp) {
                this.pop_up_for = 'chimp';
            }
        } else if (this.setChimp) {
            this.pop_up_for = 'chimp';
        }

        adyen.length > 0 ? this.adyenConnected = true : this.adyenConnected = false;
        if (this.adyenConnected) {
            this.adyenData = adyen[0];
            if (this.setAdyen){
                this.pop_up_for = 'adyen';

            }
        } else if (this.setAdyen) {
            this.pop_up_for = 'adyen';

        }

      }, error => {
        this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
      });
  }

  getStaff() {
    this.http.getData('apps/zoom/users/map' + this.include_center).subscribe(success => {
        this.staffs = success.users;

        this.staffs.forEach(staff => {
            if (staff.zoom_user) {
                staff.zoomId = staff.zoom_user.id;
            } else {
                staff.zoomId = null;
                console.log('staff.zoom_user null', staff.zoom_user);
            }
        });

      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });

  }


  getZoomUsers() {
    this.http.getData('apps/zoom/users' + this.include_center).subscribe(success => {
        const data = success.users;
        data.forEach(user => {
            let obj = {
                label : user.email,
                value : user.id
            }
            this.emails.push(obj);
        });
        this.getStaff();
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
  }


  updateStaffZoom(staff){
      console.log('we are trying to update now',staff);
        const reqObj = {
                zoom_user_id: staff.zoomId,
                user_id: staff.id
        }
      this.http.updateData('apps/zoom/users/map' + this.include_center, reqObj).subscribe(success => {
          this.generalFunctions.openToast('User updated', 3000, success);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      })
  }



  //populate dropdown
  //loop through all the staff
  //check if the map data has the staffid
  //if staffid show the populated dropdown with the selected email
  //else show no account linked as value in dropdown






  getZoomAuth() {
    this.http.getData('apps/zoom/auth' + this.include_center).subscribe(success => {
        success = success;
        window.location.href = success.url;
        this.getApps();
      }, error => {
        this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
      });
  }

  uninstallZoom() {
      this.http.deleteData('apps/zoom' + this.include_center).subscribe(success => {
        this.generalFunctions.openToast('Uninstalled app!', 3000, 'success');
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      })
  }



  triggerView(event) {
    this.view = event;
  }

  addParams(key) {
    this.router.navigate(['client/apps'], { queryParams: { app: key } });
  }
}
