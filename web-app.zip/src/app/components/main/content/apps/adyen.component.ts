import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import {GeneralServices} from '../../../../common/general-services';
import {ServerAuthService} from '../../../../common/server-auth';
import { Router } from '@angular/router';
import { SelectItem } from 'primeng/api';


@Component({
    selector: 'app-adyen',
    template: `
    <aside>
        <div class="pop-modal-container">
            <div class="pop-modal-overlay" >
            </div>
            <div class="pop-modal pop-modal-medium">
                <div class="pop-apps-header">
                    <div class="pop-apps-left">
                        <div class="pop-apps-icon">
                            <img src="../../../../../assets/img/adyen@3x.png" style="width:64px;height:64px;" alt="mailchimp">
                        </div>
                        <div class="pop-apps-name">
                            <span class="pop-apps-app-name">Adyen</span>
                            <span class="pop-apps-app-subline">Payment processing platform</span>
                        </div>
                    </div>
                    <div class="pop-apps-right">
                        <div class="pop-apps-button">
                            <button class="d-btn" id="d-btn-green" *ngIf="!adyenConnected && !install" (click)="install = true;view = 'settings';">Install now</button>
                            <button class="d-btn" *ngIf="adyenConnected" [disabled]="adyenConnected">Installed</button>
                        </div>
                    </div>
                </div>
                <div>
                    <div style="padding: 0 32px;" *ngIf="install">
                        <app-profile-navigation [items]="navigationList" (outputData)="triggerView($event)">
                        </app-profile-navigation>
                    </div>
                    <div class="pop-apps-desc" *ngIf="view === 'about'">
                        <p>
                            Process payments from POS, website and customer mobile apps through the Adyen payments platform.
                        </p>
                        <p> With this integration you can: </p>
                        <p>
                            • Securely save card information to your Adyen account
                            <br/>
                            • Process payments through POS, website and customer mobile app
                        </p>
                        <p>
                            Note 👉
                            <br/>
                            You cannot use Adyen Payment Platform for subscriptions. You can only process one-off payments using this payment gateway.
                        </p>
                    </div>
                    <div class="pop-apps-settings" *ngIf="view === 'settings'">

                        <div class="set-container form-fitday" >
                            <div class="setting-description" *ngIf="!adyenConnected && list.length > 0">
                                <div class="title">Use Payment Account from existing location(s)</div>
                                <div class="description">Connect to the Adyen account which  is in use with your existing locations. This will fetch the saved payment information for customers moving between those locations:</div>
                                <div class="form-field"  style="margin-top:12px;">
                                    <mat-radio-group class="radio-group" [(ngModel)]="connectMode">
                                        <mat-radio-button [value]="'existing'">Connect to an account from existing location</mat-radio-button>
                                        <mat-radio-button [value]="'new'">Connect to a new payments account</mat-radio-button>
                                    </mat-radio-group>
                                </div>
                            </div>

                            <ng-container *ngIf="connectMode === 'existing' && !adyenConnected && list.length > 0">
                                <div class="setting-description">
                                    <div class="title">Select location</div>
                                    <div class="description">Choose the location to which your Adyen account is already connected:</div>
                                    <div class="form-field" *ngIf="list.length > 0" style="margin-top:12px;">
                                        <p-dropdown  class="select-dropdown"  [options]="list"
                                            autoWidth="false" [style]="{'width':'320px'}" [(ngModel)]="selectedCenter"
                                            placeholder="Select center" >
                                        </p-dropdown>
                                    </div>
                                </div>
                            </ng-container>

                            <ng-container *ngIf="connectMode === 'new'">
                                <div class="form-field">
                                        <div class="set-field-label">
                                            Merchant Account
                                        </div>
                                        <div class="set-field-tagname">
                                            Add the Merchant Account ID for the account you want to integrate
                                        </div>
                                        <input type="text" [disabled] = 'disabled' [style]="{'width':'320px'}" [(ngModel)]="merchantAccount" />
                                </div>
                                <div class="form-field">
                                    <div class="set-field-label">
                                        API key
                                    </div>
                                    <div class="set-field-tagname">
                                        Add your API key from Adyen <a href='https://docs.adyen.com/checkout/get-started' target='_blank'>(Learn how)</a>
                                    </div>
                                    <input type="text" [disabled] = 'disabled' [style]="{'width':'320px'}" [(ngModel)]="apiKey" />
                                </div>
                                <div class="form-field">
                                    <div class="set-field-label">
                                        Client Key
                                    </div>
                                    <div class="set-field-tagname">
                                        Add your Client Key from Adyen <a href='https://docs.adyen.com/checkout/get-started' target='_blank'>(Learn how)</a>
                                    </div>
                                    <input type="text" [disabled] = 'disabled' [style]="{'width':'320px'}" [(ngModel)]="adyenId" />
                                </div>
                            </ng-container>
                        </div>
                    </div>
                </div>
                <div class="pop-modal-footer border-grey border-top" *ngIf="install && view === 'settings'" style="padding:24px;">
                    <div class="buttons" id="jc-flex-end">
                        <button type="button" class="d-btn"
                            (click)="show_pop_up=false; pop_up_for=null;" (click)="closeAdyen(); view = 'about';">CANCEL</button>
                        <button type="button" class="btn-default"  *ngIf="disabled" (click)="removeKey()" style="margin-right:0px;">
                            Remove </button>
                         <button type="button"  *ngIf="!disabled && connectMode === 'new'" class="btn-default"
                         [disabled] = 'addingKey' (click)="addKey()" style="margin-right:0px;">
                            Save
                            <i *ngIf="addingKey" class="fa fa-circle-o-notch fa-spin" style="color:#7e95a3; margin-left:12px;
								margin-top:2px;"></i>
                        </button>
                        <button type="button"  *ngIf="!disabled && connectMode === 'existing'" class="btn-default"
                         [disabled] = 'addingKey' (click)="addExistingKey()" style="margin-right:0px;">
                            Save
                            <i *ngIf="addingKey" class="fa fa-circle-o-notch fa-spin" style="color:#7e95a3; margin-left:12px;
								margin-top:2px;"></i>
                        </button>
                    </div>
                </div>
                <div class="pop-cross" style="top:6px; right:6px;" (click)="closeAdyen(); view = 'about';">
                    <img src="../../../../../../assets/img/cross-gray.svg" alt="close">
                </div>
            </div>

        </div>
    </aside>
    `,
    styleUrls: ['./apps.component.scss']
})


export class AdyenComponent {

    @Input() adyenConnected;
    @Input() adyenData;
    @Output() valueChange = new EventEmitter();
    @Output() updateApps = new EventEmitter();
    navigationList: Array<string> = ['settings', 'about'];
    view = 'settings';
    install = false;
    includeCenter: any;
    validKey = false;
    apiKey: any;
    merchantAccount: any;
    adyenId: any;
    selectedList: any = null;
    selectedCenter: any = null;
    disabled = false;
    keyAdded = false;
    addingKey = false;
    connectMode = 'existing';
    list: SelectItem[] = [];

    constructor(private generalFunction: GeneralServices, private http: ServerAuthService,
        private router: Router) { }

    // tslint:disable-next-line: use-life-cycle-interface
    ngOnInit() {
        this.includeCenter = this.generalFunction.includeCenter();
        this.getCenters();
        if (this.adyenConnected) {
            this.install = this.validKey =  this.disabled = true;
            this.connectMode = 'new';
            this.apiKey = this.adyenData.settings.api_key;
            this.merchantAccount = this.adyenData.settings.merchant_account;
            this.adyenId = this.adyenData.settings.client_id;
            this.selectedList = this.adyenData.settings.list_id;
        } else {
            this.view = 'about';
            this.install = false;
        }
    }

    triggerView(event) {
        this.view = event;
    }

    getCenters() {
        this.http.getData(`clients/centers` + this.includeCenter)
        .subscribe(success => {
            const centers = success.data.filter((center) => center.is_adyen_connected)
                            .map((item) => { return {label : item.name, value : item.center_id}});
            this.list = centers;
            this.list.length > 0 && !this.adyenConnected ? this.connectMode = 'existing' : this.connectMode = 'new';
        },
        err => {
            this.generalFunction.openToast(err.message, 3000, 'error');
        })
    }

    closeAdyen() {
        this.valueChange.emit(null);
        this.router.navigate([], {
            queryParams: {
             app: null
            },
            queryParamsHandling: 'merge'
          })
    }

    addKey () {
        this.addingKey = true;
        const payload = {
            api_key: this.apiKey,
            merchant_account: this.merchantAccount,
            client_id : this.adyenId
        }
        this.http.sendData(`apps/adyen` + this.includeCenter, payload)
        .subscribe(success => {
            this.adyenConnected = true;
            this.disabled = true;
            this.generalFunction.openToast('Key added successfully', 3000, 'success');
            this.addingKey = false;
            this.updateApp();
        },
        err => {
            this.addingKey = false;
            this.generalFunction.openToast(err.message, 3000, 'error');
            this.updateApp();
        })
    }

    addExistingKey () {
        this.addingKey = true;
        const payload = {
            existing_center_id: this.selectedCenter
        }
        this.http.sendData(`apps/adyen/link` + this.includeCenter, payload)
        .subscribe(success => {
            this.adyenConnected = true;
            this.disabled = true;
            this.generalFunction.openToast('Key added successfully', 3000, 'success');
            this.addingKey = false;
            this.connectMode = 'new';
            this.updateApp();
            this.http.getData('apps' + this.includeCenter).subscribe(success => {
                const adyen = success.apps.filter(app => app.app.name === 'Adyen')
                this.adyenData = adyen[0];
                this.apiKey = this.adyenData.settings.api_key;
                this.merchantAccount = this.adyenData.settings.merchant_account;
                this.adyenId = this.adyenData.settings.client_id;
            }, error => {});
        },
        err => {
            this.addingKey = false;
            this.generalFunction.openToast(err.message, 3000, 'error');
            this.updateApp();
        })
    }

    updateApp() {
        this.updateApps.emit();
    }

    removeKey() {
        this.addingKey = true;
        const payload = {
            api_key: this.apiKey,
            merchant_account: this.merchantAccount,
            client_id : this.adyenId
        }
        this.http.deleteData(`apps/adyen/remove` + this.includeCenter)
        .subscribe(response => {
            this.generalFunction.openToast('Key removed successfully', 3000, 'success');
            this.disabled = this.adyenConnected = this.validKey = false;
            this.apiKey = this.merchantAccount = this.adyenId = null;
            this.getCenters();
            this.updateApps.emit();
        },
        err => {
            this.generalFunction.openToast(err.message, 3000, 'error')
        }, () => {
            this.addingKey = false;
        })
    }
}
