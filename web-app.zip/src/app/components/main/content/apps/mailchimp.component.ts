import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';
import {GeneralServices} from '../../../../common/general-services';
import {ServerAuthService} from '../../../../common/server-auth';
import {SelectItem} from 'primeng/api';
import { Router } from '@angular/router';
import * as moment from 'moment'

@Component({
    selector: 'app-mailchimp',
    template: `
    <aside>
        <div class="pop-modal-container">
            <div class="pop-modal-overlay" >
            </div>
            <div class="pop-modal pop-modal-medium">
                <div class="pop-apps-header">
                    <div class="pop-apps-left">
                        <div class="pop-apps-icon">
                            <img src="../../../../../assets/img/chimp@3x.png" style="width:64px;height:64px;" alt="mailchimp">
                        </div>
                        <div class="pop-apps-name">
                            <span class="pop-apps-app-name">Mailchimp</span>
                            <span class="pop-apps-app-subline">Sync your contacts and send marketing emails</span>
                        </div>
                    </div>
                    <div class="pop-apps-right">
                        <div class="pop-apps-button">
                            <button class="d-btn" id="d-btn-green" *ngIf="!mailchimpConnected && !install" (click)="install = true;view = 'settings';">Install now</button>
                            <button class="d-btn" *ngIf="mailchimpConnected" [disabled]="mailchimpConnected">Installed</button>
                        </div>
                    </div>
                </div>
                <div>
                    <div style="padding: 0 32px;" *ngIf="install">
                        <app-profile-navigation [items]="navigationList" (outputData)="triggerView($event)">
                        </app-profile-navigation>
                    </div>
                    <div class="pop-apps-desc" *ngIf="view === 'about'">
                        <p>
                            Sync all your Studioyou contacts to Mailchimp with this integration. All the existing leads
                            and customers from your account are added to the selected audience (list) in Mailchimp.
                        </p>
                        <p>With this integration you can: </p>
                        <p>
                            • Sync all your contacts in Studioyou with Mailchimp. <br/>
                            • Choose the Mailchimp audience list to wish to sync the contacts with.<br/>
                            • View contacts email subscription status in Studioyou<br/>
                            • Sync your Studioyou tags with Mailchimp
                        </p>
                    </div>
                    <div class="pop-apps-settings" *ngIf="view === 'settings'">
                        <div class="success-message" *ngIf="validKey && disabled && checkforHour()">
                        The app has been successfully installed. Your contacts are being synced with your Mailchimp audience list. It can take upto 30 minutes to sync the contacts first time.
                        </div>
                        <div class="set-container form-fitday">
                                <div class="form-field">
                                    <div class="set-field-label">
                                        API key
                                    </div>
                                    <div class="set-field-tagname">
                                        Add your API key from Mailchimp <a href='https://mailchimp.com/help/about-api-keys/' target='_blank'>(Learn how)</a>
                                    </div>
                                    <input type="text" [disabled] = 'disabled' [style]="{'width':'320px'}" [(ngModel)]="apiKey" (change)='addAPIKey()'/>
                                    <!-- <span id="text-btn" (click)="removeKey()" *ngIf="disabled">Remove key</span> -->
                                </div>

                                <div class="form-field" *ngIf="validKey">
                                    <div class="set-field-label">
                                        Audience (List)
                                     </div>
                                     <div class="set-field-tagname">
                                        Select the Mailchimp Audience you want to sync Studioyou contacts with. All your leads and contacs will be added to this list
                                    </div>
                                    <p-dropdown *ngIf="list.length > 0" class="select-dropdown" [disabled]='disabled' [options]="list"
                                        autoWidth="false" [style]="{'width':'320px'}" [(ngModel)]="selectedList"
                                        placeholder="Select list" >
                                    </p-dropdown>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="pop-modal-footer border-grey border-top" *ngIf="install && view === 'settings' && validKey && selectedList" style="padding:24px;">
                    <div class="buttons" id="jc-flex-end">
                        <button type="button" class="d-btn"
                            (click)="show_pop_up=false; pop_up_for=null;" (click)="closeChimp(); view = 'about';">CANCEL</button>
                        <button type="button" class="btn-default"  *ngIf="disabled" (click)="removeKey()" style="margin-right:0px;">
                            Remove </button>
                         <button type="button"  *ngIf="!disabled" class="btn-default"
                         [disabled] = 'addingKey' (click)="addKey()" style="margin-right:0px;">
                            Save
                            <i *ngIf="addingKey" class="fa fa-circle-o-notch fa-spin" style="color:#7e95a3; margin-left:12px;
								margin-top:2px;"></i>
                        </button>
                    </div>
                </div>
                <div class="pop-cross" style="top:6px; right:6px;" (click)="closeChimp(); view = 'about';">
                    <img src="../../../../../../assets/img/cross-gray.svg" alt="close">
                </div>
            </div>

        </div>
    </aside>
    `,
    styleUrls: ['./apps.component.scss']
})
export class MailchimpComponent implements OnInit {
    @Input() mailchimpConnected;
    @Input() chimpData;
    @Output() valueChange = new EventEmitter();
    @Output() updateApps = new EventEmitter();
    navigationList: Array<string> = ['settings', 'about'];
    view = 'settings';
    install = false;
    includeCenter: any;
    validKey = false;
    list: SelectItem[] = [];
    apiKey: any;
    selectedList: any = null;
    disabled = false;
    keyAdded = false;
    addingKey = false;

    constructor(private generalFunction: GeneralServices, private http: ServerAuthService,
        private router: Router) { }

    ngOnInit(): void {
        this.includeCenter = this.generalFunction.includeCenter();
        if (this.mailchimpConnected) {
            this.install = this.validKey =  this.disabled = true;
            this.apiKey = this.chimpData.settings.api_key;
            this.selectedList = this.chimpData.settings.list_id;
            this.getList(this.apiKey);
        }
        else {
            this.view = 'about';
            this.install = false;
        }
    }

    triggerView(event) {
        this.view = event;
    }

    closeChimp() {
        this.valueChange.emit(null);
        this.router.navigate([], {
            queryParams: {
             app: null
            },
            queryParamsHandling: 'merge'
          })
    }

    addAPIKey() {
        const payload = {
            api_key : this.apiKey
        }
        if (this.apiKey.length > 0) {
            this.http.sendData(`apps/mailchimp/test` + this.includeCenter, payload).subscribe(success => {
                console.log('success', success)
                this.generalFunction.openToast('Please select the audience list', 2000, 'success')
                this.validKey = this.keyAdded = true;
                this.getList(this.apiKey);
            },
            err => {
                this.generalFunction.openToast(err.message, 3000, 'error')
            })
        }
    }

    getList(key) {
        const payload = {
            api_key : key
        }
        this.http.sendData(`apps/mailchimp/lists` + this.includeCenter, payload).subscribe( success => {
            this.prepareList(success.lists)
        },
        err => {})
    }

    prepareList(list) {
        this.list = list.map(item => {
            return {
                label: item.name,
                value: item.id
            }
        })
    }

    addKey () {
        this.addingKey = true;
        const payload = {
            api_key: this.apiKey,
            list_id: this.selectedList,
        }
        this.http.sendData(`apps/mailchimp/` + this.includeCenter, payload)
        .subscribe(success => {
            this.mailchimpConnected = true;
            this.disabled = true;
            this.generalFunction.openToast('Key added successfully', 3000, 'success');
            this.addingKey = false;
            this.updateApp();
        },
        err => {
            this.addingKey = false;
            this.generalFunction.openToast(err.message, 3000, 'error');
            this.updateApp();
        })
    }

    updateApp() {
        this.updateApps.emit();
    }

    removeKey() {
        this.addingKey = true;

        const payload = {
            api_key: this.apiKey,
            list_id: this.selectedList,
        }
        this.http.deleteBody(`apps/mailchimp/` + this.includeCenter, payload)
        .subscribe(response => {
            this.generalFunction.openToast('Key removed successfully', 3000, 'success');
            this.disabled = this.mailchimpConnected = this.validKey = false;
            this.apiKey = null;
            this.selectedList = null;
            this.updateApps.emit();

        },
        err => {
            this.generalFunction.openToast(err.message, 3000, 'error')
        }, () => {
            this.addingKey = false;

        })
    }

    checkforHour() {
    const diff =  moment().diff(this.chimpData.created_at, 'hours');
    console.log('diff', diff < 24)
    return diff <= 24;
    }
}
