export * from './marketing.component'
