import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ServerAuthService} from "app/common/server-auth";
import {GeneralServices} from "app/common/general-services";

@Component({selector: "app-referral", templateUrl: "./referral.component.html", styleUrls: ["./referral.component.scss"]})
export class ReferralComponent implements OnInit {
  constructor(private router : Router, private generalFunction : GeneralServices, private http : ServerAuthService) {}

  centerId: any;
  setupNotFound: boolean;
  referralSetup: any = {
    banner_text: ""
  };

  ngOnInit() {
    this.centerId = JSON.parse(localStorage.getItem("currentUser"))["center_id"];

    this.checkReferral();
  }
  checkReferral() {
    this.http.getData("marketing/referrals?center_id=" + this.centerId).subscribe(response => {
      this.referralSetup = response.data;
      this.setupNotFound = false;
    }, err => {
      this.setupNotFound = true;
    });
  }

  updateReferral() {
    let y = {
      type: this.referralSetup.trigger_type,
      condition: "eq",
      condition_value: this.referralSetup.trigger_condition_value
    };
    this.referralSetup.trigger = y;
    this.http.updateData(`marketing/referrals/${this.referralSetup.id}?center_id=${this.centerId}`, this.referralSetup).subscribe(response => {
      this.generalFunction.openToast("Banner text updated successfully", 3000, "success");
      this.referralSetup = response.data;
    }, err => {
      this.generalFunction.openToast("Banner text update failed", 3000, "error");
    });
  }
}
