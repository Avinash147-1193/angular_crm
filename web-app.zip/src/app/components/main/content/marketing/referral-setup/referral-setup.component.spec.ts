import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferralSetupComponent } from './referral-setup.component';

describe('ReferralSetupComponent', () => {
  let component: ReferralSetupComponent;
  let fixture: ComponentFixture<ReferralSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReferralSetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReferralSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
