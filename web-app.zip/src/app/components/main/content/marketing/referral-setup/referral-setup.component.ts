import {Component, OnInit, ViewEncapsulation, ChangeDetectorRef} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";

import {ServerAuthService} from "app/common/server-auth";
import {GeneralServices} from "app/common/general-services";
import {SelectItem} from "primeng/api";

@Component({
  selector: "app-referral-setup",
  templateUrl: "./referral-setup.component.html",
  styleUrls: [
    "../../services/styles/services.scss", "./referral-setup.component.scss", "../../events-calendar/events-calendar.component.scss"
  ],
  encapsulation: ViewEncapsulation.None
})
export class ReferralSetupComponent implements OnInit {
  constructor(private http : ServerAuthService, private generalFunctions : GeneralServices, private cdRef : ChangeDetectorRef, private route : Router) {}
  currentSection: number = 1;
  nextOne: boolean = false;
  nextTwo: boolean = false;
  nextThree: boolean = false;
  openRef: boolean = false;
  openQuillRef: boolean = false;
  message: boolean = false;
  referrerService: any = {
    service_id: "",
    id: ""
  };
  referringService: any = {
    service_id: "",
    id: "",
    region: ""
  };

  tags: any = [
    "customer_first_name",
    "business_name",
    "branch_name",
    "event_name",
    "event_date",
    "starts_at",
    "start_time",
    "end_time",
    "ends_at",
    "trainer_first_name"
  ];

  refTags: any = ["referred_by_first_name", "signup_referral_link", "referral_code", "business_name"];

  referralSetup = {
    banner_text: "Banner text",
    referred: {
      offer_type: "1"
    },
    referring: {
      offer_type: "1"
    },
    trigger: {
      type: "events_attended",
      condition: "eq",
      value: 2
    },
    messages: {
      referring_customer: {
        message: {
          subject: "Congratulations! You have earned referral reward.",
          body: "Hi {referring_customer_first_name} You have earned the referral rewards for referring your friend {referred_customer_first_name}."
        }
      },

      referred_customer: {
        message: {
          subject: "Hey! Use my referral link",
          body: "Your friend has invited you to join {business_name}. Avail your referral offer by signingup on our mobile app. Use my referral code {referral_code} while signing up."
        }
      }
    }
  };
  placeholders: any;
  centerId: any;
  groupedService: SelectItem[];
  allRegions: any;
  loaded: boolean = false;
  setup: boolean = false;

  triggerOptions: SelectItem[];
  referralId: any;

  //   0: {label: "Appointments", items: Array(7)}
  // 1: {label: "Class", items: Array(9)}
  // 2: {label: "Memberships", items: Array(10)}
  // 3: {label: "Sale", items: Array(4)}

  ngOnInit() {
    this.centerId = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.placeholders = ["referred_by_first_name", "signup_referral_link", "referral_code", "business_name"];
    this.triggerOptions = [
      {
        value: "events_attended",
        label: "Class/Appointment attended"
      }
    ];
    if (this.route.url.includes("referral/edit")) {
      this.setup = false;
      this.getAllRegions().then(() => {
        this.getReferralSetup();
      });
    } else if (this.route.url.includes("referral/setup")) {
      this.setup = true;
      this.getAllRegions().then(() => {
        this.loaded = true;
      });
    }
  }

  getAllRegions() {
    return new Promise((resolve, reject) => {
      this.http.getData("marketing/referrals/regions?service_id=1&center_id=" + this.centerId).subscribe(response => {
        let refined = [];
        let allRegion = response.regions;
        allRegion.forEach(regions => {
          var regPlan = regions.plans.map(plan => {
            return {
              value: {
                id: plan.id || null,
                service_id: "plan",
                region: regions.id
              },
              label: plan.name || null
            };
          });

          var regPack = regions.packs.map(plan => {
            return {
              value: {
                id: plan.id || null,
                service_id: "pack",
                region: regions.id
              },
              label: plan.name || null
            };
          });
          let x = {
            name: regions["name"],
            service: (this.groupedService = [
              ...regPlan,
              ...regPack
            ]),
            referredModel: {
              service_id: "",
              id: "",
              region: regions["id"]
            },
            referringModel: {
              service_id: "",
              id: "",
              region: regions["id"]
            }
          };
          refined.push(x);

          this.allRegions = refined;
          resolve();
          console.log("getAllRegions", this.allRegions);
        });
      }, err => {});
    });
  }

  onChange(model) {}

  getReferralSetup() {
    this.http.getData("marketing/referrals?center_id=" + this.centerId).subscribe(response => {
      console.log("response", response);
      let referral = response.data;
      this.referralId = response.data.id;
      this.referralSetup = {
        banner_text: referral.banner_text,
        trigger: {
          type: referral.trigger_type.toString(),
          condition: referral.trigger_condition,
          value: referral.trigger_condition_value
        },
        referred: {
          offer_type: referral.new_customer_offer_type.toString()
        },
        referring: {
          offer_type: referral.referring_customer_offer_type.toString()
        },

        messages: {
          referring_customer: {
            message: {
              subject: referral.messages.referring_customer.message.subject,
              body: referral.messages.referring_customer.message.body
            }
          },
          referred_customer: {
            message: {
              subject: referral.messages.referred_customer.message.subject,
              body: referral.messages.referred_customer.message.body
            }
          }
        }
      };
      this.allRegions.forEach((region, i) => {
        // id: 4, service_id: "plan", region: 2
        // customer_type: 2, id: 1, service_id: null, service_type_id: null, region_id: 2
        //   region.referringModel = referral.offers.referred_customer[i];
        if (referral.offers.referred_customer[i].service_id !== null) {
          this.allRegions[i].referredModel = {
            service_id: referral.offers.referred_customer[i].service_id == 4
              ? "pack"
              : "plan",
            id: referral.offers.referred_customer[i].service_type_id,
            region: referral.offers.referred_customer[i].region_id
          };
        } else {
          this.allRegions[i].referredModel = {
            service_id: null,
            id: null,
            region: referral.offers.referred_customer[i].region_id
          };
        }

        if (referral.offers.referring_customer[i].service_id !== null) {
          this.allRegions[i].referringModel = {
            service_id: referral.offers.referring_customer[i].service_id == 4
              ? "pack"
              : "plan",
            id: referral.offers.referring_customer[i].service_type_id,

            region: referral.offers.referring_customer[i].region_id
          };
        } else {
          this.allRegions[i].referringModel = {
            service_id: null,
            id: null,
            region: referral.offers.referring_customer[i].region_id
          };
        }
        if (i == referral.offers.referring_customer.length - 1) {
          this.loaded = true;
        }
      });

      this.cdRef.detectChanges();
    }, err => {});
  }

  setupReferral() {
    let request = {
      banner_text: this.referralSetup.banner_text,
      new_customer_offer_type: 1,
      referring_customer_offer_type: 1,

      trigger: {
        type: "events_attended",
        condition: "eq",
        condition_value: this.referralSetup.trigger.value
      },
      offers: {
        referring_customer: [],
        referred_customer: []
      },
      messages: {
        referred_customer: {
          message: {
            subject: this.referralSetup.messages.referred_customer.message.subject,
            body: this.referralSetup.messages.referred_customer.message.body
          }
        },
        referring_customer: {
          message: {
            subject: this.referralSetup.messages.referring_customer.message.subject,
            body: this.referralSetup.messages.referring_customer.message.body
          }
        }
      }
    };

    this.allRegions.forEach(region => {
      request.offers.referred_customer.push({
        customer_type: 1,
        service_id: region.referredModel.service_id
          ? region.referredModel.service_id == "plan"
            ? 1
            : 4
          : null,
        service_type_id: region.referredModel.id
          ? region.referredModel.id
          : null,
        region_id: region.referredModel.region
      });
      request.offers.referring_customer.push({
        customer_type: 2,
        service_id: region.referringModel.service_id
          ? region.referringModel.service_id == "plan"
            ? 1
            : 4
          : null,
        service_type_id: region.referringModel.id
          ? region.referringModel.id
          : null,
        region_id: region.referringModel.region
      });
    });
    this.http.sendData("marketing/referrals?center_id=" + this.centerId, request).subscribe(response => {
      console.log("response", response);
      this.generalFunctions.openToast("Referral program setup successful", 3000, "success");
      this.route.navigateByUrl("/client/referral");
    }, err => {
      this.generalFunctions.openToast(err, 3000, "error");
    });
  }

  updateReferral() {
    let request = {
      banner_text: this.referralSetup.banner_text,
      new_customer_offer_type: 1,
      referring_customer_offer_type: 1,

      trigger: {
        type: "events_attended",
        condition: "eq",
        condition_value: this.referralSetup.trigger.value
      },
      offers: {
        referring_customer: [],
        referred_customer: []
      },
      messages: {
        referred_customer: {
          message: {
            subject: this.referralSetup.messages.referred_customer.message.subject,
            body: this.referralSetup.messages.referred_customer.message.body
          }
        },
        referring_customer: {
          message: {
            subject: this.referralSetup.messages.referring_customer.message.subject,
            body: this.referralSetup.messages.referring_customer.message.body
          }
        }
      }
    };

    this.allRegions.forEach(region => {
      request.offers.referred_customer.push({
        customer_type: 1,
        service_id: region.referredModel.service_id
          ? region.referredModel.service_id == "plan"
            ? 1
            : 4
          : null,
        service_type_id: region.referredModel.id
          ? region.referredModel.id
          : null,
        region_id: region.referredModel.region
      });
      request.offers.referring_customer.push({
        customer_type: 2,
        service_id: region.referringModel.service_id
          ? region.referringModel.service_id == "plan"
            ? 1
            : 4
          : null,
        service_type_id: region.referringModel.id
          ? region.referringModel.id
          : null,
        region_id: region.referringModel.region
      });
    });
    this.http.updateData(`marketing/referrals/${this.referralId}?center_id=${this.centerId}`, request).subscribe(response => {
      this.generalFunctions.openToast("Referral program updated", 2000, "success");
      this.route.navigateByUrl("/client/referral");
    }, err => {});
  }

  goToNext(current, next) {
    switch (current) {
      case 1:
        this.nextOne = true;
        break;

      case 2:
        this.nextTwo = true;
        break;

      default:
        break;
    }

    this.currentSection++;
    document.getElementById(next).click();
  }

  goBack(collapse) {
    this.currentSection--;
    document.getElementById(collapse).click();
  }

  openSlider() {
    this.openRef = true;
  }

  openQuillSlider() {
    this.openQuillRef = true;
  }

  updateMessageContent(e) {
    this.referralSetup.messages.referring_customer.message.body = e;
  }

  appendTag(tagLabel) {
    var target = document.getElementById("cursor-selection")as HTMLTextAreaElement;
    if (target) {
      if (target.setRangeText) {
        target.setRangeText(" {" + tagLabel + "}");
      } else {
        target.focus();
        document.execCommand("insertText", false, " {" + tagLabel + "}");
      }
    }
  }
}
