import {Component, OnInit} from '@angular/core';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import {CLOCK_INNER_RADIUS} from 'angular-md2';

@Component({templateUrl: './prospects-table.component.html', styleUrls: ['./prospects-table.component.scss']})
export class ProspectsTableComponent implements OnInit {
  tab_id: any = 'new';
  open_filter: boolean = false;
  prospects_data: any = null;
  search_prospect_text: any;

  page_data_loaded = false;
  server_request = true;

  no_more_results = false;
  include_center: any = null;

  data_imported = false;
  import_data = false;
  file_selected = false;

  true = true;
  false = false;
  null: any = null;

  popup = false;
  popup_for: any = null;
  add_task_in_stage = false;

  enlarged_photo_popup = false;
  show_image_url: any = null;

  formDataFile: FormData = new FormData();

  lead_color: any = {
    hot: '#de474c',
    normal: '#f8b100',
    cold: '#7e95a3'
  };

  statuses_count: object = {
    total: 0,
    hot: 0,
    normal: 0,
    cold: 0
  };

  header_count: object = {
    all: 0,
    starred: 0
  };

  name_for_prospect_popup: string = null;

  filterScreenActive = false;
  isFilterActive = false;
  actualFilterObj: any = {
    period: {
      type: 'added_on',
      from: null,
      to: null
    },
    stages: [],
    sources: [],
    staff: []
  };
  virtualFilterObj: any = {
    period: {
      type: 'added_on',
      from: null,
      to: null
    },
    stages: [],
    sources: [],
    staff: []
  };

  added_via_count: object = {
    formlink: 0,
    customer_form: 0,
    prospect_form: 0
  };

  stage_change_popup_data: any = {
    id: null,
    type: 'stage',
    comment: null,
    old_stage: null,
    new_stage: null,
    task: {
      type: 'phone',
      remind_on: null,
      comment: null,
      client_id: null
    }
  };
  stage_change_data: any = null;
  lead_stages: any = [];
  sorted_lead_stages: any = [];
  staff_list: any = [];
  source_list: any = [
    {
      name: 'Facebook',
      checked: false,
      value: 'facebook'
    }, {
      name: 'Webportal',
      checked: false,
      value: 'webstore'
    }
  ];

  params: any = {
    filterBy: {
      type: ['2'],
      lead_stage: [],
      lead_source: [],
      assigned_to: []
      // starred: false
    },
    sortBy: {}
    // page: 1
  };
  loaded: boolean;
  pagination:any;
  loadingMore : boolean = false;
  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.loaded = false;
    this.getFirstData();
    this.getLeadStages();
    this.getStaff();
  }

  contentScroll(e) {
    const el = e.target;
    const totalHeight = el.scrollHeight;
    const scrolled = el.scrollTop;
	const boxHeight = el.clientHeight;
    if (this.no_more_results) {
      return false;
    }
    if (totalHeight - 40 < scrolled + boxHeight) {
      this.loadMoreData();
    }
  }

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  getLeadStages() {
    let reqObj = {
      filterBy: {
        type: ['2']
      }
    };
    this.http.sendData('prospect/stages' + this.include_center, reqObj).subscribe(success => {
      success = success;
      this.lead_stages = success.data;
      this.sorted_lead_stages = this.bubbleSort(this.lead_stages);

      this.stage_change_popup_data['new_stage'] = this.lead_stages[0].code;

    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  bubbleSort(list) {
    let swapped;
    let n = list.length - 1;
    do {
      swapped = false;
      for (let i = 0; i < n; i++) {
        if (list[i].order > list[i + 1].order) {
          const temp = list[i];
          list[i] = list[i + 1];
          list[i + 1] = temp;
          swapped = true;
        }
      }
    } while (swapped);
    return list;
  }

  getStaff() {
    this.http.sendData('staff/search' + this.include_center, '').subscribe(success => {
      success = success;
      this.staff_list = success.data;

      this.staff_list.forEach((element, index) => {
        this.staff_list[index].checked = false;
      });
      console.log('this.staff_list', this.staff_list);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  getStatusesCount() {
    this.http.getData('prospect/statuses' + this.include_center).subscribe(data => {
      this.header_count['all'] = data.total;
      data.data.forEach((item, index) => {
        if (item.starred == 1) {
          this.header_count['starred'] = item.count;
        }
      });
    }, error => {
      const msg = 'Unable to fetch data!';
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  getAddedViaCount() {
    this.http.getData('prospect/sources' + this.include_center).subscribe(data => {
      data.data.forEach((item, index) => {
        this.added_via_count[item.added_via] = item.count;
      });
    }, error => {
      const msg = 'Unable to fetch data!';
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  getFirstData() {
    this.loaded = false;
    this.prospects_data = null;
    this.server_request = true;
    this.no_more_results = false;
    this.params['page'] = 1;
    this.getStatusesCount();
    this.getAddedViaCount();
	this.params.filterBy.lead_stage[0] = this.tab_id;
    this.http.sendData('contact/search' + this.include_center, this.params).subscribe(success => {
      success = success;
	  this.prospects_data = success.data;
	  this.pagination = success.meta.pagination;
	  this.loaded = true;
      console.log('this.prospects_data', this.prospects_data);
      this.generateColor(this.prospects_data);
      const currentPage = success.meta.pagination.current_page;
      const totalPages = success.meta.pagination.total_pages;
      if (currentPage >= totalPages) {
        this.no_more_results = true;
        this.params['page'] = 1;
      } else {
        this.params['page'] += 1;
      }
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {
      this.page_data_loaded = true;
      this.server_request = false;
    });
  }









  generateColor(id) {
    console.log(id.length);
    id.forEach((element, index) => {
      let colorCode = element.id % 10;
      this.prospects_data[index].colorCode = colorCode;
    });
  }

  loadMoreData() {
	  this.loadingMore = true;
	  console.log('this.pagination', this.pagination)
    if (!this.no_more_results && !this.server_request) {
      this.server_request = true;
      this.http.sendData('contact/search' + this.include_center, this.params).subscribe(success => {
		success = success;
		this.loadingMore = false;
		this.prospects_data = this.prospects_data.concat(success.data);
		this.pagination = success.meta.pagination;
        const currentPage = success.meta.pagination.current_page;
        const totalPages = success.meta.pagination.total_pages;
        if (currentPage >= totalPages) {
          this.no_more_results = true;
          this.params['page'] = 1;
        } else {
          this.params['page'] += 1;
        }
      }, error => {
        error = error;
        const msg = error;
        this.generalFunctions.openToast(msg, 3000, 'error');
      }, () => {
        this.server_request = false;
      });
    }
  }

  filterQuery(e) {
    this.generalFunctions.isFilled(e);
    if (e.target.value.length > 0) {
      this.params.filterBy.query = this.search_prospect_text;
    } else {
      delete this.params.filterBy['query'];
    }
    this.getFirstData();
  }

  filterStatus(e) {
    const li = e.target.nodeName == 'LI'
      ? e.target
      : e.target.parentElement;
    const sib = li.parentElement.children;
    Array.prototype.forEach.call(sib, (item, index) => {
      item.classList.remove('on');
    });
    li.classList.add('on');

    const lead = li.getAttribute('data-status');
    this.params.filterBy.lead = lead;
    if (lead == 'none') {
      delete this.params.filterBy['lead'];
    }

    this.getFirstData();
  }

  filterAddedVia(e) {
    const li = e.target.nodeName == 'LI'
      ? e.target
      : e.target.parentElement;
    const span = li.getElementsByTagName('span')[0];
    if (span.classList.contains('active')) {
      span.classList.remove('active');
      delete this.params.filterBy['added_via'];
    } else {
      span.classList.add('active');
      this.params.filterBy['added_via'] = 'formlink';
    }

    this.getFirstData();
  }

  filterHeader(e) {
    const li = e.target.nodeName === 'LI'
      ? e.target
      : e.target.parentElement;
    const sib = li.parentElement.children;
    Array.prototype.forEach.call(sib, (item, index) => {
      item.classList.remove('on');
    });
    li.classList.add('on');

    const header = li.getAttribute('data-header');
    this.params.filterBy['starred'] = true;

    if (header === 'none') {
      this.params.filterBy['starred'] = false;
    }

    this.getFirstData();
  }

  sortByColumn(e) {
    if (e.target.classList.contains('active')) {
      const x = e.target.getAttribute('data-column');
      if (e.target.classList.contains('asc')) {
        e.target.classList.remove('asc');
        e.target.classList.add('desc');
        this.params.sortBy[x] = 'desc';
      } else if (e.target.classList.contains('desc')) {
        e.target.classList.remove('desc');
        e.target.classList.add('none');
        delete this.params.sortBy[x];
      } else if (e.target.classList.contains('none')) {
        e.target.classList.remove('none');
        e.target.classList.add('asc');
        this.params.sortBy[x] = 'acs';
      }
    } else {
      this.params.sortBy = {};
      Array.prototype.forEach.call(e.target.parentElement.children, (item, index) => {
        item.classList.remove('active', 'asc', 'desc', 'none');
      });
      e.target.classList.add('active', 'asc');
      const x = e.target.getAttribute('data-column');
      this.params.sortBy[x] = 'asc';
    }

    this.getFirstData();
  }

  onFileSelection(e) {
    const files = e.currentFiles;
    if (files.length !== 0) {
      this.file_selected = true;
      this.formDataFile.append('import', files[0]);
    } else {
      this.file_selected = false;
      this.formDataFile = new FormData();
    }
  }

  uploadExcel(e) {
    const btn = e.target;
    btn.classList.add('loading-ajax');
    this.http.sendFormData('prospect/import' + this.include_center, this.formDataFile).subscribe(success => {
      this.data_imported = true;
      btn.classList.remove('loading-ajax');
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      btn.classList.remove('loading-ajax');
    });
  }

  resetPopup() {
    this.popup = false;
    this.popup_for = null;
    this.add_task_in_stage = false;
    this.stage_change_popup_data['id'] = null;
    this.stage_change_popup_data['comment'] = null;
    this.stage_change_popup_data['old_stage'] = null;
    this.stage_change_popup_data['new_stage'] = 'added';
    this.stage_change_popup_data['id'] = null;
    this.stage_change_popup_data['task']['type'] = 'phone';
    this.stage_change_popup_data['task']['remind_on'] = null;
    this.stage_change_popup_data['task']['comment'] = null;
    this.stage_change_popup_data['task']['client_id'] = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
  }

  stageChangePopup(popup, popup_for, id, oldStage, first_name, last_name) {
    this.popup = popup;
    this.popup_for = popup_for;
    this.stage_change_popup_data['id'] = id;
    this.stage_change_popup_data['old_stage'] = oldStage;

    this.name_for_prospect_popup = first_name + ' ' + last_name;
  }

  changeStage() {
    const obj = JSON.parse(JSON.stringify(this.stage_change_popup_data));
    if (!this.add_task_in_stage) {
      delete obj['task'];
    } else {
      if (!obj['task']['remind_on']) {
        this.generalFunctions.openToast('Kindly tell us time to remind you the task!', 2000, 'error');
        return false;
      } else {
        const taskReminder = this.generalFunctions.convertDateToISOFormat(obj['task']['remind_on']);
        obj['task']['remind_on'] = taskReminder['date'] + ' ' + taskReminder['time'];
      }
    }

    this.http.sendData('contact/' + obj['id'] + '/activity' + this.include_center, obj).subscribe(success => {
      success = success;
      this.prospects_data.forEach((item, index) => {
        if (item.id === obj['id']) {
          this.prospects_data[index]['lead_stage'] = this.stage_change_popup_data['new_stage'];
        }
      });
      this.generalFunctions.openToast('Lead stage is changed successfully!', 2000, 'success');
      this.resetPopup();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  changeStar(id) {
    this.http.patchData('prospect/' + id + '/toggleStar' + this.include_center, null).subscribe(success => {
      success = success;
      this.updateRow(success.data.id, success.data);
      this.getStatusesCount();
      this.generalFunctions.openToast('Lead is updated!', 2000, 'success');
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  updateRow(id, data) {
    this.prospects_data.forEach((item, index) => {
      if (item.id === id) {
        this.prospects_data[index] = data;
      }
    });
  }

  showFilters() {
    this.filterScreenActive = true;
    this.virtualFilterObj = JSON.parse(JSON.stringify(this.actualFilterObj));
  }

  applyFilters() {
    // this.actualFilterObj = JSON.parse(
    // 	JSON.stringify(this.virtualFilterObj)
    // );

    // let noneApplied = true;

    // if (
    // 	this.actualFilterObj.period.from ||
    // 	this.actualFilterObj.period.to
    // ) {
    // 	if (
    // 		!(
    // 			this.actualFilterObj.period.from &&
    // 			this.actualFilterObj.period.to
    // 		)
    // 	) {
    // 		this.generalFunctions.openToast(
    // 			"Both from and to dates are required!",
    // 			2000,
    // 			"error"
    // 		);
    // 		return false;
    // 	}
    // 	this.params.filterBy[this.actualFilterObj.period.type] = {};

    // 	if (this.actualFilterObj.period.from) {
    // 		const start = this.generalFunctions.convertDateToISOFormat(
    // 			this.actualFilterObj.period.from
    // 		);
    // 		this.params.filterBy[this.actualFilterObj.period.type]["from"] =
    // 			start["date"];
    // 	}

    // 	if (this.actualFilterObj.period.to) {
    // 		const end = this.generalFunctions.convertDateToISOFormat(
    // 			this.actualFilterObj.period.to
    // 		);
    // 		this.params.filterBy[this.actualFilterObj.period.type]["to"] =
    // 			end["date"];
    // 	}
    // 	noneApplied = false;
    // } else {
    // 	if (this.params.filterBy.added_on) {
    // 		delete this.params.filterBy.added_on;
    // 	}
    // 	if (this.params.filterBy.last_activity) {
    // 		delete this.params.filterBy.last_activity;
    // 	}
    // }

    // const stageApplied = [];
    // const sourceApplied = [];
    // const staffApplied = [];

    // this.virtualFilterObj.stages.forEach((item, index) => {
    // 	if (item["filterSelected"]) {
    // 		stageApplied.push(item.code);
    // 	}
    // });
    // this.virtualFilterObj.sources.forEach((item, index) => {
    // 	if (item["filterSelected"]) {
    // 		sourceApplied.push(item.code);
    // 	}
    // });
    // this.virtualFilterObj.staff.forEach((item, index) => {
    // 	if (item["filterSelected"]) {
    // 		staffApplied.push(item.uuid);
    // 	}
    // });

    // this.params.filterBy["lead_stage"] = stageApplied;
    // this.params.filterBy["lead_source"] = sourceApplied;
    // this.params.filterBy["assigned_to"] = staffApplied;

    // if (
    // 	stageApplied.length !== 0 ||
    // 	sourceApplied.length !== 0 ||
    // 	staffApplied.length !== 0
    // ) {
    // 	noneApplied = false;
    // }

    // this.isFilterActive = !noneApplied;

    console.log('this.staff_list', this.staff_list);

    //check for the staff list for id's that is selected
    this.staff_list.forEach(element => {
      if (element.checked == true && !this.params.filterBy.assigned_to.includes(element.id)) {
        this.params.filterBy.assigned_to.push(element.id);
      }
      if (element.checked == false && this.params.filterBy.assigned_to.includes(element.id)) {
        this.params.filterBy.assigned_to.splice(this.params.filterBy.assigned_to.indexOf(element.id), 1);
      }
      console.log('this.params.filterBy.assigned_to', this.params.filterBy.assigned_to);
    });

    //check for the source list for the id's that is selecetd

    this.source_list.forEach(element => {
      if (element.checked == true && !this.params.filterBy.lead_source.includes(element.value)) {
        this.params.filterBy.lead_source.push(element.value);
      }
      if (element.checked == false && this.params.filterBy.lead_source.includes(element.value)) {
        this.params.filterBy.lead_source.splice(this.params.filterBy.lead_source.indexOf(element.value), 1);
      }
      console.log('this.params.filterBy.lead_source', this.params.filterBy.lead_source);
    });

    this.getFirstData();
    this.open_filter = false;
    this.filterScreenActive = false;
  }

  resetFilter() {
    this.params.filterBy.lead_source = [];
    this.source_list.forEach(element => {
      element.checked = false;
    });
    this.params.filterBy.assigned_to = [];
    this.staff_list.forEach(element => {
      element.checked = false;
    });
  }

  removeFilters() {
    // this.resetFilters();
    this.applyFilters();
  }

  enlargePhoto(url) {
    this.enlarged_photo_popup = true;
    this.show_image_url = url;
  }
}
