import { Component, OnInit } from '@angular/core';

@Component({
	templateUrl: './prospects.component.html',
	styleUrls: ['./prospects.component.css']
})
export class ProspectsComponent implements OnInit {

	constructor() { }

	ngOnInit() {
	}

}
