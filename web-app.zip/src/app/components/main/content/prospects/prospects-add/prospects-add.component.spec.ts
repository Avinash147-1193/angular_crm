import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProspectsAddComponent } from './prospects-add.component';

describe('ProspectsAddComponent', () => {
  let component: ProspectsAddComponent;
  let fixture: ComponentFixture<ProspectsAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProspectsAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProspectsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
