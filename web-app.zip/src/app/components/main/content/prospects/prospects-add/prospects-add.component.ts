import {Component, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import {
    SelectItem
} from 'primeng/api';
import {
    COUNTRIES
} from '../../../../../countries';
import {
    CODES
} from '../../../../../phonecodes';

@Component({templateUrl: './prospects-add.component.html', styleUrls: ['./prospects-add.component.scss']})
export class ProspectsAddComponent implements OnInit {

  null: any = null;

  universal_contact: any = {
    found: false,
    uuid: null
  };
  center_contact: any = {
    found: false,
    uuid: null,
    type: 'customer',
    added_via: null,
    name: null
  };

  include_center: any = null;

  prospect_data: any = {
    contact: {
      phone: '',
      phone_confirmation: '',
      email: '',
      first_name: '',
      last_name: '',
      gender: '',
      date_of_birth: ''
    },
    address: {
      pincode: null,
      address: null,
      city: null,
      state: null
    },
    lead: 'normal',
    lead_source: '',
    assigned_to: '',
    comment: ''
  };
  validationCheck: boolean = false;

  dobDatepickerConfig = {
    showWeekNumbers: false,
    maxDate: new Date(),
    containerClass: 'theme-default'
  };
  validationFields: any = {
    prospect_email: false,
    prospect_phone: false,
    prospect_fname: false,
    prospect_lname: false,
    prospect_city: false,
    customer_gender: false,
    emergency_number: false,
    emergency_fname: false,
    emergency_lname: false,
    medical_history: false,
    membership_id: false
  };

  staff_list: any = [];
  lead_sources: any = [];
  editLead: boolean = false;
  prospectId: any;

  @ViewChild('phone')phone;
  @ViewChild('phone_confirmation')phone_confirmation;
  @ViewChild('gender_container')gender_container;

  @ViewChild('first_name')first_name;
  @ViewChild('last_name')last_name;
  @ViewChild('email')email;

  @ViewChild('prospect_city')prospect_city;
  @ViewChild('prospect_state')prospect_state;

  emailCheckLoader: boolean = true;
  checkExisting: boolean = false;
  checkLoader: boolean = false;
  existingType: any = '3';
  foundCenter: any;
  existing_customer: any = {
    first_name: '',
    last_name: '',
    id: ''
  };

    //copy
    countryCodesDropdown: SelectItem[] = [];
    countriesDropdown: SelectItem[] = [];

    countries: any = COUNTRIES;
    codes: any = CODES;
    onceLoaded = false;


  constructor(private location : Location, private generalFunctions : GeneralServices, private http : ServerAuthService, private router : Router, private route : ActivatedRoute) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();

    this.getLeadStages();
    this.getStaff();
    if (this.router.url.includes('edit')) {
	  this.editLead = true;

      this.prospectId = this.route.snapshot.paramMap.get('id');
      this.emailCheckLoader = false;

      this.getLeadData(this.prospectId);
    }
    this.prepareCountriesDropdown();
  }

  prepareCountriesDropdown() {
    for (let i = 0; i < this.countries.length; i++) {
        let country = {
            label: '',
            value: 0
        };
        // country name
        country.label = this.countries[i].name;
        country.value = this.countries[i].id;
        this.countriesDropdown.push(country);
    }

    for (let i = 0; i < this.codes.length; i++) {
        let code = {
            label: '',
            value: 0
        };
        // country code
        code.label = this.codes[i].isd_code;
        code.value = this.codes[i].id;
        this.countryCodesDropdown.push(code);
    }
    if (!this.editLead) {
        const localization = JSON.parse(localStorage.getItem('localization'));
        this.prospect_data.contact.phone_prefix = String( localization.country.isd_code);
        this.prospect_data.address.country = String( localization.country.name);
    }
    setTimeout(() => {
        this.onceLoaded = true;
    }, 1);

}


  getLeadData(id) {
    this.http.getData('contact/' + id + this.include_center + '&include=activities,emergencyContact,address,memberships')
    .subscribe(success => {
      this.prospect_data.contact = success.data.contact.data;
      this.prospect_data.contact.date_of_birth = success.data.contact.data.date_of_birth
        ? new Date(success.data.contact.data.date_of_birth)
        : '';
      this.prospect_data.contact.id = this.prospectId;
      this.prospect_data.address = success.data.address.data;
      let cdr = this.countryCodesDropdown.filter(obj => obj.label === success.data.contact.data.phone_prefix)
      console.log('cdr', cdr);
      if (cdr.length <= 0) {
        this.countryCodesDropdown.push({label: '+0000', value: '+0000' })
      }
      this.prospect_data.contact.phone_prefix = success.data.contact.data.phone_prefix;
      this.prospect_data.address.country = success.data.address.data.country;


      this.prospect_data.assigned_to = success.data.assigned_to?.id;
      this.prospect_data.lead_source = success.data.lead_source;
      this.prospect_data.comment = success.data.comment;
      this.prospect_data.added_via = 'customer_form';
      console.log(this.prospect_data);
    }, error => {
      this.generalFunctions.openToast('Unable to load leads data!', 3000, 'error');
    });
  }

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  toggleCustomTicTac(e) {
    this.generalFunctions.toggleCustomTicTac(e);
  }

  autoIncreaseSize(e) {
    var textarea = e.target,
      height = textarea.offsetHeight;
    textarea.style.height = '16px';
    textarea.style.height = textarea.scrollHeight + 'px';
    textarea.style.maxHeight = textarea.scrollHeight + 'px';
    this.isFilled(e);
  }

  getLeadStages() {
    this.http.getData('leads/stages_sources' + this.include_center).subscribe(success => {
      success = success;
      this.lead_sources = success.data.sources;
      this.prospect_data['lead_source'] = this.lead_sources[0].code;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  getStaff() {
    this.http.sendData('staff/search' + this.include_center, []).subscribe(success => {
      success = success;
      this.staff_list = success.data;
      this.prospect_data.assigned_uuid = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
      this.staff_list.forEach(element => {
        if (element.uuid == this.prospect_data.assigned_uuid) {
          this.prospect_data.assigned_to = element.id;
        }
      });
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }
  routeBack() {
    this.location.back();
  }

  checkinput() {
    var els = document.querySelectorAll('.input-field input, .input-field textarea');
    Array.prototype.forEach.call(els, (item, index) => {
      if (item.value != '') {
        item.dispatchEvent(new Event('keyup'));
      }
    });
  }

  getLocation(e) {
    this.generalFunctions.isFilled(e);
    if (e.target.classList.contains('ng-valid')) {
      var pin = this.prospect_data.address.pincode;
    }
  }

  addNewProspect() {
    this.validationCheck = true;
    if (!(this.validationFields.prospect_email  && this.validationFields.prospect_fname && this.validationFields.prospect_lname )) {
      this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
      return;
    }
    var obj = JSON.parse(JSON.stringify(this.prospect_data));
    var dob = obj.contact.date_of_birth;
    if (dob) {
      obj.contact.date_of_birth = this.generalFunctions.convertDateToISOFormat(dob)['date'];
      obj.contact.phone = parseInt(obj.contact.phone);
      obj.contact.phone_confirmation = parseInt(obj.contact.phone_confirmation);
    }


    if (this.editLead) {
      this.http.updateData(`contact/${this.prospectId}` + this.include_center, obj).subscribe(success => {
        this.generalFunctions.openToast('Prospect Details Updated!', 3000, 'success');
        this.router.navigate(['../../'], {
          queryParams: {},
          relativeTo: this.route
        });
      }, error => {
        var msg;
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    } else {
      this.generalFunctions.removeEmpty(obj);

      if (Object.keys(obj['address']).length == 0) {
        delete obj['address'];
      }

      if (!obj['comment']) {
        delete obj['comment'];
      }
      if (!obj['assigned_to'] || obj['assigned_to'] == 'none') {
        delete obj['assigned_to'];
      }

      this.http.sendData('prospect' + this.include_center, obj).subscribe(success => {
        this.generalFunctions.openToast('Prospect created!', 3000, 'success');
        this.router.navigate(['../'], {
          queryParams: {},
          relativeTo: this.route
        });
      }, error => {
        var msg;
        if (error['errors']) {
          msg = error['errors'][Object.keys(error['errors'])[0]];
        } else {
          msg = error.message;
        }
        this.generalFunctions.openToast(msg, 3000, 'error');
      });
    }
  }

  parseDate(date) {
    var d = new Date(date);
    return d;
  }

  // phoneEdit(e){

  // 	this.isFilled(e);
  // 	if(this.center_contact.found||this.universal_contact.found){
  // 		this.resetForm();
  // 	}
  //  Validate input values
  // 	var el = e.target;
  // 	var val = el.value;
  // 	val = val.replace(/[_-]/g, "").toString();
  // 	var len = val.length;

  // 	(len<10&&len>0)?el.classList.add('invalid'):el.classList.remove('invalid');

  // 	if(len==1){
  // 		this.prospect_data.contact.phone = val;
  // 		return false;
  // 	}

  // 	var posX = e.target.selectionStart; cursor position

  // 	var code = e.keyCode || e.charCode || e.which;

  //  current model value
  // 	var t = (this.prospect_data.contact.phone)?this.prospect_data.contact.phone.toString():"";

  //  Based on input value charcode, change the ngModel values
  // 	if(posX>3){posX-=1}
  // 	if(posX>6){posX-=1}

  // 	if(code>=48 && code<=57&&t.length<11){
  // 	 Numerical values
  // 		t=[t.slice(0,posX),String.fromCharCode(code),t.slice(posX)].join("");
  // 	}else if(code == 8&&t.length<11){
  // 	 Backspace
  // 		t=[t.slice(0,posX),t.slice(posX+1)].join("");
  // 	}else if(code == 46&&t.length<11){
  // 	 Delete
  // 		t=[t.slice(0,posX+1),t.slice(posX+2)].join("");
  // 	}else if(code == 88&&t.length<11){
  // 	 character 'x'
  // 		return false;
  // 	}

  // 	this.prospect_data.contact.phone = t;

  //   Mask the input values based on its length
  //   var editedValue;
  //   switch (val.length) {
  //   	case 2:
  //   		editedValue = val[0]+"x_-___-____";
  //   		break;
  //   	case 3:
  //   		editedValue = val[0]+"xx-___-____";
  //   		break;
  //   	case 4:
  //   		editedValue = val[0]+"xx-x__-____";
  //   		break;
  //   	case 5:
  //   		editedValue = val[0]+"xx-xx_-____";
  //   		break;
  //   	case 6:
  //   		editedValue = val[0]+"xx-xxx-____";
  //   		break;
  //   	case 7:
  //   		editedValue = val[0]+"xx-xxx-x___";
  //   		break;
  //   	case 8:
  //   		editedValue = val[0]+"xx-xxx-xx__";
  //   		break;
  //   	case 9:
  //   		editedValue = val[0]+"xx-xxx-xx"+val[8]+'_';
  //   		break;
  //   	case 10:
  //   		editedValue = val[0]+"xx-xxx-xx"+val[8]+val[9];
  //   		break;
  //   }

  //   (editedValue) ?(e.target.value=editedValue):'';

  // 	var size = val.length;
  // 	if(size>3){size+=1}
  // 	if(size>6){size+=1}

  //  Move cursor to last character position
  // 	e.target.selectionStart = size;
  // 	e.target.selectionEnd = size;
  // 	if((code==8&&size==4) || (code==8&&size==8)){
  // 		e.target.selectionStart = size-1;
  // 		e.target.selectionEnd = size-1;
  // 	}
  // }

  phoneEdit(e) {
    this.isFilled(e);
    if (this.center_contact['found'] || this.universal_contact.found) {
      this.resetForm();
    }
    //Validate input values
    var el = e.target;
    var val = el.value;
    val = val.replace(/[_-]/g, '').toString();
    var len = val.length;

    len < 10 && len > 0
      ? el.classList.add('invalid')
      : el.classList.remove('invalid');

    if (len == 1) {
      this.prospect_data.contact.phone = val;
      return false;
    }

    var posX = e.target.selectionStart; //cursor position

    var code = e.keyCode || e.charCode || e.which;

    //current model value
    var t = this.prospect_data.contact.phone
      ? this.prospect_data.contact.phone.toString()
      : '';

    //Based on input value charcode, change the ngModel values
    if (posX > 3) {
      posX -= 1;
    }
    if (posX > 6) {
      posX -= 1;
    }

    if (code >= 48 && code <= 57 && t.length < 10) {
      //Numerical values
      t = [
        t.slice(0, posX),
        String.fromCharCode(code),
        t.slice(posX)
      ].join('');
    } else if (code == 8 && t.length < 11) {
      //Backspace
      t = [
        t.slice(0, posX),
        t.slice(posX + 1)
      ].join('');
    } else if (code == 46 && t.length < 11) {
      //Delete
      t = [
        t.slice(0, posX + 1),
        t.slice(posX + 2)
      ].join('');
    } else if (code == 88 && t.length < 11) {
      //character 'x'
      return false;
    }

    this.prospect_data.contact.phone = t;

    //Mask the input values based on its length
    // var editedValue;
    // switch (val.length) {
    // 	case 2:
    // 		editedValue = val[0]+"x_-___-____";
    // 		break;
    // 	case 3:
    // 		editedValue = val[0]+"xx-___-____";
    // 		break;
    // 	case 4:
    // 		editedValue = val[0]+"xx-x__-____";
    // 		break;
    // 	case 5:
    // 		editedValue = val[0]+"xx-xx_-____";
    // 		break;
    // 	case 6:
    // 		editedValue = val[0]+"xx-xxx-____";
    // 		break;
    // 	case 7:
    // 		editedValue = val[0]+"xx-xxx-x___";
    // 		break;
    // 	case 8:
    // 		editedValue = val[0]+"xx-xxx-xx__";
    // 		break;
    // 	case 9:
    // 		editedValue = val[0]+"xx-xxx-xx"+val[8]+'_';
    // 		break;
    // 	case 10:
    // 		editedValue = val[0]+"xx-xxx-xx"+val[8]+val[9];
    // 		break;
    // }

    // (editedValue) ?(e.target.value=editedValue):'';

    var size = val.length;
    if (size > 3) {
      size += 1;
    }
    if (size > 6) {
      size += 1;
    }

    //Move cursor to last character position
    e.target.selectionStart = size;
    e.target.selectionEnd = size;
    if ((code == 8 && size == 4) || (code == 8 && size == 8)) {
      e.target.selectionStart = size - 1;
      e.target.selectionEnd = size - 1;
    }
  }

  phoneConfirmedEdit(e) {
    this.isFilled(e);
    if (this.center_contact.found || this.universal_contact.found) {
      this.resetForm();
    }
    var el = e.target;
    var val = e.target.value;
    var len = val.length;
    val = val.replace(/[_-]/g, '');
    this.prospect_data.contact.phone_confirmation = val;
    this.prospect_data.contact.phone = val;
    len < 10 && len > 0
      ? el.classList.add('invalid')
      : el.classList.remove('invalid');

    var i = this.prospect_data.contact.phone,
      j = this.prospect_data.contact.phone_confirmation;

    if (val.length == 10) {
      var msg = 'Match the phone no!';
      i != j
        ? this.generalFunctions.openToast(msg, 2000, 'error')
        : this.getProspect(val);
    }
  }

  getProspect(no) {
    this.http.getData('contact/exists' + this.include_center + '&phone=' + no).subscribe(success => {}, err => {
      if (err.status_code == 302) {
        var type = err.type;
        var id = err.uuid;
        var added_via = err.added_via;
        var name = err.data.first_name + ' ' + err.data.last_name;
        this.centerContactFound(id, type, added_via, name);
      } else if (err.status_code == 404) {
        this.resetForm();
      } else if (err.status_code == 409) {
        this.universalContactFound(err.data, err.uuid);
      }
    });
  }

  centerContactFound(id, type, added_via, name) {
    this.center_contact['found'] = true;
    this.universal_contact['found'] = false;
    this.center_contact['type'] = type;
    this.center_contact['uuid'] = id;
    this.center_contact['name'] = name;
    this.center_contact['added_via'] = added_via;
  }

  universalContactFound(data, id) {
    this.center_contact['found'] = false;
    this.universal_contact['found'] = true;
    this.prospect_data['uuid'] = id;
    this.prospect_data.contact.first_name = data.first_name;
    this.prospect_data.contact.last_name = data.last_name;
    this.prospect_data.contact.email = data.email;
    this.prospect_data.contact.gender = data.gender;
    this.prospect_data.contact.date_of_birth = data.date_of_birth;
    setTimeout(() => {
      this.first_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.last_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.email.nativeElement.dispatchEvent(new Event('keyup'));
    }, 200);
  }

  resetForm() {
    this.universal_contact.found = false;
    this.center_contact.found = false;
    this.prospect_data.contact_id = null;
    delete this.center_contact['uuid'];
    this.prospect_data.contact.first_name = null;
    this.prospect_data.contact.last_name = null;
    this.prospect_data.contact.email = null;
    this.prospect_data.contact.gender = null;
    this.prospect_data.contact.date_of_birth = null;

    setTimeout(() => {
      this.first_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.last_name.nativeElement.dispatchEvent(new Event('keyup'));
      this.email.nativeElement.dispatchEvent(new Event('keyup'));
    }, 200);
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
      case 'prospect-email':
        isValid = !this.prospect_data.contact.email.replace(/\s/g, '').length || !this.validateEmail(this.prospect_data.contact.email)
          ? false
          : true;
        this.validationFields.prospect_email = isValid;
        break;

      case 'prospect-phone':
        isValid = !this.validatePhone(this.prospect_data.contact.phone)
          ? false
          : true;
        this.validationFields.prospect_phone = isValid;
        break;

      case 'customer-gender':
        isValid = !this.prospect_data.contact.gender.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_gender = isValid;
        break;

      case 'prospect-fname':
        isValid = !this.prospect_data.contact.first_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.prospect_fname = isValid;
        break;

      case 'prospect-lname':
        isValid = !this.prospect_data.contact.last_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.prospect_lname = isValid;
        break;

      case 'prospect-city':
        isValid = !this.prospect_data.address.city.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.prospect_city = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }
  validateEmail(email) {
    var re = /\S+@\S+\.\S{2,}/;
    return re.test(email);
  }
  validatePhone(phone) {
    if (this.numberCounter(phone) < 7 || this.numberCounter(phone) > 10) {
      return false;
    } else
      return true;
    }

  numberCounter(n) {
    var count = 0;
    if (n >= 1)
      ++count;

    while (n / 10 >= 1) {
      n /= 10;
      ++count;
    }

    return count;
  }


  checkEmail() {
    let validation = !this.prospect_data.contact.email.replace(/\s/g, '').length || !this.validateEmail(this.prospect_data.contact.email)
      ? false
      : true;
    validation
      ? this.getEmailData(this.prospect_data.contact.email)
      : (this.checkLoader = false);
  }

  getEmailData(email) {
    this.checkLoader = true;

    setTimeout(() => {
      this.getStaffData(email);
    }, 1200);
  }



  getStaffData(email) {
    this.http.getData('clients/contact?client_id=' + JSON.parse(localStorage.getItem('currentUser')).client_id + '&email=' + encodeURIComponent(this.prospect_data.contact.email)).subscribe(success => {
      success = success.contact;
      console.log('success["first"]', success);
      this.checkLoader = false;
      if (!success['first_name']) {
        this.checkExisting = false;
        this.emailCheckLoader = false;
        this.existingType = '3';

        this.existing_customer.first_name = '';
        this.existing_customer.last_name = '';
        this.existing_customer.id = '';
        this.existing_customer.contact_id = '';

        return;
      }

      this.existing_customer.first_name = success.first_name;
      this.existing_customer.last_name = success.last_name;
      this.existing_customer.contact_id = success.id;

      this.existingType = '2';

      success.centers.forEach(center => {
        if (center.uuid == JSON.parse(localStorage.getItem('currentUser')).center_id) {
          this.existingType = '1';
          this.existing_customer.id = center.pivot.id;

          this.getRegions(center.uuid, center.pivot.type);
          return;
        }
      });

      if (this.existingType == 2) {
        this.existing_customer.id = success.centers[0].pivot.id;

        this.getRegions(success.centers[0].uuid, success.centers[0].pivot.type);
      }
    });

    this.checkExisting = true;
    this.emailCheckLoader = true;
  }

  getRegions(id, type) {
    let centerFound;
    this.http.getData('regions').subscribe(success => {
      success.forEach(element => {
        element.centers.forEach(center => {
          if (center.uuid == id) {
            centerFound = center;
			this.foundCenter = centerFound;
			this.foundCenter['type'] = type;
          }
        });
      });
    }, error => {});
  }

  addExisting() {
    this.http.sendData('customer' + this.include_center, {contact_id: this.existing_customer.contact_id}).subscribe(success => {
      this.generalFunctions.openToast('Lead added successfully!', 3000, 'success');
	  this.router.navigate([
        '/client/prospects'
      ]);
    }, error => {
      this.generalFunctions.openToast('Error adding lead', 3000, 'error');
    });
  }
}
