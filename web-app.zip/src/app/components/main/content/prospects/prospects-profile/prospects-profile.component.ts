import {
    Component,
    OnInit,
    ViewChild,
    ViewEncapsulation,
    ElementRef,
    ChangeDetectorRef

} from '@angular/core';
import {
    Router,
    ActivatedRoute,
    Params
} from '@angular/router';
import {
    GeneralServices
} from '../../../../../common/general-services';
import {
    ServerAuthService
} from '../../../../../common/server-auth';
import {NgForm} from '@angular/forms';


@Component({
    templateUrl: './prospects-profile.component.html',
    styleUrls: ['./prospects-profile.component.scss', '../../services/styles/profiles.scss'],
    encapsulation: ViewEncapsulation.None,

})
export class ProspectsProfileComponent implements OnInit {
    primary_tab_selected: any = 'activity';
    membership_history: boolean = false;
    pt_history: boolean = false;
    profile_details_edit: boolean = false;
    transaction_filter: string = 'all';
    transaction_filter_array: Array < string > = ['all'];
    transaction_count: object = {
        total: 0,
        billing_issue: 0
    };

    prospect_id: any = null;
    prospect_data: any = null;
    include_center: any = null;
    updated_data: any = {};
    currency: any = null;

    isActive: boolean = true;

    popup: boolean = false;
    popup_for: any = null;
    popup_action: any = null;
    add_task_in_stage: boolean = false;
    add_task_in_comment: boolean = false;

    freeze_enabled: boolean = false;
    extend_enabled: boolean = false;

    sms_count: number = 1;
    sms_length: number = 140;

    is_summary_present: boolean = false;
    is_transactions_present: boolean = false;
    sms_data: any = {
        message: '',
        signature: true
    };

    lead_data: any = {
        hot: '#de474c',
        cold: '#7e95a3',
        normal: '#f8b100'
    };

    task_data: any = {
        id: null,
        type: 'phone',
        remind_on: null,
        comment: null,
        client_id: null
    };

    stage_change_data: any = {
        type: 'stage',
        comment: null,
        old_stage: null,
        new_stage: null
    };

    assign_data: any = {
        type: 'transfer',
        old_assigned_to: null,
        new_assigned_to: null
    };

    comment_data: any = {
        type: 'comment',
        comment: null
    };

    freeze_data: any = {
        id: null,
        starts_at: null,
        ends_at: null,
        m_start: null,
        m_expiry: null
    };

    unfreeze_data: any = {
        id: null,
        name: null,
        obj: null
    };

    extend_data: any = {
        starts_at: null,
        expires_at: null,
        m_start: null,
        m_expiry: null
    };

    messageDetails: any = {
        message: '',
        subject: ''
    };

    lead_stages: any = [];
    lead_sources: any = [];
    staff_list: any = [];
    prospect_tasks_incomplete: any = [];
    prospect_tasks_complete: any = [];
    staffDropdown: any = [];
    stageDropdown: any = [];
    phonePrefix: any;
    navigationList: Array < string > = [];
    view: any = '';
    groupMessage: any = {
        subject: '',
        channel: 'email',
        message: '',
        fromEmail: ''
      };
      mailChimp = false;
      stripeConnected: boolean;

      centerId: any;
      cardDetails: any;
      tool_tip_for: null;

      card: any;
      cardHandler = this.onChange.bind(this);
      error: string;

      index: any;
      token: any;
      addingCard: any = false;
      channels: any = [];
      smsNum:any = 0;
      deleteId: any;
      adyenCardData = null;





    @ViewChild('ajax_loader') ajax_loader;
    @ViewChild('gender_container') gender_container;
    @ViewChild('phone') phone;
    @ViewChild('email') email;
    @ViewChild('pincode') pincode;
    @ViewChild('emergency_contact_phone') emergency_contact_phone;
    @ViewChild('cardInfo')cardInfo: ElementRef;
    @ViewChild('dd')dd;
    paymentMode: any;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private generalFunctions: GeneralServices,
        private http: ServerAuthService,
        private cd: ChangeDetectorRef) {}

    ngOnInit() {
        this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
        this.include_center = this.generalFunctions.includeCenter();
        this.phonePrefix = JSON.parse(localStorage.getItem('localization'))['country']['isd_code']

        this.getSettings();
        this.getApps();
        this.getCenterData();


        this.route.params.subscribe(params => {
            this.prospect_id = params['id'];
            this.getProspectData(this.prospect_id);
        });

        this.route.queryParams.subscribe(params => {
            if (params['tab']) {
                this.primary_tab_selected = params['tab'];
            }
        });

        document.addEventListener('click', event => {
            this.documentClickHandler(event);
        });

        this.currency = JSON.parse(
            localStorage.getItem('localization')
        ).currency.symbol;

        this.getLeadStages();
        this.getStaff();
    }

    ngAfterViewInit () {
        const style = {
          base: {
            lineHeight: '24px',
            fontSize: '14px',
            '::placeholder': {
              color: '#546a7b'
            }
          }
        };
        this.card = elements.create('card', {
          hidePostalCode: true,
          style
        });
        this.cardInfo.nativeElement.focus();
        this.card.mount(this.cardInfo.nativeElement);

        this.card.addEventListener('change', this.cardHandler);
      }

    onChange({error}) {

        if (error) {
          this.error = error.message;
        } else {
          this.error = null;
        }
        this.cd.detectChanges();
      }

      async onSubmit(form: NgForm) {
        this.addingCard = true;

        const {token, error} = await stripe.createToken(this.card);

        if (error) {
          this.addingCard = false;
        } else {
          this.addCard(token.id);

          // ...send the token to the your backend to process the charge
        }
      }
      ngOnDestroy() {
        this.card.removeEventListener('change', this.cardHandler);
        this.card.destroy();
      }



    getCenterData() {
        this.http.getData(`center/${this.centerId}` + this.include_center).subscribe(success => {

            success.data.gateway === 'adyen' || success.data.gateway === 'stripe'
          ? (this.stripeConnected = true)
          : (this.stripeConnected = false);
        this.paymentMode = success.data.gateway;


        if (this.stripeConnected) {
          this.getCard();
        }



          let senderId = success.data.settings.automations.channels.sms;

          if (senderId == 1) {
            this.channels.push('sms')
          }
        }, error => {});
      }

      findIfAny() {
        return [...this.prospect_data.data.gift_card_details.data.filter((i) => i.current_value >= 1)].length > 0 ? true : false;
      }

      adyenValidationEvent(event) {
        console.log('event', event)

        this.adyenCardData = event;
    }

    adyenAddCard() {
        this.addingCard = true;

        if (this.adyenCardData['isValid']) {
            const token = this.adyenCardData['data']['paymentMethod'];
            this.addCard(token);
        } else {
            this.addingCard = false;

            this.generalFunctions.openToast('Please enter a valid card', 3000, 'error');
        }
    }


      addCard(token) {
        this.http.sendData('contact/' + this.prospect_id + '/payment/sources' + this.include_center + '&include=memberships,attendances,credits', {token: token}).subscribe(success => {
          this.generalFunctions.openToast('Card successfully added for the customer', 2000, 'success');
            this.card.clear();
          this.getCard();
          this.addingCard = false;
          this.popup_for = null;
        }, error => {
          this.addingCard = false;
          this.generalFunctions.openToast(error.message, 3000, 'error');
        });
      }

      getCard() {
        if (this.stripeConnected) {
          this.http.getData('contact/' + this.prospect_id + '/payment/sources' + this.include_center + '&include=memberships,attendances,credits').subscribe(success => {
            this.cardDetails = success.data;

          },
           error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }
      }

      deleteCard(id) {
        this.http.deleteData('contact/' + this.prospect_id + '/payment/sources/' + id + this.include_center).subscribe(success => {
          this.generalFunctions.openToast('Card has been deleted successfully', 3000, 'success');
          this.getCard();
        }, err => {
          this.generalFunctions.openToast(err, 3000, 'error');
        });
      }



      getApps() {
        this.http.getData('apps' + this.include_center).subscribe(success => {
            success = success;
            const chimp = success.apps.filter(app => app.app.name === 'Mailchimp')
            this.mailChimp = chimp.length > 0;

          }, error => {
            this.generalFunctions.openToast('Unable to load Apps!', 3000, 'error');
          });
      }

    prepareStaffDropdown() {
        for (let i = 0; i < this.staff_list.length; i++) {
            if (this.staff_list[i].login_access) {
                let category = {
                    label: '',
                    value: 0
                };

                category.label = this.staff_list[i].first_name;
                category.value = this.staff_list[i].id;

                this.staffDropdown.push(category);
            }
        }
    }
    prepareStageDropdown() {
        for (let i = 0; i < this.lead_stages.length; i++) {
            let stages = {
                label: '',
                value: 0
            };

            stages.label = this.lead_stages[i].name;
            stages.value = this.lead_stages[i].code;

            this.stageDropdown.push(stages);
        }
    }

    contentScroll(e) {}

    isFilled(e) {
        this.generalFunctions.isFilled(e);
    }

    toggleCustomTicTac(e) {
        this.generalFunctions.toggleCustomTicTac(e);
    }

    autoIncreaseSize(e) {
        var textarea = e.target,
            height = textarea.offsetHeight;
        textarea.style.height = '16px';
        textarea.style.height = textarea.scrollHeight + 'px';
        textarea.style.maxHeight = textarea.scrollHeight + 'px';
        this.isFilled(e);
    }

    documentClickHandler(e) {
        Array.prototype.forEach.call(
            document.getElementsByClassName('more-options-list'),
            (item, index) => {
                item.classList.contains('display-none') ?
                    '' :
                    item.classList.add('display-none');
            }
        );
        if (e.target.parentElement) {
            if (
                e.target.parentElement.classList.contains('more-options-icon')
            ) {
                var list = this.generalFunctions
                    .parents(e.target)[1]
                    .getElementsByClassName('more-options-list')[0];
                list.classList.remove('display-none');
            }
        }
    }

    getSettings() {
        this.http.getData('settings' + this.include_center).subscribe(
            success => {
                success = success;

                this.freeze_enabled =
                    success.administration.memberships.freeze_enabled;
                this.extend_enabled =
                    success.administration.memberships.extend_enabled;
            },
            error => {
                this.generalFunctions.openToast(
                    'Unable to load settings!',
                    3000,
                    'error'
                );
            }
        );
    }

    getProspectData(id) {
        var endpoint =
            'contact/' +
            id +
            this.include_center +
            '&include=activities,emergencyContact,address,memberships';

        this.http.getData(endpoint).subscribe(
            data => {
                this.prospect_data = data;
                this.areMembershipsExpired();

                if (this.prospect_data.data.added_via == 'formlink') {
                    this.primary_tab_selected = 'details';
                }
                // this.getProspectTransactionData(id);
                // check if summary is present and shares in view
                this.is_summary_present = this.isSummaryPresent();

            },
            err => {
                this.generalFunctions.openToast(err.message, 3000, 'error');
                // this.router
                // 	.navigate(['../../prospects'],
                // 		{queryParams:
                // 			{},
                // 			relativeTo : this.route
                // 		}
                // 	);
            },
            () => {}
        );

        !(this.navigationList.length > 0) ? this.organizeNavigation(): null;
        this.getCenterData();


    }

    organizeNavigation() {
        this.navigationList.push('summary');
        this.navigationList.push('payments')
        this.navigationList.push('timeline');
        this.navigationList.push('details');
        this.view = 'summary'

    }

    triggerView(event) {
        this.view = event;

    }


    editProfileDetails() {
        var clone = JSON.stringify(
            Object.assign({}, this.prospect_data['data'])
        );

        this.updated_data['id'] = JSON.parse(clone)['id'];
        this.updated_data['medical_history'] = JSON.parse(clone)[
            'medical_history'
        ];
        this.updated_data['contact'] = JSON.parse(clone)['contact'];
        this.updated_data['address'] = JSON.parse(clone)['address'];
        this.updated_data['emergencyContact'] = JSON.parse(clone)[
            'emergencyContact'
        ];
        this.profile_details_edit = true;
    }

    updateProfile(e, id) {
        var msg: string = null;

        if (
            this.updated_data.emergencyContact.data.first_name == null ||
            this.updated_data.emergencyContact.data.first_name == ''
        ) {
            msg = 'First name of emergency contact can\'t be empty';
        }

        if (
            this.emergency_contact_phone.nativeElement.classList.contains(
                'invalid'
            )
        ) {
            msg = 'Emergency contact phone no is not valid!';
        }

        if (this.pincode.nativeElement.classList.contains('invalid')) {
            msg = 'Pincode is not valid!';
        }

        // if(this.updated_data.contact.email.length<1){
        // 	msg="Prospect email can't be empty";
        // }

        if (this.email.nativeElement.classList.contains('invalid')) {
            msg = 'Prospect email is not valid!';
        }

        if (
            this.updated_data.contact.data.phone == null ||
            this.updated_data.contact.data.phone == ''
        ) {
            msg = 'Prospect phone no can\'t be empty';
        }

        if (this.phone.nativeElement.classList.contains('invalid')) {
            msg = 'Prospect phone no is not valid!';
        }

        if (
            this.updated_data.contact.data.first_name == null ||
            this.updated_data.contact.data.first_name == ''
        ) {
            msg = 'First name of prospect can\'t be empty';
        }

        if (msg) {
            this.generalFunctions.openToast(msg, 3000, 'error');
            return false;
        }

        this.ajax_loader.nativeElement.classList.add('active');
        e.target.classList.add('loading-ajax');

        var endpoint = 'contact/' + id + this.include_center;

        this.http.updateData(endpoint, this.updated_data).subscribe(
            data => {
                var clone = JSON.stringify(this.updated_data);
                e.target.classList.remove('loading-ajax');
                this.prospect_data['data']['medical_history'] = JSON.parse(
                    clone
                )['medical_history'];
                this.prospect_data['data']['contact'] = JSON.parse(clone)[
                    'contact'
                ];
                this.prospect_data['data']['address'] = JSON.parse(clone)[
                    'address'
                ];
                this.prospect_data['data']['emergencyContact'] = JSON.parse(
                    clone
                )['emergencyContact'];
                this.generalFunctions.openToast(
                    'Data updated successfully!',
                    3000,
                    'success'
                );
                this.profile_details_edit = false;
                this.ajax_loader.nativeElement.classList.remove('active');
            },
            error => {
                this.ajax_loader.nativeElement.classList.remove('active');
                e.target.classList.remove('loading-ajax');
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
    }

    onProfileImageLoad(e) {
        var el = e.target;
        el.classList.add('active');
    }


    Message(e) {
        this.autoIncreaseSize(e);
        var SMSCount = Math.ceil(e.target.value.length / 140);
        if (SMSCount) {
            this.sms_count = SMSCount;
            this.sms_length = SMSCount * 140;
        }
    }

    sendSMS(e) {
        if (this.sms_data['message'] == '') {
            this.generalFunctions.openToast('Enter message', 3000, 'error');
            return false;
        }
        this.http
            .sendData(
                'contact/' +
                this.prospect_id +
                '/message' +
                this.include_center,
                this.sms_data
            )
            .subscribe(
                success => {
                    this.generalFunctions.openToast(
                        'Message successfully sent',
                        3000,
                        'success'
                    );
                    this.sms_data['message'] = '';
                    this.sms_data['signature'] = true;
                    this.sms_count = 1;
                    this.sms_length = 140;
                    this.popup = false;
                    this.popup_for = null;
                },
                err => {
                    this.generalFunctions.openToast(err.message, 3000, 'error');
                }
            );
    }

    showPdf(id) {
        var endpoint = 'pos/invoice/' + id + this.include_center;
        this.http.getData(endpoint).subscribe(
            success => {
                success = success;
                window.open('data:application/pdf;base64,' + success.data);
            },
            error => {
                if (error.status_code == 404) {
                    this.generalFunctions.openToast(
                        'Invoice not available!',
                        3000,
                        'error'
                    );
                }
            }
        );
    }

    // Lead management

    resetPopup() {
        this.popup = false;
        this.popup_action = null;
        this.popup_for = null;
        this.add_task_in_stage = false;
        this.add_task_in_comment = false;
        this.task_data['id'] = null;
        this.task_data['type'] = 'phone';
        this.task_data['remind_on'] = null;
        this.task_data['comment'] = null;
        this.task_data['client_id'] = JSON.parse(
            localStorage.getItem('currentUser')
        )['client_id'];

        this.stage_change_data['type'] = 'stage';
        this.stage_change_data['comment'] = null;
        this.stage_change_data['old_stage'] = null;
        this.stage_change_data['new_stage'] = null;

        this.assign_data['type'] = 'transfer';
        this.assign_data['old_assigned_to'] = null;
        this.assign_data['new_assigned_to'] = JSON.parse(
            localStorage.getItem('currentUser')
        )['client_id'];
        this.assign_data['comment'] = null;

        this.comment_data['type'] = 'comment';
        this.comment_data['comment'] = null;
    }

    getLeadStages() {
        this.http
            .getData('leads/stages_sources' + this.include_center)
            .subscribe(
                success => {
                    success = success;
                    this.lead_stages = success.data.stages;
                    if (this.lead_stages > 0) {
                        this.stage_change_data[
                            'new_stage'
                        ] = this.lead_stages[0]['code'];
                    }
                    this.prepareStageDropdown();

                    this.lead_sources = success.data.sources;
                },
                err => {
                    this.generalFunctions.openToast(err.message, 3000, 'error');
                }
            );
    }

    getStaff() {
        this.http.sendData('staff/search' + this.include_center, []).subscribe(
            success => {
                success = success;
                this.staff_list = success.data;
                this.task_data['client_id'] = JSON.parse(
                    localStorage.getItem('currentUser')
                )['client_id'];
                this.assign_data['new_assigned_to'] = JSON.parse(
                    localStorage.getItem('currentUser')
                )['client_id'];
                this.prepareStaffDropdown();
            },
            err => {
                this.generalFunctions.openToast(err.message, 3000, 'error');
            }
        );
    }

    changeStar() {
        var endpoint =
            'prospect/' +
            this.prospect_id +
            '/toggleStar' +
            this.include_center +
            '&include=activities,emergencyContact,address,memberships';
        this.http.patchData(endpoint, null).subscribe(
            success => {
                this.prospect_data = success;
                this.generalFunctions.openToast(
                    'Lead is updated!',
                    2000,
                    'success'
                );
            },
            error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
    }

    //Managing Transactions

    getTransactionCount(data) {
        var transactions = data;
        var total = 0;
        var billingIssue = 0;
        transactions.forEach((item, index) => {
            total += 1;
            parseInt(item.sale.data.amount_due) ? (billingIssue += 1) : '';
        });
        this.transaction_count['total'] = total;
        this.transaction_count['billing_issue'] = billingIssue;
    }

    getProspectTransactionData(id) {
        var endpoint = 'contact/' + id + '/transactions' + this.include_center;

        this.http.getData(endpoint).subscribe(
            data => {
                this.prospect_data['data']['transactions'] = data.data;

                this.getTransactionCount(data.data);
                // check if transactions is present and shares in view
                this.is_transactions_present = this.areTransactionsPresent();
            },
            err => {
                this.generalFunctions.openToast(err.message, 3000, 'error');
                // this.router
                // 	.navigate(['../../customers'],
                // 		{queryParams:
                // 			{},
                // 			relativeTo : this.route
                // 		}
                // 	);
            },
            () => {}
        );
    }

    areTransactionsPresent() {
        if (this.transaction_count['total'] > 0) {
            if (!this.is_summary_present) {
                this.primary_tab_selected = 'payments';
            }

            return true;
        }

        return false;
    }

    areMembershipsExpired() {
        let length: number = this.prospect_data.data.memberships.data.filter(
            function (obj) {
                return (
                    obj.status == 'active' ||
                    obj.status == 'upcoming' ||
                    obj.status == 'billing_issue' ||
                    obj.status == 'freezed'
                );
            }
        ).length;

        if (length == 0) {
            return true;
        }

        return false;
    }

    arePersonalTrainingsExpiredPresent() {
        let length: number = this.prospect_data.data.personal_training.data.filter(
            function (obj) {
                return (
                    obj.status == 'active' ||
                    obj.status == 'upcoming' ||
                    obj.status == 'billing_issue' ||
                    obj.status == 'freezed'
                );
            }
        ).length;

        if (length == 0) {
            return true;
        }

        return false;
    }

    arePersonalTrainingsPresent() {
        if (
            this.prospect_data.data.hasOwnProperty('personal_training') &&
            this.prospect_data.data.personal_training.data.length > 0
        ) {
            return true;
        }

        return false;
    }

    //checks if summary is present
    isSummaryPresent() {
        let SumPre1: boolean = true;
        let SumPre2: boolean = false;

        SumPre1 =
            this.prospect_data.data.memberships.data.length > 0 ||
            this.prospect_data.data.revenue.data.pending > 0 ||
            this.prospect_data.data.revenue.data.total > 0;

        if (this.prospect_data.data.hasOwnProperty('personal_trainings')) {
            SumPre2 =
                this.prospect_data.data.personal_trainings.data.length > 0;
        }

        if (SumPre1 || SumPre2) {
            // this.primary_tab_selected='summary';
        }

        return SumPre1 || SumPre2;
    }

    changeStage() {
        var objStage = JSON.parse(JSON.stringify(this.stage_change_data));
        var objTask = JSON.parse(JSON.stringify(this.task_data));

        // if(this.add_task_in_stage){
        //     var valid = this.validateTaskObject(objTask);
        // 	if(!valid){
        // 		return false;
        // 	}
        // 	if(objTask["client_id"]=='none'){
        // 		delete objTask["client_id"];
        // 	}

        //     var taskReminder = this.generalFunctions.convertDateToISOFormat(objTask["remind_on"])
        //     objTask["remind_on"] = taskReminder["date"]+' '+taskReminder["time"];
        //     objStage["task"] = objTask;
        // }

        this.http
            .sendData(
                'contact/' +
                this.prospect_id +
                '/activity' +
                this.include_center,
                objStage
            )
            .subscribe(
                success => {
                    success = success;
                    this.prospect_data.data[
                        'lead_stage'
                    ] = this.stage_change_data['new_stage'];
                    this.prospect_data.data.activities.data.unshift(
                        success.data
                    );
                    this.generalFunctions.openToast(
                        'Lead stage is changed successfully!',
                        2000,
                        'success'
                    );
                    this.resetPopup();
                },
                error => {
                    this.generalFunctions.openToast(
                        error.message,
                        3000,
                        'error'
                    );
                }
            );
    }

    changeStaff() {
        this.http
            .sendData(
                'contact/' +
                this.prospect_id +
                '/activity' +
                this.include_center,
                this.assign_data
            )
            .subscribe(
                success => {
                    success = success;
                    this.prospect_data.data.activities.data.unshift(
                        success.data
                    );
                    this.generalFunctions.openToast(
                        'Lead is assigned to the staff successfully!',
                        2000,
                        'success'
                    );
                    this.resetPopup();
                    this.getProspectData(this.prospect_id);
                },
                error => {
                    this.generalFunctions.openToast(
                        error.message,
                        3000,
                        'error'
                    );
                }
            );
    }

    addComment() {
        var objStage = JSON.parse(JSON.stringify(this.comment_data));
        var objTask = JSON.parse(JSON.stringify(this.task_data));

        if (this.add_task_in_comment) {
            // var valid = this.validateTaskObject(objTask);

            if (objTask['client_id'] == 'none') {
                delete objTask['client_id'];
            }

            var taskReminder = this.generalFunctions.convertDateToISOFormat(
                objTask['remind_on']
            );
            objTask['remind_on'] =
                taskReminder['date'] + ' ' + taskReminder['time'];
            objStage['task'] = objTask;
        }

        this.http
            .sendData(
                'contact/' +
                this.prospect_id +
                '/activity' +
                this.include_center,
                objStage
            )
            .subscribe(
                success => {
                    success = success;
                    this.prospect_data.data.activities.data.unshift(
                        success.data
                    );
                    this.generalFunctions.openToast(
                        'Comment is successfully added in lead activity!',
                        2000,
                        'success'
                    );
                    this.resetPopup();
                },
                error => {
                    this.generalFunctions.openToast(
                        error.message,
                        3000,
                        'error'
                    );
                }
            );
    }

    clearDues(id) {
        this.router.navigate(['../../pos', id], {
            queryParams: {},
            relativeTo: this.route
        });
    }

    freezePopup(id, start, expire) {
        this.freeze_data['id'] = id;
        this.freeze_data['m_expiry'] = expire;
        this.freeze_data['m_start'] = start;
        this.popup_for = 'freeze';
        this.popup = true;
    }

    extendPopup(id, start, expiry) {
        this.extend_data['id'] = id;
        this.extend_data['m_expiry'] = expiry;
        this.extend_data['m_start'] = start;
        this.extend_data['expires_at'] = expiry;
        this.extend_data['starts_at'] = start;
        this.popup_for = 'extend';
        this.popup = true;
    }

    unfreezePopup(id, name) {
        this.popup_for = 'unfreeze';
        this.popup = true;
        this.unfreeze_data['id'] = id;
        this.unfreeze_data['name'] = name;
    }

    freezeMembership(e) {
        var err = null;

        if (this.freeze_data['starts_at']) {
            var start = this.generalFunctions.convertDateToISOFormat(
                this.freeze_data['starts_at']
            );
            var newmin = parseInt(start['time'].split(':')[1], 10);
            var pad = function (n) {
                return n < 10 ? '0' + n : n;
            };
            start['time'] = [
                start['time'].split(':')[0],
                pad(newmin + 1).toString(),
                start['time'].split(':')[2]
            ].join(':');
            this.freeze_data['starts_at'] = start['date'] + ' ' + start['time'];
        } else {
            err = 'Enter freeze start date';
        }

        if (this.freeze_data['ends_at']) {
            var end = this.generalFunctions.convertDateToISOFormat(
                this.freeze_data['ends_at']
            );
            var newmin = parseInt(end['time'].split(':')[1], 10);
            var pad = function (n) {
                return n < 10 ? '0' + n : n;
            };
            end['time'] = [
                end['time'].split(':')[0],
                pad(newmin + 1).toString(),
                end['time'].split(':')[2]
            ].join(':');
            this.freeze_data['ends_at'] = end['date'] + ' ' + end['time'];
        } else {
            err = 'Enter freeze end date';
        }

        if (err) {
            this.generalFunctions.openToast(err.message, 3000, 'error');
            return false;
        }
        var endpoint =
            'membership/' +
            this.freeze_data['id'] +
            '/freeze' +
            this.include_center;
        var obj = JSON.parse(JSON.stringify(this.freeze_data));

        this.http.sendData(endpoint, obj).subscribe(
            success => {
                success = success;
                var msg = 'Membership is successfully freezed';
                this.generalFunctions.openToast(msg, 3000, 'success');
                this.router.navigate(['../../refresh'], {
                    queryParams: {
                        url: 'customers/' + this.prospect_id
                    },
                    relativeTo: this.route
                });
            },
            error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
    }

    unfreezeMembership(e) {
        var endpoint =
            'membership/' +
            this.unfreeze_data['id'] +
            '/unfreeze' +
            this.include_center;
        var obj = this.unfreeze_data['obj'];

        this.http.sendData(endpoint, obj).subscribe(
            success => {
                var msg = 'Membership is successfully unfreezed';
                this.generalFunctions.openToast(msg, 3000, 'success');
                this.router.navigate(['../../refresh'], {
                    queryParams: {
                        url: 'customers/' + this.prospect_id
                    },
                    relativeTo: this.route
                });
            },
            error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
    }

    extendMembership(e) {
        var err = null;

        if (this.extend_data['expires_at']) {
            var expiry = this.generalFunctions.convertDateToISOFormat(
                this.extend_data['expires_at']
            );
            this.extend_data['expires_at'] = expiry['date'];
        } else {
            err = 'Enter new expiry date';
        }

        if (this.extend_data['starts_at']) {
            var start = this.generalFunctions.convertDateToISOFormat(
                this.extend_data['starts_at']
            );
            this.extend_data['starts_at'] = start['date'];
        } else {
            err = 'Enter new start date';
        }

        if (err) {
            this.generalFunctions.openToast(err.message, 3000, 'error');
            return false;
        }

        var endpoint =
            'membership/' +
            this.extend_data['id'] +
            '/extend' +
            this.include_center;
        var obj = JSON.parse(JSON.stringify(this.extend_data));

        this.http.sendData(endpoint, obj).subscribe(
            success => {
                var msg = 'Membership is successfully extended';
                this.router.navigate(['../../refresh'], {
                    queryParams: {
                        url: 'customers/' + this.prospect_id
                    },
                    relativeTo: this.route
                });
            },
            error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
            }
        );
    }

    updateMessageContent(e) {
        this.messageDetails.message = e;
    }

    sendMessage() {
        this.messageDetails.channel = this.groupMessage.channel;

        if ((this.messageDetails.subject == '' && this.messageDetails.channel == 'email') || this.messageDetails.message == '') {
            this.generalFunctions.openToast('Please fill in the required fields', 3000, 'error');
            return;
          }
          this.messageDetails.channel === 'email' ? this.messageDetails.channel = 'mail' : '';

          this.http.sendData('contact/' + this.prospect_id + '/message' + this.include_center, this.messageDetails).subscribe(response => {
            this.generalFunctions.openToast('Message has been sent', 3000, 'success');
            this.resetPopup();
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });


        // if (
        //     this.messageDetails.subject == '' ||
        //     this.messageDetails.message == ''
        // ) {
        //     this.generalFunctions.openToast(
        //         'Please fill in both the fields',
        //         3000,
        //         'error'
        //     );
        // }
        // this.messageDetails.channel =  "mail"




        // this.http
        //     .sendData(
        //         'contact/' +
        //         this.prospect_id +
        //         '/message' +
        //         this.include_center,
        //         this.messageDetails
        //     )
        //     .subscribe(
        //         response => {
        //             console.log(response);
        //             this.generalFunctions.openToast(
        //                 'Message has been sent',
        //                 3000,
        //                 'success'
        //             );
        //             this.resetPopup();
        //         },
        //         error => {
        //             this.generalFunctions.openToast(error, 3000, 'error');
        //         }
        //     );



        }

    getSourceName(name) {

       const arr =  this.lead_sources.filter(element => {
            if (element.code === name) {
                return element;
            }
        });
        return arr[0].name;
    }

    groupMessageClick() {
        if (this.channels.includes('sms')) {
            this.messageDetails.message = '';
          this.groupMessage.channel = 'sms';
        }
      }
      smsCounter(data) {
        data.length == 0
          ? (this.smsNum = 0)
          : (this.smsNum = Math.floor(data.length / 160) + 1);
      }

      unarchiveCustomer(id) {
        this.http.getData(`contact/${id}/unarchive` + this.include_center).subscribe(response => {
          this.generalFunctions.openToast('Lead has been unarchived', 3000, 'success');

          this.router.navigate(['../client/prospects']);
        }, error => {
          this.generalFunctions.openToast(error.message, 3000, 'error');
        });
      }

      deleteCustomer() {
        this.http.deleteData(`contact/${this.deleteId}${this.include_center}`).subscribe(response => {
          this.popup_for = null;
          this.generalFunctions.openToast('Lead has been archived successfully', 3000, 'success');
          this.router.navigate(['../client/prospects']);
        }, error => {
          this.popup_for = null;

          this.generalFunctions.openToast(error.message, 3000, 'error');
        });
      }

      deleteLead() {
        this.http.deleteData(`contact/${this.deleteId}/delete${this.include_center}`).subscribe(response => {
          this.popup_for = null;
          this.generalFunctions.openToast('Lead has been deleted successfully', 3000, 'success');
          this.router.navigate(['../client/prospects']);
        }, error => {
          this.popup_for = null;

          this.generalFunctions.openToast(error.message, 3000, 'error');
        });
      }
}
