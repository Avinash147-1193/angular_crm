import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProspectsProfileComponent } from './prospects-profile.component';

describe('ProspectsProfileComponent', () => {
  let component: ProspectsProfileComponent;
  let fixture: ComponentFixture<ProspectsProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProspectsProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProspectsProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
