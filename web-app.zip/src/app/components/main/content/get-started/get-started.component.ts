import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute, Params} from "@angular/router";
import {GeneralServices} from "../../../../common/general-services";
import {ServerAuthService} from "../../../../common/server-auth";

@Component({selector: "app-get-started", templateUrl: "./get-started.component.html", styleUrls: ["./get-started.component.scss"]})
export class GetStartedComponent implements OnInit {
  constructor(private router : Router, private route : ActivatedRoute, private generalFunctions : GeneralServices, private http : ServerAuthService) {}
  include_center: any;
  getStartedData: any = {
    add_availability: false,
    add_customer: false,
    add_membership: false,
    add_staff: false,
    book_appointment: false,
    book_class: false,
    business_settings: false,
    class_schedule: false,
    customer_apps: false,
    payment_provider: false,
    website_portal: false
  };
  window: any;

  ngOnInit() {
    // this.include_center = this.generalFunctions.includeCenter();
    this.include_center = JSON.parse(localStorage.getItem("currentUser")).center_id;
    this.getInitialData();
    this.window = <any>window; } getInitialData() {
        console.log("this.include_center", this.include_center);
        this.http.getData("center/" + this.include_center + "/onboarding?center_id=" + this.include_center).subscribe(response => {
          console.log("response", response);
          this.getStartedData.add_membership = response.data.add_membership;
          this.getStartedData.add_availability = response.data.add_availability;
          this.getStartedData.add_customer = response.data.add_customer;
          this.getStartedData.add_staff = response.data.add_staff;
          this.getStartedData.book_appointment = response.data.book_appointment;
          this.getStartedData.book_class = response.data.book_class;
          this.getStartedData.business_settings = response.data.business_settings;
          this.getStartedData.class_schedule = response.data.class_schedule;
          this.getStartedData.customer_apps = response.data.customer_apps;
          this.getStartedData.payment_provider = response.data.payment_provider;
          this.getStartedData.website_portal = response.data.website_portal;

          this.getStartedData = response.data;
          console.log("this.getStartedData", this.getStartedData);
        }, err => {});
      }

      startTour(tourId) {
        console.log("yes");
        this.window.Intercom("startTour", tourId);
      }
      }
