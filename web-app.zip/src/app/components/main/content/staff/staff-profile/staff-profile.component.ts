import {Component, OnInit, ViewChild, OnDestroy, ViewEncapsulation} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import * as moment from 'moment';
import {resetFakeAsyncZone} from '@angular/core/testing';

@Component({templateUrl: './staff-profile.component.html', styleUrls: ['./staff-profile.component.scss','../../services/styles/profiles.scss'], encapsulation: ViewEncapsulation.None})
export class StaffProfileComponent implements OnInit,
OnDestroy {
  navigationList: Array<string> = ['summary', 'profile'];
  show_update_profile_picture_popup: boolean = false;
  tab_selected: string = 'details';
  staff_data: any = null;
  updated_staff_data: any = null;
  roles_data: any = [];
  services_data: any = [];
  profile_details_edit: boolean = false;
  delete_pop_up: boolean = false;
  include_center: any = null;
  personal_training_id: any = null;
  is_trainer: boolean = false;
  setAvailability: boolean = false;
  pt_subscriber: boolean = false;
  message_pop_up: boolean;
  pop_up_for: any = null;

  true: boolean = true;
  false: boolean = false;
  null: any = null;
  view: any = 'summary';
  conflicts: any;
  overwrite: any = false;
  reqHoliday: any;

  months: any = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12
  ];
  weeks: any = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20
  ];
  days: any = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30
  ];
  messageDetails: any = {
    message: '',
    subject: '',
    channel: 'email'
  };
  newDurationDefaultData: object = {
    amount: 2000,
    duration_type: 'month',
    duration: 1,
    freeze_limit: 0
  };
  updatedDurationDetails: any = {
    id: 0,
    duration_type: 'month',
    duration: 1,
    amount: 2000,
    freeze_limit: 0
  };

  ptData: any = [];
  pt_edit_mode: boolean = false;
  subscribed_customer_table: boolean = false;

  freeze_enabled: boolean = false;

  videoStream: any = null;
  webcam_initiate: boolean = false;
  photo_selected: boolean = false;
  photo_captured: boolean = false;

  isCameraAdapted: boolean = true;

  enlarged_photo_popup: boolean = false;

  staff_id: any = null;
  phonePrefix: any;
  startDate: any = new Date();

  startDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default',
    minDate: new Date()
  };

  holiday: any = {
    reason: '',
    startDate: new Date(),
    startTime: '',
    endDate: new Date(),
    endTime: ''
  };
  endDatepickerConfig = {
    showWeekNumbers: false,
    containerClass: 'theme-default',
    minDate: this.holiday.startDate
  };

  tool_tip_for: any = null;
  holidayHistory: any = [];
  holidayLoading: any = false;
  working: any;
  senderId : any = [];
  smsNum:any;
  centerId:any;
  @ViewChild('new_duration_box')new_duration_box;

  @ViewChild('submit_button')submit_button;
  @ViewChild('ajax_loader')ajax_loader;

  @ViewChild('video')video;
  @ViewChild('canvas')canvas;
  @ViewChild('photo_tag')photo_tag;

  @ViewChild('selected_image')selected_image;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private generalFunctions: GeneralServices,
    private http: ServerAuthService) {}

  ngOnInit() {
    this.centerId = JSON.parse(localStorage.getItem('currentUser'))['center_id'];

    this.include_center = this.generalFunctions.includeCenter();
    this.initializeDndTimes();
    this.phonePrefix = JSON.parse(localStorage.getItem('localization'))['country']['isd_code'];
    // this.getRoles();
    // this.getRoles();
    // this.getServices();
    this.getSettings();
    this.getCenterData();

    this.route.params.subscribe(params => {
      this.staff_id = params['id'];
      this.getStaffData(params['id']);
      this.getHoliday();
    });
    document.addEventListener('click', event => {
      this.documentClickHandler(event);
    });
  }

  ngOnDestroy() {
    this.stopWebcam();
  }



  initializeDndTimes() {
    let d = new Date();
    let now = Number(moment().add(1, 'hours').format('HH'));
    d.setHours(now, 0, 0, 0);
    this.holiday.startTime = d;
    this.holiday.endTime = d;
    let x: any = moment().add(1, 'days');
    this.holiday.endDate = new Date(x);
  }

  startDateChanged(e) {
    if (this.holiday.startDate > this.holiday.endDate) {
      let x: any = moment(this.holiday.startDate).add(1, 'days');
      this.holiday.endDate = new Date(x);
    }
  }

  documentClickHandler(e) {
    Array.prototype.forEach.call(document.getElementsByClassName('more-options-list'), (item, index) => {
      item.classList.contains('display-none')
        ? ''
        : item.classList.add('display-none');
    });
    if (e.target.parentElement) {
      if (e.target.parentElement.classList.contains('more-options-icon')) {
        var list = this.generalFunctions.parents(e.target)[1].getElementsByClassName('more-options-list')[0];
        list.classList.remove('display-none');
      }
    }
  }

  contentScroll(e) {
    // this.generalFunctions.breadcrumbToggle(e);
  }
  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }
  toggleCustomTicTac(e) {
    this.generalFunctions.toggleCustomTicTac(e);
  }

  getSettings() {
    this.http.getData('settings' + this.include_center).subscribe(success => {
      success = success;
      this.freeze_enabled = success.administration.memberships.freeze_enabled;
    }, error => {
      this.generalFunctions.openToast('Unable to load settings!', 3000, 'error');
    });
  }

  getStaffData(id) {
    this.http.getData('staff/' + id + this.include_center).subscribe(success => {
      success = success;
      this.staff_data = success.data;
      this.working = [];
      this.getWorkingHours(success.data.availability.availability);
      this.getRoles(success.data);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  getWorkingHours(data) {
    data.forEach(element => {
      this.working.push({
        day: this.getDay(element.day),
        slots: element.slots
      });
    });
  }

  togglePT() {
    this.setAvailability = !this.setAvailability;
  }
  getRoles(value) {
    this.roles_data = [];
    this.http.getData('roles' + this.include_center).subscribe(success => {
      success = success;
      this.roles_data = success.data;
      let role = this.roles_data.filter(role => value.role_id === role.id);
     console.log('role', role[0].name)
     this.staff_data.roleName = role[0].name;
    //   this.roles_data.forEach(role => {
    //     if (value.role_id == role.id) {
    //       this.staff_data.roleName = role.name;
    //     }
    //   });
      console.log(this.roles_data);
    });
  }

  checkIsTrainer() {
    var found = false;
    if (this.staff_data.roles.length != 0) {
      this.staff_data.roles.forEach((item, index) => {
        if (item == 'trainer') {
          found = true;
        }
      });
      this.is_trainer = found;
    } else {
      this.is_trainer = found;
    }
    if (!found && this.tab_selected == 'pt') {
      this.tab_selected = 'details';
    }
  }

  editProfile(e) {
    this.profile_details_edit = true;
    this.router.navigate(['/client/staff/edit/' + this.staff_data.id]);
    this.updated_staff_data = JSON.parse(JSON.stringify(this.staff_data));
    if (this.updated_staff_data.roles.length == 0) {
      this.updated_staff_data['role_id'] = this.roles_data[0].id;
    } else {
      this.updated_staff_data['role_id'] = this.updated_staff_data.roles.id;
    }
  }

  deleteStaff() {
    var endpoint = 'staff/' + this.staff_data.id + this.include_center;
    this.http.deleteData(endpoint).subscribe(success => {
      var msg = 'Staff is deleted succesfully!';
      this.generalFunctions.openToast(msg, 3000, 'success');
      this.router.navigate(['../'], {
        queryParams: {},
        relativeTo: this.route
      });
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  reinviteStaff() {
    this.http.getData(`staff/${this.staff_id}/invite${this.include_center}`).subscribe(success => {
      this.generalFunctions.openToast('Verification email has been resent', 3000, 'success');
    }, err => {
      this.generalFunctions.openToast(err.message, 1500, 'error');
    });
  }

  updateProfile(e) {
    var clone = Object.assign({}, this.updated_staff_data),
      obj = clone;
    var dob = obj.date_of_birth,
      msg = null;

    if (dob) {
      dob = this.generalFunctions.convertDateToISOFormat(dob);
      obj.date_of_birth = dob['date'];
    } else {
      msg = 'Enter valid date of birth';
    }

    if (!obj['first_name']) {
      msg = 'Enter first name.';
    }

    if (!obj['last_name']) {
      msg = 'Enter last name.';
    }

    if (!obj['email']) {
      msg = 'Enter email.';
    }

    if (!obj['address']['pincode']) {
      msg = 'Enter pincode.';
    }

    if (!obj['address']['address']) {
      msg = 'Enter address.';
    }

    if (!obj['address']['state']) {
      msg = 'Enter state.';
    }

    if (!obj['address']['city']) {
      msg = 'Enter city.';
    }

    if (!obj['designation']) {
      msg = 'Enter designation.';
    }

    if (msg) {
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    if (!obj.login_access) {
      delete obj['role_id'];
    } else {
      obj['role_id'] = obj['role_id'];
    }

    delete obj['roles'];
    delete obj['phone'];

    this.ajax_loader.nativeElement.classList.add('active');
    this.submit_button.nativeElement.classList.add('loading-ajax');

    this.http.updateData('staff/' + obj['id'] + this.include_center, obj).subscribe(success => {
      this.ajax_loader.nativeElement.classList.remove('active');
      this.submit_button.nativeElement.classList.remove('loading-ajax');
      this.generalFunctions.openToast('Staff updated successfully!', 3000, 'success');
      this.staff_data = success.data;
      this.profile_details_edit = false;
      this.updated_staff_data = null;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.ajax_loader.nativeElement.classList.remove('active');
      this.submit_button.nativeElement.classList.remove('loading-ajax');
    });
  }

  /* PERSONAL TRAINING RELATED METHODS */

  toggleNewDuration() {
    this.pt_edit_mode = !this.pt_edit_mode;
    this.new_duration_box.nativeElement.classList.toggle('display-none');
  }

  toggleOldDuration(e, id) {
    var li = this.generalFunctions.closestTag(e.target, 'LI');
    var editable = li.getElementsByClassName('edit-plan')[0];
    this.pt_edit_mode = !this.pt_edit_mode;
    editable.classList.toggle('shown');
    if (id) {
      var ids = [];
      if (this.staff_data.services.data[0].plans.data.length != 0) {
        this.staff_data.services.data[0].plans.data.durations.data.map((item, index) => {
          ids.push(item.id);
        });
        var i = ids.indexOf(id);
        var obj = this.staff_data.services.data[0].plans.data.durations.data[i];
        if (obj['duration_type'].slice(-1) == 's') {
          var len = obj['duration_type'].length;
          obj['duration_type'] = obj['duration_type'].substring(0, len - 1);
        }
      }
      this.updatedDurationDetails = JSON.parse(JSON.stringify(obj));
    }
  }

  addDuration(e) {
    var obj = {};
    var endpoint = {};
    if (this.staff_data.services.data[0].plans.data.length == 0) {
      obj['name'] = this.staff_data.first_name + ' ' + this.staff_data.last_name;
      obj['staff_id'] = this.staff_data.id;
      obj['service_id'] = this.personal_training_id;
      obj['durations'] = [];
      obj['durations'][0] = JSON.parse(JSON.stringify(this.newDurationDefaultData));
      if (!this.freeze_enabled) {
        delete obj['durations'][0]['freeze_limit'];
      }
      endpoint = 'plan' + this.include_center;
    } else {
      obj = JSON.parse(JSON.stringify(this.newDurationDefaultData));
      if (!this.freeze_enabled) {
        delete obj['freeze_limit'];
      }
      endpoint = 'plan/' + this.staff_data.services.data[0].plans.data.id + '/duration' + this.include_center;
    }
    this.http.sendData(endpoint, obj).subscribe(success => {
      if (this.staff_data.services.data[0].plans.data.length == 0) {
        this.staff_data.services.data[0].plans.data = success.data;
      } else {
        this.staff_data.services.data[0].plans.data.durations.data.push(success.data);
      }
      this.toggleNewDuration();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  deleteDuration(e, durationId, ptId) {
    var endpoint = 'plan/' + ptId + '/duration/' + durationId + this.include_center;
    this.http.deleteData(endpoint).subscribe(success => {
      this.generalFunctions.openToast('Duration is deleted!', 3000, 'success');
      var id = null;
      this.staff_data.services.data[0].plans.data.durations.data.forEach((item, index) => {
        if (item.id == durationId) {
          id = index;
        }
      });
      this.pt_edit_mode = false;
      this.staff_data.services.data[0].plans.data.durations.data.splice(id, 1);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    }, () => {});
  }

  updateDuration(e, durationId, ptId) {
    var endpoint = 'plan/' + ptId + '/duration/' + durationId + this.include_center;
    var obj = this.updatedDurationDetails;
    if (!this.freeze_enabled) {
      delete obj['freeze_limit'];
    }
    this.http.updateData(endpoint, obj).subscribe(success => {
      this.staff_data.services.data[0].plans.data.durations.data.forEach((item, index) => {
        if (item.id == success.data.id) {
          this.staff_data.services.data[0].plans.data.durations.data[index] = success.data;
        }
      });
      var li = this.generalFunctions.closestTag(e.target, 'LI');
      var editable = li.getElementsByClassName('edit-plan')[0];
      this.pt_edit_mode = false;
      editable.classList.remove('shown');
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  updateMessageContent(e) {
    this.messageDetails.message = e;
  }

  sendMessage() {
    if ((this.messageDetails.subject == '' && this.messageDetails.channel == 'email')
    || this.messageDetails.message == '') {
      this.generalFunctions.openToast('Please fill in both the fields', 3000, 'error');
    }
    this.http.sendData('staff/' + this.staff_id + '/message' + this.include_center, this.messageDetails).subscribe(response => {
      this.generalFunctions.openToast('Message has been sent', 3000, 'success');

      this.message_pop_up = false;
      this.messageDetails.message = '';
      this.messageDetails.subject = '';
    }, error => {

      this.message_pop_up = false;
      this.messageDetails.message = '';
      this.messageDetails.subject = '';
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  removeStaff(data) {
    let reqObj = Object.assign({}, data);
    reqObj.status = 0;
    this.http.updateData('staff/' + data.id + this.include_center, reqObj).subscribe(success => {
      this.generalFunctions.openToast('Staff archived successfully!', 3000, 'success');
      this.staff_data = success.data;
      this.router.navigate(['../'], {
        queryParams: {},
        relativeTo: this.route
      });
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }


  unArchiveStaff(data) {
    let reqObj = Object.assign({}, data);
    reqObj.status = 1;
    this.http.updateData('staff/' + data.id + this.include_center, reqObj).subscribe(success => {
      this.generalFunctions.openToast('Staff unarchived successfully!', 3000, 'success');
      this.staff_data = success.data;
      this.router.navigate(['../'], {
        queryParams: {},
        relativeTo: this.route
      });
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  openPhotoPopup() {
    this.webcam_initiate = true;
    let width = 400;
    let height = 400;
    setTimeout(() => {
      navigator.mediaDevices.getUserMedia({video: true, audio: false}).then(stream => {
        this.video.nativeElement.srcObject = stream;
        this.videoStream = stream;
        this.video.nativeElement.play();
      }).catch(err => {
        this.isCameraAdapted = false;
      });

      this.video.nativeElement.addEventListener('canplay', e => {
        height = width;
        if (isNaN(height)) {
          height = width;
        }

        this.video.nativeElement.setAttribute('width', width);
        this.video.nativeElement.setAttribute('height', height);
      }, false);
    }, 200);
  }

  takePicture() {
    var context = this.canvas.nativeElement.getContext('2d');
    this.canvas.nativeElement.width = 400;
    this.canvas.nativeElement.height = 400;
    context.drawImage(this.video.nativeElement, -66.66, 0, 533.33, 400);

    var data = this.canvas.nativeElement.toDataURL('image/png');
    this.photo_tag.nativeElement.setAttribute('src', data);
    this.photo_captured = true;
  }

  changePicture() {
    var context = this.canvas.nativeElement.getContext('2d');
    context.fillStyle = '#AAA';
    context.fillRect(0, 0, 0, 0);

    var data = this.canvas.nativeElement.toDataURL('image/png');
    this.photo_tag.nativeElement.removeAttribute('src');
    this.photo_captured = false;
  }

  stopWebcam() {
    if (this.videoStream) {
      this.videoStream.getTracks()[0].stop();
    }
    this.webcam_initiate = false;
  }

  selectPicture(e) {
    var src = this.photo_tag.nativeElement.getAttribute('src');
    e.target.classList.add('loading-ajax');

    var data = this.canvas.nativeElement.toDataURL('image/png');
    this.photo_tag.nativeElement.removeAttribute('src');

    var obj = {};

    obj['photo'] = src;

    console.log('src', src);
    const uploadData = new FormData();

    uploadData.append('blob', src);
    uploadData.append('type', 'contacts');

    this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
      console.log('this.customer_data', response);
      var context = this.canvas.nativeElement.getContext('2d');
      context.fillStyle = '#AAA';
      context.fillRect(0, 0, 0, 0);
      this.photo_captured = false;
      this.photo_selected = true;
      this.saveImage(response.url);

      this.stopWebcam();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.stopWebcam();
      this.photo_captured = false;
      this.photo_selected = true;
      this.webcam_initiate = false;
    });
  }

  newFileUpload(event) {
    console.log(event);
    let fSize = event.target.files[0].size;

    if (event.target.files && event.target.files[0] && fSize < 2000000) {
      const file = event.target.files[0];
      console.log(event.target.files);
      const fileType = file.type.split('/');
      const uploadData = new FormData();
      uploadData.append('image', file);
      uploadData.append('type', 'contacts');

      this.http.sendFormData(`image${this.include_center}`, uploadData).subscribe(response => {
        this.saveImage(response.url);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
    } else {
      this.generalFunctions.openToast('Please upload a image of size 2mb or less', 3000, 'error');
    }
  }

  saveImage(url) {
    let obj = {
      image_url: url
    };
    let endPoint = `staff/${this.staff_id}/image` + this.include_center;
    this.http.patchData(endPoint, obj).subscribe(success => {
      this.generalFunctions.openToast('Profile picture has been updated successfully', 3000, 'success');
      this.getStaffData(this.staff_id);
      this.show_update_profile_picture_popup = false;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  triggerView(event) {
    this.view = event;
  }

  holidayProvider() {
    this.pop_up_for = 'holiday';
  }

  checkHoliday() {
    this.holidayLoading = true;
    console.log('this.holiday', this.holiday);
    let reqObj = {
      reason: this.holiday.reason,
      starts_at: `${moment(this.holiday.startDate).format('YYYY-MM-DD')} ${moment(this.holiday.startTime).format('HH:mm')}:00`,
      ends_at: `${moment(this.holiday.endDate).format('YYYY-MM-DD')} ${moment(this.holiday.endTime).format('HH:mm')}:00`
    };
    this.reqHoliday = reqObj;

    console.log(this.reqHoliday);

    this.http.sendData('staff/' + this.staff_id + '/holidays/conflicts' + this.include_center, reqObj).subscribe(response => {
      console.log(response);
      this.conflicts = response.events;
      if (this.conflicts.length == 0) {
        this.addHoliday();
        return;
      }
      //   this.getHoliday();
      this.pop_up_for = 'holiday-next';
      this.holidayLoading = false;
    }, err => {
      this.generalFunctions.openToast(err, 3000, 'error');
      this.holidayLoading = false;
    });
  }

  addHoliday() {
    this.holidayLoading = true;
    console.log('this.holiday', this.holiday);
    let reqObj = {
      reason: this.holiday.reason,
      starts_at: `${moment(this.holiday.startDate).format('YYYY-MM-DD')} ${moment(this.holiday.startTime).format('HH:mm')}:00`,
      ends_at: `${moment(this.holiday.endDate).format('YYYY-MM-DD')} ${moment(this.holiday.endTime).format('HH:mm')}:00`
    };
    this.http.sendData('staff/' + this.staff_id + '/holidays' + this.include_center, reqObj).subscribe(response => {
      console.log(response);
      this.generalFunctions.openToast('Holiday added', 3000, 'success');
      this.getHoliday();
      this.pop_up_for = null;
      this.holidayLoading = false;
    }, err => {
      this.generalFunctions.openToast(err, 3000, 'error');
      this.holidayLoading = false;
    });
  }

  getHoliday() {
    this.http.getData('staff/' + this.staff_id + '/holidays' + this.include_center).subscribe(success => {
      console.log('success', success);
      this.holidayHistory = success.data;
    }, err => {});
  }

  deleteHoliday(id) {
    this.http.deleteData('staff/' + this.staff_id + '/holidays/' + id + this.include_center).subscribe(success => {
      this.generalFunctions.openToast('Holiday deleted', 3000, 'success');
      this.getHoliday();
    }, err => {
      this.generalFunctions.openToast(err, 3000, 'error');
    });
  }

  hourDateFormat(date) {
    return moment(date).format('hh:mm a, DD MMM YYYY');
  }

  goToEvent(event) {
    // console.log("event", event);
    // this.router.navigate(["/client/calendar"], {
    //   queryParams: {
    //     event: event
    //   }
    // });

    let x = `#/client/calendar?event=${event}`;
    window.open(x, '_blank');
  }

  getDay(num) {
    let weeks = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday'
    ];
    return weeks[num - 1];
  }

  getTime(time) {
    let x = time;
    let hour = x.split(':')[0];
    let minute = x.split(':')[1];
    let zone = 'am';

    if (hour >= 12 && minute >= 0) {
      hour = hour == 12
        ? 12
        : hour - 12;
      hour = hour <= 9
        ? '0' + hour
        : hour;
      zone = 'pm';
    } else if (hour == '00') {
      hour = 12;
      zone = 'am';
    }

    return hour + ':' + minute + ' ' + zone;
  }

  smsCounter(data) {
    data.length == 0
      ? (this.smsNum = 0)
      : (this.smsNum = Math.floor(data.length / 160) + 1);
  }

  groupMessageClick() {
    if (this.senderId.includes('sms')) {
        this.messageDetails.message = '';
      this.messageDetails.channel = 'sms';
    }
  }


  getCenterData() {
    this.http.getData(`center/${this.centerId}` + this.include_center).subscribe(success => {


      let senderId = success.data.settings.automations.channels.sms;

      if (senderId === 1) {
        this.senderId.push('sms')
      }
    }, error => {});
  }

}
