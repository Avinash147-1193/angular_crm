import { Component, OnInit, ViewChild, OnDestroy, ElementRef, DoCheck, Input, Output ,
		 OnChanges, SimpleChanges, SimpleChange, EventEmitter } from '@angular/core';
import { CalendarEvent } from 'angular-calendar';
import { GeneralServices } from '../../../../../common/general-services'; 
import { ServerAuthService } from '../../../../../common/server-auth';

@Component({
		 selector: 'staff-attendance-component',
		 templateUrl: 'attendance-calendar.component.html',
		 styles: [`
					.biometric-input{
							 width: 121px;
							 height: 32px;
							 margin-left: 8px;
							 margin-right: 16px;
							 line-height: 16px;
							 padding: 8px;
							 border-radius: 3px;
							 border: 1px solid #dfe3e9;
							 float: right;
					}
					.attendance-number{
							 color: #546a7b;
							 font-size: 26px;
							 line-height: 32px;
							 float: right;
							 width: 122px;
							 text-align: right;
							 padding-right: 8px;
							 padding-left: 8px;
					}
					.edit-attendance-value{
							 margin-right: 32px;
							 line-height: 30px;
							 border: 1px solid #dfe3e9;
							 border-radius: 3px;
				}
		`]
})
export class StaffAttendanceComponent implements OnChanges {

		true: boolean = true;
		false: boolean = false;
		null: any = null;

		view: string = 'month';
		totalMonthlyAttendance: number = 0;
		totalDaysInMonth: number = 0;
		viewDate: Date = new Date();

		biometricEnabled: boolean = true;
		biometricValue : any = null;
		biometricValueEdit: boolean = false;

		attendee_id: any = null;

		colors: any = {
			success: '#43c081'
		}

		events: CalendarEvent<{id: number}>[] = [];

		@Input() staff_id;
		_staff_id: any  = null;

		 
		 @ViewChild('id_edit') id_edit;
		 include_center: any = null;

		constructor(
			private http: ServerAuthService,
			private generalFunctions: GeneralServices
		){

		this.include_center = this.generalFunctions
							.includeCenter();
		}

		ngOnChanges(changes: SimpleChanges){
			const staff_id: SimpleChange = changes.staff_id;
			if(changes.staff_id){
				this._staff_id = staff_id.currentValue;
				this.getAttendance();
				this.setAttendanceData();
			}
		}
 
		getAttendance(){
			var endpoint = 'staff/'+this._staff_id+'/attendance'+this.include_center
			+'&month='+(this.viewDate.getMonth()+1)+'&year='+this.viewDate.getFullYear();
			this.totalDaysInMonth = this.daysInMonth(this.viewDate.getMonth()+1,this.viewDate.getFullYear());
			this.http.getData(endpoint)
				.subscribe(
					(success)=>{
						success = success.data;
						this.formatDataToEvent(success);
						this.totalMonthlyAttendance = success.length;
					},
					(err)=>{
					this.generalFunctions.openToast(err.message,3000,"error");
				}
				)
		}


		formatDataToEvent(data){
			var newEvents:  CalendarEvent<{id: number}>[] = data.map((item,index)=>{
				if(item.status=='accepted'){
					return {
						title: item.in_time,
						start: new Date(item.date),
						color: this.colors.success,
						meta:{
							start: item.in_time,
							end: item.out_time,
							text: 'spaces',
							bool:true
						}
					}
				}else{
					return {
						title: item.in_time,
						start: new Date(item.date),
						color: this.colors.success,
						meta:{
							start: item.in_time,
							end: item.out_time,
							bool:false,
							text: 'Access denied'
						} 
					}
				}
				
			})
			this.events= newEvents;

		}

		daysInMonth(month,year) {
			return new Date(year, month, 0).getDate();
	}

		showPreviousMonth(){
			var r = this.viewDate;	
		r.setMonth(r.getMonth() - 1);
			this.viewDate = new Date(r);
			this.getAttendance();
		}

		showNextMonth(){
			var r = this.viewDate;	
		r.setMonth(r.getMonth() + 1);
			this.viewDate = new Date(r);
			this.getAttendance();
		}


		 editAttendanceId(){
					this.biometricValueEdit=true;
					setTimeout(()=>{
							 this.id_edit.nativeElement.focus()
					},200);
		 }

		 updateAttendanceId(){
					this.biometricValueEdit=false;
					var endpoint = 'staff/'+this._staff_id+'/biometric'+this.include_center;
					var obj = {};
					obj["attendee_id"] = this.attendee_id;
					this.http.patchData(endpoint,obj)
							 .subscribe(
										(data)=>{ 
												 this.biometricValue = this.attendee_id;
												 var message = "Attendance ID successfully updated";
												 this.generalFunctions.openToast(message,3000,"success");
										},
										(err)=>{

												 this.attendee_id = this.biometricValue;
												 this.generalFunctions.openToast(err.message,3000,"error");
												 if(this.id_edit){
															this.id_edit.nativeElement.focus();
												 }
										},
										()=>{}
							 )
		 }

		setAttendanceData(){
					this.http.getData('settings'+this.include_center)
							 .subscribe(
										(success)=>{
												 this.biometricEnabled = success.attendance.biometric.enabled;
										},(err)=>{
												 this.generalFunctions.openToast(err.message,3000,"error");
										}
							 ) 
					
					var endpoint = 'staff/'+this._staff_id+this.include_center+'&include=emergencyContact,address,memberships';
					this.http.getData(endpoint)
							 .subscribe(
										(data)=>{
												 this.biometricValue = data.data.attendee_id;
												 this.attendee_id = data.data.attendee_id;
										},
										(err)=>{
												 this.generalFunctions.openToast(err.message,3000,"error");
										},
										()=>{}
							 )
		 }

} 
