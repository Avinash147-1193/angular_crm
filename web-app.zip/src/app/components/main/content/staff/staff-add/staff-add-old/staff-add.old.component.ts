// import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
// import { Router, ActivatedRoute } from "@angular/router";
// import { Location } from "@angular/common";
// import { GeneralServices } from "../../../../../common/general-services";
// import { ServerAuthService } from "../../../../../common/server-auth";

// @Component({
//   templateUrl: "./staff-add.component.html",
//   styleUrls: ["./staff-add.component.css"]
// })
// export class StaffAddComponent implements OnInit, OnDestroy {
//   public maskXX = [
//     /[1-9]/,
//     /[x0-9]/,
//     /[x0-9]/,
//     "-",
//     /[x0-9]/,
//     /[x0-9]/,
//     /[x0-9]/,
//     "-",
//     /[x0-9]/,
//     /[x0-9]/,
//     /[0-9]/,
//     /[0-9]/
//   ];
//   public maskPhone = [
//     /[1-9]/,
//     /[0-9]/,
//     /[0-9]/,
//     "-",
//     /[0-9]/,
//     /[0-9]/,
//     /[0-9]/,
//     "-",
//     /[0-9]/,
//     /[0-9]/,
//     /[0-9]/,
//     /[0-9]/
//   ];

//   false: boolean = false;
//   true: boolean = true;
//   null: any = null;
//   include_center: any = null;
//   // loaderflags starts
//   heyLoader: boolean = false;
//   heyLoaderImage: boolean = false;
//   fileLoaded: any = null;
//   uploadFlag = false;
//   imagePreview: boolean = false;

//   // loaderflags ends
//   staff_data: any = {
//     phone: null,
//     phone_confirmation: null,
//     email: null,
//     first_name: null,
//     last_name: null,
//     gender: null,
//     date_of_birth: null,
//     address: {
//       pincode: null,
//       address: null,
//       city: null,
//       state: null
//     },
//     designation: "trainer",
//     login_access: false,
//     image_url: null,
//     role_id: null,
//     description: null,
//     type: "trainer"
//   };

//   roles_data: any = [];

//   webcam_initiate: boolean = false;
//   photo_selected: boolean = false;
//   photo_captured: boolean = false;

//   isCameraAdapted: boolean = true;
//   videoStream: any = null;

//   @ViewChild("video") video;
//   @ViewChild("canvas") canvas;
//   @ViewChild("photo_tag") photo_tag;

//   @ViewChild("selected_image") selected_image;

//   @ViewChild("phone") phone;
//   @ViewChild("phone_confirmation") phone_confirmation;
//   @ViewChild("gender_container") gender_container;

//   @ViewChild("first_name") first_name;
//   @ViewChild("last_name") last_name;
//   @ViewChild("email") email;

//   @ViewChild("staff_city") staff_city;
//   @ViewChild("staff_state") staff_state;

//   @ViewChild("submit_button") submit_button;
//   @ViewChild("ajax_sreen") ajax_sreen;

//   constructor(
//     private location: Location,
//     private generalFunctions: GeneralServices,
//     private http: ServerAuthService,
//     private router: Router,
//     private route: ActivatedRoute
//   ) {}

//   ngOnInit() {
//     this.include_center = this.generalFunctions.includeCenter();
//     this.getRoles();
//   }

//   ngOnDestroy() {}

//   // ngOnDestroy(){
//   // 	this.stopWebcam();
//   // }

//   isFilled(e) {
//     this.generalFunctions.isFilled(e);
//   }

//   toggleCustomTicTac(e) {
//     this.generalFunctions.toggleCustomTicTac(e);
//   }

//   autoIncreaseSize(e) {
//     var textarea = e.target,
//       height = textarea.offsetHeight;
//     textarea.style.height = "16px";
//     textarea.style.height = textarea.scrollHeight + "px";
//     textarea.style.maxHeight = textarea.scrollHeight + "px";
//     this.isFilled(e);
//   }

//   contentScroll(e) {
//     // this.generalFunctions.breadcrumbToggle(e);
//   }

//   routeBack() {
//     this.location.back();
//   }

//   getLocation(e) {
//     this.generalFunctions.isFilled(e);
//     if (e.target.classList.contains("ng-valid")) {
//       var pin = this.staff_data.address.pincode;
//       this.http.getLocation(pin).subscribe(success => {
//         this.staff_data.address.city = success.city;
//         this.staff_data.address.state = success.state;
//         setTimeout(() => {
//           this.staff_city.nativeElement.dispatchEvent(new Event("keyup"));
//           this.staff_state.nativeElement.dispatchEvent(new Event("keyup"));
//         }, 200);
//       });
//     }
//   }

//   getRoles() {
//     this.http.getData("roles" + this.include_center).subscribe(success => {
//       success = success;
//       this.roles_data = success.data;
//       this.staff_data.role_id = this.roles_data.id;
//     });
//   }

//   imageClick(event) {
//     document.getElementById("imageInput").click();
//   }

//   fileUpload(event) {
//     console.log(event);

//     if (event.target.files && event.target.files[0]) {
//       let msg;
//       const file = event.target.files[0];
//       console.log(event.target.files);
//       const fileType = file.type.split("/");
//       this.heyLoaderImage = true;

//       const uploadData = new FormData();
//       uploadData.append("image", file);
//       uploadData.append("type", "plans");
//       console.log(uploadData);

//       this.http
//         .sendFormData(`image${this.include_center}`, uploadData)
//         .subscribe(
//           response => {
//             this.heyLoaderImage = false;

//             this.staff_data.image_url = response.url;
//           },
//           error => {
//             this.generalFunctions.openToast(error, 3000, "error");
//           }
//         );

//       this.fileLoaded = "File uploaded";
//       this.uploadFlag = true;

//       this.imagePreview = true;
//     }
//   }

//   // openPhotoPopup(){
//   // 	this.webcam_initiate=true;
//   // 	let width = 400;
//   // 	let height = 400;
//   // 	setTimeout(()=>{
//   // 		navigator.mediaDevices.getUserMedia({ video: true, audio: false })
//   // 			.then((stream)=>{
//   // 				this.video.nativeElement.srcObject = stream;
//   // 				this.videoStream = stream;
//   // 				this.video.nativeElement.play();
//   // 			})
//   // 			.catch((err)=>{
//   // 				this.isCameraAdapted = false;
//   //        	 	});
//   // 		if(this.video){
//   // 			this.video.nativeElement.addEventListener('canplay', (e)=>{
//   // 				// height = this.video.nativeElement.videoHeight / (this.video.nativeElement.videoWidth/width);
//   // 	              	height = width;
//   // 	               if (isNaN(height)) {
//   // 					height = width;
//   // 				}

//   // 	               this.video.nativeElement.setAttribute('width', width);
//   // 		          this.video.nativeElement.setAttribute('height', height);
//   // 	          }, false);
//   // 		}
//   //       },200)
//   // }

//   // takePicture(){
//   // 	var context = this.canvas.nativeElement.getContext('2d');
//   // 	this.canvas.nativeElement.width = 400;
//   // 	this.canvas.nativeElement.height = 400;
//   // 	context.drawImage(this.video.nativeElement, -66.66, 0, 533.33, 400);

//   // 	var data = this.canvas.nativeElement.toDataURL('image/png');
//   // 	this.photo_tag.nativeElement.setAttribute('src', data);
//   // 	this.photo_captured = true;
//   // }

//   // selectPicture(){
//   // 	var src= this.photo_tag.nativeElement.getAttribute('src');

//   // 	var context = this.canvas.nativeElement.getContext('2d');
//   // 	context.fillStyle = "#AAA";
//   // 	context.fillRect(0, 0, 0, 0);
//   // 	var data = this.canvas.nativeElement.toDataURL('image/png');
//   // 	this.photo_tag.nativeElement.removeAttribute('src');
//   // 	this.photo_captured = false;
//   // 	this.photo_selected = true;

//   // 	this.stopWebcam();

//   // 	setTimeout(()=>{
//   // 		this.selected_image.nativeElement.setAttribute('src', src);
//   // 		this.staff_data.img_data = src;
//   // 	},300)
//   // }

//   // changePicture(){
//   // 	var context = this.canvas.nativeElement.getContext('2d');
//   // 	context.fillStyle = "#AAA";
//   // 	context.fillRect(0, 0, 0, 0);

//   // 	var data = this.canvas.nativeElement.toDataURL('image/png');
//   // 	this.photo_tag.nativeElement.removeAttribute('src');
//   // 	this.photo_captured = false;
//   // }

//   // stopWebcam(){
//   // 	if(this.videoStream){
//   // 		this.videoStream.getTracks()[0].stop();
//   // 	}
//   // 	this.webcam_initiate=false;
//   // }

//   addNewStaff(form, e) {
//     if (!form.valid) {
//       e.target.classList.add("submit-false");
//       this.generalFunctions.openToast(
//         "Kindly, enter valid values!",
//         2000,
//         "error"
//       );
//       return false;
//     } else {
//       e.target.classList.remove("submit-false");
//     }
    

//     // SEND DATA AND REDIRECT TO POS
//     var clone = Object.assign({}, this.staff_data),
//       obj = clone;
//     var dob = obj.date_of_birth,
//       msg = null;

//     if (dob) {
//       dob = this.generalFunctions.convertDateToISOFormat(dob);
//       obj.date_of_birth = dob["date"];
//     } else {
//       msg = "Enter valid date of birth";
//     }

//     if (!obj.phone) {
//       msg = "Kindly, enter the phone no.";
//     }

//     if (!obj.gender) {
//       msg = "Kindly, select gender.";
//     }

//     if (!obj.phone_confirmation) {
//       msg = "Kindly, confirm the phone no.";
//     }

//     if (obj.phone != obj.phone_confirmation) {
//       msg = "Kindly, match the phone nos.";
//     }

//     if (msg) {
//       this.generalFunctions.openToast(msg, 3000, "error");
//       return false;
//     }

//     if (!obj.login_access) {
//       delete obj["role_id"];
//     } else {
//       obj["role_id"] = obj["role_id"];
//     }

//     obj.phone = parseInt(obj.phone);
//     obj.phone_confirmation = parseInt(obj.phone_confirmation);
//     obj.image_url =
//       "https://s3.us-east-2.amazonaws.com/fitdaybucket/centers/6058829f-b0b8-4033-822b-ff48bd7343ce/plans/KgpcuX.jpg";
//     this.ajax_sreen.nativeElement.classList.add("active");
//     this.submit_button.nativeElement.classList.add("loading-ajax");

//     this.http.sendData("staff" + this.include_center, obj).subscribe(
//       success => {
//         this.ajax_sreen.nativeElement.classList.remove("active");
//         this.submit_button.nativeElement.classList.remove("loading-ajax");
//         this.generalFunctions.openToast(
//           "Staff added successfully!",
//           3000,
//           "success"
//         );
//         this.router.navigate(["../"], {
//           queryParams: {},
//           relativeTo: this.route
//         });
//       },
//       error => {
//         error.type == undefined
//           ? this.generalFunctions.openToast(
//               "Phone number is already taken",
//               3000,
//               "error"
//             )
//           : this.generalFunctions.openToast(
//               "select different staff type",
//               3000,
//               "error"
//             );

//         this.ajax_sreen.nativeElement.classList.remove("active");
//         this.submit_button.nativeElement.classList.remove("loading-ajax");
//       }
//     );
//   }

//   parseDate(date) {
//     var d = new Date(date);
//     return d;
//   }

//   phoneEdit(e) {
//     this.isFilled(e);
//     //Validate input values
//     var el = e.target;
//     var val = el.value;
//     val = val.replace(/[_-]/g, "").toString();
//     var len = val.length;

//     len < 10 && len > 0
//       ? el.classList.add("invalid")
//       : el.classList.remove("invalid");

//     if (len == 1) {
//       this.staff_data.phone = val;
//       return false;
//     }

//     var posX = e.target.selectionStart; //cursor position
//     var code = e.keyCode || e.charCode || e.which;

//     //current model value
//     var t = this.staff_data.phone ? this.staff_data.phone.toString() : "";
//     //Based on input value charcode, change the ngModel values
//     if (posX > 3) {
//       posX -= 1;
//     }
//     if (posX > 6) {
//       posX -= 1;
//     }

//     if (code >= 48 && code <= 57 && t.length < 10) {
//       //Numerical values
//       t = [t.slice(0, posX), String.fromCharCode(code), t.slice(posX)].join("");
//     } else if (code == 8 && t.length < 11) {
//       //Backspace
//       t = [t.slice(0, posX), t.slice(posX + 1)].join("");
//     } else if (code == 46 && t.length < 11) {
//       //Delete
//       t = [t.slice(0, posX + 1), t.slice(posX + 2)].join("");
//     } else if (code == 88 && t.length < 11) {
//       //character 'x'
//       return false;
//     }

//     this.staff_data.phone = t;

//     //Mask the input values based on its length
//     var editedValue;
//     switch (val.length) {
//       case 2:
//         editedValue = val[0] + "x_-___-____";
//         break;
//       case 3:
//         editedValue = val[0] + "xx-___-____";
//         break;
//       case 4:
//         editedValue = val[0] + "xx-x__-____";
//         break;
//       case 5:
//         editedValue = val[0] + "xx-xx_-____";
//         break;
//       case 6:
//         editedValue = val[0] + "xx-xxx-____";
//         break;
//       case 7:
//         editedValue = val[0] + "xx-xxx-x___";
//         break;
//       case 8:
//         editedValue = val[0] + "xx-xxx-xx__";
//         break;
//       case 9:
//         editedValue = val[0] + "xx-xxx-xx" + val[8] + "_";
//         break;
//       case 10:
//         editedValue = val[0] + "xx-xxx-xx" + val[8] + val[9];
//         break;
//     }

//     editedValue ? (e.target.value = editedValue) : "";

//     var size = val.length;
//     if (size > 3) {
//       size += 1;
//     }
//     if (size > 6) {
//       size += 1;
//     }

//     //Move cursor to last character position
//     e.target.selectionStart = size;
//     e.target.selectionEnd = size;
//     if ((code == 8 && size == 4) || (code == 8 && size == 8)) {
//       e.target.selectionStart = size - 1;
//       e.target.selectionEnd = size - 1;
//     }
//   }

//   phoneConfirmedEdit(e) {
//     this.isFilled(e);
//     var el = e.target;
//     var val = e.target.value;
//     var len = val.length;
//     val = val.replace(/[_-]/g, "");
//     this.staff_data.phone_confirmation = val;
//     this.staff_data.phone = val;
//     len < 10 && len > 0
//       ? el.classList.add("invalid")
//       : el.classList.remove("invalid");

//     var i = this.staff_data.phone,
//       j = this.staff_data.phone_confirmation;

//     if (val.length == 10) {
//       var msg = "Match the phone no!";
//       i != j ? this.generalFunctions.openToast(msg, 2000, "error") : "";
//     }
//   }
// }
