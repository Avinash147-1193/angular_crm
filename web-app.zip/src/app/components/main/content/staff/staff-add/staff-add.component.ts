import {Component, OnInit, ViewChild, OnDestroy} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import {
    SelectItem
} from 'primeng/api';
import {
    COUNTRIES
} from '../../../../../countries';
import {
    CODES
} from '../../../../../phonecodes';
import { isNull } from 'util';

@Component({templateUrl: './staff-add.component.html', styleUrls: ['./staff-add.component.scss']})
export class StaffAddComponent implements OnInit {

  totalRoles: any;
  false: boolean = false;
  true: boolean = true;
  null: any = null;
  include_center: any = null;
  // loaderflags starts
  heyLoader: boolean = false;
  heyLoaderImage: boolean = false;
  accessDropdownPopulated: boolean = false;
  accessValue: boolean = false;
  fileLoaded: any = null;
  uploadFlag = false;
  imagePreview: boolean = false;
  noImage: any = false;

  // loaderflags ends
  staff_data: any = {
    phone: '',
    phone_confirmation: '',
    email: '',
    first_name: '',
    last_name: '',
    gender: '',
    date_of_birth: '',
    phone_prefix:'',
    address: {
      pincode: '',
      city: '',
      state: '',
      address_line_1: '',
      country:''
    },
    login_access: false,
    image_url: null,
    role_id: '',
    description: null,
    designation: 'trainer',
    type: ''
  };
  validationCheck: boolean = false;
  validationFields: any = {
    staff_email: false,
    staff_phone: false,
    staff_fname: false,
    staff_lname: false,
    customer_gender: false,
    staff_role: false,
    customer_dob: false,
    customer_address: false,
    customer_city: false,
    customer_state: false,
    customer_pincode: false,
    staff_type: false
  };
  checkValidation: boolean = false;

  dobDatepickerConfig = {
    showWeekNumbers: false,
    maxDate: new Date(),
    containerClass: 'theme-default'
  };

  roles_data: any = [];

  webcam_initiate: boolean = false;
  photo_selected: boolean = false;
  photo_captured: boolean = false;

  isCameraAdapted: boolean = true;
  videoStream: any = null;
  editStaff: boolean = false;
  editStaffId: any;

  @ViewChild('video')video;
  @ViewChild('canvas')canvas;
  @ViewChild('photo_tag')photo_tag;

  @ViewChild('selected_image')selected_image;

  @ViewChild('phone')phone;
  @ViewChild('phone_confirmation')phone_confirmation;
  @ViewChild('gender_container')gender_container;

  @ViewChild('first_name')first_name;
  @ViewChild('last_name')last_name;
  @ViewChild('email')email;

  @ViewChild('staff_city')staff_city;
  @ViewChild('staff_state')staff_state;

  @ViewChild('submit_button')submit_button;
  @ViewChild('ajax_sreen')ajax_sreen;

  accessDropdown: any = [];

  emailCheckLoader: boolean = true;
  checkExisting: boolean = false;
  checkLoader: boolean = false;
  existingType: any = '3';
  foundCenter: any;

  countryCodesDropdown: SelectItem[] = [];
  countriesDropdown: SelectItem[] = [];

  countries: any = COUNTRIES;
  codes: any = CODES;
  onceLoaded = false;

  constructor(private location: Location,
    private generalFunctions: GeneralServices,
    private http: ServerAuthService,
    private router: Router,
    private route: ActivatedRoute,
    private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getRoles();

    if (this.router.url.includes('staff/edit')) {
      this.editStaff = true;
      let id = this.activatedRoute.snapshot.paramMap.get('id');
      this.editStaffId = id;
      this.emailCheckLoader = false;
      this.getStaff(id);
    }

    this.prepareCountriesDropdown();
  }


  prepareCountriesDropdown() {
    for (let i = 0; i < this.countries.length; i++) {
        let country = {
            label: '',
            value: 0
        };
        // country name
        country.label = this.countries[i].name;
        country.value = this.countries[i].id;
        this.countriesDropdown.push(country);
    }

    for (let i = 0; i < this.codes.length; i++) {
        let code = {
            label: '',
            value: 0
        };
        // country code
        code.label = this.codes[i].isd_code;
        code.value = this.codes[i].id;
        this.countryCodesDropdown.push(code);
    }
        if (!this.editStaff) {
            const localization = JSON.parse(localStorage.getItem('localization'));
            this.staff_data.phone_prefix = String( localization.country.isd_code);
            this.staff_data.address.country = String( localization.country.name);
        }
        setTimeout(() => {
            this.onceLoaded = true;
        }, 1);
    }


  getStaff(id) {
    this.http.getData('staff/' + id + '/' + this.include_center).subscribe(success => {
      success = success;
      this.staff_data.phone = success.data.phone;
      this.staff_data.email = success.data.email;
      this.staff_data.first_name = success.data.first_name;
      this.staff_data.last_name = success.data.last_name ? success.data.last_name : '';
      this.staff_data.gender = success.data.gender;
      this.staff_data.date_of_birth = new Date(success.data.date_of_birth);
      this.staff_data.address.pincode = success.data.address.pincode;
      this.staff_data.address.address_line_1 = success.data.address.address_line_1;
      this.staff_data.address.city = success.data.address.city;
      this.staff_data.address.state = success.data.address.state;
      this.staff_data.login_access = success.data.login_access;
      this.staff_data.image_url = success.data.image_url;
      this.staff_data.role_id = success.data.role_id;

      this.staff_data.phone_prefix = success.data.phone_prefix;
      this.staff_data.address.country = success.data.address.country;



      this.staff_data.description = success.data.description;
      this.staff_data.designation = success.data.designation;
      this.staff_data.type = success.data.type;

      if (success.data.is_owner == 1) {
        this.staff_data.is_owner = 1;
        this.staff_data.role_id = null;
      } else {
        this.staff_data.is_owner = 2;
      }
    });
  }

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  toggleCustomTicTac(e) {
    this.generalFunctions.toggleCustomTicTac(e);
  }

  autoIncreaseSize(e) {
    var textarea = e.target,
    height = textarea.offsetHeight;
    textarea.style.height = '16px';
    textarea.style.height = textarea.scrollHeight + 'px';
    textarea.style.maxHeight = textarea.scrollHeight + 'px';
    this.isFilled(e);
  }

  contentScroll(e) {
    // this.generalFunctions.breadcrumbToggle(e);
  }

  routeBack() {
    this.location.back();
  }

  getLocation(e) {
    this.generalFunctions.isFilled(e);
    if (e.target.classList.contains('ng-valid')) {
      var pin = this.staff_data.address.pincode;
      this.http.getLocation(pin).subscribe(success => {
        this.staff_data.address.city = success.city;
        this.staff_data.address.state = success.state;
        setTimeout(() => {
          this.staff_city.nativeElement.dispatchEvent(new Event('keyup'));
          this.staff_state.nativeElement.dispatchEvent(new Event('keyup'));
        }, 200);
      });
    }
  }

  getRoles() {
    this.http.getData('roles' + this.include_center).subscribe(success => {
      success = success;
      this.roles_data = success.data;
      if (!this.editStaff) {
        this.roles_data.forEach(role => {
          if (role.name == 'trainer') {
            this.staff_data.role_id = role.id;
          }
        });
      }
      this.totalRoles = success.meta.pagination.total;
      this.prepareAccess();

      if (this.editStaff) {
        this.accessValue = true;
      }
    });
  }

  prepareAccess() {
    for (let i = 0; i < this.totalRoles; i++) {
      let category = {
        label: '',
        value: 0
      };
      category.label = this.roles_data[i].name !== 'trainer' ?  this.roles_data[i].name : 'instructor';
      category.value = this.roles_data[i].id;
      this.accessDropdown.push(category);
    }
    this.accessDropdownPopulated = true;
  }

  mapImageUrl(event) {
    this.staff_data.image_url = event;
  }
  // removeFile() {
  //   console.log("check if clicked");
  //   this.staff_data.image_url = null;
  //   this.staff_data.image_url = null;
  //   this.noImage = true;
  // }
  // imageClick(event) {
  //   document.getElementById("imageInput").click();
  // }

  // fileUpload(event) {
  //   console.log(event);

  //   if (event.target.files && event.target.files[0]) {
  //     let msg;
  //     const file = event.target.files[0];
  //     console.log(event.target.files);
  //     const fileType = file.type.split("/");
  //     this.heyLoaderImage = true;

  //     const uploadData = new FormData();
  //     uploadData.append("image", file);
  //     uploadData.append("type", "plans");
  //     console.log(uploadData);

  //     this.http
  //       .sendFormData(`image${this.include_center}`, uploadData)
  //       .subscribe(
  //         response => {
  //           this.heyLoaderImage = false;

  //           this.staff_data.image_url = response.url;
  //         },
  //         error => {
  //           this.generalFunctions.openToast(error.message, 3000, "error");
  //         }
  //       );

  //     this.fileLoaded = "File uploaded";
  //     this.uploadFlag = true;
  //     this.imagePreview = true;
  //   }
  // }

  // openPhotoPopup(){
  // 	this.webcam_initiate=true;
  // 	let width = 400;
  // 	let height = 400;
  // 	setTimeout(()=>{
  // 		navigator.mediaDevices.getUserMedia({ video: true, audio: false })
  // 			.then((stream)=>{
  // 				this.video.nativeElement.srcObject = stream;
  // 				this.videoStream = stream;
  // 				this.video.nativeElement.play();
  // 			})
  // 			.catch((err)=>{
  // 				this.isCameraAdapted = false;
  //        	 	});
  // 		if(this.video){
  // 			this.video.nativeElement.addEventListener('canplay', (e)=>{
  // 			  height = this.video.nativeElement.videoHeight / (this.video.nativeElement.videoWidth/width);
  // 	              	height = width;
  // 	               if (isNaN(height)) {
  // 					height = width;
  // 				}

  // 	               this.video.nativeElement.setAttribute('width', width);
  // 		          this.video.nativeElement.setAttribute('height', height);
  // 	          }, false);
  // 		}
  //       },200)
  // }

  // takePicture(){
  // 	var context = this.canvas.nativeElement.getContext('2d');
  // 	this.canvas.nativeElement.width = 400;
  // 	this.canvas.nativeElement.height = 400;
  // 	context.drawImage(this.video.nativeElement, -66.66, 0, 533.33, 400);

  // 	var data = this.canvas.nativeElement.toDataURL('image/png');
  // 	this.photo_tag.nativeElement.setAttribute('src', data);
  // 	this.photo_captured = true;
  // }

  // selectPicture(){
  // 	var src= this.photo_tag.nativeElement.getAttribute('src');

  // 	var context = this.canvas.nativeElement.getContext('2d');
  // 	context.fillStyle = "#AAA";
  // 	context.fillRect(0, 0, 0, 0);
  // 	var data = this.canvas.nativeElement.toDataURL('image/png');
  // 	this.photo_tag.nativeElement.removeAttribute('src');
  // 	this.photo_captured = false;
  // 	this.photo_selected = true;

  // 	this.stopWebcam();

  // 	setTimeout(()=>{
  // 		this.selected_image.nativeElement.setAttribute('src', src);
  // 		this.staff_data.img_data = src;
  // 	},300)
  // }

  // changePicture(){
  // 	var context = this.canvas.nativeElement.getContext('2d');
  // 	context.fillStyle = "#AAA";
  // 	context.fillRect(0, 0, 0, 0);

  // 	var data = this.canvas.nativeElement.toDataURL('image/png');
  // 	this.photo_tag.nativeElement.removeAttribute('src');
  // 	this.photo_captured = false;
  // }

  // stopWebcam(){
  // 	if(this.videoStream){
  // 		this.videoStream.getTracks()[0].stop();
  // 	}
  // 	this.webcam_initiate=false;
  // }

  addNewStaff() {
    this.checkValidation = true;

    if (!(this.validationFields.staff_fname && this.validationFields.staff_phone && this.validationFields.staff_email && this.validationFields.customer_address && this.validationFields.customer_city && this.validationFields.customer_state && this.validationFields.customer_pincode && this.validationFields.customer_gender && this.validationFields.customer_dob && this.validationFields.staff_type)) {
      this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
      return;
    }
    // SEND DATA AND REDIRECT TO POS
    var clone = Object.assign({}, this.staff_data),
      obj = clone;
    var dob = obj.date_of_birth,
      msg = null;

    if (dob) {
      dob = this.generalFunctions.convertDateToISOFormat(dob);
      obj.date_of_birth = dob['date'];
    } else {
      msg = 'Enter valid date of birth';
    }

    if (!obj.phone) {
      msg = 'Kindly, enter the phone no.';
    }

    if (!obj.gender) {
      msg = 'Kindly, select gender.';
    }
    // if (!obj.address.address) {
    //   msg = "Kindly, select address.";
    // }
    // if (!obj.address.city) {
    //   msg = "Kindly, select city.";
    // }
    // if (!obj.address.state) {
    //   msg = "Kindly, select state.";
    // }

    // if (!obj.address.pincode) {
    //   msg = "Kindly, select pincode.";
    // }

    if (!obj.type) {
      msg = 'Kindly, select a valid staff type.';
    }

    // if (!obj.phone_confirmation) {
    //   msg = "Kindly, confirm the phone no.";
    // }

    // if (obj.phone != obj.phone_confirmation) {
    //   msg = "Kindly, match the phone nos.";
    // }

    if (msg) {
      this.generalFunctions.openToast(msg, 3000, 'error');
      return false;
    }

    if (!obj.login_access) {
      delete obj['role_id'];
    } else {
      obj['role_id'] = obj['role_id'];
    }

    obj.phone = parseInt(obj.phone);
    obj.phone_confirmation = parseInt(obj.phone_confirmation);
    // this.ajax_sreen.nativeElement.classList.add("active");
    // this.submit_button.nativeElement.classList.add("loading-ajax");

    if (this.editStaff) {
      obj.address.zipcode = obj.address.pincode;
      if (obj.login_access == false) {
        obj.role_id = null;
        delete obj['roleid'];
        delete obj['role_value'];
        delete obj['role_id'];
      } else {
        console.log('isNull(obj.role_id)', isNull(obj.role_id))

          if(isNull(obj.role_id)){
            obj.role_id = this.accessDropdown[0].value
            console.log('this.staff_data.role_id', this.staff_data.role_id)
          }
      }

      this.http.updateData('staff/' + this.editStaffId + this.include_center, obj).subscribe(success => {
        this.generalFunctions.openToast('Staff updated successfully!', 3000, 'success');
        this.staff_data = success.data;
        this.router.navigate(['../../'], {
          queryParams: {},
          relativeTo: this.route
        });
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
      });
    } else {
      let address_line_1 = obj.address.address_line_1;
      let city = obj.address.city;
      let state = obj.address.state;
      let pincode = obj.address.pincode;

      if (obj.address) {
        delete obj['address'];
      }

      let reqObj = Object.assign({
        address_line_1: address_line_1,
        city: city,
        state: state,
        zipcode: pincode
      }, obj);

      if (reqObj.login_access == true) {
        if (isNull(reqObj.role_id)) {
            reqObj.role_id = this.accessDropdown[0].value
          }
      }

      this.http.sendData('staff' + this.include_center, reqObj).subscribe(success => {
        this.generalFunctions.openToast('Staff added successfully!', 3000, 'success');
        this.router.navigate(['../'], {
          queryParams: {},
          relativeTo: this.route
        });
      }, error => {
        error.type == undefined
          ? this.generalFunctions.openToast('Email or phone number is already taken', 3000, 'error')
          : this.generalFunctions.openToast('select different staff type', 3000, 'error');

        this.ajax_sreen.nativeElement.classList.remove('active');
        this.submit_button.nativeElement.classList.remove('loading-ajax');
      });
    }
  }

  parseDate(date) {
    var d = new Date(date);
    return d;
  }

  phoneEdit(e) {
    this.isFilled(e);
    //Validate input values
    var el = e.target;
    var val = el.value;
    val = val.replace(/[_-]/g, '').toString();
    var len = val.length;

    len < 10 && len > 0
      ? el.classList.add('invalid')
      : el.classList.remove('invalid');

    if (len == 1) {
      this.staff_data.phone = val;
      return false;
    }

    var posX = e.target.selectionStart; //cursor position
    var code = e.keyCode || e.charCode || e.which;

    //current model value
    var t = this.staff_data.phone
      ? this.staff_data.phone.toString()
      : '';
    //Based on input value charcode, change the ngModel values
    if (posX > 3) {
      posX -= 1;
    }
    if (posX > 6) {
      posX -= 1;
    }

    if (code >= 48 && code <= 57 && t.length < 10) {
      //Numerical values
      t = [
        t.slice(0, posX),
        String.fromCharCode(code),
        t.slice(posX)
      ].join('');
    } else if (code == 8 && t.length < 11) {
      //Backspace
      t = [
        t.slice(0, posX),
        t.slice(posX + 1)
      ].join('');
    } else if (code == 46 && t.length < 11) {
      //Delete
      t = [
        t.slice(0, posX + 1),
        t.slice(posX + 2)
      ].join('');
    } else if (code == 88 && t.length < 11) {
      //character 'x'
      return false;
    }

    this.staff_data.phone = t;

    //Mask the input values based on its length
    var editedValue;
    switch (val.length) {
      case 2:
        editedValue = val[0] + 'x_-___-____';
        break;
      case 3:
        editedValue = val[0] + 'xx-___-____';
        break;
      case 4:
        editedValue = val[0] + 'xx-x__-____';
        break;
      case 5:
        editedValue = val[0] + 'xx-xx_-____';
        break;
      case 6:
        editedValue = val[0] + 'xx-xxx-____';
        break;
      case 7:
        editedValue = val[0] + 'xx-xxx-x___';
        break;
      case 8:
        editedValue = val[0] + 'xx-xxx-xx__';
        break;
      case 9:
        editedValue = val[0] + 'xx-xxx-xx' + val[8] + '_';
        break;
      case 10:
        editedValue = val[0] + 'xx-xxx-xx' + val[8] + val[9];
        break;
    }

    editedValue
      ? (e.target.value = editedValue)
      : '';

    var size = val.length;
    if (size > 3) {
      size += 1;
    }
    if (size > 6) {
      size += 1;
    }

    //Move cursor to last character position
    e.target.selectionStart = size;
    e.target.selectionEnd = size;
    if ((code == 8 && size == 4) || (code == 8 && size == 8)) {
      e.target.selectionStart = size - 1;
      e.target.selectionEnd = size - 1;
    }
  }

  phoneConfirmedEdit(e) {
    this.isFilled(e);
    var el = e.target;
    var val = e.target.value;
    var len = val.length;
    val = val.replace(/[_-]/g, '');
    this.staff_data.phone_confirmation = val;
    this.staff_data.phone = val;
    len < 10 && len > 0
      ? el.classList.add('invalid')
      : el.classList.remove('invalid');

    var i = this.staff_data.phone,
      j = this.staff_data.phone_confirmation;

    if (val.length == 10) {
      var msg = 'Match the phone no!';
      i != j
        ? this.generalFunctions.openToast(msg, 2000, 'error')
        : '';
    }
  }

  checkEmail() {
    let validation = !this.staff_data.email.replace(/\s/g, '').length || !this.validateEmail(this.staff_data.email)
      ? false
      : true;
    validation
      ? this.getEmailData()
      : (this.checkLoader = false);
  }

  getEmailData() {
    this.checkLoader = true;

    setTimeout(() => {
      this.getStaffData();
    }, 1200);
  }

  getStaffData() {
    this.http.getData('clients/staff' + this.include_center + '&email=' + encodeURIComponent(this.staff_data.email)).subscribe(success => {
      success = success.staff;
      this.checkLoader = false;

      if (!success['first_name']) {
        this.checkExisting = false;
        this.emailCheckLoader = false;
        this.existingType = '3';

        this.staff_data.first_name = '';
        this.staff_data.last_name = '';
        this.staff_data.id = '';
        this.staff_data.type = '';
        this.staff_data.phone = '';
        return;
      }

      this.staff_data.first_name = success.first_name;
      this.staff_data.last_name = success.last_name;
      this.staff_data.id = success.id;
      this.staff_data.type = success.centers[0].pivot.type;
      this.staff_data.phone = success.phone;
      this.existingType = '2';

      success.centers.forEach(center => {
        if (center.uuid == JSON.parse(localStorage.getItem('currentUser')).center_id) {
          this.existingType = '1';
          this.getRegions(center.uuid);
        }
      });

      if (this.existingType == 2) {
        this.getRegions(success.centers[0].uuid);
      }
    });

    this.checkExisting = true;
    this.emailCheckLoader = true;
  }

  getRegions(id) {
    let centerFound;
    this.http.getData('regions').subscribe(success => {
      success.forEach(element => {
        element.centers.forEach(center => {
          if (center.uuid == id) {
            centerFound = center;
            this.foundCenter = centerFound;
          }
        });
      });
    }, error => {});
  }

  addExisting() {
    this.http.sendData('staff' + this.include_center, {user_id: this.staff_data.id}).subscribe(success => {
      this.generalFunctions.openToast('Staff added successfully!', 3000, 'success');
      this.router.navigate(['../'], {
        queryParams: {},
        relativeTo: this.route
      });
    }, error => {
      this.generalFunctions.openToast('Error adding staff', 3000, 'error');
    });
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
      case 'staff-email':
        isValid = !this.staff_data.email.replace(/\s/g, '').length || !this.validateEmail(this.staff_data.email)
          ? false
          : true;
        this.validationFields.staff_email = isValid;

        break;

      case 'staff-phone':
        isValid = !this.validatePhone(this.staff_data.phone)
          ? false
          : true;
        this.validationFields.staff_phone = isValid;
        break;

      case 'staff-fname':
        isValid = !this.staff_data.first_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.staff_fname = isValid;
        break;

      case 'staff-lname':
        isValid = !this.staff_data.last_name.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.staff_lname = isValid;
        break;

      case 'customer-gender':
        isValid = !this.staff_data.gender.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_gender = isValid;
        break;

      case 'staff-role':
        isValid = !this.staff_data.role_id.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.staff_role = isValid;
        break;

      case 'staff-type':
        isValid = !this.staff_data.type.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.staff_type = isValid;
        break;

      case 'customer-dob':
        // isValid = (!this.staff_data.contact.date_of_birth.replace(/\s/g, '').length)  ? false : true;
        isValid = this.checkDob(this.staff_data.date_of_birth);

        this.validationFields.customer_dob = isValid;
        break;

      case 'customer-address':
        isValid = !this.staff_data.address.address_line_1.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_address = isValid;
        break;

      case 'customer-city':
        isValid = !this.staff_data.address.city.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_city = isValid;
        break;
      case 'customer-state':
        isValid = !this.staff_data.address.state.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_state = isValid;
        break;

      case 'customer-pincode':
        isValid = !this.staff_data.address.pincode.replace(/\s/g, '').length
          ? false
          : true;
        this.validationFields.customer_pincode = isValid;
        break;

      default:
        break;
    }
    return !isValid;
  }
  validateEmail(email) {
    var re = /\S+@\S+\.\S{2,}/;
    return re.test(email);
  }
  validatePhone(phone) {
    if (this.numberCounter(phone) < 7 || this.numberCounter(phone) > 10) {
      return false;
    } else
      return true;
      // else {
      //   var re = /\+?\d[\d -]{8,12}\d/;
      //   return re.test(phone);
      // }
    }

  numberCounter(n) {
    var count = 0;
    if (n >= 1)
      ++count;

    while (n / 10 >= 1) {
      n /= 10;
      ++count;
    }

    return count;
  }

  checkDob(date) {
    var timestamp = Date.parse(date);

    if (isNaN(timestamp) == false) {
      var d = new Date(timestamp);
      return true;
    } else {
      return false;
    }
  }
}
