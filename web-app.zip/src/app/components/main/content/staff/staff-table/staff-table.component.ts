import {Component, OnInit} from "@angular/core";
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";
import {elementAt} from "rxjs/operators";

@Component({templateUrl: "./staff-table.component.html", styleUrls: ["./staff-table.component.css"]})
export class StaffTableComponent implements OnInit {
  tab_id: any = "all";

  staff_data: any = null;
  search_staff_text: any;

  page_data_loaded: boolean = false;
  server_request: boolean = true;

  no_more_results: boolean = false;
  include_center: any = null;

  statuses_count: object = {
    total: 0,
    login_access: 0
  };

  params: any = {
    filterBy: {},
    sortBy: {},
    page: 1
  };

  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getFirstData();
  }

  // contentScroll(e) {
  //   this.generalFunctions.breadcrumbToggle(e);
  // 	var el = e.target;
  // 	var totalHeight = el.scrollHeight;
  // 	var scrolled = el.scrollTop;
  // 	var boxHeight = el.clientHeight;
  // 	if(this.no_more_results){
  // 		return false;
  // 	}
  // 	if((totalHeight-8) < (scrolled)+(boxHeight)){
  // 		this.loadMoreData();
  // 	}
  // }

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }

  getStatusesCount() {
    this.http.getData("staff/count" + this.include_center).subscribe(data => {
      this.statuses_count["total"] = data.total;
      data.data.forEach((item, index) => {
        this.statuses_count[item.status] = item.count;
      });
    }, error => {
      var msg = "Unable to fetch data!";
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {});
  }

  getFirstData() {
    this.staff_data = null;
    this.server_request = true;
    this.no_more_results = false;
    this.params["page"] = 1;
    // this.getStatusessCount();
    this.http.sendData("staff/search" + this.include_center, this.params).subscribe(success => {
      success = success;
      this.staff_data = success.data;
      let i = 0;
      this.staff_data.forEach(element => {
        i = i + 1;
      });
      this.staff_data["length"] = i;
      this.generateColor(this.staff_data);
    }, err => {
      var msg = err.message;
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {
      this.page_data_loaded = true;
      this.server_request = false;
    });
  }

  generateColor(id) {
    id.forEach((element, index) => {
      let colorCode = element.id % 10;
      this.staff_data[index].colorCode = colorCode;
    });
  }
  // loadMoreData(){
  // 	if(!this.no_more_results && !this.server_request){
  // 		this.server_request = true;
  //    	this.http.sendData("staff/search"+this.include_center, this.params)
  // 		 .subscribe(
  // 			(success)=>{
  // 			    success = success;
  // 			    this.staff_data = this.staff_data.concat(success.data);
  // 			    var currentPage = success.meta.pagination.current_page;
  // 			    var totalPages = success.meta.pagination.total_pages;
  // 			    if(currentPage == totalPages){
  // 				   this.no_more_results = true;
  // 				   this.params["page"] = 1;
  // 			    }else{
  // 				   this.params["page"] +=1;
  // 			    }
  // 			},
  // 			(error)=>{
  // 			    error = error;
  // 			    var msg = error.message;
  // 			    this.generalFunctions.openToast(msg,3000,"error");
  // 			},
  // 			()=>{
  // 			    this.server_request = false;
  // 			}
  // 		 )
  // 	}
  // }

  filterQuery(e) {
    this.generalFunctions.isFilled(e);
    if (e.target.value.length > 0) {
      this.params.filterBy.query = this.search_staff_text;
    } else {
      delete this.params.filterBy["query"];
    }
    this.getFirstData();
  }

  filterStatus(e) {
    var li = e.target.nodeName == "LI"
      ? e.target
      : e.target.parentElement;
    var sib = li.parentElement.children;
    Array.prototype.forEach.call(sib, (item, index) => {
      item.classList.remove("on");
    });
    li.classList.add("on");

    var status = li.getAttribute("data-status");
    this.params.filterBy["login_access"] = true;
    if (status == "none") {
      delete this.params.filterBy["login_access"];
    }

    this.getFirstData();
  }

  sortByColumn(e) {
    if (e.target.classList.contains("active")) {
      var x = e.target.getAttribute("data-column");
      if (e.target.classList.contains("asc")) {
        e.target.classList.remove("asc");
        e.target.classList.add("desc");
        this.params.sortBy[x] = "desc";
      } else if (e.target.classList.contains("desc")) {
        e.target.classList.remove("desc");
        e.target.classList.add("none");
        delete this.params.sortBy[x];
      } else if (e.target.classList.contains("none")) {
        e.target.classList.remove("none");
        e.target.classList.add("asc");
        this.params.sortBy[x] = "asc";
      }
    } else {
      this.params.sortBy = {};
      Array.prototype.forEach.call(e.target.parentElement.children, (item, index) => {
        item.classList.remove("active", "asc", "desc", "none");
      });
      e.target.classList.add("active", "asc");
      var x = e.target.getAttribute("data-column");
      this.params.sortBy[x] = "asc";
    }

    this.getFirstData();
  }
}
