import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaiverSettingsComponent } from './waiver-settings.component';

describe('WaiverSettingsComponent', () => {
  let component: WaiverSettingsComponent;
  let fixture: ComponentFixture<WaiverSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WaiverSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WaiverSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
