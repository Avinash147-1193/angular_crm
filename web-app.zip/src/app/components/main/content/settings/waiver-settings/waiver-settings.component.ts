import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {ServerAuthService} from '../../../../../common/server-auth';
import {GeneralServices} from '../../../../../common/general-services';

@Component({selector: 'app-waiver-settings', templateUrl: './waiver-settings.component.html', styleUrls: ['./waiver-settings.component.scss']})
export class WaiverSettingsComponent implements OnInit {
    include_center: any;
    updated_center_settings : any = {
      general: {
        liability_waiver: false
      }
    };
    center_settings: any;
    waiverText: any;
    waiverLink: any;
    waiverType: any;
    editMode = true;
    editLink = true;
    gotAll = false;
    waiver: any = {
        type : 'link',
        content : 'loreum'
    }

  constructor(private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private generalFunctions : GeneralServices) {}


  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getSettings();

    this.getCenterData();
  }

  getSettings() {
    this.http.getData('settings' + this.include_center).subscribe(success => {
      success = success;
      console.log('success', success);
      this.center_settings = this.updated_center_settings = success;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }
  getCenterData() {
    this.http.getData('center/' + this.include_center).subscribe(success => {
      this.waiverText = success.data[0].client.waiver_text;
      this.waiverLink = success.data[0].client.waiver_link;
      this.waiverType = success.data[0].client.waiver_type;
      this.waiverText == null
        ? (this.editMode = true)
        : (this.editMode = false);
        this.waiverLink == null ? this.editLink = true : this.editLink = false
      this.gotAll = true;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  updateWaiverText() {
    let reqObj = {};
    reqObj = {
      client : {
        waiver_text: this.waiverText
      }
    };
    console.log('reqObj', reqObj);
    this.http.patchData('center/' + this.include_center, reqObj).subscribe(success => {
      this.generalFunctions.openToast('Waiver text has been updated', 3000, 'success');

      this.editMode = false;
      this.editLink = false;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }

  updateWaiverLink() {
    let reqObj = {};
    reqObj = {
      client :  {
        waiver_link: this.waiverLink
      }
    };
    console.log('reqObj', reqObj);
    this.http.patchData('center/' + this.include_center, reqObj).subscribe(success => {
      this.generalFunctions.openToast('Waiver link has been updated', 3000, 'success');

      this.editMode = false;
      this.editLink = false;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });
  }


  updateType() {
    let reqObj = {};
    reqObj = {
      client : {
        waiver_type: this.waiverType
      }
    };
    console.log('reqObj', reqObj);
    this.http.patchData('center/' + this.include_center, reqObj).subscribe(success => {
      this.generalFunctions.openToast('Waiver type has been updated', 3000, 'success');

    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
    });

  }

  updateSettings(endpoint, value, name) {
    var obj = {};
    obj['value'] = value;
    this.http.patchData('settings/' + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + ' settings updated', 3000, 'success');
      this.setValue('a', endpoint, value);
      this.getCenterData();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

  setValue(i, endpoint, value) {
    endpoint = endpoint.split('.');
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }
}
