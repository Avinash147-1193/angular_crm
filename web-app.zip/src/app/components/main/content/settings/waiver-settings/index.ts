export * from "./waiver-settings.component";
