import {Component, OnInit, ViewEncapsulation} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";

@Component({selector: "app-business-settings", templateUrl: "./business-settings.component.html", styleUrls: ["./business-settings.component.scss"], encapsulation: ViewEncapsulation.None})
export class BusinessSettingsComponent implements OnInit {
  tab_id: any;

  include_center: any = null;
  addEmail: boolean = false;
  centerId: string = "";
  noEmail: boolean;
  sender_id: any;
  pop_up_for: any;
  validationCheck: boolean = false;
  validationFields: any = {
    customer_email: false,
    contact_number: false,
    business_email: false,
    from_name: false,
    reply_to: false,
    customer_fid: false
  };
  email_delete: any;

  basicDetails: any = {
    branch: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    country: "",
    currency: "",
    timezon: "",
    timezone_name: "",
    phone: "",
    client: {
      name: "",
      email: "",
      contact_name: "",
      phone: "",
      sender_id: null
    }
  };
  updateEmail: any = {
    email: "",
    from_name: "",
    reply_to: ""
  };
  is_disabled: boolean;
  center_id: any;
  show_sender_id: boolean;
  rechecking: boolean = false;
  checker: boolean = false;
  center_settings: any;
  updated_center_settings: any;
  sms_enabled: any;
    addingEmail: boolean = false;

  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {
    this.tab_id = "detail";
    this.include_center = this.generalFunctions.includeCenter();

    // this.basicDetails.client.sender_id = null;
    this.center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    this.basicDetails.currency = JSON.parse(localStorage.getItem("localization")).currency.name + " , " + JSON.parse(localStorage.getItem("localization")).currency.symbol;
    this.basicDetails.timezon = JSON.parse(localStorage.getItem("localization"))["timezone"];
    this.basicDetails.timezone_name = JSON.parse(localStorage.getItem("localization"))["timezone_name"];

    //show sms settings only for us india and canada
    var country = JSON.parse(localStorage.getItem("localization")).country.name;
    country === 'India' || country === 'United States' || country === 'Canada'
      ? (this.show_sender_id = true)
      : (this.show_sender_id = false);
    console.log(country);

    this.getCenterData();
    this.getSettings();
  }

  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
      success = success;
      console.log("success", success);
      this.center_settings = this.updated_center_settings = success;
      this.center_settings.automations.channels.sms == 0
        ? (this.sms_enabled = false)
        : (this.sms_enabled = true);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  updateSenderSettings() {
    let endpoint = "automations.channels.sms";
    let value;
    let obj = {};
    let name = "SMS";
    if (this.sms_enabled == true) {
      value = 1;
    } else {
      value = 0;
    }

    obj["value"] = value;
    this.http.patchData("settings/" + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + " settings updated", 3000, "success");
      this.setValue("a", endpoint, value);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

  setValue(i, endpoint, value) {
    endpoint = endpoint.split(".");
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  getCenterData() {
    this.http.getData("center/" + this.center_id).subscribe(success => {
      let rs = success.data;
      this.prepareEmail(rs.client.emails);
      let ls = this.basicDetails;
      ls.client = rs.client;
      ls.name = rs.name;
      ls.address = rs.address;
      ls.city = rs.city;
      ls.state = rs.state;
      ls.pincode = rs.pincode;
      ls.country = rs.country;
      ls.timezone = rs.timezone;
      ls.phone = rs.phone;
      rs.client.email == null
        ? (ls.client.email = "")
        : (ls.client.email = rs.client.email);
      // ls.client.sender_id = rs.client.sender_id;
      rs.client.sender_id == ""
        ? (ls.client.sender_id = null)
        : (ls.client.sender_id = rs.client.sender_id);
      ls.client.sender_id !== null
        ? (ls.client.sender_id = ls.client.sender_id.toUpperCase())
        : {};
      ls.client.name = rs.client.name;
      ls.client.phone = rs.client.phone;
      ls.client.image_url = rs.client.image_url;
      ls.client.contact_name = rs.client.contact_name;
      console.log(ls);
      this.isDisabled();
      return true;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      return false;
    });
  }
  isDisabled() {
    if (this.basicDetails.client.sender_id == null) {
      this.is_disabled = false;
    } else if (this.basicDetails.client.sender_id.length == 6) {
      this.is_disabled = true;
    }
  }
  confirmSenderChange(id) {
    console.log("changes made to the sender are called");
    this.basicDetails.client.sender_id = this.basicDetails.client.sender_id.toUpperCase();
    if (this.basicDetails.client.sender_id.length < 6) {
      this.generalFunctions.openToast("Please give valid six letters to add sender id", 3000, "error");
      this.basicDetails.client.sender_id = " ";
      return;
    } else if (this.basicDetails.client.sender_id.length == 6) {
      this.pop_up_for = "sender_id";
      this.sender_id = id;
      this.validationCheck = true;
      this.isDisabled();
    }
  }

  saveSenderId() {
    this.basicDetails.client.sender_id = this.sender_id;
    console.log("this.basicDetails", this.basicDetails);

    this.http.patchData("center?center_id=" + this.center_id, this.basicDetails).subscribe(success => {
      this.generalFunctions.openToast("Settings has been successfully updated", 3000, "success");

      this.getCenterData();
    }, error => {
      console.log(error);
    });
    this.pop_up_for = false;
  }

  deleteEmail(id) {
    this.http.deleteData("settings/email/" + id + "?center_id=" + this.center_id).subscribe(success => {
      this.getCenterData();
      this.pop_up_for = false;
      this.generalFunctions.openToast("You have successfully deleted your email", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  prepareEmail(emails) {
    if (emails.length <= 0) {
      this.noEmail = true;
    } else {
      this.noEmail = false;
      this.basicDetails.client.emails = emails;
    }
    if (emails.length < 5) {
      this.addEmail = true;
      console.log("email is in range");
    } else {
      this.addEmail = false;
      console.log("out of range");
    }
  }

  addBusinessEmail() {
    // this.validationCheck = true;
    this.addingEmail = true;

    if (!this.validationFields.business_email || !this.validationFields.from_name || !this.validationFields.reply_to) {
      this.generalFunctions.openToast("Please fill in required fields", 3000, "error");
      this.addingEmail = false;
      return;
    }

    const reqObj = {
        from_email : this.updateEmail.email,
        reply_to  : this.updateEmail.reply_to,
        from_name : this.updateEmail.from_name
    }

    this.http.sendData("settings/email?center_id=" + this.center_id, reqObj).subscribe(success => {
      this.getCenterData();
      this.addingEmail = false;
      this.pop_up_for = 'okay';
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.addingEmail = false;
      this.pop_up_for = false;
    });
  }

  clearForm() {
    this.updateEmail = {
        email: "",
        from_name: "",
        reply_to: ""
      };
  }

  savePhone() {
    this.validationCheck = true;
    if (!this.validationFields.contact_number) {
      this.generalFunctions.openToast("Please fill in required fields", 3000, "error");
      return;
    }
    this.saveDetails();
  }

  saveDetails() {
    this.http.patchData("center?center_id=" + this.center_id, this.basicDetails).subscribe(success => {
      this.generalFunctions.openToast("Settings has been successfully updated", 3000, "success");

      this.getCenterData();
    }, error => {
      console.log(error);
    });
  }

  flushSender() {
    this.basicDetails.client.sender_id = null;
    this.is_disabled = false;
  }
  setDefault(id) {
    this.http.patchData("settings/email/" + id + "?center_id=" + this.center_id, {is_default: 1}).subscribe(success => {
      this.getCenterData();
      this.generalFunctions.openToast("You have successfully set default", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  mapImageUrl(event) {
    this.basicDetails.client.image_url = event;
    this.saveDetails();
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
        case "customer-email":
        isValid = !this.validateEmail(this.basicDetails.client.email)
          ? false
          : true;
        this.validationFields.customer_email = isValid;
        break;

        case "business-email":
        isValid = !this.validateEmail(this.updateEmail.email)
          ? false
          : true;
        this.validationFields.business_email = isValid;
        break;

        case "reply-to":
            isValid = !this.validateEmail(this.updateEmail.reply_to)
              ? false
              : true;
            this.validationFields.reply_to = isValid;
        break;

        case "from-name":
            isValid = !(this.updateEmail.from_name.length > 1)
                ? false
                : true;
            this.validationFields.from_name = isValid;
        break;

        case "customer-fid":
        isValid = !(this.basicDetails.client.sender_id.length == 6) || !(this.basicDetails.client.sender_id.length == 0)
          ? false
          : true;
        this.validationFields.customer_fid = isValid;
        break;

        case "contact-number":
        isValid = !this.validatePhone(this.basicDetails.client.phone)
          ? false
          : true;
        this.validationFields.contact_number = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }
  validateEmail(email) {
    var re = /(^$)|(\S+@\S+\.\S+)/;
    return re.test(email);
  }
  validatePhone(phone) {
    var re = /(^$)|(^\d{10}$)/;
    return re.test(phone);
  }

  recheckEmail(i) {
    this.rechecking = true;
    this.getCenterData();

    this.http.getData("settings/email/recheck/?center_id=" + this.center_id).subscribe(success => {
      this.getCenterData();
      setTimeout(() => {
        this.checkStatus(i);
      }, 3000);
    }, error => {
      this.generalFunctions.openToast("There is some trouble checking your validation", 1000, "error");
    });
  }
  checkStatus(i) {
    console.log(this.basicDetails.client.emails);
    this.basicDetails.client.emails[i].status == 1
      ? this.generalFunctions.openToast("Email has been successfully verified", 3000, "success")
      : this.generalFunctions.openToast("Email not verified, please check your inbox", 3000, "success");
  }
  uppercaseMe(e) {
    this.generalFunctions.isFilled(e);
    e.target.value = e.target.value.toUpperCase();
  }

  resendEmail(email) {
    this.http.sendData("settings/email?center_id=" + this.center_id, {
      email: email,
      resend: 1
    }).subscribe(success => {
      this.getCenterData();
      this.generalFunctions.openToast("The confirmation has been resent, Please check your inbox", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }
}
