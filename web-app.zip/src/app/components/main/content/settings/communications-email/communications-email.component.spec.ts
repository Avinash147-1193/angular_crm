import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommunicationsEmailComponent } from './communications-email.component';

describe('CommunicationsEmailComponent', () => {
  let component: CommunicationsEmailComponent;
  let fixture: ComponentFixture<CommunicationsEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommunicationsEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
