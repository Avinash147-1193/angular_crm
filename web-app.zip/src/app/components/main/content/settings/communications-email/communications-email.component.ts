import { Component, OnInit } from '@angular/core';
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";

@Component({
  selector: 'app-communications-email',
  templateUrl: './communications-email.component.html',
  styleUrls: ['../settings.component.scss', './communications-email.component.scss']
})


export class CommunicationsEmailComponent implements OnInit {



  tab_id: any;

  include_center: any = null;
  addEmail: boolean = false;
  centerId: string = "";
  noEmail: boolean;
  sender_id: any;
  pop_up_for: any;
  validationCheck: boolean = false;
  validationFields: any = {
    customer_email: false,
    contact_number: false,
    business_email: false,
    from_name: false,
    update_reply_to: false,
    update_from_name: false,
    reply_to: false,
    customer_fid: false
  };
  email_delete: any;

  basicDetails: any = {
    branch: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    country: "",
    currency: "",
    timezon: "",
    timezone_name: "",
    phone: "",
    client: {
      name: "",
      email: "",
      contact_name: "",
      phone: "",
      sender_id: null
    }
  };
  updateEmail: any = {
    email: "",
    from_name: "",
    reply_to: ""
  };
  email_data : any;
  is_disabled: boolean;
  center_id: any;
  show_sender_id: boolean;
  rechecking: boolean = false;
  checker: boolean = false;
  center_settings: any;
  updated_center_settings: any;
  sms_enabled: any;
    addingEmail: boolean = false;
    domainName: any = "";
    dnsMapping: any[];
    domain: any;
    loaders: any = {
        domainVerifying : false,
        addDom : false,
    };

  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

  ngOnInit() {
    this.tab_id = "detail";
    this.include_center = this.generalFunctions.includeCenter();

    // this.basicDetails.client.sender_id = null;
    this.center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    this.basicDetails.currency = JSON.parse(localStorage.getItem("localization")).currency.name + " , " + JSON.parse(localStorage.getItem("localization")).currency.symbol;
    this.basicDetails.timezon = JSON.parse(localStorage.getItem("localization"))["timezone"];
    this.basicDetails.timezone_name = JSON.parse(localStorage.getItem("localization"))["timezone_name"];

    //show sms settings only for us india and canada
    var country = JSON.parse(localStorage.getItem("localization")).country.name;
    country === 'India' || country === 'United States' || country === 'Canada'
      ? (this.show_sender_id = true)
      : (this.show_sender_id = false);
    console.log(country);

    this.getCenterData();
    this.getSettings();

    this.getDomains();
  }

  getDomains() {
    this.http.getData("settings/domains" + this.include_center).subscribe(success => {
      console.log("domains", success);
      this.domain = success.data[0];
      this.getDomainData(this.domain.id);

    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  deleteDomain() {
    this.http.deleteData(`settings/domains/${this.domain.id}` + this.include_center).subscribe(success => {
        console.log("domains", success);
        this.domain = success.data[0];
        this.getDomainData(this.domain.id);
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });
  }

  getDomainData(id){
    this.http.getData(`settings/domains/${id}` + this.include_center).subscribe(success => {
        // this.getDomains();
        this.dnsMapping = this.formatDns(success.sendgrid_data.dns);
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
      });
  }



  checkDnsStatus(id){
      this.loaders.domainVerifying = true;
    this.http.sendData("settings/domains/verify" + this.include_center, {domain_id : id}).subscribe(success => {
        let result  = success.sendgrid_data.validation_results;
        if(success.sendgrid_data.valid){
            this.generalFunctions.openToast('DNS verified successfully', 3000, "success");
            this.getDomains();
        }
        else{
            let keys = Object.keys(result);
            if(keys.length > 0) {
                for (let index = 0; index < keys.length; index++) {
                  if(!result[keys[index]].valid){
                    this.generalFunctions.openToast('One or more CNAME records not found', 3000, "error");
                    // this.generalFunctions.openToast(result[keys[index]].reason, 3000, "error");
                    this.loaders.domainVerifying = false;

                    return;
                  }

                }
            }
        }
        this.loaders.domainVerifying = false;
      },
      error => {
        this.loaders.domainVerifying = false;
        this.generalFunctions.openToast(error.message, 3000, "error");
      });
  }



  addDomain(){
      console.log('this.validUrl', this.validURL(this.domainName))
      this.loaders.addDom = true;
      if(this.validURL(this.domainName)){
        this.http.sendData("settings/domains" + this.include_center, {domain : this.domainName}).subscribe(success => {
            this.getDomains();
            this.loaders.addDom = false;

          }, error => {
            this.loaders.addDom = false;

            this.generalFunctions.openToast(error.message, 3000, "error");
          });
      }
      else {
        this.loaders.addDom = false;

        this.generalFunctions.openToast('Please enter a valid domain name', 3000, "error");

      }
  }

  formatDns(dns){
    console.log('dns.keys()', Object.keys(dns))
    let dnsObj = [];
    let keys = Object.keys(dns);
    for (let index = 0; index < keys.length; index++) {
        dnsObj.push(dns[keys[index]]);
    }
    return dnsObj;
  }

  validURL(str) {
    const pattern = new RegExp('^(((?!-))(xn--|_{1,1})?[a-z0-9-]{0,61}[a-z0-9]{1,1}\.)*(xn--)?([a-z0-9][a-z0-9\-]{0,60}|[a-z0-9-]{1,30}\.[a-z]{2,})$');
    return pattern.test(str);
  }

  copyToClipboard(str) {
    const el = document.createElement('textarea');
    el.value = str;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    this.generalFunctions.openToast('Copied to clipboard', 3000, 'success');
  }



  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
      success = success;
      console.log("success", success);
      this.center_settings = this.updated_center_settings = success;
      this.center_settings.automations.channels.sms == 0
        ? (this.sms_enabled = false)
        : (this.sms_enabled = true);
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }



  updateSenderSettings() {
    let endpoint = "automations.channels.sms";
    let value;
    let obj = {};
    let name = "SMS";
    if (this.sms_enabled == true) {
      value = 1;
    } else {
      value = 0;
    }

    obj["value"] = value;
    this.http.patchData("settings/" + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + " settings updated", 3000, "success");
      this.setValue("a", endpoint, value);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }



  setValue(i, endpoint, value) {
    endpoint = endpoint.split(".");
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  getCenterData() {
    this.http.getData("center/" + this.center_id).subscribe(success => {
      let rs = success.data;
      this.prepareEmail(rs.client.emails);
      let ls = this.basicDetails;
      ls.client = rs.client;
      ls.name = rs.name;
      ls.address = rs.address;
      ls.city = rs.city;
      ls.state = rs.state;
      ls.pincode = rs.pincode;
      ls.country = rs.country;
      ls.timezone = rs.timezone;
      ls.phone = rs.phone;
      rs.client.email == null
        ? (ls.client.email = "")
        : (ls.client.email = rs.client.email);
      // ls.client.sender_id = rs.client.sender_id;
      rs.client.sender_id == ""
        ? (ls.client.sender_id = null)
        : (ls.client.sender_id = rs.client.sender_id);
      ls.client.sender_id !== null
        ? (ls.client.sender_id = ls.client.sender_id.toUpperCase())
        : {};
      ls.client.name = rs.client.name;
      ls.client.phone = rs.client.phone;
      ls.client.image_url = rs.client.image_url;
      ls.client.contact_name = rs.client.contact_name;
      console.log(ls);
      this.isDisabled();
      return true;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      return false;
    });
  }
  isDisabled() {
    if (this.basicDetails.client.sender_id == null) {
      this.is_disabled = false;
    } else if (this.basicDetails.client.sender_id.length == 6) {
      this.is_disabled = true;
    }
  }
  confirmSenderChange(id) {
    console.log("changes made to the sender are called");
    this.basicDetails.client.sender_id = this.basicDetails.client.sender_id.toUpperCase();
    if (this.basicDetails.client.sender_id.length < 6) {
      this.generalFunctions.openToast("Please give valid six letters to add sender id", 3000, "error");
      this.basicDetails.client.sender_id = " ";
      return;
    } else if (this.basicDetails.client.sender_id.length == 6) {
      this.pop_up_for = "sender_id";
      this.sender_id = id;
      this.validationCheck = true;
      this.isDisabled();
    }
  }

  saveSenderId() {
    this.basicDetails.client.sender_id = this.sender_id;
    console.log("this.basicDetails", this.basicDetails);

    this.http.patchData("center?center_id=" + this.center_id, this.basicDetails).subscribe(success => {
      this.generalFunctions.openToast("Settings has been successfully updated", 3000, "success");

      this.getCenterData();
    }, error => {
      console.log(error);
    });
    this.pop_up_for = false;
  }

  deleteEmail(id) {
    this.http.deleteData("settings/email/" + id + "?center_id=" + this.center_id).subscribe(success => {
      this.getCenterData();
      this.pop_up_for = false;
      this.generalFunctions.openToast("You have successfully deleted your email", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  prepareEmail(emails) {
    if (emails.length <= 0) {
      this.noEmail = true;
    } else {
      this.noEmail = false;
      this.basicDetails.client.emails = emails;
    }
    if (emails.length < 5) {
      this.addEmail = true;
      console.log("email is in range");
    } else {
      this.addEmail = false;
      console.log("out of range");
    }
  }

  addBusinessEmail() {
    // this.validationCheck = true;
    this.addingEmail = true;

    if (!this.validationFields.business_email || !this.validationFields.from_name || !this.validationFields.reply_to) {
      this.generalFunctions.openToast("Please fill in required fields", 3000, "error");
      this.addingEmail = false;
      return;
    }

    if(this.updateEmail.email.split('@')[1].includes(this.domain.domain)){
        console.log('domain matches');
    }else{
        this.generalFunctions.openToast("Provided email and verified domain must match", 3000, "error");
        this.addingEmail = false;
        return;
    }

    const reqObj = {
        email : this.updateEmail.email,
        reply_to  : this.updateEmail.reply_to,
        from_name : this.updateEmail.from_name
    }

    this.http.sendData("settings/email?center_id=" + this.center_id, reqObj).subscribe(success => {
      this.getCenterData();
      this.addingEmail = false;
      this.pop_up_for = 'okay';
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.addingEmail = false;
      this.pop_up_for = false;
    });
  }

  updateBusinessEmail() {
    // this.validationCheck = true;

    if (!this.validationFields.update_from_name || !this.validationFields.update_reply_to) {
      this.generalFunctions.openToast("Please fill in required fields", 3000, "error");
      return;
    }

    const reqObj = {
        reply_to  : this.email_data.reply_to,
        from_name : this.email_data.from_name
    }

    this.http.patchData("settings/email/" + this.email_data.id + "?center_id=" + this.center_id, {
        reply_to  : this.email_data.reply_to,
        from_name : this.email_data.from_name,
        is_default : this.email_data.is_default
    }).subscribe(success => {
        this.getCenterData();
        this.generalFunctions.openToast("You have successfully set default", 3000, "success");
        this.pop_up_for = null;
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
        this.pop_up_for = false;
      });

  }

  clearForm() {
    this.updateEmail = {
        email: "",
        from_name: "",
        reply_to: ""
      };
  }

  savePhone() {
    this.validationCheck = true;
    if (!this.validationFields.contact_number) {
      this.generalFunctions.openToast("Please fill in required fields", 3000, "error");
      return;
    }
    this.saveDetails();
  }

  saveDetails() {
    this.http.patchData("center?center_id=" + this.center_id, this.basicDetails).subscribe(success => {
      this.generalFunctions.openToast("Settings has been successfully updated", 3000, "success");

      this.getCenterData();
    }, error => {
      console.log(error);
    });
  }

  flushSender() {
    this.basicDetails.client.sender_id = null;
    this.is_disabled = false;
  }
  setDefault(id) {
    this.http.patchData("settings/email/" + id + "?center_id=" + this.center_id, {is_default: 1}).subscribe(success => {
      this.getCenterData();
      this.generalFunctions.openToast("You have successfully set default", 3000, "success");
    }, error => {
        this.getCenterData();

      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  mapImageUrl(event) {
    this.basicDetails.client.image_url = event;
    this.saveDetails();
  }

  formValidate(field) {
    let isValid = true;

    switch (field) {
        case "customer-email":
        isValid = !this.validateEmail(this.basicDetails.client.email)
          ? false
          : true;
        this.validationFields.customer_email = isValid;
        break;

        case "business-email":
        isValid = !this.validateEmail(this.updateEmail.email)
          ? false
          : true;
        this.validationFields.business_email = isValid;
        break;

        case "reply-to":
            isValid = !this.validateEmail(this.updateEmail.reply_to)
              ? false
              : true;
            this.validationFields.reply_to = isValid;
        break;

        case "from-name":
            isValid = !(this.updateEmail.from_name.length > 1)
                ? false
                : true;
            this.validationFields.from_name = isValid;
        break;

        case "update-reply-to":
            isValid = !this.validateEmail(this.email_data.reply_to)
              ? false
              : true;
            this.validationFields.update_reply_to = isValid;
        break;

        case "update-from-name":
            isValid = !(this.email_data?.from_name?.length > 1)
                ? false
                : true;
            this.validationFields.update_from_name = isValid;
        break;

        case "customer-fid":
        isValid = !(this.basicDetails.client.sender_id.length == 6) || !(this.basicDetails.client.sender_id.length == 0)
          ? false
          : true;
        this.validationFields.customer_fid = isValid;
        break;

        case "contact-number":
        isValid = !this.validatePhone(this.basicDetails.client.phone)
          ? false
          : true;
        this.validationFields.contact_number = isValid;
        break;

      default:
        break;
    }

    return !isValid;
  }
  validateEmail(email) {
    var re = /(^$)|(\S+@\S+\.\S+)/;
    return re.test(email);
  }
  validatePhone(phone) {
    var re = /(^$)|(^\d{10}$)/;
    return re.test(phone);
  }

  recheckEmail(i) {
    this.rechecking = true;
    this.getCenterData();

    this.http.getData("settings/email/recheck/?center_id=" + this.center_id).subscribe(success => {
      this.getCenterData();
      setTimeout(() => {
        this.checkStatus(i);
      }, 3000);
    }, error => {
      this.generalFunctions.openToast("There is some trouble checking your validation", 1000, "error");
    });
  }

  checkStatus(i) {
    console.log(this.basicDetails.client.emails);
    this.basicDetails.client.emails[i].status == 1
      ? this.generalFunctions.openToast("Email has been successfully verified", 3000, "success")
      : this.generalFunctions.openToast("Email not verified, please check your inbox", 3000, "success");
  }
  uppercaseMe(e) {
    this.generalFunctions.isFilled(e);
    e.target.value = e.target.value.toUpperCase();
  }

  resendEmail(email) {
    this.http.sendData("settings/email?center_id=" + this.center_id, {
      email: email,
      resend: 1
    }).subscribe(success => {
      this.getCenterData();
      this.generalFunctions.openToast("The confirmation has been resent, Please check your inbox", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

}




let obj = {
    "sendgrid_data": {
        "id": 10287813,
        "user_id": 19987029,
        "subdomain": "em680",
        "domain": "gymday.in",
        "username": "rajat@getstudioyou.com",
        "ips": [],
        "custom_spf": false,
        "default": false,
        "legacy": false,
        "automatic_security": true,
        "valid": false,
        "dns": {
            "mail_cname": {
                "valid": false,
                "type": "cname",
                "host": "em680.gymday.in",
                "data": "u19987029.wl030.sendgrid.net"
            },
            "dkim1": {
                "valid": false,
                "type": "cname",
                "host": "s1._domainkey.gymday.in",
                "data": "s1.domainkey.u19987029.wl030.sendgrid.net"
            },
            "dkim2": {
                "valid": false,
                "type": "cname",
                "host": "s2._domainkey.gymday.in",
                "data": "s2.domainkey.u19987029.wl030.sendgrid.net"
            }
        }
    },
    "domain": {
        "domain": "gymday.in",
        "client_id": 3,
        "sendgrid_id": 10287813,
        "updated_at": "2021-01-25 10:43:44",
        "created_at": "2021-01-25 10:43:44",
        "id": 3
    }
}
