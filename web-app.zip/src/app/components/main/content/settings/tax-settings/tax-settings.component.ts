import {
	Component,
	OnInit
} from '@angular/core';
import {
	Router,
	ActivatedRoute
} from '@angular/router';
import {
	GeneralServices
} from '../../../../../common/general-services';
import {
	ServerAuthService
} from '../../../../../common/server-auth';

@Component({
  selector: 'app-tax-settings',
  templateUrl: './tax-settings.component.html',
  styleUrls: ['./tax-settings.component.scss']
})
export class TaxSettingsComponent implements OnInit {

  constructor(
    private generalFunctions: GeneralServices,
		private http: ServerAuthService,
		private route: ActivatedRoute,
		private router: Router
  ) { }

  taxSettings: any = {
    collectTax: '',
    taxPercentage : ''
  }
  center_id : any = null;



  ngOnInit() {
    this.center_id = JSON.parse(localStorage.getItem('currentUser')).center_id;
    this.getCenterData();
    

  }
	getCenterData() {
		this.http.getData('center/' + this.center_id)
			.subscribe(
				(success) => {

					let rs = success.data;
          this.taxSettings.collectTax = rs.settings.tax.enabled;
          this.taxSettings.taxPercentage = rs.tax_percentage;				
				},
				(error) => {
					this.generalFunctions
						.openToast(error.message, 3000, "error");
				}
			)
  }
  
  saveTax(){
    (this.taxSettings.collectTax == false) ? this.saveTaxRate() : null;
        this.http.patchData('settings/tax.enabled?center_id='+this.center_id,{'value':this.taxSettings.collectTax})
    .subscribe(
      (success)=>{
        this.generalFunctions.openToast('Settings has been saved', 3000, "success");
      }

    ), (error)=>{
      this.generalFunctions
      .openToast(error.message, 3000, "error");
    }
  }

  saveTaxRate(){
    if(this.taxSettings.taxPercentage >100 ){
      this.generalFunctions.openToast('Tax can not be greater than 100', 2000, 'error' )
    }
    else{
    (this.taxSettings.collectTax == false) ? this.taxSettings.taxPercentage = 0 : null
    this.http.patchData('center?center_id='+this.center_id,{'tax_percentage':this.taxSettings.taxPercentage})
    .subscribe(
      (success)=>{
        this.generalFunctions.openToast('Settings has been saved', 3000, "success");
      }

    ), (error)=>{
      this.generalFunctions
      .openToast(error.message, 3000, "error");
    }
  }
  }

}

