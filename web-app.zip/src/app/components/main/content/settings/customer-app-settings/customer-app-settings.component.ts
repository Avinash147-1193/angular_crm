import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ServerAuthService} from "../../../../../common/server-auth";
import {GeneralServices} from "../../../../../common/general-services";

import {Location, LocationStrategy, PathLocationStrategy} from "@angular/common";
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';


@Component({
  selector: 'app-customer-app-settings',
  templateUrl: './customer-app-settings.component.html',
  styleUrls: ['./customer-app-settings.component.scss','../settings.component.scss']
})
export class CustomerAppSettingsComponent implements OnInit {
	tab_id = "portal_address";
	webPortalLink: any;
	website_url: any;
	urls: any;
	color = "#dfe3e9";
	include_center: any;
	updated_center_settings: any = {
	  general: {
		brand_color: ""
	  },
	  webstore: {
		font_family: "1",
		text_color: "#ffffff",
		background_color: "#fffff",
		services : { classes : true, appointments : true}
	  },
	  website_url: null
	};
	center_settings: any;
    urlDisabled: boolean;
    services:any;
    center_id: any;

  constructor(private http : ServerAuthService, private generalFunctions : GeneralServices) { }


  ngOnInit() {
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];

    this.include_center = this.generalFunctions.includeCenter();
    this.getCenterData();
    this.getSettings();
    this.getServices();
  }

  dropGroup(event) {

    moveItemInArray(this.services, event.previousIndex, event.currentIndex);

    let reqObj = {
        "services": []
      }
    this.services.forEach((element, index) => {
        let obj = {
            "id": element.id,
            "order": index+1,
            "status": element.status
          }
          reqObj.services.push(obj);
    });


    this.http.updateData(`center/${this.center_id}/services`, reqObj).subscribe(success => {
        console.log('services', this.services)
      }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });


}

getServices() {
    this.http.getData(`center/${this.center_id}/services`).subscribe(success => {
        this.services = success.sort((a,b) => a.order-b.order);
    }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });
}

serviceUpdated(service) {
    let reqObj = {
        "services": [
          {
            "status": service.status,
            "id": service.id,
            "order": service.order
          }
        ]
      }
      this.http.updateData(`center/${this.center_id}/services`, reqObj).subscribe(success => {
        this.generalFunctions.openToast('Services updated', 3000, "success");

      }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
      });
}

  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
        this.center_settings = this.updated_center_settings = success;
    }, err => {
        this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  checkIf() {
    if (this.updated_center_settings.general.brand_color.length == 7) {
      this.updateSettings("general.brand_color", this.updated_center_settings.general.brand_color, "Web portal theme color");
    }
  }

  updateSettings(endpoint, value, name) {
    console.log("endpoint, value, name", endpoint, value, name);
    var obj = {};
    obj["value"] = value;
    this.http.patchData("settings/" + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + " settings updated", 3000, "success");
      this.setValue("a", endpoint, value);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

  setValue(i, endpoint, value) {
    endpoint = endpoint.split(".");
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  getCenterData() {
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    this.http.getData("center/" + center_id).subscribe(success => {
      this.webPortalLink = success.data.webstore_url;
      this.website_url = success.data.website_url;
      //   this.website_url = "https://www.boxfit.com/reserve/";
      if (this.website_url !== null) {
        this.urlDisabled = true;
        this.urls = this.generateIframeLinks(this.website_url);
        console.log("urls", this.urls);
      } else {
        this.urlDisabled = false;
      }
      console.log("this.webPortalLink", success);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  generateIframeLinks(website_url) {
    let obj = {};
    obj["script"] = '<div id="zingfit-embed">' + "</div>" + '<script src="https://boxfit.getstudioyou.com/static/embed.js”>' + "</script>" + "<script>" + "studioyouembed(‘boxfit.getstudioyou.com’);" + "</script>";
    obj["schedule"] = website_url + "#/schedule/site/1";
    obj["pricing"] = website_url + "#/pricing/site/1";
    obj["myAccount"] = website_url + "#/myaccount/site/1";

    obj["signup"] = website_url + "#/signup/site/1";

    obj["login"] = website_url + "#/login/site/1";
    obj["password"] = website_url + "#/password/site/1";

    return obj;
  }

  removeDetails() {
    this.website_url = null;
    this.urlDisabled = false;
    this.saveDetails();
  }

  saveDetails() {
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    if (this.website_url.length > 5 && (this.website_url.includes("http://") || this.website_url.includes("https://"))) {
      this.http.patchData("center?center_id=" + center_id, {
        client: {
          website_url: this.website_url
        }
      }).subscribe(success => {
        this.generalFunctions.openToast("Settings has been successfully updated", 3000, "success");
        this.getCenterData();
      }, error => {
        console.log(error);
      });
    } else {
      this.generalFunctions.openToast("Enter a valid url", 3000, "error");
    }
  }

  copyToClipboard(str) {
    const el = document.createElement("textarea");
    el.value = str;
    el.setAttribute("readonly", "");
    el.style.position = "absolute";
    el.style.left = "-9999px";
    document.body.appendChild(el);
    el.select();
    document.execCommand("copy");
    document.body.removeChild(el);
    this.generalFunctions.openToast("Copied to clipboard", 3000, "success");
  }
  changeColor() {}


}
