import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerAppSettingsComponent } from './customer-app-settings.component';

describe('CustomerAppSettingsComponent', () => {
  let component: CustomerAppSettingsComponent;
  let fixture: ComponentFixture<CustomerAppSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerAppSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerAppSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
