import { Component, OnInit, ViewEncapsulation, ɵSWITCH_CHANGE_DETECTOR_REF_FACTORY__POST_R3__ } from '@angular/core';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop'

@Component({
  selector: 'app-lead-settings',
  templateUrl: './lead-settings.component.html',
  styleUrls: ['../settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LeadSettingsComponent implements OnInit {

    include_center: any;
    pop_up_for: any = null;
    stageName: '';
    stageRenameObj: '';
    stages: any;
    sources: any;
    hoveredStage  = null;
    hoveredSource = null;
    dltData : any;


  constructor(private generalFunctions: GeneralServices, private http: ServerAuthService) { }

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.getLeadSettings();
  }


  getLeadSettings() {
    this.http.getData('leads/stages_sources' + this.include_center)
    .subscribe(
    response => {
        this.stages = response.data.stages.sort((a, b) => a.order - b.order );
        this.sources = response.data.sources.sort((a, b) => a.order - b.order );
    },
    err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
    })
  }


  dropSource(event: CdkDragDrop<string[]>){
      moveItemInArray(this.sources, event.previousIndex, event.currentIndex);


    const newResObj = Object.values(this.sources);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        code : element['code'],
        order: index + 1
      };
      arr[index] = obj;
    });


    const reqObj = {type : 'source', sources : arr};

    this.http.sendData('leads/order_stages_sources' + this.include_center, reqObj).subscribe(response => {
    }, err => { this.generalFunctions.openToast(err.message, 3000, 'error'); });

  }


  dropStage(event: CdkDragDrop<string[]>){
    moveItemInArray(this.stages, event.previousIndex, event.currentIndex);


  const newResObj = Object.values(this.stages);
  const arr = [];
  newResObj.forEach((element, index) => {
    const obj = {
      code : element['code'],
      order: index + 1
    };
    arr[index] = obj;
  });


  const reqObj = {type : 'stage', stages : arr};

  this.http.sendData('leads/order_stages_sources' + this.include_center, reqObj).subscribe(response => {
  }, err => { this.generalFunctions.openToast(err.message, 3000, 'error'); });

}


  addStage(type) {
    this.stageName = '';
    if (type === 'stage') {
        this.pop_up_for = 'stage_add';
    } else {
        this.pop_up_for = 'source_add';
    }
  }

  createStage(type) {
      this.pop_up_for = null;
    this.http.sendData('leads/stages_sources' + this.include_center,
    {
    type: type,
    name : this.stageName})
    .subscribe(
    response => {
        this.generalFunctions.openToast(`${type} added`, 3000, 'success');
        this.getLeadSettings()
    },
    err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
    })
  }

  renameStage(type, code, name) {

    let reqObj =  {
        type: type,
        code : code,
        name : name
    };
    if(name.length === 0) {
        this.generalFunctions.openToast('Please enter a valid name', 3000, 'error');
        this.pop_up_for = null;
        return;
    }
    this.pop_up_for = null;

    this.http.updateData('leads/stages_sources' + this.include_center, reqObj)
        .subscribe(
        response => {
            this.generalFunctions.openToast(`${type} renamed`, 3000, 'success');
            this.getLeadSettings();

        },
        err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
        })
  }

  deleteStage(stage, type) {

    let reqObj =  {code : stage.code, type : type};
    this.pop_up_for = null;
      this.http.deleteBody('leads/stages_sources' + this.include_center, reqObj).subscribe(
        (response) => {
        this.generalFunctions.openToast(`${type} deleted`, 3000, 'success');
        this.getLeadSettings();
        },
        err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
        }
      )
  }

  dltPopUp(stage, type) {
    this.dltData = {
        stage : stage,
        type : type
    }
      this.pop_up_for = 'delete';

  }

}

