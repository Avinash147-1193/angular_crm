import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {ServerAuthService} from '../../../../../common/server-auth';
import {GeneralServices} from '../../../../../common/general-services';

import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import {environment} from '../../../../../../environments/environment';

@Component({
    selector: 'app-webstore-settings',
    templateUrl: './webstore-settings.component.html',
    styleUrls: ['./webstore-settings.component.scss']
})
export class WebstoreSettingsComponent implements OnInit {
  tab_id = 'portal_address';
  webPortalLink: any;
  website_url: any;
  regions: any;
  urls: any;
  color = '#dfe3e9';
  include_center: any;
  updated_center_settings: any = {
    general: {
      brand_color: ''
    },
    webstore: {
      font_family: '1',
      text_color: '#ffffff',
      background_color: '#fffff'
    },
    website_url: null
  };
  center_settings: any;
  urlDisabled: boolean;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private http: ServerAuthService,
    private generalFunctions: GeneralServices,
    private location: Location
  ) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();

    this.getCenterData();
    this.getSettings();
  }

  getSettings() {
    this.http.getData('settings' + this.include_center).subscribe(success => {
      success = success;
      console.log('success', success);
      this.center_settings = this.updated_center_settings = success;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  checkIf(type) {
    if (type === 'brand') {
        if (this.updated_center_settings.general.brand_color.length === 7) {
            this.updateSettings('general.brand_color', this.updated_center_settings.general.brand_color, 'Web portal theme color');
        } else {
            this.generalFunctions.openToast('Please enter a valid hex code', 3000, 'error');
        }
    } else {
        if (this.updated_center_settings.webstore.background_color.length === 7) {
            this.updateSettings('webstore.background_color', this.updated_center_settings.webstore.background_color, 'Web portal background color');
        } else {
            this.generalFunctions.openToast('Please enter a valid hex code', 3000, 'error');
        }
    }


  }

  updateSettings(endpoint, value, name) {
    console.log('endpoint, value, name', endpoint, value, name);
    const obj = {};
    obj['value'] = value;
    this.http.patchData('settings/' + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      const value = success.value;
      this.generalFunctions.openToast(name + ' settings updated', 3000, 'success');
      this.setValue('a', endpoint, value);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

  setValue(i, endpoint, value) {
    endpoint = endpoint.split('.');
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  getCenterData() {
    const center_id = JSON.parse(localStorage.getItem('currentUser')).center_id;
      this.http.getData('regions').subscribe(success_data => {
        this.regions = success_data;
         this.http.getData('center/' + center_id).subscribe(success => {
           this.webPortalLink = success.data.webstore_url;
           this.website_url = success.data.website_url;
              //   this.website_url = "https://www.boxfit.com/reserve/";
            if (this.website_url !== null) {
                this.urlDisabled = true;
                this.urls = this.generateIframeLinks(this.website_url, this.regions);
                console.log('urls', this.urls);
            } else {
              this.urlDisabled = false;
            }
            console.log('this.webPortalLink', success);
         }, error => {
           this.generalFunctions.openToast(error.message, 3000, 'error');
         });
      }, error => {
          this.generalFunctions.openToast("Something has gone wrong", 2000, 'error');
      });
  }

  generateIframeLinks(website_url, regions) {
    const obj = {};
    let url_prefix = JSON.parse(localStorage.getItem('client'))['client_url'];
    if (environment.production === false) {
        url_prefix = url_prefix + '.store';
    }

    obj['script'] = `<div id="studioyou-embed"></div>
                        <script>
                            const date = Date.now();
                            const xscript =  document.createElement("script");
                            xscript.setAttribute("src",\`https://${url_prefix}.getstudioyou.com/embed/index.js?t=\${date}\`);
                            const embedContainer = document.querySelector("body");
                            xscript.onload = function () {new StudioYouEmbed('${url_prefix}.getstudioyou.com');};
                            embedContainer.appendChild(xscript);
                        </script>
                        `;


    // obj['script'] = `<div id="studioyou-embed"></div>
    // <script src="https://${url_prefix}.getstudioyou.com/embed/index.js"></script>
    // <script type="application/javascript">
    // new StudioYouEmbed("${url_prefix}.getstudioyou.com");
    // </script>`;

    obj['myAccount'] = website_url + '#/my-account';
    obj['signup'] = website_url + '#/create-account';
    obj['login'] = website_url + '#/login';
    obj['password'] = website_url + '#/reset-password';
    obj['waiver'] = website_url + '#/waiver';



    obj['schedules'] = {
        'display': 'region',
        'region': [],
        'location': []
    };
    obj['appointment'] = {
        'display': 'region',
        'region': [],
        'location': []
    };

    obj['courses'] = {
        'display': 'region',
        'region': [],
        'location': []
    };
    obj['pricings'] = {
        'display': 'region',
        'region': [],
        'location': []
    };
    obj['vod'] = {
        'display': 'region',
        'region': [],
        'location': []
    };

    regions.forEach((region: any) => {
        obj['schedules']['region'].push({
            url: website_url + '#/class-schedule/r/' + region.id,
            name: region.name
        });
        obj['vod']['region'].push({
            url: website_url + '#/vod/r/' + region.id,
            name: region.name
        });


        obj['pricings']['region'].push({
            url: website_url + '#/pricing/r/' + region.id,
            name: region.name
        });
        region.centers.forEach((center: any) => {
            obj['pricings']['location'].push({
                url: website_url + '#/pricing/r/' + region.id + '/loc/' + center.id,
                name: center.name + ', ' + region.name
            });
            obj['schedules']['location'].push({
                url: website_url + '#/class-schedule/r/' + region.id + '/?loc=' + center.id,
                name: center.name + ', ' + region.name
            });
            obj['appointment']['location'].push({
                url: website_url + '#/appointment/r/' + region.id + '/loc/' + center.id,
                name: center.name + ', ' + region.name
            });

            obj['courses']['location'].push({
                url: website_url + '#/courses/r/' + region.id + '/loc/' + center.id,
                name: center.name + ', ' + region.name
            });

        })
    });


    return obj;
  }

  removeDetails() {
    this.website_url = null;
    this.urlDisabled = false;
    this.saveDetails();
  }

  saveDetails() {
    const center_id = JSON.parse(localStorage.getItem('currentUser')).center_id;
    if ((this.website_url === null) || (this.website_url && this.website_url.length > 5 && (
            this.website_url.includes('http://') || this.website_url.includes('https://')))) {
      this.http.patchData('center?center_id=' + center_id, {
        client: {
          website_url: this.website_url
        }
      }).subscribe(success => {
        this.generalFunctions.openToast('Settings has been successfully updated', 3000, 'success');
        this.getCenterData();
      }, error => {
        console.log(error);
      });
    } else {
      this.generalFunctions.openToast('Enter a valid url', 3000, 'error');
    }
  }

  copyToClipboard(str) {
    const el = document.createElement('textarea');
    el.value = str;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    this.generalFunctions.openToast('Copied to clipboard', 3000, 'success');
  }
  changeColor() {}
}
