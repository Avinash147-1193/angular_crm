import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebstoreSettingsComponent } from './webstore-settings.component';

describe('WebstoreSettingsComponent', () => {
  let component: WebstoreSettingsComponent;
  let fixture: ComponentFixture<WebstoreSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebstoreSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebstoreSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
