import {Component, OnInit, ViewChild} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {GeneralServices} from "app/common/general-services";
import {ServerAuthService} from "app/common/server-auth";
import { SelectItem } from "primeng/api";

@Component({selector: "app-payment-settings", templateUrl: "./payment-settings.component.html", styleUrls: ["./payment-settings.component.scss"]})
export class PaymentSettingsComponent implements OnInit {
  tab_id: any = "general";

  refund: any = {
    value: 1
  };
  pop_up_for: any = null;

  true: boolean = true;
  false: boolean = false;
  null: any = null;
  allTaxes: any = null;
  include_center: any = null;

  selected_settings: any = "general";

  center_settings: any = null;
  updated_center_settings: any = null;

  sms_sign: any = null;
  tin_no: any = null;
  globalTaxRate: any = null;

  got_setting: boolean = false;
  got_center: boolean = false;
  t_n_c_edit_mode: boolean = false;

  valid_file: boolean = false;
  migration_complete: boolean = false;

  migration_data: any = null;
  selected_tag_migrated_data: any = "all";
  migration_file_delete_modal: boolean = false;

  biometric_popup: boolean = false;
  biometric_popup_step: number = 1;

  currency = null;
  country = null;

  biometric_data: any = {
    status: false,
    device_name: null,
    serial_number: null,
    ip_address: null
  };

  selected_role: any = {
    display_name: null,
    permissions: {}
  };
  new_role_saved: boolean = true;

  hidePermission: boolean = false;

  stripeOn: any = "";

  navigationList: Array<string> = ['settings', 'about'];
  view = 'settings';
  connectMode = 'existing';
  list: SelectItem[] = [];
  install = false;
  selectedCenter = '';
  addingKey = false;
  stripeId = '';

  @ViewChild("role_name_input")role_name_input;
  @ViewChild("role_nav")role_nav;

  constructor(private generalFunctions : GeneralServices, private http : ServerAuthService, private route : ActivatedRoute, private router : Router) {}

  ngOnInit() {
    this.include_center = this.generalFunctions.includeCenter();
    this.allTaxes = true;
    this.getSettings();
    this.getCenter();
    this.getGatewayCenters();
    this.getBiometricData();
    this.route.queryParams.subscribe(params => {
      if (params["name"]) {
        this.selected_settings = params["name"];
      }
    });
    var userCountry = JSON.parse(localStorage.getItem("localization")).country.name;
    this.country = userCountry === "India"
      ? true
      : false;
    this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;

    document.addEventListener("click", event => {
      this.documentClickHandler(event);
    });

    if (JSON.parse(localStorage.getItem("currentUser")).roles) {
      this.hidePermission = true;
    }
  }

  // Helper Functions

  isFilled(e) {
    this.generalFunctions.isFilled(e);
  }



  autoIncreaseSize(e) {
    var textarea = e.target,
      height = textarea.offsetHeight;
    textarea.style.height = "16px";
    textarea.style.height = textarea.scrollHeight + "px";
  }

  toggleSwitch(e, endpoint, value, name) {
    var updatedValue = e.target.value == "true"
      ? false
      : true;
    var update = this.updateSettings(endpoint, updatedValue, name);
  }

  documentClickHandler(e) {
    Array.prototype.forEach.call(document.getElementsByClassName("more-options-list"), (item, index) => {
      item.classList.contains("display-none")
        ? ""
        : item.classList.add("display-none");
    });
    if (e.target.parentElement) {
      if (e.target.parentElement.classList.contains("more-options-icon")) {
        var list = this.generalFunctions.parents(e.target)[1].getElementsByClassName("more-options-list")[0];
        list.classList.remove("display-none");
      }
    }
  }

  setValue(i, endpoint, value) {
    endpoint = endpoint.split(".");
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  // Populate required data

  getSettings() {
    this.http.getData("settings" + this.include_center).subscribe(success => {
      success = success;
      this.center_settings = this.updated_center_settings = success;
      if (success.role_groups.roles[0]) {
        var name = success.role_groups.roles[0].display_name;
        var id = success.role_groups.roles[0].id;
        var staff_count = success.role_groups.roles[0].staff_count;

        this.populatePermission(name, id, staff_count);
        this.got_setting = true;
        this.getMigrationData();
      }
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }


  getMigrationData() {
    this.http.getData("setup/migration" + this.include_center).subscribe(success => {
      this.migration_data = success;
      if (this.migration_data.status == "completed") {
        var endpoint = "contact/formlink" + this.include_center + "&source=migration" + "&log_id=" + this.migration_data["uuid"];
        this.getMigratedData(endpoint);
      }
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  getMigratedData(endpoint) {
    this.http.getData(endpoint).subscribe(success => {
      this.migration_data["data"] = success.data;
      this.migration_data["total_count"] = success.meta.type_counts.total;
      this.migration_data["submitted_count"] = 0;
      this.migration_data["pending_count"] = 0;
      success.meta.type_counts.data.forEach((item, index) => {
        this.migration_data[item.type + "_count"] = item.count;
      });
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  getCenter() {
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    this.http.getData("center/" + center_id).subscribe(success => {
    //   console.log("success.data.stripe_id", success.data.gateway_id);
    if(success.data.is_stripe_connected) {
        this.stripeOn = true;
         this.install = true;
         this.stripeId = success.data.gateway_id;
    } else {
        this.stripeOn = false;
        this.install = false;
        this.view = 'about';
    }

      this.sms_sign = success.data.signature;
      this.tin_no = success.data.tin_no;
      this.got_center = true;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  getGatewayCenters() {
    this.http.getData(`clients/centers` + this.include_center)
    .subscribe(success => {
        const centers = success.data.filter((center) => center.is_stripe_connected)
                        .map((item) => { return {label : item.name, value : item.center_id}});
        this.list = centers;
        this.list.length > 0 && !this.stripeOn ? this.connectMode = 'existing' : this.connectMode = 'new';
    },
    err => {
        this.generalFunctions.openToast(err.message, 3000, 'error');
    })
}

  // Update SMS sign and GST no.

  updateSMSSign() {
    var obj = {};
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    obj["signature"] = this.sms_sign;
    this.http.patchData("center/" + center_id, obj).subscribe(success => {
      var msg = "SMS signature is updated!";
      this.generalFunctions.openToast(msg, 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  updateTin() {
    var obj = {};
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    obj["tin_no"] = this.tin_no;
    this.http.patchData("center/" + center_id, obj).subscribe(success => {
      var msg = "GST no. is updated!";
      this.generalFunctions.openToast(msg, 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  updateTaxRates() {
    var obj = {};
    var center_id = JSON.parse(localStorage.getItem("currentUser")).center_id;
    console.log(this.globalTaxRate);
    obj["globalTaxRate"] = this.globalTaxRate;
    this.http.patchData("center/" + center_id, obj).subscribe(success => {
      var msg = "Tax rate is updated!";
      this.generalFunctions.openToast(msg, 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  // Universal setting switch update function

  updateSettings(endpoint, value, name) {
    var obj = {};
    obj["value"] = value;
    this.http.patchData("settings/" + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + " settings updated", 3000, "success");
      this.setValue("a", endpoint, value);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

  // ROLES AND PERMISSIONS CHANGE

  addUpdateRole() {
    if (this.selected_role["id"] == "new") {
      var n = this.updated_center_settings.role_groups.roles.length;
      var newRoleData = JSON.parse(JSON.stringify(this.updated_center_settings.role_groups.roles[n - 1]));

      delete newRoleData["id"];
      newRoleData["display_name"] = this.selected_role["display_name"];
      newRoleData["name"] = newRoleData["display_name"].split(" ").join("");
      this.http.sendData("roles" + this.include_center, newRoleData).subscribe(success => {
        success = success;
        var msg = "New role is successfully saved!";
        var i = 0;
        this.updated_center_settings.role_groups.roles.forEach((item, index) => {
          if (item.id == "new") {
            i = index;
          }
        });
        this.updated_center_settings.role_groups.roles[i] = success.data;
        this.generalFunctions.openToast(msg, 3000, "success");
        setTimeout(() => {
          this.role_nav.nativeElement.getElementsByTagName("li")
          [i].dispatchEvent(new Event("click"));
        }, 100);
        this.new_role_saved = true;
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
        this.new_role_saved = false;
      });
      return false;
    }
    var endpoint = "roles/" + this.selected_role["id"] + this.include_center;
    var obj = {};
    obj["display_name"] = this.selected_role["display_name"];

    this.http.updateData(endpoint, obj).subscribe(success => {
      success = success;
      var i;
      this.updated_center_settings.role_groups.roles.forEach((item, index) => {
        if (item.id == this.selected_role["id"]) {
          i = index;
        }
      });
      this.updated_center_settings.role_groups.roles[i] = success.data;
      var msg = "Role name is successfully changed!";
      this.generalFunctions.openToast(msg, 3000, "success");
      this.populatePermission(success.data.display_name, success.data.id, success.data.staff_count);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  deleteRole(id) {
    this.http.deleteData("roles/" + id + this.include_center).subscribe(success => {
      success = success;
      var i;
      this.updated_center_settings.role_groups.roles.forEach((item, index) => {
        if (item.id == id) {
          i = index;
        }
      });
      this.updated_center_settings.role_groups.roles.splice(i, 1);
      var len = this.updated_center_settings.role_groups.roles.length;
      if (i == len) {
        i = -1;
      }
      this.role_nav.nativeElement.children[i + 1].click();
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  addRoleStructure() {
    var newRoleStructure = {};
    newRoleStructure["display_name"] = "Sample role";
    newRoleStructure["id"] = "new";
    newRoleStructure["permissions"] = [];
    this.updated_center_settings.role_groups.default_permissions.forEach((item, index) => {
      var permission = {};
      permission["display_name"] = item.display_name;
      permission["name"] = item.name;
      permission["settings"] = null;
      if (item.name == "sale-show-all") {
        permission["settings"] = {};
        permission["settings"]["limit_transactions"] = false;
        permission["settings"]["limit_upto_days"] = 30;
      }
      permission["activated"] = true;
      newRoleStructure["permissions"].push(permission);
    });

    this.updated_center_settings.role_groups.roles.push(newRoleStructure);

    setTimeout(() => {
      this.role_nav.nativeElement.lastElementChild.click();
      this.role_name_input.nativeElement.focus();
      this.new_role_saved = false;
    }, 50);
  }

  populatePermission(name, id, staff) {
    this.selected_role["display_name"] = name;
    this.selected_role["id"] = id;
    this.selected_role["staff_count"] = staff;
    var i;
    this.updated_center_settings.role_groups.roles.forEach((item, index) => {
      if (item.id == id) {
        i = index;
      }
    });
    var rolePermissions = {};
    this.updated_center_settings.role_groups.roles[i].permissions.forEach((item, index) => {
      rolePermissions[item.name] = item.activated;
      if (item.name == "sale-show-all") {
        this.selected_role["limit_transactions"] = item.settings.limit_transactions;
        this.selected_role["limit_upto_days"] = item.settings.limit_upto_days;
      }
    });
    console.log(rolePermissions);
    this.selected_role["permissions"] = rolePermissions;
  }

  changePermission(role_id, permission_name, permission_status) {
    var obj = {};
    obj["permissions"] = [];
    obj["permissions"][0] = {};
    obj["permissions"][0]["name"] = permission_name;
    obj["permissions"][0]["display_name"] = permission_name.split("-").join(" ");
    var type = !permission_status
      ? "/removePermission"
      : "/addPermission";
    var endpoint = "roles/" + role_id + type + this.include_center;

    this.http.updateData(endpoint, obj).subscribe(success => {
      success = success;
      var i;
      this.updated_center_settings.role_groups.roles.forEach((item, index) => {
        if (item.id == role_id) {
          i = index;
        }
      });
      this.updated_center_settings.role_groups.roles[i] = success.data;
      this.populatePermission(success.data.display_name, success.data.id, success.data.staff_count);
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  updateRoleHistoryRestriction(role_id, bool) {
    var obj = {
      update_settings: {
        limit_transactions: bool,
        limit_upto_days: this.selected_role.limit_upto_days
      }
    };
    var endpoint = "roles/" + role_id + "/permissionSetting/sale-show-all" + this.include_center;

    this.http.updateData(endpoint, obj).subscribe(success => {
      success = success;
      var i;
      this.updated_center_settings.role_groups.roles.forEach((item, index) => {
        if (item.id == role_id) {
          i = index;
        }
      });
      this.updated_center_settings.role_groups.roles[i] = success.data;
      this.populatePermission(success.data.display_name, success.data.id, success.data.staff_count);
      this.generalFunctions.openToast("Setting updated", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  updateRoleHistoryLimit(role_id, no) {
    if (no < 1) {
      this.generalFunctions.openToast("Enter valid number", 3000, "error");
      return false;
    }

    var obj = {
      update_settings: {
        limit_upto_days: no,
        limit_transactions: this.selected_role.limit_transactions
      }
    };
    var endpoint = "roles/" + role_id + "/permissionSetting/sale-show-all" + this.include_center;

    this.http.updateData(endpoint, obj).subscribe(success => {
      success = success;
      var i;
      this.updated_center_settings.role_groups.roles.forEach((item, index) => {
        if (item.id == role_id) {
          i = index;
        }
      });
      this.updated_center_settings.role_groups.roles[i] = success.data;
      this.populatePermission(success.data.display_name, success.data.id, success.data.staff_count);
      this.generalFunctions.openToast("Setting updated", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  // Biometric methods

  setupBiometric() {
    var err = null;
    if (!this.biometric_data["device_name"]) {
      err = "Device name is required";
    }
    if (!this.biometric_data["serial_number"]) {
      err = "Serial number is required";
    }
    if (!this.biometric_data["ip_address"]) {
      err = "IP address is required";
    }

    if (err) {
      this.generalFunctions.openToast(err.message, 2000, "error");
      return false;
    }

    this.biometric_popup_step = 2;
  }

  finishBiometricIntegration() {
    this.http.sendData("biometric/add" + this.include_center, this.biometric_data).subscribe(success => {
      var msg = "Biometric connection is under progress";
      this.generalFunctions.openToast(msg, 3000, "success");
      this.biometric_popup = false;
      this.biometric_data["status"] = true;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  updateBiometric() {
    var obj = {};
    obj["ip_address"] = this.biometric_data["ip_address"];
    this.http.sendData("biometric/edit" + this.include_center, obj).subscribe(success => {
      var msg = "IP address for biometric is updated!";
      this.generalFunctions.openToast(msg, 3000, "success");
      this.biometric_popup = false;
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  getBiometricData() {
    this.http.getData("biometric/details" + this.include_center).subscribe(success => {
      this.biometric_data = success.data;
      if (this.biometric_data["ip_address"]) {
        this.biometric_data["status"] = true;
      } else {
        this.biometric_data["status"] = false;
      }
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }

  // Migration Methods

  onCustomerMigration(e) {
    var files = e.currentFiles;
    if (files.length > 0) {
      let formData: FormData = new FormData();
      formData.append("import", files[0]);
      this.http.sendFormData("customer/import" + this.include_center, formData).subscribe(success => {
        var msg = "You will be notified when migration is complete!";
        this.generalFunctions.openToast(msg, 3000, "success");
        this.getMigrationData();
      }, error => {
        this.generalFunctions.openToast(error.message, 3000, "error");
        this.valid_file = false;
      });
    } else {
      this.valid_file = false;
    }
  }

  filterMigratedData(b) {
    var endpoint = null;
    switch (b) {
      case "all":
        this.selected_tag_migrated_data = "all";
        endpoint = "contact/formlink" + this.include_center + "&source=migration" + "&log_id=" + this.migration_data["uuid"];
        break;

      case "completed":
        this.selected_tag_migrated_data = "completed";
        endpoint = "contact/formlink" + this.include_center + "&source=migration&type=submitted" + "&log_id=" + this.migration_data["uuid"];
        break;

      case "pending":
        this.selected_tag_migrated_data = "pending";
        endpoint = "contact/formlink" + this.include_center + "&source=migration&type=pending" + "&log_id=" + this.migration_data["uuid"];
        break;
    }
    this.getMigratedData(endpoint);
  }

  deleteMigratedFile() {
    this.http.deleteData("setup/migration" + this.include_center).subscribe(success => {
      this.migration_file_delete_modal = false;
      this.migration_complete = false;
      this.migration_data = {
        message: "No file us uploaded"
      };
      this.selected_tag_migrated_data = "all";
      this.generalFunctions.openToast("File successfully removed!", 3000, "success");
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "error");
    });
  }

  resendFormLink(no) {
    var obj = {};
    obj["phone"] = no;
    this.http.sendData("contact/add" + this.include_center, obj).subscribe(success => {
      var msg = "Formlink is resent to " + no + " succesfully.";
      this.generalFunctions.openToast(msg, 3000, "success");
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, "error");
    });
  }


  deleteFormLink(id, no) {
    var endpoint = "contact/formlink/" + id + this.include_center;
    this.http.deleteData(endpoint).subscribe(success => {
      var msg = "Formlink to " + no + " is succesfully deleted.";
      this.generalFunctions.openToast(msg, 3000, "success");
      var endpoint = "contact/formlink" + this.include_center + "&source=migration" + "&log_id=" + this.migration_data["uuid"];
      this.getMigratedData(endpoint);
      this.selected_tag_migrated_data = "all";
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "success");
    });
  }

  connectStripe() {
    this.http.getData("settings/stripe/oauth" + this.include_center).subscribe(success => {
      window.location.href = success.data.url;
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, "success");
    });
  }

  openSetup() {
    this.pop_up_for = 'stripe';
    if(this.stripeOn) {
        this.view = 'settings'; this.install = true;
    }else {
        this.view = 'about'; this.install = false;

    }
  }
  triggerView(event) {
    this.view = event;
}

addExistingKey () {
    this.addingKey = true;
    const payload = {
        existing_center_id: this.selectedCenter
    }
    this.http.sendData(`apps/stripe/link` + this.include_center, payload)
    .subscribe(success => {
        this.stripeOn = true;
        this.generalFunctions.openToast('Key added successfully', 3000, 'success');
        this.addingKey = false;
        this.connectMode = 'new';
        this.getCenter();
    },
    err => {
        this.addingKey = false;
        this.generalFunctions.openToast(err.message, 3000, 'error');
    })
}
}
