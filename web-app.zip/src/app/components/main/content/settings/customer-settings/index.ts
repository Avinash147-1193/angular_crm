export * from "./customer-settings.component";
