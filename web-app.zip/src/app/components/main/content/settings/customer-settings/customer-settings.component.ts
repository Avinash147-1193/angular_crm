import {Component, OnInit} from '@angular/core';
import {GeneralServices} from "../../../../../common/general-services";
import {ServerAuthService} from "../../../../../common/server-auth";

@Component({
    selector: 'app-customer-settings',
    templateUrl: './customer-settings.component.html',
    styleUrls: ['../business-settings/business-settings.component.scss', '../settings.component.scss']})


    export class CustomerSettingsComponent implements OnInit {
        tab_id = 'tag';
        pop_up_for: any  = null;
        hoveredSource: any = null;
        sources: any;
        colors = ['#ff9500', '#21d37a', '#00ace0'];
        tags: any;
        include_center: any;
        newTag: any = {
            name: '',
            color: ''
        };
        tagRenameObj: any;

        constructor(private generalFunctions : GeneralServices, private http : ServerAuthService) {}

        ngOnInit(): void {
            // Called after the constructor, initializing input properties, and the first call to ngOnChanges.
            // Add 'implements OnInit' to the class.
            this.include_center = this.generalFunctions.includeCenter();
            this.getTags();

            this.sources = [
            {
                name : 'Student',
                editable: 'false',
                img: 'student-tag'
            },
            {
                name : 'Corporate',
                editable: 'false',
                img: 'corporate-tag'
            }
        ]
    }

    dltPopUp() {

    }

    addTags() {
        this.pop_up_for = 'source_add';
    }

    getTags() {
        this.http.getData(`tags${this.include_center}`).subscribe(response => {
            this.tags =  response.tags.filter(tag => tag.is_system === 0)
          console.log('tags', this.tags)
        })
    }

    createTag() {
        let reqObj = {
            tag_name : this.newTag.name,
            tag_color : this.newTag.color
        }
        this.http.sendData(`tag/create${this.include_center}`, reqObj).subscribe(response => {
            this.generalFunctions.openToast(response.message, 3000, 'success');
            this.newTag = {
                name : '',
                color : ''
            }
            this.getTags();
            this.pop_up_for = null;
          },
          err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
            this.pop_up_for = null;
          }
          )
    }

    renameTag() {
        let reqObj = {
            tag_id : this.tagRenameObj.id,
            tag_name : this.tagRenameObj.name,
            tag_color : this.tagRenameObj.tag_color
        }
        this.http.updateData(`tag/edit${this.include_center}`, reqObj).subscribe(response => {
            console.log('tags', response);
            this.generalFunctions.openToast(response.message, 3000, 'success');
            this.tagRenameObj = {};
            this.getTags();
            this.pop_up_for = null;
          },err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
            this.pop_up_for = null;
          })
    }

    dj(tag){
        console.log('tag', tag)
    }

    deleteTag(tag) {
        const reqObj = {
            tag_id : tag.id
        }
        this.http.deleteData(`tags/${tag.id}${this.include_center}`).subscribe(response => {
            console.log('tags', response);
            this.generalFunctions.openToast(response.message, 3000, 'success');
            this.tagRenameObj = {};
            this.getTags();
            this.pop_up_for = null;
          },err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
            this.pop_up_for = null;
          })
    }
}

