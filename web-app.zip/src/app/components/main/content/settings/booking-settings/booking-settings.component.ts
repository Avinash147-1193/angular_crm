import {Component, OnInit, ViewChild, ViewEncapsulation, ElementRef} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from '../../../../../common/general-services';
import {ServerAuthService} from '../../../../../common/server-auth';
import * as moment from 'moment';

@Component({selector: 'app-booking-settings', templateUrl: './booking-settings.component.html',
styleUrls: ['../settings.component.scss'], encapsulation: ViewEncapsulation.None})
export class BookingSettingsComponent implements OnInit {

  @ViewChild('noShow') noShow: ElementRef;
  @ViewChild('cancellation') cancellation: ElementRef;


  tab_id: any;
  center_settings: any = null;
  updated_center_settings: any = {
    administration: {
      classes: {
        calendar_view: '2 weeks '
      },
      booking_ahead : {
          limit: 0,
          status: false,
          allow_staff_override: false
      }
    }
  };
  got_setting: boolean = false;
  include_center: any;
  waitlist: boolean;
  newCategory: any;
  allCategory: any;
  pop_up_for: any = null;
  temp: any;
  currency: any;
  policy: any;
  createPolicy: any = {};
  newPolicyStructure: any = {
    'name': '',
    'description': '',
    'free_cancelation_window': 0,
    'late_cancelation_type': 1,
    'late_cancelation_unlimited_credits_charge': 0,
    'late_cancelation_refund_charge': null,
    'noshow_type': 1,
    'noshow_unlimited_credits_charge': null,
    'noshow_fee': 0
  };
  policyEditMode = false;
  deletePolicyObj: any;

  constructor(private generalFunctions: GeneralServices, private http: ServerAuthService) {}

  ngOnInit() {
    this.tab_id = 'general';
    this.include_center = this.generalFunctions.includeCenter();
    this.currency = this.generalFunctions.getCurrency();
    this.getSettings();
    this.getAllCategory();
    this.getPolicy();
    // this.updateSettings("administration.classes.waitlist.dnd.starts_at", "21:00", "asa");
  }


  getSettings() {
    this.http.getData('settings' + this.include_center).subscribe(success => {
      success = success;

      this.center_settings = this.updated_center_settings = success;
      this.updated_center_settings.administration.classes.waitlist.slots > 0
        ? (this.waitlist = true)
        : (this.waitlist = false);


        this.updated_center_settings.administration.classes.bookings.window.endAt = this.updated_center_settings.administration.classes.bookings.window.end.split(' ')[0]
        this.updated_center_settings.administration.classes.bookings.window.endAs = this.updated_center_settings.administration.classes.bookings.window.end.split(' ')[1]



        this.updated_center_settings.administration.appointments.bookings.window.endAt = this.updated_center_settings.administration.appointments.bookings.window.end.split(' ')[0]
        this.updated_center_settings.administration.appointments.bookings.window.endAs = this.updated_center_settings.administration.appointments.bookings.window.end.split(' ')[1]





      this.updated_center_settings.administration.classes.waitlist.dnd.starts_at = this.prepareDNDdate(this.updated_center_settings.administration.classes.waitlist.dnd.starts_at);
      this.updated_center_settings.administration.classes.waitlist.dnd.ends_at = this.prepareDNDdate(this.updated_center_settings.administration.classes.waitlist.dnd.ends_at);

      if (success.role_groups.roles[0]) {
        var name = success.role_groups.roles[0].display_name;
        var id = success.role_groups.roles[0].id;
        var staff_count = success.role_groups.roles[0].staff_count;

        this.got_setting = true;
      }
    }, err => {
      this.generalFunctions.openToast(err.message, 3000, 'error');
    });
  }

  prepareDNDdate(time) {
    let d = new Date();
    // let time = date.toLocaleTimeString();

    let hh = time.substr(0, 2);
    let mm = time.substr(3, 2);
    let ss = 0;

    d.setHours(hh, mm, ss);

    return d;
  }

  updateSettings(endpoint, value, name) {
    if (endpoint == 'administration.classes.waitlist.dnd.starts_at' || endpoint == 'administration.classes.waitlist.dnd.ends_at') {
      console.log('value', value);

      value = moment(value).format('HH:mm');
      console.log('value', value);
    }


    if (endpoint == 'administration.classes.bookings.window.end') {
        value  = `${this.updated_center_settings.administration.classes.bookings.window.endAt} ${this.updated_center_settings.administration.classes.bookings.window.endAs}`
      }

      if (endpoint == 'administration.appointments.bookings.window.end') {
        value  = `${this.updated_center_settings.administration.appointments.bookings.window.endAt} ${this.updated_center_settings.administration.appointments.bookings.window.endAs}`
      }

    var obj = {};
    obj['value'] = value;
    this.http.patchData('settings/' + endpoint + this.include_center, obj).subscribe(success => {
      success = success;
      var value = success.value;
      this.generalFunctions.openToast(name + ' settings updated', 3000, 'success');

      if (endpoint == 'administration.classes.waitlist.dnd.starts_at') {
        this.updated_center_settings.administration.classes.waitlist.dnd.starts_at = this.prepareDNDdate(value);
      } else if (endpoint == 'administration.classes.waitlist.dnd.ends_at') {
        this.updated_center_settings.administration.classes.waitlist.dnd.ends_at = this.prepareDNDdate(value);
      } else {
        this.setValue('a', endpoint, value);
      }
    }, error => {
      this.generalFunctions.openToast(error.message, 3000, 'error');
      this.updated_center_settings.endpoint = this.center_settings.endpoint;
    });
  }

changeWaitlist(value) {
    console.log('value', value)
    if (value) {
        this.updateSettings('administration.classes.waitlist.removal_window',
        '0 hours',
        'Waitlist slots')
    }
}

  setValue(i, endpoint, value) {
    endpoint = endpoint.split('.');
    if (endpoint.length == 1) {
      this.updated_center_settings[endpoint[0]] = value;
    }
    if (endpoint.length == 2) {
      this.updated_center_settings[endpoint[0]][endpoint[1]] = value;
    }
    if (endpoint.length == 3) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]] = value;
    }
    if (endpoint.length == 4) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]] = value;
    }
    if (endpoint.length == 5) {
      this.updated_center_settings[endpoint[0]][endpoint[1]][endpoint[2]][endpoint[3]][endpoint[4]] = value;
    }
  }

  createCategory() {
    if (this.newCategory.length <= 0) {
      this.generalFunctions.openToast('Please provide valid category name', 3000, 'error');
      return;
    }
    this.http.sendData(`categories${this.include_center}`, {name: this.newCategory}).subscribe(success => {
      this.pop_up_for = null;
      this.getAllCategory();
    }, err => {
      console.log('err :', err);
    });
  }

  getAllCategory() {
    this.http.getData(`categories${this.include_center}`).subscribe(success => {
      this.allCategory = success.data;
    }, err => {
      console.log('err :', err);
    });
  }

  renameCategory(category) {
    if (category.name.length <= 0) {
      this.generalFunctions.openToast('Please provide valid category name', 3000, 'error');
      return;
    }
    this.http.updateData(`categories/${category.id}${this.include_center}`, {name: category.name}).subscribe(success => {
      this.getAllCategory();
      this.pop_up_for = null;
    }, err => {
      this.generalFunctions.openToast('Category can not be renamed', 3000, 'error');
    });
  }

  deleteCategory(category) {
    this.http.deleteData(`categories/${category.id}${this.include_center}`).subscribe(success => {
      this.getAllCategory();
      this.pop_up_for = null;
      this.generalFunctions.openToast('Category deleted', 3000, 'success');
    }, err => {
      this.generalFunctions.openToast('Category can not be deleted', 3000, 'error');
    });
  }

  deletePop(category) {
    this.pop_up_for = 'delete';
    this.temp = {
      ...category
    };
  }

  renamePop(category) {
    this.pop_up_for = 'rename';
    this.temp = {
      ...category
    };
  }

  disableWaitlist() {
    if (this.waitlist === false) {
      this.updateSettings('administration.classes.waitlist.slots', 0, 'Waitlist');
    }
  }



    clickedRef() {
        this.noShow.nativeElement.focus();
    }

    clickedRefCancellation() {
        this.cancellation.nativeElement.focus();
    }

    getPolicy() {
        this.http.getData('policies' + this.include_center).subscribe(success => {
            this.policy = success.data;
        }, err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
        })
    }

    addPolicy() {
      this.http.sendData(`policies${this.include_center}`, this.createPolicy)
      .subscribe(response => {
        this.generalFunctions.openToast('Policy added successfully', 3000, 'success');
        this.getPolicy();
        this.pop_up_for = null;
      }, err => {
        this.getPolicy();
        this.pop_up_for = null;
        this.generalFunctions.openToast(err.message, 3000, 'error');
      })
    }

    savePolicy() {
        const reqObj = {};
            ({
                name: reqObj['name'],
                description: reqObj['description'],
                free_cancelation_window: reqObj['free_cancelation_window'],
                late_cancelation_type: reqObj['late_cancelation_type'],
                late_cancelation_unlimited_credits_charge: reqObj['late_cancelation_unlimited_credits_charge'],
                late_cancelation_refund_charge: reqObj['late_cancelation_refund_charge'],
                noshow_type: reqObj['noshow_type'],
                noshow_unlimited_credits_charge: reqObj['noshow_unlimited_credits_charge'],
                noshow_fee: reqObj['noshow_fee'],
            }  = this.createPolicy);

        this.http.updateData(`policies/${this.createPolicy.id}` + this.include_center, reqObj)
        .subscribe(response => {
          this.generalFunctions.openToast('Policy updated successfully', 3000, 'success');
          this.getPolicy();
          this.pop_up_for = null;
        }, err => {
          this.getPolicy();
          this.pop_up_for = null;
          this.generalFunctions.openToast(err.message, 3000, 'error');
        })
      }

    capturePolicy(id) {
        this.pop_up_for = 'new-policy';
        this.policyEditMode = true;
        this.http.getData(`policies/${id}` + this.include_center).subscribe(success => {
            this.createPolicy = success.policy;
            // this.createPolicy['is_default'] = 1;
            console.log('this.createPolicy', this.createPolicy)
        }, err => {})
    }

    deletePolicy(id) {
        this.http.deleteData(`policies/${id}` + this.include_center).subscribe(success => {
            this.pop_up_for = null;
            this.getPolicy();
            this.generalFunctions.openToast('Policy deleted', 2000, 'success');
        }, err => {
            this.generalFunctions.openToast(err.message, 2000, 'success');
        })
    }

    clearState() {
        this.newPolicyStructure = {
            'name': '',
            'description': '',
            'free_cancelation_window': 0,
            'late_cancelation_type': 1,
            'late_cancelation_unlimited_credits_charge': 0,
            'late_cancelation_refund_charge': null,
            'noshow_type': 1,
            'noshow_unlimited_credits_charge': null,
            'noshow_fee': 0
          }
    }
}
