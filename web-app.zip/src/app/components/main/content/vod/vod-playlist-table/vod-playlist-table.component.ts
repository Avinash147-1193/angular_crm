import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GeneralServices } from 'app/common/general-services';
import { ServerAuthService } from 'app/common/server-auth';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-vod-playlist-table',
  templateUrl: './vod-playlist-table.component.html',
  styleUrls: ['./vod-playlist-table.component.scss',  '../../../../../components/main/content/services/styles/service-list.scss']
})
export class VodPlaylistTableComponent implements OnInit {
    center_id: any;
    client_id: any;
    playlist: any;
    loader = false;
    hovered = null;


    constructor(private generalFunctions: GeneralServices,
        private http: ServerAuthService) { }

  ngOnInit(): void {
    this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
    this.client_id = JSON.parse(localStorage.getItem('currentUser'))['client_id'];

    this.getPlaylist();
  }


  getPlaylist() {
      this.loader = true;

    this.http.getData(`playlists?client_id=${this.client_id}&center_id=${this.center_id}`).subscribe((response) => {
        this.playlist = response.data.sort((a,b) => a.order - b.order);
        this.loader = false;
    },(error) => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
    })
  }

  durationConverter(time) {
   return this.generalFunctions.secToMin(time)
  }

  dropGroup(event) {

    moveItemInArray(this.playlist, event.previousIndex, event.currentIndex);

    const newResObj = Object.values(this.playlist);
    const arr = [];
    newResObj.forEach((element, index) => {
      const obj = {
        playlist_id: element['id'],
        order: index + 1
      };
      arr[index] = obj;
    });


    this.http.updateData('playlists/order?center_id=' + this.center_id, {playlists : arr}).subscribe(response => {
    }, err => {
    });
  }

}
