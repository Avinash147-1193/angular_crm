import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VodPlaylistTableComponent } from './vod-playlist-table.component';

describe('VodPlaylistTableComponent', () => {
  let component: VodPlaylistTableComponent;
  let fixture: ComponentFixture<VodPlaylistTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VodPlaylistTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VodPlaylistTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
