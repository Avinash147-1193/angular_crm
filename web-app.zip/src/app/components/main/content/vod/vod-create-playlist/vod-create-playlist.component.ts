import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GeneralServices } from 'app/common/general-services';
import { ServerAuthService } from 'app/common/server-auth';
import { MembershipTypes, ServiceId } from 'app/constants';
import { SelectItem } from 'primeng/api/selectitem';
import { Price } from '../../services/models/schedule.model';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';


@Component({
  selector: 'app-vod-create-playlist',
  templateUrl: './vod-create-playlist.component.html',
  styleUrls: ['./vod-create-playlist.component.scss', '../../../../../components/main/content/services/styles/services.scss', '../../../../../components/main/content/services/styles/schedule.scss']
})
export class VodCreatePlaylistComponent implements OnInit {
    membershipPlans: any;
    membershipPacks: any;
    memberships: any;
    membershipsGroup: any;
    addVideoModal: boolean;
    playlistId: string;
    client_id: any;
    videos: any;
    addedVideos: any;
    preparedVideos: any;
    pop_up_for:any = null;

  constructor(private generalFunctions: GeneralServices,
    private router: Router,
    private http: ServerAuthService,
    private activatedRoute: ActivatedRoute,) { }

    center_id: any;
    isNewPlaylist = true;
    currentSection = 1;
    pageLoader = false;
    validationFields: any = {
        className: false,
    };
    nextOne: boolean = false;
    nextTwo: boolean = false;
    playlist: any = {
        name: '',
        category: 0,
        description: '',
        big_description:'',
        category_id: 0,
        users: [],
        price_type: 2,
        pricing: [],
        image: null,
        login_required: 1,
        is_published: 1
    };
    priceType: any = 6;
    pricingLoader: any = false;
    newPricingService: any = [];
    categories: any;
    categoriesDropdown: SelectItem[] = [];
    trainersDropdown: SelectItem[] = [];

    ngOnInit(): void {
        this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
        this.client_id = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
        this.getCategories();
        this.getTrainers();
        this.getAllVideos();

      if (this.router.url.includes('/playlist/create')) {
        this.isNewPlaylist = true;
        this.getMembershipPlans();


      } else {
        this.isNewPlaylist = false;

        this.playlistId = this.activatedRoute.snapshot.paramMap.get('id');
        this.getPlaylist();
    }
}

getPlaylist(){
    this.http.getData(`playlists/${this.playlistId}?client_id=${this.client_id}&center_id=${this.center_id}`).subscribe((response) => {
        console.log('playlist', response);
        this.transformPlaylistData(response.data);
    },(error) => {
        this.generalFunctions.openToast(error.message, 3000, 'error');
    })
}

    transformPlaylistData(data){
        const instructors = [];
        data.users.forEach(element => {
            instructors.push(element.user_id)
        })




        this.playlist = {
            name: data.name,
            category: 0,
            description: data.description,
            big_description: data.big_description,
            is_published:data.is_published,
            category_id: data.category_id,
            users: instructors,
            price_type: data.price_type,
            pricing: data.pricing,
            image: data.image,
            videos: data.videos.sort((a,b) => a.order-b.order),
            login_required : data.login_required
        };



         if (this.playlist.price_type == 2 || this.playlist.price_type == 3) {
            this.priceType = 6;
          } else if (data.price_type == 1) {
            this.priceType = 1;

          }
          this.getMembershipPlans();
          this.getAllVideos();
          console.log('this.playlist', this.playlist)
    }

    getAllVideos() {
        this.http.getData('videos?center_id=' + this.center_id)
            .subscribe(
                (response) => {
                    this.videos = response.data;
                    if(!this.isNewPlaylist){
                        this.videos.forEach((vid, i)  => {
                            this.playlist.videos.forEach((playlistVid,j) => {
                                if(vid.id === playlistVid.video_id) {
                                    this.videos[i].checked = true;
                                    this.videos[i].is_free = playlistVid.is_free;
                                    this.videos[i].order = playlistVid.order
                                 }
                            });
                        });
                        this.videoToList();
                        console.log('this.videos', this.videos)
                      }
                },
                (error) => this.generalFunctions.openToast(error.message, 3000, 'error'))
    }

    mapImageUrl(event) {
        this.playlist.image = event;
    }

    formValidate(field) {
        let isValid = true;

        switch (field) {
        case 'class-name':
            isValid = !this.playlist.name.replace(/\s/g, '').length
            ? false
            : true; //check if field contains only whitespaces
            this.validationFields.className = isValid;
            break;

        // case 'class-size':
        //     isValid = this.playlist.max_allowed > 0
        //     ? true
        //     : false;
        //     this.validationFields.classSize = isValid;
        //     break;

        default:
            break;
        }

        return !isValid;
    }

    goToNext(current, next) {
        switch (current) {
        case 1:
            this.nextOne = true;

            if (!this.validationFields.className) {
              this.generalFunctions.scrolltoinvalid('className');
              this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
              return;
            }
            break;

        case 2:
            this.nextTwo = true;

            // this.isDaysScheduleValid = this.getDaysScheduleValidityStatus();

            // if (!this.isDaysScheduleValid) {
            //   this.generalFunctions.openToast('Please select at least one day for the class schedule', 3000, 'error');
            //   return;
            // }

        default:
            break;
        }

        this.currentSection++;
        document.getElementById(next).click();
    }

    goBack(collapse) {
        this.currentSection--;
        document.getElementById(collapse).click();
    }

    priceTypeChange() {
        if (this.priceType == 6) {
        this.playlist.price_type = 2;
        }
        if (this.priceType === 1) {
        this.playlist.price_type = 1;
        }
    }

    getCategories() {
        this.http.getData('categories?center_id=' + this.center_id ).subscribe(response => {
        this.categories = response.data;
        this.prepareCategoriesDropdown();
        }, err => {
        err = err;
        this.generalFunctions.openToast(err.message, 3000, 'error');
        });
    }

    prepareCategoriesDropdown() {
        for (let i = 0; i < this.categories.length; i++) {
        let category = {
            label: '',
            value: 0
        };
        category.label = this.categories[i].name;
        category.value = this.categories[i].id;
        this.categoriesDropdown.push(category);
        }
        this.pageLoader = false;
    }

    getTrainers() {
        this.http.getData('staff?center_id=' + this.center_id).subscribe(response => {
        const trainers = response.data;
          this.prepareTrainersMultiselect(trainers);
        }, err => {
          this.generalFunctions.openToast(err.message, 3000, 'error');
        }, () => {});
    }

    prepareTrainersMultiselect(trainers) {
        for (let i = 0; i < trainers.length; i++) {
            let trainer = {
            label: '',
            value: 0
            };

            trainer.label = trainers[i].first_name + ' ' + trainers[i].last_name;
            trainer.value = trainers[i].id;

            this.trainersDropdown.push(trainer);
        }
    }


  getMembershipPlans() {
    let reqObj = {};
    this.http.sendData('plan?center_id=' + this.center_id, reqObj).subscribe(response => {
      this.membershipPlans = response.data.filter(plan => plan.type === MembershipTypes.PLAN || plan.type === MembershipTypes.SUBSCRIPTION);
      this.membershipPacks = response.data.filter(pack => pack.type === MembershipTypes.PACK);
      this.memberships = response.data;
      this.createMembershipsArray()
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, 'error');
    }, () => {});
  }

  createMembershipsArray() {
    this.http.getData('groups?service_id=1&center_id=' + this.center_id).subscribe(response => {
        this.membershipsGroup = response.data.sort((a, b) => a.order - b.order);
        this.membershipsGroup.length = response.data.length;
        this.createMembershipsPricingArray();

        }, err => {});
  }

  createMembershipsPricingArray() {
    let newServicePacks = this.membershipsGroup;
    this.membershipsGroup.forEach((element, index) => {
      newServicePacks[index].pack = [];
      this.memberships.forEach((e, i) => {
        if (e.service_group_id == element.id) {

          newServicePacks[index].pack.push({
              planId : e.id,
              planName : e.name,
              isChecked : false,
              type : 'plan',
            });
        }
      });
    });

    this.newPricingService = newServicePacks.concat(this.newPricingService);

  if (!this.isNewPlaylist) {
        this.pricingLoader = true;
        this.preparePricingForm();
  }
}



preparePricingForm() {
    switch (this.playlist.price_type) {
    case 3:
        for (let i = 0; i < this.playlist.pricing.length; i++) {
          let price = this.playlist.pricing[i];
            this.newPricingService.forEach(group => {
                for (let j = 0; j < group.pack.length; j++) {
                      if (group.pack[j].planId === price.service_type_id) {
                        group.pack[j].customerType = price.customer_type;
                        group.pack[j].planId = price.service_type_id;
                        group.pack[j].isChecked = true;
                        group.pack[j]['type'] = 'plan'
                        group.pack[j].planName = group.pack[j].planName;
                    }
                  }
            });
        }
        break;

        default:
        break;
    }
    this.pricingLoader = false;
  }

  preparePricingArray() {
    let pricingArray = [],
      singlePlan,
      reqPlan;

    const newPricePlanPack  = this.newPricingService;


    // No charge
    if (this.priceType === 1) {
      this.playlist.price_type = 1;
      pricingArray = [
        // Price by customer type
      ];
    }
    if (this.priceType === 6) {
        newPricePlanPack.forEach(group => {
            for (let i = 0; i < group.pack.length; i++) {
                singlePlan = Object.assign({}, group.pack[i]);
                reqPlan = {};
                if (singlePlan.isChecked) {
                  reqPlan['service_type_id'] = singlePlan.planId;
                  reqPlan['service_id'] = singlePlan.type == 'plan'
                    ? ServiceId.SERVICE_ID_PLAN
                    : singlePlan.type == 'pack'
                      ? ServiceId.SERVICE_ID_PACK
                      : ServiceId.SERVICE_ID_PACK;
                  pricingArray.push(reqPlan);
                }
              }
        });

    }
    console.log('pricingArray', pricingArray)
    this.playlist['pricing'] = Object.assign({}, pricingArray);
  }

  createPlaylist() {
      this.preparePricingArray();
      this.prepareVideoList()

      let reqObj = {
        "name": this.playlist.name,
        "description": this.playlist.description,
        "big_description": this.playlist.big_description,
        "category_id": this.playlist.category_id,
        "is_published": this.playlist.is_published,
        "price_type": this.playlist.price_type,
        "image": this.playlist.image,
        "videos": this.preparedVideos,
        "users":this.playlist.users,
        "login_required" : this.playlist.login_required,
        "pricing": this.playlist.pricing,

      }
      this.http.sendData(`playlists?client_id=${this.client_id}&center_id=${this.center_id}`, reqObj).subscribe((response) => {
        this.routeBack();
        },(error) => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
  }

  prepareVideoList() {
      this.preparedVideos = this.addedVideos.map((video, index) => {

          return {
              "video_id" : video.id,
              "is_free" : video.is_free ? true : false,
              "order" : index+1
          }
      })
      console.log('this.preparedVideos', this.preparedVideos)
  }

  addVideo() {
      this.addVideoModal = true;
  }

  getFormStatus() {
    let isFormValid = true;
    // check if all input fields are valid
        for (var property in this.validationFields) {
        isFormValid = isFormValid && this.validationFields[property];
        if (!this.validationFields[property]) {
            this.generalFunctions.scrolltoinvalid(property);
            return isFormValid;
        }
        }
    }

  savePlaylist() {


    this.preparePricingArray();
    this.prepareVideoList();
    let reqObj = {
      "name": this.playlist.name,
      "description": this.playlist.description,
      "big_description": this.playlist.big_description,
      "category_id": this.playlist.category_id,
      "is_published": this.playlist.is_published,
      "price_type": this.playlist.price_type,
      "image": this.playlist.image,
      "videos": this.preparedVideos,
      "users":this.playlist.users,
      "login_required":this.playlist.login_required,
      "pricing": this.playlist.pricing
    }
    this.http.updateData(`playlists/${this.playlistId}?client_id=${this.client_id}&center_id=${this.center_id}`, reqObj)
    .subscribe((response) => {
        this.routeBack();
      },(error) => {
          this.generalFunctions.openToast(error.message, 3000, 'error');
      })
  }

  videoToList() {
    this.addedVideos =  this.videos.filter(item => item.checked).sort((a,b) => a.order-b.order);
    this.addVideoModal = false;
  }

  removeVideo(id) {
    this.addedVideos = this.addedVideos.filter(item => item.id !== id);
    this.videos.forEach(video => {
       if(video.id === id){
           video.checked = false;
       }
    });
  }

  deletePlaylist() {
    this.pop_up_for = null;

    this.http.deleteData(`playlists/${this.playlistId}?client_id=${this.client_id}&center_id=${this.center_id}`)
    .subscribe((response) => {
        this.generalFunctions.openToast('Deleted successfully', 3000, 'success');

        this.routeBack();
    },(error) => {
        this.routeBack();
        this.pop_up_for = null;

        this.generalFunctions.openToast(error.message, 3000, 'error');
    })
  }
  durationConverter(time) {
    return this.generalFunctions.secToMin(time)
   }
   dropGroup(event) {
    moveItemInArray(this.addedVideos, event.previousIndex, event.currentIndex);

  }

  routeBack() {
    this.router.navigate(['/client/services/vod/list'], {
        queryParams : {
          view : 'playlist'
        }
    });
  }
}
