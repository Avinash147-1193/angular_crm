import { HttpHeaders } from '@angular/common/http';
import {
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild
} from '@angular/core';
import { Router } from '@angular/router';
import {
    GeneralServices
} from 'app/common/general-services';
import {
    ServerAuthService
} from 'app/common/server-auth/server.auth';
import { environment } from 'environments/environment';

import {Upload} from 'tus-js-client';


@Component({
    selector: 'app-dan-vod-upload',
    templateUrl: './vod-upload.component.html',
    styleUrls: ['./vod-upload.component.scss']
})
export class VodUploadComponent implements OnInit {
    // [x: string]: any;
    uploadModal = true;
    @Output() valueChange = new EventEmitter();
    progress = [];
    validatingUrl: boolean;
    viaLink = false;
    cancelled  = [];
    @ViewChild("uploadLink") uploadLink;
  filenames: string[] = [];
    center_id: any;
    client_id: any;
    baseApiUrl: string;
    upload: Upload;
    vd: any;
    uploadsStream= [];

    constructor(private generalFunctions: GeneralServices,
        private router: Router,
        private http: ServerAuthService, ) {
            this.baseApiUrl = environment.baseUrl + "api/";
        };

    ngOnInit(): void {
        this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
        this.client_id = JSON.parse(localStorage.getItem('currentUser'))['client_id'];
        this.getAllVideos();


    };

    closeModel() {
        //checkprogress
        if (this.progress.length === 0){
            this.uploadModal = false;
            this.valueChange.emit(false);
        } else {
            const filtered = this.progress.filter(video => video.currentProgress !== '100%')
            console.log('filtered', filtered)
            if(filtered.length > 0){
                this.generalFunctions.openToast('Video uploading', 3000, 'error');
            } else {
                this.uploadModal = false;
                this.valueChange.emit(false);
            }
        }
    }

    imageClick(event) {
        document.getElementById("imageInput").click();
    }

    async getOneTimeUploadUrl(tus = false, fSize) {
        if(tus) {
            return await this.http.getData(`videos/url?tus=1&content_length=${fSize}&client_id=${this.client_id}&center_id=${this.center_id}`);
        } else {
            return await this.http.getData(`videos/url?client_id=${this.client_id}&center_id=${this.center_id}`);
        }
    }

    private getToken() {
        var token = JSON.parse(localStorage.getItem("currentUser")).token;
        return token;
      }


    async fileUpload(event) {
        console.log('event', event)
        let fSize = event.target.files[0].size;
        // if (event.target.files && event.target.files[0] && fSize < 180000000) {
         if (event.target.files && event.target.files[0] && fSize < 7242880 ) {

            let url = await this.getOneTimeUploadUrl(false, fSize);
            url.subscribe((result) => {
                const url = result.stream_response.result.uploadURL;
                const id  = result.video.id;
                const file = event.target.files[0];
                const uploadData = new FormData();
                uploadData.append("file", file);
                this.startPolling(id, file);

                this.http.sendData(`videos/${id}?client_id=${this.client_id}&center_id=${this.center_id}`,{name : file.name})
                .subscribe((response) => {},(error) => {this.generalFunctions.openToast(error.message, 3000, 'error');})

                this.http.videoUpload(url, uploadData).subscribe(response => {
                    this.getAllVideos();
                }, error => {
                    this.generalFunctions.openToast(error.message, 3000, 'error')
                })
            });
        } else {
            console.log('using tus protocol');
            var mediaId = '', vId = '';
            this.vd = vId;
            const file = event.target.files[0];
            let url = `${this.baseApiUrl}videos/url/tus?content_length=${fSize}&client_id=${this.client_id}&center_id=${this.center_id}`
            let that = this, once = true, twice = true;
            var options = {
                endpoint: url,
                headers: {

                    Accept: "application/x.gymday.v1+json",
                    Authorization: "Bearer" + this.getToken(),
                  },
                chunkSize: 5 * 1024 * 1024, // Required a minimum chunk size of 5MB, here we use 50MB.
                metadata: {
                  filename: file.name,
                  filetype: file.type,
                },
                uploadSize: fSize,
                onError: function (error) {
                    delete options.headers.Authorization;
                    throw error;
                },
                onProgress: function (bytesUploaded, bytesTotal) {
                  var percentage = (bytesUploaded / bytesTotal * 100).toFixed(2);
                //   console.log("video id", vId);
                       let time = Math.round(bytesUploaded / bytesTotal * 100)+ "%";
                    //    console.log(bytesUploaded, bytesTotal, percentage + "%", time);
                    //     console.log('vId, time', vId, time)
                        that.updateProgress(vId, time);
                        if (twice) {
                            that.updateName(file.name, vId);
                            twice = false;
                        }
                },
                onSuccess: function () {
                  console.log("Upload finished");

                },
                onAfterResponse: function (req, res) {
                  return new Promise<void>(resolve => {
                    delete options.headers.Authorization;
                    console.log(res)
                    var mediaIdHeader = res.getHeader("stream-media-id");
                    vId = res.getHeader("studioyou-video-id") ? res.getHeader("studioyou-video-id") : vId ;

                    if(once){
                        const progressingVideo = {
                            name: file.name,
                            size: (Math.round(file.size / 1000000)),
                            currentProgress: 0 + '%',
                            id: vId
                        };
                        that.progress.push(progressingVideo);
                        that.uploadsStream.push({up : that.upload, id: vId})

                        once = false;
                    }
                    if (mediaIdHeader) {
                        mediaId = mediaIdHeader;
                    }
                    resolve();
                  })
                }
              };
              console.log('options', options)
               this.upload = new Upload(file, options);
              this.upload.start();

        }

    }


    updateName(name, id){
        console.log('name, id', name, id)
        this.http.sendData(`videos/${id}?client_id=${this.client_id}&center_id=${this.center_id}`,{name : name})
        .subscribe((response) => {},(error) => {this.generalFunctions.openToast(error.message, 3000, 'error');})

    }



    startPolling(id, file) {

      let time, interval;
      this.startProgressing(file,id);

         interval = setInterval(() => {
            this.http.getData(`videos/${id}/info?client_id=${this.client_id}&center_id=${this.center_id}`)
            .subscribe((response) => {
                console.log('response.result.status.state', response.result.status.state)
                if(response.result.status.state !== 'error'){
                    time = !isNaN(response.result.status.pctComplete) ? Math.round(response.result.status.pctComplete) +'%' : '0%';
                    this.updateProgress(id, time);
                    if(time === '100%' || this.cancelled.includes(id)){
                        console.log('this.cancelled', this.cancelled)
                        clearInterval(interval);
                    }
                }
                else {
                    this.generalFunctions.openToast('Error in '+response.result.status.step, 3000, 'error');
                    this.removeProgressingVideo(id);
                    clearInterval(interval);
                }
            },(error) => {
                clearInterval(interval);
            })

        }, 10000);
    }

    removeProgressingVideo(id) {
        this.progress = this.progress.filter(video => video.id !== id);
    }

    getAllVideos() {
        this.http.getData('videos?center_id=' + this.center_id)
            .subscribe(
                (response) => console.log('response', response),
                (error) => this.generalFunctions.openToast(error.message, 3000, 'error'))
    }

    updateProgress(id, time){
       this.progress.forEach((element, index) => {
           if(id === element.id){
               this.progress[index].currentProgress = time;
               if (time === '100%') {
                console.log('call update here')
                this.http.updateData(`videos/${id}?client_id=${this.client_id}&center_id=${this.center_id}`, {
                big_description: '',
                description: '',
                category_id: '',
                users: []})
                .subscribe((response) => {

                }, (error) => {

                    this.generalFunctions.openToast(error.message, 3000, 'error');
                })
               }
           }
       });
    }

    startProgressing(file, id) {
        const progressingVideo = {
            name: file.name,
            size: (Math.round(file.size / 1000000)),
            currentProgress: 0 + '%',
            id: id
        };
        this.progress.push(progressingVideo);
    }

    uploadLinkState() {}

    checkValidUrl() {
        let event = this.uploadLink.nativeElement.value;
        this.validatingUrl = true;

        this.uploadViaLink(event);

        // var expression = /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;
        // let regEx = new RegExp(expression);
        // let dp = event.split('.');



        // if (event.match(regEx) &&  dp.includes('dropbox')) {
        //     let params = event.split('?');
        //     let onlyurl = params[0]+`?raw=1`;

        //     console.log('VALID', onlyurl)

        // } else {
        //     this.validatingUrl = false;
        //     this.generalFunctions.openToast('Please enter a valid url', 3000, 'error');
        // }
     }

    uploadViaLink(link) {
        // this.http.sendData(`videos/link?client_id=${this.client_id}&center_id=${this.center_id}`,{url : link, meta: { name : link}})

        this.http.sendData(`videos/link?client_id=${this.client_id}&center_id=${this.center_id}`, {url : link})
        .subscribe((response) => {
            console.log('response', response);

            this.http.sendData(`videos/${response.video.id}?client_id=${this.client_id}&center_id=${this.center_id}`,{name : response.stream_response.result.meta["downloaded-from"]})
            .subscribe((response) => {
                this.generalFunctions.openToast('Video from the link is getting uploaded', 3000, 'success');
                this.validatingUrl = false;
                this.viaLink = false;
                this.closeModel();

            },(error) => {this.generalFunctions.openToast(error.message, 3000, 'error');})

        },(error) => {
            this.generalFunctions.openToast(error.message, 3000, 'error')
            this.validatingUrl = false;
        })
    }


    cancelUpload(id) {

        let tusStream = this.uploadsStream.filter(item => item.id == id);
        console.log('this.uploadStream', tusStream[0]);

        if(tusStream.length > 0) {
            tusStream[0].up.abort();
        }

        this.http.deleteData(`videos/${id}?client_id=${this.client_id}&center_id=${this.center_id}`)
        .subscribe((response) => {
            this.generalFunctions.openToast('Cancelled successfully', 3000, 'success');
            this.removeProgressingVideo(id);
            this.cancelled.push(id);
        },(error) => {
            this.router.navigate(['/client/services/vod/list']);
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
    }

}
