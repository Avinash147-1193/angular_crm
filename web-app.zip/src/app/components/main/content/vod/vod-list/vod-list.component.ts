import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-vod-list',
  templateUrl: './vod-list.component.html',
  styleUrls: ['./vod-list.component.scss','../../../../../components/main/content/services/styles/service-list.scss']
})
export class VodListComponent implements OnInit {

    navigationList: Array < string > = ['videos', 'playlist' ];
    view: any= 'videos';
    uploadModal = false;
    default: any;

    constructor(private activatedRoute : ActivatedRoute, private router : Router) { }

    ngOnInit(): void {
        this.activatedRoute.queryParams.subscribe(params => {
            console.log('params', params)
            if (params["view"] == 'playlist') {
                this.default = this.view = 'playlist';
            }else if (params["view"] == 'videos') {
                this.default = this.view = 'videos';
            }

        })
    }

    triggerView(event) {
        this.view = event;
        this.router.navigate([], {
            queryParams: {
              'view': null,
            },
            queryParamsHandling: 'merge'
          })
    }

    switchView() {
        console.log('value changed');
        this.view = null;
        setTimeout(() => {
            this.view  = 'videos';
        }, 50);
    }

}
