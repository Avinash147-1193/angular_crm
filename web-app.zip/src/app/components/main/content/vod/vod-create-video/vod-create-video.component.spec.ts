import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VodCreateVideoComponent } from './vod-create-video.component';

describe('VodCreateVideoComponent', () => {
  let component: VodCreateVideoComponent;
  let fixture: ComponentFixture<VodCreateVideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VodCreateVideoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VodCreateVideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
