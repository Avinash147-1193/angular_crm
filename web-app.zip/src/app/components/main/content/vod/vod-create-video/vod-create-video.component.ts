import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GeneralServices } from 'app/common/general-services';
import { ServerAuthService } from 'app/common/server-auth';
import { SelectItem } from 'primeng/api/selectitem';

@Component({
  selector: 'app-vod-create-video',
  templateUrl: './vod-create-video.component.html',
  styleUrls: ['./vod-create-video.component.scss', '../../../../../components/main/content/services/styles/services.scss']
})
export class VodCreateVideoComponent implements OnInit {
    videoId: string;
    client_id: any;
    pop_up_for: any = null;


    constructor(private generalFunctions: GeneralServices,
        private router: Router,
        private http: ServerAuthService,
        private activatedRoute: ActivatedRoute,) { }

    isNewPlaylist = true;
    currentSection = 1;
    pageLoader = false;
    validationFields: any = {
        className: false,
        classSize: false
    };
    nextOne: boolean = false;
    nextTwo: boolean = false;
    playlist: any = {
        name: '',
        big_description: '',
        description: '',
        category_id: 0,
        users: [],
        image: null,
        is_published: true
    };
    priceType: any = 6;
    pricingLoader: any = false;
    newPricingService: any = [];
    categories: any;
    categoriesDropdown: SelectItem[] = [];
    center_id: any;
    trainersDropdown: SelectItem[] = [];

    ngOnInit(): void {
        this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
        this.client_id = JSON.parse(localStorage.getItem('currentUser'))['client_id'];

        this.getCategories();
        this.getTrainers();
        this.videoId = this.activatedRoute.snapshot.paramMap.get('id');
        this.getVideoData()

    }

    getVideoData(){
        this.http.getData(`videos/${this.videoId}?client_id=${this.client_id}&center_id=${this.center_id}`).subscribe((response) => {
            console.log('response', response);
            let data = response.data;
            this.playlist.name = data.name;
            this.playlist.image = data.image;
            this.playlist.big_description = data.big_description;
            this.playlist.description = data.description;
            this.playlist.category_id = data.category_id;
            this.playlist.users = data.users;
            this.playlist.is_published = data.is_published;

        },(error) => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
    }

    getPreview() {
        this.http.getData(`videos/${this.videoId}/signed?client_id=${this.client_id}&center_id=${this.center_id}`).subscribe((response) => {
            let url = `https://videodelivery.net/${response.signed_url.token}/thumbnails/thumbnail.gif`;
            window.open(url,'_blank');
        },(error) => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
    }

    getCategories() {
        this.http.getData('categories?center_id=' + this.center_id ).subscribe(response => {
        this.categories = response.data;
        this.prepareCategoriesDropdown();
        }, err => {
        err = err;
        this.generalFunctions.openToast(err.message, 3000, 'error');
        });
    }

    prepareCategoriesDropdown() {
        for (let i = 0; i < this.categories.length; i++) {
        let category = {
            label: '',
            value: 0
        };
        category.label = this.categories[i].name;
        category.value = this.categories[i].id;
        this.categoriesDropdown.push(category);
        }
        this.pageLoader = false;
    }

    mapImageUrl(event) {
        this.playlist.image = event;
    }

    formValidate(field) {
        let isValid = true;
        switch (field) {
        case 'class-name':
            isValid = !this.playlist.name.replace(/\s/g, '').length
            ? false
            : true; //check if field contains only whitespaces
            this.validationFields.className = isValid;
            break;

        case 'class-size':
            isValid = this.playlist.max_allowed > 0
            ? true
            : false;
            this.validationFields.classSize = isValid;
            break;

        default:
            break;
        }

        return !isValid;
    }

    priceTypeChange() {
        if (this.priceType == 6) {
        this.playlist.price_type = 4;
        }
        if (this.priceType === 1) {
        this.playlist.price_type = 1;
        }
    }

    getTrainers() {
        this.http.getData('staff?center_id=' + this.center_id).subscribe(response => {
        const trainers = response.data;
          this.prepareTrainersMultiselect(trainers);
        }, err => {
          this.generalFunctions.openToast(err.message, 3000, 'error');
        }, () => {});
    }


    prepareTrainersMultiselect(trainers) {
        for (let i = 0; i < trainers.length; i++) {
            let trainer = {
            label: '',
            value: 0
            };
            trainer.label = trainers[i].first_name + ' ' + trainers[i].last_name;
            trainer.value = trainers[i].id;
            this.trainersDropdown.push(trainer);
        }
    }

    createvideo() {
        this.http.updateData(`videos/${this.videoId}?client_id=${this.client_id}&center_id=${this.center_id}`,this.playlist )
        .subscribe((response) => {
            this.router.navigate(['/client/services/vod/list']);
        },(error) => {
            this.router.navigate(['/client/services/vod/list']);
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
    }

    deleteVideo() {
        this.http.deleteData(`videos/${this.videoId}?client_id=${this.client_id}&center_id=${this.center_id}`)
        .subscribe((response) => {
            this.generalFunctions.openToast('Deleted successfully', 3000, 'success');
            this.router.navigate(['/client/services/vod/list']);
            this.pop_up_for= null;
        },(error) => {
            this.pop_up_for= null;

            this.router.navigate(['/client/services/vod/list']);
            this.generalFunctions.openToast(error.message, 3000, 'error');
        })
    }
}


