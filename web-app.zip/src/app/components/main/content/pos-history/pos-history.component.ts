import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { GeneralServices } from '../../../../common/general-services';
import { ServerAuthService } from '../../../../common/server-auth';



@Component({
	templateUrl: './pos-history.component.html',
	styleUrls: ['./pos-history.component.scss']
})

export class PosHistoryComponent implements OnInit {


	pos_transaction_history_data:any = null;
	selected_pos_history_item:string = null;

	ajax_call: boolean = true;
	result_end: boolean = false;

	true: boolean = true;
	false: boolean = false;
  null: any = null;
  currency: any = null;

	page: number = 1;

	//REFUND CART VARIABLES
	refund_mode:boolean = false;
	refund_items:Array<any> = [];
	refund_payment_mode: any = "cash";
	total_refund: number = 0;
	net_refund: number = 0

	// REFUND MODAL VARIABLES
	refund_modal_mode:boolean = false;
	refund_calculation:boolean = false;
	refund_confirmation:boolean = false;
	refund_complete:boolean = false;

	history_query: any = null;

	include_center: any = null;

	sendInvoice: any = false;
     custom_email: any = null;

     @ViewChild("item_container")item_container;
	@ViewChild('pos_history_item') pos_history_item;
	@ViewChild('row_container') row_container;

	constructor(
		private router : Router,
		private route: ActivatedRoute,
	   	private generalFunctions: GeneralServices,
	   	private http : ServerAuthService
    	) { }

	ngOnInit() {
		this.include_center = this.generalFunctions
              .includeCenter();
    this.currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;
		this.route
			.queryParams
			.subscribe(params => {
					if(params["trn"]){
						var endpoint = 'pos/transactions'+this.include_center+'&trn_id='+params["trn"];
						this.getData(endpoint);
					}else{
						this.getData('pos/transactions'+this.include_center);
					}
				}
			)
	}

	contentScroll(e) {
		var el = e.target;
		var totalHeight = el.scrollHeight;
		var scrolled = el.scrollTop;
		var boxHeight = el.clientHeight;
		if(this.result_end||this.ajax_call){
			return false;
		}
		if((totalHeight-8) < (scrolled)+(boxHeight)){
			this.ajax_call = true;

			let len = (this.history_query)&&(this.history_query.length!=0);
			if(len){
				var endpoint = 'pos/transactions'+this.include_center+'&query='+this.history_query+'&page='+this.page;
				this.loadMoreData(endpoint);
			}else{
				var endpoint = 'pos/transactions'+this.include_center+'&page='+this.page;
				this.loadMoreData(endpoint);
			}
		}
	}

	getData(endpoint){
		this.http.getData(endpoint+'&include=centerContact')
				.subscribe(
					(success)=>{
						success = success;
						this.pos_transaction_history_data = success.data;
						this.ajax_call = false;

						//STOP FURTHER AJAX ON END OF THE RESULTS
						var currentPage = success.meta.pagination.current_page;
						var totalPages = success.meta.pagination.total_pages;
						if(currentPage >= totalPages){
							this.result_end = true;
							this.page = 1;
						}else{
							this.page +=1;
							this.result_end = false;
						}

						setTimeout(()=>{
							if(this.row_container){
								this.row_container.nativeElement.children[0].click();
							}
						},50)
					},
					(err)=>{
						this.generalFunctions.openToast(err.message,3000,"error");
						this.ajax_call = false;
					}
				)
	}

	loadMoreData(endpoint){
		this.http.getData(endpoint+'&include=centerContact')
				.subscribe(
					(success)=>{
						success = success;
						success.data.forEach((item,index)=>{
							this.pos_transaction_history_data.push(item);
						});
						this.ajax_call = false;

						//STOP FURTHER AJAX ON END OF THE RESULTS
						var currentPage = success.meta.pagination.current_page;
						var totalPages = success.meta.pagination.total_pages;
						if(currentPage >= totalPages){
							this.result_end = true;
							this.page = 1;
						}else{
							this.page +=1;
							this.result_end = false;
						}
					},
					(err)=>{
						this.generalFunctions.openToast(err.message,3000,"error");
						this.ajax_call = false;
					}
				)
	}

	searchTransaction(e){
		this.generalFunctions.isFilled(e);
		var len = this.history_query.length;
		if(len!=0){
			var endpoint = 'pos/transactions'+this.include_center+'&query='+this.history_query;
			this.getData(endpoint);
		}else{
			var endpoint = 'pos/transactions'+this.include_center;
			this.getData(endpoint);
		}

	}

	showPdf(id){
		var endpoint = 'pos/invoice/'+id+this.include_center;
		this.http.getData(endpoint)
			.subscribe(
				(success)=>{
					success = success;
					window.open("data:application/pdf;base64," + success.data);
				},(error)=>{
					if(error.status_code == 404){
						this.generalFunctions.openToast("Invoice not available!",3000,"error");
					}
				}
			)
	}

	selectHistoryItem(e){
		var tr = (e.target.nodeName == 'TR')?e.target:this.generalFunctions.closestTag(e.target,'TR');
		var id = tr.getAttribute('data-index');
		if(this.selected_pos_history_item&&this.selected_pos_history_item["transaction_no"]==id){
			return false;
		}

		var i;
		this.pos_transaction_history_data.forEach((item,index)=>{
			(item.transaction_no == id)? (i = index):"";
		})

		var clone = JSON.parse(JSON.stringify(this.pos_transaction_history_data[i]));

		if(clone.payments.data.length!=0){
			var total = [];
			clone.payments.data.map((item,index)=>{total.push(item.amount)});
			clone["total_paid"] = total.reduce((sum,item)=>{return sum+item});
		}

		this.selected_pos_history_item = clone;

		this.resetRefund();
		this.refund_mode = false;
	}

	toggleRefundItem(e){
		var li = this.generalFunctions.closestTag(e.target,"LI");
		var obj = {};
		obj["id"] = li.getAttribute("data-item-id");
		obj["total"] = parseInt(li.getAttribute("data-item-total"));
		li.classList.toggle("to-refund");
		if(li.classList.contains("to-refund")){
			this.refund_items.push(obj);
			this.total_refund += obj["total"];
			this.net_refund += obj["total"];
		}else{
			var i = this.refund_items.indexOf(obj);
			this.refund_items.splice(i,1);
			this.total_refund -= obj["total"];
			this.net_refund -= obj["total"];
		}
	}

	resetRefund(){
		this.refund_items = [];
		this.total_refund = 0;
		this.net_refund = 0;
		if(this.item_container){
			var els = this.item_container.nativeElement
							.getElementsByTagName("li");
			for(var i = 0; i<els.length; i++){
				els[i].classList.remove("to-refund");
			}
		}
	}

	completeRefund(e){
		var obj = {};
		obj["amount"] = this.net_refund;
		obj['mode'] = this.refund_payment_mode;
		obj["items"] = [];
		this.refund_items.forEach((item,index)=>{
			obj["items"].push(item.id);
		})
		var trn_id = this.selected_pos_history_item["id"];

		e.target.classList.add("loading-ajax");

		this.http.sendData("pos/"+trn_id+'/refund'+this.include_center+'&include=centerContact',obj)
			.subscribe(
				(success)=>{
					console.log(success.data);
					 this.pos_transaction_history_data.unshift(success.data)

					this.refund_confirmation = false;
					this.refund_complete = true;
					this.resetRefund();
					this.refund_mode = false;
					this.refund_payment_mode = 'cash'
					e.target.classList.remove("loading-ajax");
				},(error)=>{
					this.generalFunctions.openToast(error.message,3000,"error");
					e.target.classList.remove("loading-ajax");
				}
			)
	}

	sendInvoiceToCustomEmail(e){
		if(!this.custom_email){
			this.generalFunctions.openToast('Please enter email ID',3000,"error");
			return;
		}
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    		if(!re.test(String(this.custom_email).toLowerCase())){
			this.generalFunctions.openToast('Please enter valid email ID',3000,"error");
			return;
		}
		var obj = {'email': this.custom_email};
		var trn_id = this.selected_pos_history_item["id"];
		e.target.classList.add("loading-ajax");
		this.http.sendData("pos/invoice/"+trn_id+'/email'+this.include_center,obj)
			.subscribe(
				(success)=>{
					this.sendInvoice = false;
					this.generalFunctions.openToast("Invoice successfully sent to "+ this.custom_email,3000,"success");
					e.target.classList.remove("loading-ajax");
				},(error)=>{
					this.generalFunctions.openToast(error.message,3000,"error");
					e.target.classList.remove("loading-ajax");
				}
			)
	}
}
