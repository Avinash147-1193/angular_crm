import {Component, OnInit, AfterContentInit, ViewEncapsulation} from "@angular/core";
import {Router} from "@angular/router";
import {ElementRef, ViewChild} from "@angular/core";
import {ServerAuthService} from "app/common/server-auth";
import {HttpClient, HttpHeaders, HttpResponse, HttpErrorResponse} from "@angular/common/http";
import {Observable} from "rxjs";
import {map, catchError} from "rxjs/operators";
import {SelectItem} from "primeng/api";
import * as moment from "moment";
import ChartsModule from "ng2-charts/ng2-charts";

@Component({selector: "app-dashboard-new", templateUrl: "./dashboard-new.component.html", styleUrls: ["./dashboard-new.component.scss"], encapsulation: ViewEncapsulation.None})
export class DashboardNewComponent implements OnInit,
AfterContentInit {
  @ViewChild("canvasChart")canvas: ElementRef;

  ngAfterContentInit(): void {
    //Called after ngOnInit when the component's or directive's content has been initialized.
    //Add 'implements AfterContentInit' to the class.
  }

  dateTypes: any = [
    {
      label: "Yesterday",
      value: "-1"
    }, {
      label: "Today",
      value: "0"
    }, {
      label: "Tomorrow",
      value: "1"
    }
  ];

  currentState: any = "MORE";
  dummyArray: any = Array(15).fill(0);
  currency = JSON.parse(localStorage.getItem("localization")).currency.symbol;

  currentUser = JSON.parse(localStorage.getItem("currentUser"));
  centerId: string = "";
  percentage: any;
  utilizationChartData: any = [
    {
      data: [],
      label: "This week"
    }, {
      data: [],
      label: "Last week"
    }
  ];
  utilizationChartLabels: Array<any> = this.getLastSevenWeekdays();
  utilizationChartType: string = "line";
  utilizationChartLegend: boolean = false;
  utilizationChartColors: Array<any> = [];

  utilizationChartOptions: any = {
    elements: {
      line: {
        tension: 0, // disables bezier curves
        borderWidth: "3"
      }
    },
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            stepSize: 25,
            callback: function (label, index, labels) {
              switch (label) {
                case 0:
                  return "0%";
                case 25:
                  return "25%";
                case 50:
                  return "50%";
                case 75:
                  return "75%";
                case 100:
                  return "100%";
              }
            }
          }
        }
      ],
      xAxes: [
        {
          gridLines: {
            display: false
          }
        }
      ]
    },
    animation: {
      duration: 300 * 1.5,
      easing: "linear"
    },
    tooltips: {
      // callbacks: {
      //   title: function(tooltipItem, data) {
      //     console.log(data);
      // 	return data['labels'][tooltipItem[0]['index']];
      //   },
      //   label: function(tooltipItem, data) {
      // 	return data['datasets'][0]['data'][tooltipItem['index']];
      //   },
      //   afterLabel: function(tooltipItem, data) {
      // 	var dataset = data['datasets'][0];
      // 	console.log(dataset);
      // 	var percent = Math.round((dataset['data'][tooltipItem['index']] / dataset["_meta"][0]['total']) * 100)
      // 	return '(' + percent + '%)';
      //   }
      // },
      backgroundColor: "#404040",
      titleFontSize: 14,
      titleFontColor: "#fff",
      bodyFontColor: "#fff",
      bodyFontSize: 14,
      displayColors: true,
      cornerRadius: 1
    }
  };

  revenueChartStepSize = 0;
  revenueChartData: Array<any> = [];
  revenueChartLabels: Array<any> = [];
  revenueChartType: string = "line";
  revenueChartLegend: boolean = false;
  revenueChartColors: Array<any> = [];
  revenueChartOptions: any = {
    elements: {
      line: {
        tension: 0, // disables bezier curves
        borderWidth: "3"
      }
    },
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            stepSize: this.revenueChartStepSize
          }
        }
      ],
      xAxes: [
        {
          gridLines: {
            display: false
          }
        }
      ]
    },
    animation: {
      duration: 300 * 1.5,
      easing: "linear"
    },
    tooltips: {
      // callbacks: {
      //   title: function(tooltipItem, data) {
      //     console.log(data);
      // 	return data['labels'][tooltipItem[0]['index']];
      //   },
      //   label: function(tooltipItem, data) {
      // 	return data['datasets'][0]['data'][tooltipItem['index']];
      //   },
      //   afterLabel: function(tooltipItem, data) {
      // 	var dataset = data['datasets'][0];
      // 	console.log(dataset);
      // 	var percent = Math.round((dataset['data'][tooltipItem['index']] / dataset["_meta"][0]['total']) * 100)
      // 	return '(' + percent + '%)';
      //   }
      // },
      backgroundColor: "#404040",
      titleFontSize: 14,
      titleFontColor: "#fff",
      bodyFontColor: "#fff",
      bodyFontSize: 14,
      displayColors: true,
      cornerRadius: 1
    }
  };

  selectedFilter: any = {
    classes: "-1",
    appointments: "-1"
  };

  today: string = "";

  classes: any = {};
  appointments: any = {};
  customers: any = {};
  expiredCustomers: any = {};

  capacityUtilization: any = {};
  dashboardData: any = {
    billing_issue: {},
    tasks: {}
  };
  openMore: boolean = false;

  getStartedData: any = {
    add_availability: false,
    add_customer: false,
    add_membership: false,
    add_staff: false,
    book_appointment: false,
    book_class: false,
    business_settings: false,
    class_schedule: false,
    customer_apps: false,
    payment_provider: false,
    website_portal: false
  };

  isNotBeginner: boolean = true;
  hasCompletedSix: boolean = true;
  currentDate: any;
  i = 0;
  constructor(private http : ServerAuthService, private router : Router) {}

  ngOnInit() {
    this.centerId = this.currentUser["center_id"];
    this.getInitialData();
    this.today = moment(new Date()).format("YYYY-MM-DD");
    this.currentDate = moment(this.today).format("MMM DD");

    this.getCapacityUtilization();
    this.getRevenueData();

    // let gradient = this.canvas.nativeElement.getContext('2d').createLinearGradient(0, 0, 0, 200);
    // gradient.addColorStop(0, 'rgba(123, 76, 217, 0.5)');
    // gradient.addColorStop(1, 'rgba(123, 76, 217, 0.05)');
    // this.utilizationChartColors = [
    // 	{
    // 		backgroundColor: gradient,
    // 		borderColor: '9b72ee',
    // 		pointBackgroundColor: '#fff',
    // 		pointBorderColor: '#9b72ee',
    // 		pointHoverBackgroundColor: '#9b72ee',
    // 		lineWidth: 300
    // 	},
    // 	{
    // 		backgroundColor: 'rgba(103, 58, 183, .1)',
    // 		borderColor: 'rgb(103, 58, 183)',
    // 		pointBackgroundColor: 'rgb(103, 58, 183)',
    // 		pointBorderColor: '#fff',
    // 		pointHoverBackgroundColor: '#fff',
    // 		pointHoverBorderColor: 'rgba(103, 58, 183, .8)'
    // 	  }
    // ];

    this.getClasses();
    this.getAppointments();
    this.getDashboardData();
    this.getCustomers();
    this.getExpiredCustomers();
  }

  getDateFromDropdown(offset) {
    return;
  }

  getInitialData() {
    this.http.getData("center?center_id=" + this.centerId).subscribe(response => {
      response.data[0].total_sales > 1
        ? (this.isNotBeginner = true)
        : (this.isNotBeginner = false);

    }, err => {});

    this.http.getData("center/" + this.centerId + "/onboarding?center_id=" + this.centerId).subscribe(response => {
      let counter = Object.values(response.data);
      let count = 0;
      counter.forEach(element => {

        if (element == true) {
          count = count + 1;
        }
      });
      this.percentage = Math.ceil(count * (100 / 11));
      this.percentage = Math.ceil(this.percentage);
      if (count >= 6) {
        this.hasCompletedSix = true;
      } else {
        this.hasCompletedSix = false;
      }
    }, err => {});
  }

  getCapacityUtilization() {
    this.http.getData(`reports/dashboard/utilization?center_id=` + this.centerId).subscribe(response => {
      // console.log('Utilization');
      this.capacityUtilization = response;

      // var arr = []

      // for (var weekday in response.graph_data.date_data.keys()) {
      // 	arr.push(response[weekday].percentage);
      // }

      this.utilizationChartData = [
        {
          data: Object.values(response.graph_data.date_data.current_week),
          label: "This week"
        }, {
          data: Object.values(response.graph_data.date_data.previous_week),
          label: "Last week"
        }
      ];
    }, error => {
      // console.log(error);
    });
  }

  getRevenueData() {
    this.http.getData(`reports/dashboard/revenue?center_id=` + this.centerId).subscribe(response => {
      // console.log(Object.values(response.data));
      this.revenueChartData.push({
        data: Object.values(response.data),
        label: ""
      });
      this.revenueChartLabels = Object.keys(response.data);

      var val = Object.keys(response.data).map(function (key) {
        return response.data[key];
      });

      // console.log("Math.max(response.data.values())", Math.max(response["data"].values()));
      this.revenueChartStepSize = Math.max(...val) / val.length;
      var values = Object.keys(response.data).map(function (key) {
        return response.data[key];
      });

      this.revenueChartOptions.scales.yAxes[0].ticks.stepSize = values.reduce(function (a, b) {
        return Math.max(a, b);
      }) / 5;
    }, error => {
      // console.log(error);
    });
  }

  getClasses() {
    let data = {
      filterBy: {
        service_id: 3,
        start_date: this.today,
        end_date: this.today
      }
    };
    // console.log(this.dateTypes);

    // console.log(this.selectedFilter.classes);

    this.http.sendData(`events?center_id=` + this.centerId, data).subscribe(response => {
      this.classes = response.data;
    }, error => {});
  }

  getAppointments() {
    let data = {
      filterBy: {
        service_id: 2,
        start_date: this.today,
        end_date: this.today
      }
    };

    // console.log(this.selectedFilter.appointments);

    this.http.sendData(`events?center_id=` + this.centerId, data).subscribe(response => {
      // console.log(response);
      this.appointments = response.data;
    }, error => {
      // console.log(error);
    });
  }

  getCustomers() {
    this.http.sendData(`contact/search?center_id=` + this.centerId, {
      filterBy: {
        type: ["1"]
      },
      sortBy: {},
      page: 1
    }).subscribe(response => {
      // console.log(response);
      // this.generateColor(this.customers);
      this.customers = response.data;
    }, error => {
      // console.log(error);
    });
  }

  getExpiredCustomers() {
    this.http.sendData(`contact/search?center_id=` + this.centerId, {
      filterBy: {
        membership_status: [2],
        type: [1],
        status: [2]
      },
      sortBy: {},
      page: 1
    }).subscribe(response => {
      this.expiredCustomers = response.data;
    }, error => {
      // console.log(error);
    });
  }

  exCustomers(data) {
    data.forEach(i => {
      if (i.status == 4) {
        this.expiredCustomers.push(i);
      }
    });
    // console.log(this.expiredCustomers);
  }

  // generateColor(data){
  // 	for (let index = 0; index < data.length; index++) {
  // 		const element = data[index];
  // 		let colorCode =  element.id % 10;
  // 	  	this.customers[index].colorCode = colorCode;
  // 		}
  // 	}

  getTime(string) {
    return moment(string).format("h:mm a");
  }

  getDashboardData() {
    this.http.getData(`reports/dashboard/charts?center_id=` + this.centerId).subscribe(response => {
      // console.log(response);
      this.dashboardData = response;
    }, error => {
      // console.log(error);
    });
  }

  getLastSevenWeekdays() {
    var date = moment();
    var dates = [];

    let dayFromNumber = function (number) {
      switch (number) {
        case 0:
          return "Sun";
        case 1:
          return "Mon";
        case 2:
          return "Tue";
        case 3:
          return "Wed";
        case 4:
          return "Thu";
        case 5:
          return "Fri";
        case 6:
          return "Sat";
      }
    };

    for (let index = 0; index < 8; index++) {
      dates.push(dayFromNumber(moment().subtract(index, "days").day()));
    }

    return dates.reverse();
  }

  goToEvent(event) {
    this.router.navigate(["/client/calendar"], {
      queryParams: {
        event: event.id
      }
    });
  }

  countBooked (booked) {
    return booked.filter(booking => booking.status === 1).length;
  }
}
