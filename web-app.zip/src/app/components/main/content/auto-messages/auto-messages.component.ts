import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auto-messages',
  templateUrl: './auto-messages.component.html',
  styleUrls: ['./auto-messages.component.scss']
})
export class AutoMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
