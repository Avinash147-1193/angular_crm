import {
  Component,
  OnInit,
  OnChanges,
  ViewEncapsulation
} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import {GeneralServices} from 'app/common/general-services';
import {ServerAuthService} from 'app/common/server-auth';
import {SelectItem, SelectItemGroup} from 'primeng/api';

@Component({
  selector: 'app-auto-messages-details',
  templateUrl: './auto-messages-details.component.html',
  styleUrls: [
    '../../services/styles/services.scss', './auto-messages-details.component.scss'
  ],
  encapsulation: ViewEncapsulation.None
})
export class AutoMessagesDetailsComponent implements OnInit,
OnChanges {
  smsNum: any = 0;
  currency: any;
  center_id: any;
  isNewMessage: boolean = true;
  autoMessageId: string = '';
  currentSection: number = 1;
  availableChannels = [];

  pageLoader: boolean = false;
  eventLoader: boolean = false;

  autoMessageResponse: any;

  autoMessageDetails: any = {
    name: '',
    recepient_type: 1,
    automation_event_id: 0,
    delay: {
      value: 0,
      metric: 'minutes',
      delayType: 'before'
    },
    channel: 'mail',
    message: {
      // fromEmail: '',
    //   fromName: '',
      emailSubject: '',
      content: '',
      dynamicAttachment: ''
    },
    sms: {
        content: ''
    },
    dnd: {
      starts_at: '',
      ends_at: ''
    },

    placeholders: <any>[], testEmailTo: '', status: 0, user_id:
      <any>[] }; automationEvents: any; automations: any; centerSettings: any; validationFields: any = {
          messageName: false,
          event: false,
          // fromEmail: false,
        //   fromName: false,
          emailSubject: false
        };
         nextOne: boolean = false;
         nextTwo: boolean = false;
         nextThree: boolean = false;
         automationEventsDropdown: SelectItemGroup[] = [];
         senderEmailsDropdown: SelectItem[] = [];

         sendDropdown: SelectItem[] = [{
          label: 'Staff',
          value: 2 },
        {
          label: 'Contact',
          value: 1
        }];
        trainersDropdown: SelectItem[] = [];
        trainersDropdownGroup: any;

        timeMetricTypes: any = [{
          label: 'Minutes',
          value: 'minutes'
        },
        {
          label: 'Hours',
          value: 'hours'
        },
        {
          label: 'Days',
          value: 'days'
        }];
        attachmentTypes: SelectItem[] = [];
        eventLabel: string = '';
        senderId: any;
        doneLoading: boolean = false;
        triggerCategory: SelectItem[] = [];
        triggerCategoryValue: any = 0;
        isDefault: false;

         constructor(
             private generalFunctions: GeneralServices,
             private router: Router,
             private http: ServerAuthService,
             private activatedRoute: ActivatedRoute ) {}

        ngOnInit() {
          this.currency = JSON.parse(localStorage.getItem('localization')).currency.symbol;
          this.center_id = JSON.parse(localStorage.getItem('currentUser'))['center_id'];
          this.generalFunctions.plan_details = null;
          this.getCenterData();
          this.initializeDndTimes();

          if (this.router.url.includes('/auto-messages/create')) {
            this.getSenderEmails();

            this.isNewMessage = true;
            this.getAutomationEvents();
            this.getTrainers();
          } else {
            this.isNewMessage = false;
            this.autoMessageId = this.activatedRoute.snapshot.paramMap.get('id');
            this.pageLoader = true;
            this.eventLoader = true;

            this.http.getData(`automations/${this.autoMessageId}?center_id=${this.center_id}`).subscribe(response => {
              this.autoMessageResponse = response.data;

              let am = this.autoMessageResponse;
              // create edit plan object
              if(am.event.settings.channels.mail.attachments){
                this.attachmentTypes = [];
                am.event.settings.channels.mail.attachments.forEach(attachment => {
                  this.attachmentTypes.push({label: attachment, value: attachment});
                });
              }
              this.isDefault = am.event.is_default;
              this.autoMessageDetails.name = am.name;
              this.autoMessageDetails.delay.value = am.settings.delay.split(' ')[0];
              this.autoMessageDetails.delay.metric = am.settings.delay.split(' ')[1];
              this.autoMessageDetails.recepient_type = am.settings.recepient_type;
              this.autoMessageDetails.delay.delayType = am.settings.delay_type;
              this.autoMessageDetails.channel = am.channel;
              this.autoMessageDetails.message.fromEmail = am.settings.channels?.mail?.from;
            //   this.autoMessageDetails.message.fromName = am.settings.channels?.mail?.from_name;
              this.autoMessageDetails.message.dynamicAttachment = am.settings.channels.mail.attachments ? am.event.settings.channels.mail.attachments[0] : '' ;
              this.autoMessageDetails.message.emailSubject = am.settings.channels.mail.subject;
              this.autoMessageDetails.message.content = am.content;
              if (this.autoMessageDetails.channel === 'sms' || this.autoMessageDetails.channel === 'push') {
                  this.autoMessageDetails.sms.content = am.content;
              }
              this.autoMessageDetails.status = am.status;
              this.autoMessageDetails.placeholders = am.placeholders;
              this.getTrainers();
              this.getSenderEmails();



              // dnd times
              if (am.dnd) {
                this.autoMessageDetails.dnd.starts_at = this.prepareDNDdate(am.dnd.starts_at);
                this.autoMessageDetails.dnd.ends_at = this.prepareDNDdate(am.dnd.ends_at);
              }
              this.getAutomationEvents();
              this.pageLoader = false;
            }, error => {
              this.generalFunctions.openToast(error.message, 3000, 'error');
            });
          }
        }

        ngOnChanges(e) {}

        getTrainers() {
          this.http.getData('staff?center_id=' + this.center_id).subscribe(response => {
            this.trainersDropdownGroup = response.data;
            this.prepareTrainersMultiselect();
          }, err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
          }, () => {});
        }

        prepareTrainersMultiselect() {
          this.trainersDropdownGroup.forEach(element => {
            let trainer = {
              label: '',
              value: 0
            };
            trainer.label = element.first_name + ' ' + element.last_name;
            trainer.value = element.id;
            this.trainersDropdown.push(trainer);
          });

          if (!this.isNewMessage) {
            this.prepareSelectedTrainers();
          } else {
            this.doneLoading = true;
          }
        }

        prepareSelectedTrainers() {
          for (let i = 0; i < this.autoMessageResponse.user_id.length; i++) {
            this.autoMessageDetails.user_id.push(this.autoMessageResponse.user_id[i]);
          }
          this.doneLoading = true;
        }

        getSenderEmails() {
          this.http.getData('center/' + this.center_id + '?center_id=' + this.center_id).subscribe(response => {
            this.centerSettings = response.data;
            if (this.isNewMessage) {
            //   this.autoMessageDetails.message.fromName = this.centerSettings.client.name;
            }

            if (this.centerSettings.client.emails.length !== 0) {
              for (let i = 0; i < this.centerSettings.client.emails.length; i++) {
                if (this.centerSettings.client.emails[i].status != 1) {
                  continue;
                }
                let event = {
                  label: '',
                  value: 0
                };
                event.label = this.centerSettings.client.emails[i].email;
                event.value = this.centerSettings.client.emails[i].email;
                this.senderEmailsDropdown.push(event);
              }

            }

            // else {
            //   let event = {
            //     label: 'no-reply@getstudioyou.com',
            //     value: 'no-reply@getstudioyou.com'
            //   };
            //   this.senderEmailsDropdown.push(event);
            // }
          }, err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
          }, () => {
            console.log('this.senderEmailsDropdown', this.senderEmailsDropdown);
            if (this.senderEmailsDropdown.length > 0 && this.isNewMessage) {
                this.autoMessageDetails.message.fromEmail = this.senderEmailsDropdown[0].value;
            }

              if (!this.isNewMessage) {
                this.autoMessageDetails.message.fromEmail = this.autoMessageResponse.settings.channels.mail.from;
                console.log('this.autoMessageDetails', this.autoMessageResponse)
            }
          });

        }

        initializeDndTimes() {
          let d = new Date();
          d.setHours(0, 0, 0, 0);

          this.autoMessageDetails.dnd.starts_at = d;
          this.autoMessageDetails.dnd.ends_at = d;
        }

        prepareDNDdate(time) {
          let d = new Date();
          // let time = date.toLocaleTimeString();

          let hh = time.substr(0, 2);
          let mm = time.substr(3, 2);
          let ss = 0;

          d.setHours(hh, mm, ss);

          return d;
        }

        getAutomationEvents() {
          this.http.getData('automations/events?center_id=' + this.center_id).subscribe(response => {
            this.automationEvents = response.data.events;

            let event,
              item;


            /*
             * step 1 ->  looping through the event object
             * step 2 ->  if length of dropdown is 0 then push the events object to the dd object
             * step 3 ->  else loop through the dd object check if the category exists
             * step 4 ->  if category exist in dropdown push the items object to the same category
             *
             *
             * // [](10) ->  loop -> if array[0] -> pushing category and pushing it to items -> else
             *
            */
            for (let i = 0; i < this.automationEvents.length; i++) {
              event = {
                label: '',
                items: []
              };
              if (this.automationEventsDropdown.length == 0) {
                event.label = this.automationEvents[i].category;
                item = {
                  label: '',
                  value: 0,
                  settings: [],
                  delayType: '',
                  template: '',
                  placeholders: []
                };

                item.label = this.automationEvents[i].name;
                item.value = this.automationEvents[i].id;
                item.settings = this.automationEvents[i].settings.channels.mail.attachments;
                item.delayType = this.automationEvents[i].settings.delay_type[0];
                item.template = this.automationEvents[i].settings.channels.mail;
                item.placeholders = this.automationEvents[i].settings.placeholders;
                event.items.push(item);
                this.automationEventsDropdown.push(event);
              } else {
                for (let j = 0; j < this.automationEventsDropdown.length; j++) {
                  if (this.automationEvents[i].category == this.automationEventsDropdown[j].label) {
                    item = {
                      label: '',
                      value: 0,
                      settings: [],
                      delayType: '',
                      template: '',
                      placeholders: []
                    };

                    item.label = this.automationEvents[i].name;
                    item.value = this.automationEvents[i].id;
                    item.settings = this.automationEvents[i].settings.channels.mail.attachments;
                    item.delayType = this.automationEvents[i].settings.delay_type[0];
                    item.template = this.automationEvents[i].settings.channels.mail;
                    item.placeholders = this.automationEvents[i].settings.placeholders;
                    this.automationEventsDropdown[j].items.push(item);
                    break;
                  }
                  else if (this.automationEventsDropdown.length - 1 == j) {
                    event = {
                      label: '',
                      items: []
                    };
                    event.label = this.automationEvents[i].category;
                    this.automationEventsDropdown.push(event);
                  }
                }
              }
            }


            this.availableChannels = response.data.channels;
            this.triggerCategory = this.automationEventsDropdown.map((event, index) =>  { return {'label' : event.label, 'value' : index} })

            if (!this.isNewMessage) {
              // set automation event details

              for (let i = 0; i < this.automationEventsDropdown.length; i++) {
                if (this.automationEventsDropdown[i].items.some((item) => item.value === this.autoMessageResponse.automation_event_id)){
                    this.triggerCategoryValue = i;
                }
              }
              this.autoMessageDetails.automation_event_id = this.autoMessageResponse.automation_event_id;
              this.eventLabel = this.autoMessageResponse.event.name;
              this.eventLoader = false;
            }



            console.log('this.automationEventsDropdown', this.triggerCategory)

          }, err => {
            this.generalFunctions.openToast(err.message, 3000, 'error');
          }, () => {});
        }

        getCenterData() {
          this.http.getData('center/' + this.center_id).subscribe(success => {
            let senderId = success.data.settings.automations.channels.sms;
            if (senderId == 1) {
              this.senderId = true;
            } else {
              this.senderId = false;
            }
          }, error => {});
        }

        smsCounter(data) {
          data.length == 0
            ? (this.smsNum = 0)
            : (this.smsNum = Math.floor(data.length / 160) + 1);
        }

        getAutomations() {
          this.http.getData('automations?center_id=' + this.center_id).subscribe(response => {
            this.automations = response.data;
          }, err => {
            this.generalFunctions.openToast(err.msg, 3000, 'error');
          }, () => {});
        }

        automationEventChanged() {
          this.automationEventsDropdown.forEach(element => {
            this.prepareEventReaction(element);
          });
        }

        prepareEventReaction(element) {
          element.items.forEach(item => {
            if (item.value == this.autoMessageDetails.automation_event_id) {
              if (item.settings) {
                  this.attachmentTypes = [];
                item.settings.forEach(attachment => {
                  this.attachmentTypes.push({label: attachment, value: attachment});
                });
                console.log('this.attachmentTypes', this.attachmentTypes, item.settings)
              }
              if (item.delayType) {
                this.autoMessageDetails.delay.delayType = item.delayType;
              }
              if (item.template.content) {
                this.autoMessageDetails.message.content = item.template.content;
              }
              if (item.template.subject) {
                this.autoMessageDetails.message.emailSubject = item.template.subject;
              }
              if (item.placeholders) {
                this.autoMessageDetails.placeholders = item.placeholders;
              }
            }
          });
        }

        getFormStatus() {
          let isFormValid = true;

          if (this.autoMessageDetails.channel == 'sms') {
            this.validationFields = {
              messageName: true,
              event: true
            };
          }

          for (var property in this.validationFields) {
            isFormValid = isFormValid && this.validationFields[property];
                if (!this.validationFields[property]) {
                this.generalFunctions.scrolltoinvalid(property);
                break;
                }
          }

          return isFormValid;
        }

        prepareAutoMessageRequest() {
          let reqObj = {};
          reqObj = {
            automation_event_id: this.autoMessageDetails.automation_event_id,
            name: this.autoMessageDetails.name,
            channel: this.autoMessageDetails.channel,
            runs_at: '00:00:00',
            user_id: this.autoMessageDetails.user_id,
            content: this.autoMessageDetails.channel !== 'sms' && this.autoMessageDetails.channel !== 'push' ? this.autoMessageDetails.message.content :  this.autoMessageDetails.sms.content,
            settings: {
              recepient_type: this.autoMessageDetails.recepient_type,
              delay: `${this.autoMessageDetails.delay.value} ${this.autoMessageDetails.delay.metric}`,
              delay_type: this.autoMessageDetails.delay.delayType,
              channels: {
                mail: {
                  from: this.autoMessageDetails.message.fromEmail,
                //   from_name: this.autoMessageDetails.message.fromName,
                  subject: this.autoMessageDetails.message.emailSubject,
                  attachments: this.autoMessageDetails.message.dynamicAttachment ? [this.autoMessageDetails.message.dynamicAttachment] : ''
                },
                push : {
                    subject: this.autoMessageDetails.message.emailSubject,

                }
              }
            },

            dnd: {
              starts_at: '',
              ends_at: ''
            }
          };
          // DND fields
          reqObj['dnd'].starts_at = this.autoMessageDetails.dnd.starts_at.toLocaleTimeString();
          reqObj['dnd'].ends_at = this.autoMessageDetails.dnd.ends_at.toLocaleTimeString();

          return reqObj;
        }

        createAutoMessage() {
          let reqObj = this.prepareAutoMessageRequest();
          console.log('reqObj', reqObj)

          this.http.sendData(`automations?center_id=${this.center_id}`, reqObj).subscribe(response => {
            this.router.navigate(['/client/auto-messages']);
            this.generalFunctions.openToast('Auto message created', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        saveMessage() {
          let isFormValid = this.getFormStatus();

          if (!isFormValid) {
            this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            return;
          }

          let reqObj = this.prepareAutoMessageRequest();

          this.http.patchData(`automations/${this.autoMessageId}?center_id=${this.center_id}`, reqObj).subscribe(response => {
            this.router.navigate(['/client/auto-messages']);
            this.generalFunctions.openToast('Auto message saved', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        pauseMessage() {
          this.http.patchData(`automations/${this.autoMessageId}/pause?center_id=${this.center_id}`, {}).subscribe(response => {
            this.autoMessageDetails.status = 2;
            this.generalFunctions.openToast('Auto message paused', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        resumeMessage() {
          this.http.patchData(`automations/${this.autoMessageId}/resume?center_id=${this.center_id}`, {}).subscribe(response => {
            this.autoMessageDetails.status = 1;
            this.generalFunctions.openToast('Auto message resumed', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        cancelChanges() {
          this.router.navigate(['/client/auto-messages']);
        }

        deleteMessage() {
          this.http.deleteData(`automations/${this.autoMessageId}?center_id=${this.center_id}`).subscribe(response => {
            this.router.navigate(['/client/auto-messages']);
            this.generalFunctions.openToast('Auto message deleted', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        sendTestEmail() {
          let reqObj = {
            content: this.autoMessageDetails.message.content,
            subject: this.autoMessageDetails.message.emailSubject,
            from: 'no-reply@getstudioyou.com',
            to: this.autoMessageDetails.testEmailTo,
            // from_name: this.autoMessageDetails.message.fromName,
            channel: this.autoMessageDetails.channel
          };

          this.http.sendData(`automations/test/mail?center_id=${this.center_id}`, reqObj).subscribe(response => {
            this.generalFunctions.openToast('Test email sent', 3000, 'success');
          }, error => {
            this.generalFunctions.openToast(error.message, 3000, 'error');
          });
        }

        sendTestSms() {
          let reqObj = {
            content: this.autoMessageDetails.sms.content,
            phone: this.autoMessageDetails.testSmsTo
          };

          if (!this.autoMessageDetails.testSmsTo || this.autoMessageDetails.testSmsTo.length != 10) {
            this.generalFunctions.openToast('Please enter a valid phone number', 3000, 'error');
          } else {
            this.http.sendData(`automations/test/sms?center_id=${this.center_id}`, reqObj).subscribe(response => {
              this.generalFunctions.openToast('Test SMS sent', 3000, 'success');
            }, error => {
              this.generalFunctions.openToast(error.message, 3000, 'error');
            });
          }
        }
        sendTestPush() {
            let reqObj = {
              content: this.autoMessageDetails.sms.content,
              subject: this.autoMessageDetails.message.emailSubject,
              to: this.autoMessageDetails.testEmailTo,
            };
              this.http.sendData(`automations/test/push?center_id=${this.center_id}`, reqObj).subscribe(response => {
                this.generalFunctions.openToast('Test SMS sent', 3000, 'success');
              }, error => {
                this.generalFunctions.openToast(error.message, 3000, 'error');
              });

          }

        formValidate(field) {
          let isValid = true;

          switch (field) {
            case 'message-name':
              isValid = !this.autoMessageDetails.name.replace(/\s/g, '').length
                ? false
                : true; //check if field contains only whitespaces
              this.validationFields.messageName = isValid;
              break;

              // case "staff":
              //   isValid = (!(this.autoMessageDetails.user_id.length == 0) && this.autoMessageDetails.settings.recepient_type == 2)
              //   ? false
              //   : true;
              //   this.validationFields.staff = isValid;
              //   break;

            case 'event':
              isValid = this.autoMessageDetails.automation_event_id === 0
                ? false
                : true; //check if event is selected from dropdown
              this.validationFields.event = isValid;
              break;

              // case "from-email":
              // 	isValid = (/(.+)@(.+){2,}\.(.+){2,}/.test(this.autoMessageDetails.message.fromEmail)) ? true : false; check if email is valid
              // 	this.validationFields.fromEmail = isValid;
              // 	break;

            // case 'from-name':
            //   isValid = !this.autoMessageDetails.message.fromName.replace(/\s/g, '').length
            //     ? false
            //     : true;
            //   this.validationFields.fromName = isValid;
            //   break;

            case 'email-subject':
              isValid = !this.autoMessageDetails.message.emailSubject.replace(/\s/g, '').length
                ? false
                : true;
              this.validationFields.emailSubject = isValid;
              break;

            case 'test-email':
              isValid = /(.+)@(.+){2,}\.(.+){2,}/.test(this.autoMessageDetails.testEmailTo)
                ? true
                : false;
              this.validationFields.fromEmail = isValid;
              break;

            default:
              break;
          }

          return !isValid;
        }

        goToNext(current, next) {
          switch (current) {
            case 1:
              this.nextOne = true;

              // Identify first invalid field in the form and take action accordingly
              if (!this.validationFields.messageName) {
                this.generalFunctions.scrolltoinvalid('messageName');
                this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                return;
              } else if (!this.validationFields.event) {
                this.generalFunctions.scrolltoinvalid('event');
                this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                return;
              }

              break;

            case 2:
              this.nextTwo = true;
              break;

            case 3:
              this.nextThree = true;

              // Identify first invalid field in the form and take action accordingly
              /*if (!this.validationFields.fromEmail) {
					this.generalFunctions.scrolltoinvalid('fromEmail');
					this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
					return;
				} else*/

            // if (!this.validationFields.fromName && this.autoMessageDetails.channel == 'mail') {
            //     this.generalFunctions.scrolltoinvalid('fromName');
            //     this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
            //     return;
            //   } else

              if (!this.validationFields.emailSubject && this.autoMessageDetails.channel == 'mail') {
                this.generalFunctions.scrolltoinvalid('emailSubject');
                this.generalFunctions.openToast('Please fill in required fields', 3000, 'error');
                return;
              }

            default:
              break;
          }

          this.currentSection++;

          document.getElementById(next).click();
        }

        goBack(collapse) {
          this.currentSection--;
          document.getElementById(collapse).click();
        }

        getLoaderStatus() {
          return this.pageLoader || this.eventLoader;
        }

        updateMessageContent(e) {
          this.autoMessageDetails.message.content = e;
        }

        appendTag(tagLabel) {
            var target = document.getElementById("cursor-selection")as HTMLTextAreaElement;
            if (target) {
              if (target.setRangeText) {
                target.setRangeText(" {" + tagLabel + "}");
              } else {
                target.focus();
                document.execCommand("insertText", false, " {" + tagLabel + "}");
              }
            }
          }

        avc() {}}
