import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoMessagesDetailsComponent } from './auto-messages-details.component';

describe('AutoMessagesDetailsComponent', () => {
  let component: AutoMessagesDetailsComponent;
  let fixture: ComponentFixture<AutoMessagesDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoMessagesDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoMessagesDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
