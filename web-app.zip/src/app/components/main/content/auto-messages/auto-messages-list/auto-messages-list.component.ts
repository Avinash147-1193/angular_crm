import {Component, OnInit} from "@angular/core";
import {Router, ActivatedRoute, Params} from "@angular/router";
import {ServerAuthService} from "app/common/server-auth";
import {GeneralServices} from "app/common/general-services";
import * as moment from "moment";

@Component({
  selector: "app-auto-messages-list",
  templateUrl: "./auto-messages-list.component.html",
  styleUrls: ["../../services/styles/service-list.scss", "./auto-messages-list.component.scss"]
})
export class AutoMessagesListComponent implements OnInit {
  currencySymbol: any;
  centerId: any;

  automations: any;
  totalAutomations: any;

  constructor(private router : Router, private route : ActivatedRoute, private http : ServerAuthService, private generalFunctions : GeneralServices) {}

  ngOnInit() {
    this.currencySymbol = JSON.parse(localStorage.getItem("localization")).currency.symbol;
    this.centerId = JSON.parse(localStorage.getItem("currentUser"))["center_id"];
    this.getAutomations();
  }

  getAutomations() {
    this.http.getData("automations?center_id=" + this.centerId).subscribe(response => {
      this.automations = response.data;
      console.log(this.automations);
      // this.totalAutomations = response.meta.pagination.total;
    }, err => {
      const msg = err;
      this.generalFunctions.openToast(msg, 3000, "error");
    }, () => {});
  }

  getStatus(index) {
    let am = this.automations[index];
    let status = "";

    let now = new Date();
    let amStartDate = new Date();
    let amEndDate = new Date();

    // if dnd is empty and invalid, return 'running'
    if (!am.dnd.starts_at) {
      this.automations[index].statusText = // if dnd is valid and active, calculate status
      "running";
    } else {
      // start time for today
      let startHH = am.dnd.starts_at.substr(0, 2);
      let startMM = am.dnd.starts_at.substr(3, 2);
      amStartDate.setHours(startHH, startMM);

      // end time for today
      let endHH = am.dnd.ends_at.substr(0, 2);
      let endMM = am.dnd.ends_at.substr(3, 2);
      amEndDate.setHours(endHH, endMM);

      // get milliseconds since epoch
      am.startMilliseconds = amStartDate.valueOf();
      am.endMilliseconds = amEndDate.valueOf();
      let currentMilliseconds = now.valueOf();

      // if end time lesser than start time -- increment end date by 1 (add 1 day worth of milliseconds to endDate)
      if (am.endMilliseconds < am.startMilliseconds) {
        am.endMilliseconds += 86400000;
      }

      // check if automessage is paused
      if (this.automations[index].status === 2) {
        this.automations[index].statusText = // check if current time falls between start and end DND time
        "paused";
      } else if (am.endMilliseconds < am.startMilliseconds) {
        // if (currentMilliseconds >= am.endMilliseconds && currentMilliseconds <= am.startMilliseconds) {
        //   this.automations[index].statusText = "suspended";
        // } else {
        //   this.automations[index].statusText = "running";
        // }
      } else {
        if (currentMilliseconds >= am.startMilliseconds && currentMilliseconds <= am.endMilliseconds) {
          this.automations[index].statusText = "suspended";
        } else {
          this.automations[index].statusText = "running";
        }
      }
    }

    return this.automations[index].statusText;
  }

  getRunningTime(index) {
    let am = this.automations[index];
    let runningTime = "";

    if (am.dnd.starts_at && am.dnd.ends_at) {
      runningTime =   am.dnd.starts_at.substr(0, 5) + " - " + am.dnd.ends_at.substr(0, 5)
    }

    return runningTime;
  }
}
