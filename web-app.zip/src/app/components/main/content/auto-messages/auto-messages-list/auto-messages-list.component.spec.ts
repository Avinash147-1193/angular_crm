import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoMessagesListComponent } from './auto-messages-list.component';

describe('AutoMessagesListComponent', () => {
  let component: AutoMessagesListComponent;
  let fixture: ComponentFixture<AutoMessagesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoMessagesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoMessagesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
