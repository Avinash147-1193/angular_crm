import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoMessagesComponent } from './auto-messages.component';

describe('AutoMessagesComponent', () => {
  let component: AutoMessagesComponent;
  let fixture: ComponentFixture<AutoMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoMessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
