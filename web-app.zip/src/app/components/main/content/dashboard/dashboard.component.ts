import { Component, OnInit, ViewChild, OnDestroy, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GeneralServices } from '../../../../common/general-services';
import { ServerAuthService } from '../../../../common/server-auth';
import { PopupComponent } from '../../../../common/popup';
import * as echarts from '../../../../../../src/assets/js/echarts/echarts';


@Component({
	templateUrl: 'dashboard.component.html',
	styleUrls: ['dashboard.component.css']
})

export class DashboardComponent implements OnInit, OnChanges {

	/* FIRST TIME SIGN UP VARIABLES */
	worldTimeZone: any[] = null;
	onboarding: boolean = false;
	user_name: any = null;
	include_center: any = null;
	onboarding_step: any = 1;
	step_one_done: boolean = false;
	step_two_done: boolean = false;
	step_three_done: boolean = false;
	step_four_done: boolean = false;
	otp_validated: boolean = false;
	show_otp_field: boolean = false;
	currency: any[] = null;
	currencyObj: any;
	countryObj: any;
	localTimeObj: any;
	local_currency: any;
	countries: any[] = null;
	selectedCountry: any = 0;
	selectedTimezone: any;
	countryFlag: boolean = false;
	country: boolean = false;
	countryName: any = null;
	localTime: any = 0;
	isd_code: any = null;
	selectedCurrency : any;
	show_send_id_example: boolean = false;

	popup: boolean = false;
	popup_for: any = null;
	popup_action: any = null;
	add_task_in_stage: boolean = false;
	add_task_in_comment: boolean = false;

	prospect_id: any = null;
	prospect_data: any = null;
	prospect_name: string = null;
	prospect_phone: any  = null;

	task_data: any = {
		"id": null,
		"type": "phone",
		"remind_on": null,
		"comment": null,
		"client_id": null
	}
	// For loading up current task using task_order
	tasks_order: any = {
		"0": "overdue",
		"1": "today",
		"2": "tomorrow"

	};

	// For checking current tab in tasks from today tomorrow overdue
	tasks_order_id: number = 0;

	task_class_id: number = 0;

	staff_list: any = [];

	prospect_tasks_incomplete: any = null;

	auxillary_tasks: any = null;



	client: any = {
		"name": null,
		"multiple_location": false,
		"branch": null,
		"pincode": null,
		"address": null,
		"state": null,
		"city": null,
		"phone": null,
		"sender_id": null,
		"otp": null,
	}

	@ViewChild("phone") phone;
	@ViewChild("otp") otp;
	@ViewChild("pincode") pincode;
	@ViewChild("sender_id") sender_id;
	@ViewChild('ajax_sreen') ajax_sreen;

	@ViewChild("weekly_chart") weekly_chart;
	@ViewChild("monthly_chart") monthly_chart;

    @ViewChild(PopupComponent) Popup:PopupComponent;
	/* NORMAL DASHBORAD FLOW */
	show_expiring: boolean = true;

	dashboard_figures: any = null;

	revenue_chart: any = 'monthly';
	show_chart: boolean = true;

	constructor(
		private route: ActivatedRoute,
		private router: Router,
		private generalFunctions: GeneralServices,
		private http: ServerAuthService
	) { }

	ngOnInit() {
		if (JSON.parse(localStorage.getItem("currentUser")).roles) {
			JSON.parse(JSON.parse(localStorage.getItem("currentUser")).roles).permissions.forEach((item, index) => {
				if (item.name == "sale-show-all") {
					this.show_chart = !item.settings.limit_transactions;
				}
			})
		}

		if (!JSON.parse(localStorage.getItem("currentUser")).center_id) {
			this.onboarding = true;
			this.user_name = JSON.parse(localStorage.getItem("currentUser")).name;
			this.client.phone = JSON.parse(localStorage.getItem("currentUser")).phone;
		} else {
			this.include_center = this.generalFunctions.includeCenter();
			this.getData();
    	}

		this.getCountries();
		this.getCurrencies();
		if (JSON.parse(localStorage.getItem("localization")) != null) {
			let localizationData = JSON.parse(localStorage.getItem("localization"))
			this.local_currency = localizationData.currency.symbol;
		}

		this.worldTimeZone = [
			{
			"zone": "Pacific/Midway",
			"gmt": "(GMT-11:00)",
			"name": "Midway Island"
			},
			{
			"zone": "US/Samoa",
			"gmt": "(GMT-11:00)",
			"name": "Samoa"
			},
			{
			"zone": "US/Hawaii",
			"gmt": "(GMT-10:00)",
			"name": "Hawaii"
			},
			{
			"zone": "US/Alaska",
			"gmt": "(GMT-09:00)",
			"name": "Alaska"
			},
			{
			"zone": "US/Pacific",
			"gmt": "(GMT-08:00)",
			"name": "Pacific Time (US &amp; Canada)"
			},
			{
			"zone": "America/Tijuana",
			"gmt": "(GMT-08:00)",
			"name": "Tijuana"
			},
			{
			"zone": "US/Arizona",
			"gmt": "(GMT-07:00)",
			"name": "Arizona"
			},
			{
			"zone": "US/Mountain",
			"gmt": "(GMT-07:00)",
			"name": "Mountain Time (US &amp; Canada)"
			},
			{
			"zone": "America/Chihuahua",
			"gmt": "(GMT-07:00)",
			"name": "Chihuahua"
			},
			{
			"zone": "America/Mazatlan",
			"gmt": "(GMT-07:00)",
			"name": "Mazatlan"
			},
			{
			"zone": "America/Mexico_City",
			"gmt": "(GMT-06:00)",
			"name": "Mexico City"
			},
			{
			"zone": "America/Monterrey",
			"gmt": "(GMT-06:00)",
			"name": "Monterrey"
			},
			{
			"zone": "Canada/Saskatchewan",
			"gmt": "(GMT-06:00)",
			"name": "Saskatchewan"
			},
			{
			"zone": "US/Central",
			"gmt": "(GMT-06:00)",
			"name": "Central Time (US &amp; Canada)"
			},
			{
			"zone": "US/Eastern",
			"gmt": "(GMT-05:00)",
			"name": "Eastern Time (US &amp; Canada)"
			},
			{
			"zone": "US/East-Indiana",
			"gmt": "(GMT-05:00)",
			"name": "Indiana (East)"
			},
			{
			"zone": "America/Bogota",
			"gmt": "(GMT-05:00)",
			"name": "Bogota"
			},
			{
			"zone": "America/Lima",
			"gmt": "(GMT-05:00)",
			"name": "Lima"
			},
			{
			"zone": "America/Caracas",
			"gmt": "(GMT-04:30)",
			"name": "Caracas"
			},
			{
			"zone": "Canada/Atlantic",
			"gmt": "(GMT-04:00)",
			"name": "Atlantic Time (Canada)"
			},
			{
			"zone": "America/La_Paz",
			"gmt": "(GMT-04:00)",
			"name": "La_Paz"
			},
			{
			"zone": "America/Santiago",
			"gmt": "(GMT-04:00)",
			"name": "Santiago"
			},
			{
			"zone": "Canada/Newfoundland",
			"gmt": "(GMT-03:30)",
			"name": "Newfoundland"
			},
			{
			"zone": "America/Buenos_Aires",
			"gmt": "(GMT-03:00)",
			"name": "Buenos Aires"
			},
			{
			"zone": "Greenland",
			"gmt": "(GMT-03:00)",
			"name": "Greenland"
			},
			{
			"zone": "Atlantic/Stanley",
			"gmt": "(GMT-02:00)",
			"name": "Stanley"
			},
			{
			"zone": "Atlantic/Azores",
			"gmt": "(GMT-01:00)",
			"name": "Azores"
			},
			{
			"zone": "Atlantic/Cape_Verde",
			"gmt": "(GMT-01:00)",
			"name": "Cape Verde Is."
			},
			{
			"zone": "Africa/Casablanca",
			"gmt": "(GMT)",
			"name": "Casablanca"
			},
			{
			"zone": "Europe/Dublin",
			"gmt": "(GMT)",
			"name": "Dublin"
			},
			{
			"zone": "Europe/Lisbon",
			"gmt": "(GMT)",
			"name": "Libson"
			},
			{
			"zone": "Europe/London",
			"gmt": "(GMT)",
			"name": "London"
			},
			{
			"zone": "Africa/Monrovia",
			"gmt": "(GMT)",
			"name": "Monrovia"
			},
			{
			"zone": "Europe/Amsterdam",
			"gmt": "(GMT+01:00)",
			"name": "Amsterdam"
			},
			{
			"zone": "Europe/Belgrade",
			"gmt": "(GMT+01:00)",
			"name": "Belgrade"
			},
			{
			"zone": "Europe/Berlin",
			"gmt": "(GMT+01:00)",
			"name": "Berlin"
			},
			{
			"zone": "Europe/Bratislava",
			"gmt": "(GMT+01:00)",
			"name": "Bratislava"
			},
			{
			"zone": "Europe/Brussels",
			"gmt": "(GMT+01:00)",
			"name": "Brussels"
			},
			{
			"zone": "Europe/Budapest",
			"gmt": "(GMT+01:00)",
			"name": "Budapest"
			},
			{
			"zone": "Europe/Copenhagen",
			"gmt": "(GMT+01:00)",
			"name": "Copenhagen"
			},
			{
			"zone": "Europe/Ljubljana",
			"gmt": "(GMT+01:00)",
			"name": "Ljubljana"
			},
			{
			"zone": "Europe/Madrid",
			"gmt": "(GMT+01:00)",
			"name": "Madrid"
			},
			{
			"zone": "Europe/Paris",
			"gmt": "(GMT+01:00)",
			"name": "Paris"
			},
			{
			"zone": "Europe/Prague",
			"gmt": "(GMT+01:00)",
			"name": "Prague"
			},
			{
			"zone": "Europe/Rome",
			"gmt": "(GMT+01:00)",
			"name": "Rome"
			},
			{
			"zone": "Europe/Sarajevo",
			"gmt": "(GMT+01:00)",
			"name": "Sarajevo"
			},
			{
			"zone": "Europe/Skopje",
			"gmt": "(GMT+01:00)",
			"name": "Skopje"
			},
			{
			"zone": "Europe/Stockholm",
			"gmt": "(GMT+01:00)",
			"name": "Stockholm"
			},
			{
			"zone": "Europe/Vienna",
			"gmt": "(GMT+01:00)",
			"name": "Vienna"
			},
			{
			"zone": "Europe/Warsaw",
			"gmt": "(GMT+01:00)",
			"name": "Warsaw"
			},
			{
			"zone": "Europe/Zagreb",
			"gmt": "(GMT+01:00)",
			"name": "Zagreb"
			},
			{
			"zone": "Europe/Athens",
			"gmt": "(GMT+02:00)",
			"name": "Athens"
			},
			{
			"zone": "Europe/Bucharest",
			"gmt": "(GMT+02:00)",
			"name": "Bucharest"
			},
			{
			"zone": "Africa/Cairo",
			"gmt": "(GMT+02:00)",
			"name": "Cairo"
			},
			{
			"zone": "Africa/Harare",
			"gmt": "(GMT+02:00)",
			"name": "Harere"
			},
			{
			"zone": "Europe/Helsinki",
			"gmt": "(GMT+02:00)",
			"name": "Helsinki"
			},
			{
			"zone": "Europe/Istanbul",
			"gmt": "(GMT+02:00)",
			"name": "Istanbul"
			},
			{
			"zone": "Asia/Jerusalem",
			"gmt": "(GMT+02:00)",
			"name": "Jerusalem"
			},
			{
			"zone": "Europe/Kiev",
			"gmt": "(GMT+02:00)",
			"name": "Kiev"
			},
			{
			"zone": "Europe/Minsk",
			"gmt": "(GMT+02:00)",
			"name": "Minsk"
			},
			{
			"zone": "Europe/Riga",
			"gmt": "(GMT+02:00)",
			"name": "Riga"
			},
			{
			"zone": "Europe/Sofia",
			"gmt": "(GMT+02:00)",
			"name": "Sofia"
			},
			{
			"zone": "Europe/Tallinn",
			"gmt": "(GMT+02:00)",
			"name": "Tallinn"
			},
			{
			"zone": "Europe/Vilnius",
			"gmt": "(GMT+02:00)",
			"name": "Vilnius"
			},
			{
			"zone": "Asia/Baghdad",
			"gmt": "(GMT+03:00)",
			"name": "Baghdad"
			},
			{
			"zone": "Asia/Kuwait",
			"gmt": "(GMT+03:00)",
			"name": "Kuwait"
			},
			{
			"zone": "Africa/Nairobi",
			"gmt": "(GMT+03:00)",
			"name": "Nairobi"
			},
			{
			"zone": "Asia/Riyadh",
			"gmt": "(GMT+03:00)",
			"name": "Riyadh"
			},
			{
			"zone": "Asia/Tehran",
			"gmt": "(GMT+03:30)",
			"name": "Tehran"
			},
			{
			"zone": "Europe/Moscow",
			"gmt": "(GMT+04:00)",
			"name": "Moscow"
			},
			{
			"zone": "Asia/Baku",
			"gmt": "(GMT+04:00)",
			"name": "Baku"
			},
			{
			"zone": "Europe/Volgograd",
			"gmt": "(GMT+04:00)",
			"name": "Volgograd"
			},
			{
			"zone": "Asia/Muscat",
			"gmt": "(GMT+04:00)",
			"name": "Muscat"
			},
			{
			"zone": "Asia/Tbilisi",
			"gmt": "(GMT+04:00)",
			"name": "Tbilisi"
			},
			{
			"zone": "Asia/Yerevan",
			"gmt": "(GMT+04:00)",
			"name": "Yerevan"
			},
			{
			"zone": "Asia/Kabul",
			"gmt": "(GMT+04:30)",
			"name": "Kabul"
			},
			{
			"zone": "Asia/Karachi",
			"gmt": "(GMT+05:00)",
			"name": "Karachi"
			},
			{
			"zone": "Asia/Tashkent",
			"gmt": "(GMT+05:00)",
			"name": "Tashkent"
			},
			{
			"zone": "Asia/Kolkata",
			"gmt": "(GMT+05:30)",
			"name": "Kolkata"
			},
			{
			"zone": "Asia/Kathmandu",
			"gmt": "(GMT+05:45)",
			"name": "Kathmandu"
			},
			{
			"zone": "Asia/Yekaterinburg",
			"gmt": "(GMT+06:00)",
			"name": "Yekaterinburg"
			},
			{
			"zone": "Asia/Almaty",
			"gmt": "(GMT+06:00)",
			"name": "Almaty"
			},
			{
			"zone": "Asia/Dhaka",
			"gmt": "(GMT+06:00)",
			"name": "Dhaka"
			},
			{
			"zone": "Asia/Novosibirsk",
			"gmt": "(GMT+07:00)",
			"name": "Novosibirsk"
			},
			{
			"zone": "Asia/Bangkok",
			"gmt": "(GMT+07:00)",
			"name": "Bangkok"
			},
			{
			"zone": "Asia/Jakarta",
			"gmt": "(GMT+07:00)",
			"name": "Jakarta"
			},
			{
			"zone": "Asia/Krasnoyarsk",
			"gmt": "(GMT+08:00)",
			"name": "Krasnoyarsk"
			},
			{
			"zone": "Asia/Chongqing",
			"gmt": "(GMT+08:00)",
			"name": "Chongqing"
			},
			{
			"zone": "Asia/Hong_Kong",
			"gmt": "(GMT+08:00)",
			"name": "Hong Kong"
			},
			{
			"zone": "Asia/Kuala_Lumpur",
			"gmt": "(GMT+08:00)",
			"name": "Kuala Lumpur"
			},
			{
			"zone": "Australia/Perth",
			"gmt": "(GMT+08:00)",
			"name": "Perth"
			},
			{
			"zone": "Asia/Singapore",
			"gmt": "(GMT+08:00)",
			"name": "Singapore"
			},
			{
			"zone": "Asia/Taipei",
			"gmt": "(GMT+08:00)",
			"name": "Taipei"
			},
			{
			"zone": "Asia/Ulaanbaatar",
			"gmt": "(GMT+08:00)",
			"name": "Ulaan Bataar"
			},
			{
			"zone": "Asia/Urumqi",
			"gmt": "(GMT+08:00)",
			"name": "Urumqi"
			},
			{
			"zone": "Asia/Irkutsk",
			"gmt": "(GMT+09:00)",
			"name": "Irkutsk"
			},
			{
			"zone": "Asia/Seoul",
			"gmt": "(GMT+09:00)",
			"name": "Seoul"
			},
			{
			"zone": "Asia/Tokyo",
			"gmt": "(GMT+09:00)",
			"name": "Tokyo"
			},
			{
			"zone": "Australia/Adelaide",
			"gmt": "(GMT+09:30)",
			"name": "Adelaide"
			},
			{
			"zone": "Australia/Darwin",
			"gmt": "(GMT+09:30)",
			"name": "Darwin"
			},
			{
			"zone": "Asia/Yakutsk",
			"gmt": "(GMT+10:00)",
			"name": "Yakutsk"
			},
			{
			"zone": "Australia/Brisbane",
			"gmt": "(GMT+10:00)",
			"name": "Brisbane"
			},
			{
			"zone": "Australia/Canberra",
			"gmt": "(GMT+10:00)",
			"name": "Canberra"
			},
			{
			"zone": "Pacific/Guam",
			"gmt": "(GMT+10:00)",
			"name": "Guam"
			},
			{
			"zone": "Australia/Hobart",
			"gmt": "(GMT+10:00)",
			"name": "Hobart"
			},
			{
			"zone": "Australia/Melbourne",
			"gmt": "(GMT+10:00)",
			"name": "Melbourne"
			},
			{
			"zone": "Pacific/Port_Moresby",
			"gmt": "(GMT+10:00)",
			"name": "Port Moresby"
			},
			{
			"zone": "Australia/Sydney",
			"gmt": "(GMT+10:00)",
			"name": "Sydney"
			},
			{
			"zone": "Asia/Vladivostok",
			"gmt": "(GMT+11:00)",
			"name": "Vladivostok"
			},
			{
			"zone": "Asia/Magadan",
			"gmt": "(GMT+12:00)",
			"name": "Magadan"
			},
			{
			"zone": "Pacific/Auckland",
			"gmt": "(GMT+12:00)",
			"name": "Auckland"
			},
			{
			"zone": "Pacific/Fiji",
			"gmt": "(GMT+12:00)",
			"name": "Fiji"
			}
		];
	}

	ngOnChanges(e) {
		if (this.countryFlag) {
			this.isd_code = this.client.isd_code;
			this.country = this.client.country === "India" ? true : false;
		} else {
			this.isd_code = null;
			this.country = false;
		}
	}

	timeZoneWrap(id: string) {
		this.selectedTimezone = id;
		let selectedId = this.selectedTimezone.split(": ");
		this.client.timezone = this.worldTimeZone[selectedId[0]-1].zone;
		this.localTime = id;
		this.localTimeObj = this.worldTimeZone[selectedId[0]-1];
	}

	countryChange(val: string) {
		this.selectedCountry = val;
		this.client.phone = '';
		this.show_otp_field = false;
		let selectedId = this.selectedCountry.split(": ");
		this.client.country = this.countries[selectedId[0]-1].name;
		this.client.country_id = this.countries[selectedId[0]-1].id;
		this.countryFlag = true;
		this.client.isd_code = this.countries[selectedId[0]-1].isd_code;
		this.country = this.client.country === "India" ? true : false;
		this.countryObj = this.countries[selectedId[0]-1];
	}

	currencyChange(val: string) {
		console.log(this.selectedCurrency);
		this.currencyObj = this.selectedCurrency;
		console.log(this.currencyObj);


		// this.selectedCurrency = val;
		// let selectedId = this.selectedCurrency.split(": ");
		// this.client.currency_id = this.currency[selectedId[0]-1].id;
		// this.currencyObj = this.currency[selectedId[0]-1];
	}


	isFilled(e) {
		this.generalFunctions.isFilled(e);
	}

	getCountries() {
		this.http.getCountryCode("countries")
			.subscribe(
				(success) => {
					success = success;
					this.countries = success.data;
				}, (error) => {
					this.generalFunctions
						.openToast(error.message, 3000, "error");
				}
			)
	}

	getCurrencies() {
		this.http.getCountryCode("currencies")
			.subscribe(
				(success) => {
					success = success;
					this.currency = success.data;
					this.selectedCurrency = this.currency[0];
				}, (error) => {
					this.generalFunctions
						.openToast(error.message, 3000, "error");
				}
			)
	}

	getData() {
		this.http.getData("reports/dashboard/charts" + this.include_center)
			.subscribe(
				(success) => {
					success = success;
					this.dashboard_figures = success;
					setTimeout(() => {
						if (this.show_chart) {
							// this.formCharts();
						}
						this.getTasks(0);
					}, 200)
				}, (error) => {
					this.generalFunctions
						.openToast(error.message, 3000, "error");
				}
			)

	}

	getTasks(tasksOrderId: number) {
		this.tasks_order_id = this.task_class_id = tasksOrderId;

		this.prospect_tasks_incomplete = null;

		this.http.getData("reports/dashboard/charts" + this.include_center)
			.subscribe((success) => {

				success = success;
				this.dashboard_figures = success;

			});


		if (this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data.length > 0) {
			this.prospect_tasks_incomplete = this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data;
		}
	}

	openTaskEditPopup(taskAction, taskId, taskType, taskRemind, taskComment, taskClient, prospectId, prospectName,prospectContact) {

		this.Popup.openTaskEditPopup(taskAction, taskId, taskType, taskRemind, taskComment, taskClient, prospectId, prospectName, prospectContact);
		this.prospect_id = prospectId;
		this.prospect_name = prospectName;

	}

	getStaff() {
		this.http.getData("staff/dropdown" + this.include_center)
			.subscribe(
			(success) => {
				success = success;
				this.staff_list = success.data;
				this.task_data["client_id"] = JSON.parse(localStorage.getItem("currentUser"))["client_id"];
			},
			(err) => {
				this.generalFunctions.openToast(err.message, 3000, "error");
			}
			)
	}


	validateTaskObject(obj) {
		if (!obj["remind_on"]) {
			this.generalFunctions.openToast("Tell us the time to remind you!", 2000, "error");
			return false;
		}
		if (!obj["client_id"]) {
			this.generalFunctions.openToast("Select a staff to assign!", 2000, "error");
			return false;
		}
		return true;
	}

	updateTask(taskObj?) {
		var obj = JSON.parse(JSON.stringify(taskObj));
		var valid = this.validateTaskObject(obj);
		if (!valid) {
			return false;
		}
		if (obj["client_id"] == 'none') {
			delete obj["client_id"];
		}


		var taskReminder = this.generalFunctions.convertDateToISOFormat(obj["remind_on"])
		obj["remind_on"] = taskReminder["date"] + ' ' + taskReminder["time"];


		this.http.updateData("contact/" + this.prospect_id + '/task/' + obj["id"] + this.include_center, obj)
			.subscribe(
			(success) => {

				//  Api call again to ease out complex process of sorting as tasks are coming inside today,
				// tomorrow and overdue

				this.http.getData("reports/dashboard/charts" + this.include_center)
					.subscribe((success) => {

						success = success;

						this.dashboard_figures["tasks"]["overdue"].data = success["tasks"]["overdue"].data;

						this.dashboard_figures["tasks"]["today"].data = success["tasks"]["today"].data;

						this.dashboard_figures["tasks"]["tomorrow"].data = success["tasks"]["tomorrow"].data;


						if(this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data.length > 0)
						{
							this.prospect_tasks_incomplete = this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data;
						}
						else
						{
							this.prospect_tasks_incomplete = null;
						}

					},
					(err) => {
						this.generalFunctions.openToast(err.message, 3000, "error");
					});


				this.generalFunctions.openToast("Task is succesfully updated!", 3000, "success");
			},
			(err) => {
				this.generalFunctions.openToast(err.message, 3000, "error");
			}
			);

	}

	deleteTask(taskObj?) {


		var obj = JSON.parse(JSON.stringify(taskObj));
		var taskId = obj["id"];
		this.http.deleteData("contact/" + this.prospect_id + '/task/' + taskId + this.include_center)
			.subscribe(
			(success) => {
				success = success;

				this.http.getData("reports/dashboard/charts" + this.include_center)
					.subscribe((success) => {
						success = success;

						this.dashboard_figures["tasks"]["overdue"].data = success["tasks"]["overdue"].data;

						this.dashboard_figures["tasks"]["today"].data = success["tasks"]["today"].data;

						this.dashboard_figures["tasks"]["tomorrow"].data = success["tasks"]["tomorrow"].data;

					    if(this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data.length > 0)
						{
							this.prospect_tasks_incomplete = this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data;
						}
						else
						{
							this.prospect_tasks_incomplete = null;
						}

					},
					(err) => {
						this.generalFunctions.openToast(err.message, 3000, "error");
					});


				//this.resetPopup();
				this.generalFunctions.openToast("Task is succesfully deleted!", 3000, "success");
			},
			(err) => {
				this.generalFunctions.openToast(err.message, 3000, "error");
			}
			)

	}
	resetPopup() {
		this.popup = false;
		this.popup_action = null;
		this.popup_for = null;
		this.add_task_in_stage = false;
		this.add_task_in_comment = false;
		this.task_data["id"] = null;
		this.task_data["type"] = 'phone';
		this.task_data["remind_on"] = null;
		this.task_data["comment"] = null;
		this.task_data["client_id"] = JSON.parse(localStorage.getItem("currentUser"))["client_id"];
	}

	markTaskComplete(taskId, prospectId, schedule) {
		this.http.patchData("contact/" + prospectId + '/task/' + taskId + this.include_center, null)
			.subscribe(
			(success) => {

				success = success;

				//Filtering out current dashboard tasks from array.
				this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data =

					this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data.filter((item, index) => {

						return item.uuid !== taskId;

					});
				//Filtering out current dashboard tasks from overdue tasks as well if today task is completed
				if (this.tasks_order_id == 1) {
					this.dashboard_figures["tasks"][this.tasks_order[(this.tasks_order_id - 1)]].data =

						this.dashboard_figures["tasks"][this.tasks_order[(this.tasks_order_id - 1)]].data.filter((item, index) => {

							return item.uuid !== taskId;

						});
				}

				this.prospect_tasks_incomplete = this.dashboard_figures["tasks"][this.tasks_order[this.tasks_order_id]].data;

			},
			(err) => {
				this.generalFunctions.openToast(err.message, 3000, "error");
			}
			)
	}
	formCharts() {
		var colorList1 = ['#43a5ae', '#b1e1e6', '#fadaa3'],
			itemStyle1 = {
				normal: {
					color: function(params) {
						if (params.dataIndex >= 0) {
							return colorList1[params.seriesIndex];
						}
					},
					barBorderRadius: 2
				}
			},
			color1 = {
				lineStyle: {
					color: "rgba(0,0,0,0.2)"
				}
			},
			color2 = {
				textStyle: {
					color: "rgba(0,0,0,0.38)"
				}
			},
			yaxisObj = [{
				type: 'value',
				axisLine: color1,
				axisLabel: color2,
				axisTick: color1,
				splitLine: {
					lineStyle: {
						color: "rgba(255,255,255,1)"
					}
				}
			}],
			gridObj = {
				x: 30,
				y: 10,
				y2: 30,
				x2: 20
			},
			tooltipObj = {
				trigger: 'axis',
				backgroundColor: 'rgba(0,0,0,0.6)',
				axisPointer: {
					type: 'shadow'
				},
				formatter: function(params) {
					var res = '<div style="color:#eee">';
					res += '<strong>' + params[0].name + '</strong>'
					for (var i = 0, l = params.length; i < l; i++) {
						res += '<br/><span style="color:' + colorList1[i] + '">' + params[i].seriesName + ' : ' + params[i].value + '</span>';
					}
					res += '</div>';
					return res;
				}
			},
			optionHeading = {
				tooltip: tooltipObj,
				toolbox: {
					show: false
				},
				calculable: false,
				legend: {
					x: 'right',
					data: ['New', 'Renewal', 'Total'],
					itemWidth: 16,
					itemHeight: 10
				},
				grid: {
					x: 30,
					y: 30,
					y2: 30,
					x2: 0
				},
				xAxis: [{
					type: 'category',
					// data: monthArray,
					axisLine: color1,
					axisLabel: color2
				}],
				yAxis: yaxisObj,
				series: [
					{
						name: 'New',
						type: 'bar',
						itemStyle: itemStyle1,
						// data:  newCArray,
						barMaxWidth: 10
					},
					{
						name: 'Renewal',
						type: 'bar',
						itemStyle: itemStyle1,
						// data: renewCArray,
						barMaxWidth: 10
					},
					{
						name: 'Total',
						type: 'bar',
						itemStyle: itemStyle1,
						// data: totalCArray,
						barMaxWidth: 10
					}
				]
			};

		var weekData = this.dashboard_figures["revenue"]["weekly"];
		var weekArray = [];
		var weekRevenueArray = [];

		weekData.forEach(function(item, index) {
			weekArray.push(item["week"].split("-")[1]);
			weekRevenueArray.push(item["amount"]);
		});

		var weeklyChartDiv = this.weekly_chart.nativeElement;
		var weeklyChart = echarts.init(weeklyChartDiv);
		var itemStyle2 = {
			normal: {
				color: "#00b898",
				barBorderRadius: 2
			}
		},
			optionWeekly = {
				tooltip: tooltipObj,
				toolbox: {
					show: false
				},
				calculable: true,
				grid: {
					x: 50,
					y: 10,
					x2: 20,
					y2: 20
				},
				xAxis: [{
					type: 'category',
					data: weekArray,
					axisLine: color1,
					axisLabel: color2
				}],
				yAxis: yaxisObj,
				series: [{
					name: 'Revenue',
					type: 'bar',
					itemStyle: itemStyle2,
					data: weekRevenueArray,
					barMaxWidth: 20
				}]
			};
		weeklyChart.setOption(optionWeekly);

		//Data arrays for monthly data

		var monthData = this.dashboard_figures["revenue"]["monthly"];
		var monthArray = [];
		var monthRevenueArray = [];
		monthData.forEach(function(item, index) {
			monthArray.push(item["month"].split("-")[1]);
			monthRevenueArray.push(item["amount"]);
		});

		var monthlyChartDiv = this.monthly_chart.nativeElement;
		var monthlyChart = echarts.init(monthlyChartDiv),
			optionMonthly = {
				tooltip: tooltipObj,
				toolbox: {
					show: false
				},
				calculable: false,
				grid: {
					x: 50,
					y: 10,
					x2: 20,
					y2: 20
				},
				xAxis: [{
					type: 'category',
					data: monthArray,
					axisLine: color1,
					axisLabel: color2
				}],
				yAxis: yaxisObj,
				series: [{
					name: 'Revenue',
					type: 'bar',
					itemStyle: itemStyle2,
					data: monthRevenueArray,
					barMaxWidth: 20
				}]
			};
		monthlyChart.setOption(optionMonthly);
	}

	moveToStepTwo() {

		var msg;
		if (!this.client.name) {
			msg = "Kindly, enter youre studio name!";
		}
		if (!this.client.domain_prefix) {
			msg = "Kindly, enter website url";
		}
		if (!this.client.branch) {
			msg = "Kindly, enter branch name";
		}
		if (!this.client.address) {
			msg = "Kindly, enter address of the studio!";
		}
		if (!this.client.city) {
			msg = "Kindly, enter city name!";
		}
		if (!this.client.state) {
			msg = "Kindly, enter state name!";
		}
		if (!this.client.pincode) {
			msg = "Kindly, enter pincode!";
		}
		// if (!document.getElementById('country').classList.contains('ng-dirty')) {
		// 	msg = "Kindly, select your country!";
		// }

		if (msg) {
			this.onboarding_step = 1;
			this.generalFunctions.openToast(msg, 3000, "error");
			return false;
		}

		this.step_one_done = true;
		this.onboarding_step = 2;
		return true;
	}

	verifyPin(e) {
		this.generalFunctions.isFilled(e);
		if (e.target.classList.contains("valid")) {
			var pin = this.client.pincode;
		}
	}

	sendOTP(e) {
		this.generalFunctions.isFilled(e);
		var el = e.target;
		if (e.target.classList.contains('valid') && this.country) {
			this.requestOTP();
		} else {
			this.show_otp_field = false;
		}
	}

	requestOTP() {
		var phone = this.client.phone;
		this.http.getData("otp/request/?phone=" + phone)
			.subscribe(
			(success) => {
				this.show_otp_field = true;
				this.generalFunctions
					.openToast(success.message, 3000, "success");

			}
			)
	}

	resendOTP() {
		if (this.show_otp_field) {
			this.requestOTP();
		}
	}

	confirmOTP(e) {
		this.generalFunctions.isFilled(e);
		if (this.otp.nativeElement.classList.contains("valid")) {
			var obj = {};
			obj["phone"] = this.client.phone;
			obj["otp"] = e.target.value;
			this.http.sendData("otp/verify", obj)
				.subscribe(
				(success) => {
					this.generalFunctions
						.openToast(success.message, 3000, "success");
					this.otp_validated = true;
				}, (error) => {
					this.generalFunctions
						.openToast(error.message, 3000, "error");
				}
				)
		}

	}

	startTrial(e) {
		var msg;

		if (!this.client.phone) {
			msg = "Kindly, enter your phone no!";
		}
		if (this.show_otp_field) {
			if (!this.otp_validated) {
				setTimeout(() => {
					this.phone.nativeElement.dispatchEvent(new Event("input"));
				}, 20)
			}
			if (!this.client.sender_id) {
				msg = "Kindly enter sender ID!";
			}
			if (this.sender_id.nativeElement.classList.contains("invalid")) {
				msg = "Kindly enter valid 6 characters long sender ID with only letters!";
			}
		}

		if (msg) {
			this.onboarding_step = 2;
			this.generalFunctions.openToast(msg, 3000, "error");
			return false;
		}

		e.target.classList.add("loading-ajax");
		this.ajax_sreen.nativeElement
			.classList.add("active");

		this.http.sendData("setup/initial", this.client)
			.subscribe(
			(success) => {
				var center_id = success.data.id;
				var user = JSON.parse(localStorage.getItem("currentUser"))
				user.center_id = center_id;
				localStorage.removeItem("currentUser");
				localStorage.setItem("currentUser", JSON.stringify(user));
				localStorage.setItem("localization", JSON.stringify({
					timezone: this.localTimeObj,
					currency: this.currencyObj,
					country: this.countryObj
				}));
				this.generalFunctions
					.openToast("Center successfully added!", 2000, "success");
				setTimeout(() => {
					location.reload()
				}, 1000)
			}, (error) => {
				this.generalFunctions
					.openToast(error.message, 3000, "error");
				e.target.classList.remove("loading-ajax");
				this.ajax_sreen.nativeElement
					.classList.remove("active");
				if (error.status_code == 403) {
					localStorage.removeItem("currentUser");
					this.router.navigate(['login']);
				}
			}
			)

	}



}
